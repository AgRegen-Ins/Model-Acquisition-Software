# Community Model Acquisition Toolkit v1.1.4

Image generation/editing expansion from the supplied v1.1.3 baseline. See [image quickstart](docs/IMAGE-QUICKSTART-v1.1.4.md), [catalog, sizes and profiles](docs/IMAGE-CATALOG-v1.1.4.md), and [licenses/runtime limitations](docs/IMAGE-MODELS-v1.1.4.md). 68 historical entries remain unchanged. 27 image variants and 59 shared/support components are added; WAI is explicitly unresolved. Manual XLSX gains appended dependency, license and hardware columns. No acquisition/storage internals changed. `all` adds about 618.89GB; explicit review and existing large-download safeguards remain required.

## Retained prior documentation

# Community Model Acquisition Toolkit v1.1.3

Educational assessment acquisition: eight typed artifacts from AiAWE, AutoSCORE, ArguLens and the Phi essay evaluator. See [component catalog](docs/v1.1.3/COMPONENT_CATALOG.md), [Ubuntu quickstart](docs/v1.1.3/OPERATOR_QUICKSTART.md), [change report](docs/v1.1.3/CHANGE_REPORT.md) and [qualification](docs/v1.1.3/VALIDATION_REPORT.md). All previous functionality remains available. The following retained documentation includes historical release details.

# Community Model Acquisition Toolkit v1.1.2

Correct the simulated ext4 recovery-directory ownership fixture for ordinary-user test runs. Production scanner and acquisition code are unchanged. See [v1.1.2 change report](docs/v1.1.2/CHANGE_REPORT.md). Write-enabled production activation remains pending operator authorization.

# v1.1.1 maintenance release

Fix inventory and read-only archive comparison at an ext4 filesystem root: exclude only a confirmed conventional filesystem `lost+found` recovery directory. Exclusions are reported explicitly; other permission errors remain errors. All catalog entries, storage identity checks and acquisition behavior are unchanged. See [v1.1.1 maintenance notes](docs/v1.1.1/CHANGE_REPORT.md) for qualification and acceptance instructions.

# Community Model Acquisition Toolkit v1.1.0

Dedicated-storage release based on **v1.0.4.8.1**. The supplied installation
now defaults to `/srv/ai-models` and requires its configured filesystem UUID
before all supported archive write workflows. The old model archive is read-only
in the supplied settings. Catalog and preservation-policy content are unchanged.

Start with [Ubuntu installation](docs/v1.1.0/INSTALL_UBUNTU.md), then the
[Edmund-Library cutover guide](docs/v1.1.0/CUTOVER_EDMUND_LIBRARY.md).
Use [operator quickstart](docs/v1.1.0/OPERATOR_QUICKSTART.md) for current commands
and [storage limitations](docs/v1.1.0/STORAGE_DESIGN_AND_LIMITATIONS.md) for
qualification boundaries. `model_report.py --output NEW.xlsx` exports the
catalog and actual manifest states; `compare_archives.py` supplies a read-only
checksum comparison. Neither certifies that production migration has passed.

The material below is retained release history. Older storage-path examples
are historical; follow the v1.1.0 instructions above for this installation.

---

# Community Model Acquisition Toolkit v1.0.4.8.1

Fix legitimate underscore-prefixed payload paths such as `__init__.py` while retaining strict managed identifiers and path-security checks. Clarify final-reporting failures without changing acquisition results. All 60 model entries and profiles unchanged. See [path fix](docs/PATH_VALIDATION_FIX_V10481.md), [Ubuntu acceptance](docs/UBUNTU_ACCEPTANCE_V10481.md), and [release report](docs/RELEASE_REPORT_V10481.md).

# Community Model Acquisition Toolkit v1.0.4.8

Add five Q4_K_M refusal-reduced inference variants; all 55 historical entries and named profiles preserved. GPT-OSS uses two raw parts from the authorized public mradermacher alternative. Acquisition behavior unchanged. See [model manifests and resources](docs/LARGE_REFUSAL_REDUCED_MODELS_V1048.md), [Ubuntu commands](docs/UBUNTU_ACCEPTANCE_V1048.md), [benchmark plan](docs/MODEL_BENCHMARK_PLAN_V1048.md), and [release notes](docs/RELEASE_REPORT_V1048.md).

# Community Model Acquisition Toolkit 1.0.4.7

**v1.0.4.7:** adds exactly two Huihui-derived Q4_K_M GGUF variants: `huihui-glm-4-7-flash-abliterated-gguf-q4-k-m` and `huihui-qwen3-32b-abliterated-gguf-q4-k-m`. All 53 prior entries, policies and named-profile selections are preserved. Select individually with `--model`; no new profiles. Both are community modifications and third-party conversions, not official Z.ai/Qwen releases. [Exact sources, lineage and limitations](docs/HUIHUI_MODELS_V1047.md) · [Ubuntu instructions](docs/UBUNTU_ACCEPTANCE_V1047.md) · [release report](docs/RELEASE_REPORT_V1047.md).

**v1.0.4.6 — two-model reasoning GGUF release:** adds only `qwen3-next-80b-a3b-thinking-gguf-q6-k` (official Qwen Q6_K) and `glm-4-5-air-gguf-q4-k-m` (ggml-org Q4_K_M). Based exclusively on the verified v1.0.4.5 ZIP. All 51 existing entries and old profile selections remain unchanged; no new profiles. Select these variants with `--model`, or through the naturally expanded `all` profile. [Exact artifacts and runtime notes](docs/REASONING_GGUF_V1046.md) · [Ubuntu acquisition/verification](docs/UBUNTU_ACCEPTANCE_V1046.md) · [release validation](docs/RELEASE_REPORT_V1046.md).

**v1.0.4.5:** adds only `gpt-oss-120b-gguf-mxfp4` and `gpt-oss-120b-local-inference`. The original remains unchanged. [Artifact details](docs/GPT_OSS_120B_GGUF.md) · [HP benchmark preparation](docs/HP_GPT_OSS_120B.md) · [Ubuntu acceptance](docs/UBUNTU_ACCEPTANCE_V1045.md).

**v1.0.4.4 historical additions:** adds OpenScholar 8B and ether0 24B canonical sources plus one Q4_K_M GGUF each. All 46 prior entries and profiles are preserved; no acquisition/registry code changes. [Scientific model list and exact pins](docs/SCIENTIFIC_MODELS.md) · [four opt-in profiles](docs/SCIENTIFIC_PROFILES.md) · [HP runtime notes](docs/HP_SCIENTIFIC_DEPLOYMENT.md) · [software roadmap](docs/SCIENTIFIC_SOFTWARE_ROADMAP.md) · [Ubuntu acceptance](docs/UBUNTU_ACCEPTANCE_V1044.md).

**v1.0.4.3 historical additions:** multimodal inference selections, explicit component dependencies, tiered preservation-policy metadata, and a separate non-destructive cross-project registry/accountability CLI. All 38 previous model entries and historical profile selections remain unchanged. [Ubuntu acceptance](docs/UBUNTU_ACCEPTANCE.md) · [new models](docs/MULTIMODAL_ADDITIONS.md) · [registry](docs/CROSS_PROJECT_REGISTRY.md) · [policy](docs/PRESERVATION_POLICY.md) · [exports](docs/ACCOUNTABILITY_INVENTORY.md).

A standalone Python toolkit for acquiring and preserving AI models for the Community Library. It does not change or depend on the book/article acquisition toolkit. **No model weights are included in this ZIP.**

The sequence is: choose a model root → select variants → inspect the size/revision plan → confirm → download → verify → catalog/report. Model files are never loaded or executed.

## Start on Ubuntu

Python **3.10 or newer** is required (Ubuntu 24.04 includes a suitable Python). Keep the application on your internal drive and put its downloaded models on the mounted external drive.

1. Download `community-model-acquisition-v1.0.4.7.zip` and its SHA-256 sidecar into Downloads. Extract into a fresh directory; do not merge releases.
2. Open Terminal and run:

```bash
sudo apt update
sudo apt install python3-venv python3-pip unzip
cd ~/Downloads
sha256sum -c community-model-acquisition-v1.0.4.7.zip.sha256
unzip community-model-acquisition-v1.0.4.7.zip
cd community-model-acquisition
bash setup-linux.sh
```

The setup script **asks for the full model root every time it runs**. For your server, enter:

```text
/srv/community-library/models
```

The shipped `settings.json` requires `/srv/community-library` to be mounted when the root is `/srv/community-library/models` or a descendant on POSIX systems. Setup and real acquisition abort if it is absent. Windows skips this POSIX-only rule. For another location, edit `settings.json` or provide `--expected-mount /your/mount`; no path is hard-coded in the implementation.

Before setup or downloading, confirm the external drive is mounted:

```bash
findmnt /srv/community-library
```

You should see the external disk mounted there. If nothing is shown, stop and mount the drive first; otherwise files could fill the internal disk beneath an empty mount point.

First inspect the smallest profile:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile small-cpu --dry-run
```

Then acquire it, with an interactive confirmation:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile small-cpu
```

This profile is approximately **3.61 GB**, containing official Q4_K_M GGUF variants of Qwen3-4B and Qwen2.5-Coder-1.5B-Instruct. It is a sensible first acquisition for learning on your Dell. Actual speed depends on the runtime and context size; downloadability is not a performance guarantee.

For the menu, omit the profile:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models
```

If `--root` is omitted, an interactive terminal prompts for it. The program always displays the selected root, and does not silently reuse a previously saved path. Noninteractive use must supply it explicitly.

## Preservation expansion in v1.0.4

Eleven new variants cover GLM-5.3-Flash, Mistral Small 4, MiniMax-M3, Kimi-K2.7-Code and full GLM-5.3. Canonical/source checkpoints, official deployment quantizations and third-party GGUFs remain distinct. These are future-hardware archives, not 32 GB Dell models. GLM-5.3-Flash GGUF requires a converter-compatible experimental runtime.

See [the exact new models, commits, sizes, precision and runtime notes](docs/PRESERVATION_ADDITIONS.md), [new profile memberships](docs/PROFILES.md), and [provenance and customization caveats](docs/PROVENANCE.md). All 25 prior model entries and prior profile memberships remain unchanged.

## Profiles

The exact catalog and sizes are in [docs/CATALOG.md](docs/CATALOG.md). Profiles select **variants**, not necessarily distinct base models.

| Profile | Contents / purpose |
|---|---|
| `small-cpu` | Qwen3 4B + Qwen Coder 1.5B official Q4_K_M |
| `dell` | Qwen3 4B, 8B, 14B + Coder 1.5B, 7B Q4_K_M; BGE embedding/reranking |
| `coding-local` | Q4_K_M Coder 1.5B, 7B, 14B (official) + 30B-A3B (Unsloth third-party); about 33.34 GB, menu coding choice |
| `coding-archive` | Original coding weights, including 14B, 30B-A3B, Next, GLM and 480B (about 1.29 TB) |
| `coding` | Explicit selection of ALL coding variants, including enormous archives |
| `retrieval` | BGE-M3 and BGE-reranker-v2-m3 |
| `future` | Original-weight LLM archives and Qwen3 32B GGUF |
| `dell-upper-tier` | Exactly Qwen3-32B Q4_K_M + gpt-oss-20b MXFP4 + GLM-4.7-Flash Q4_K_M; about 50.18 GB |
| `agentic-core-originals` | Five new canonical sources; about 3.84 TB |
| `agentic-core-runnable` | Five primary inference variants; about 1.77 TB; Flash GGUF experimental |
| `research-agent` | Four research-oriented inference variants; about 1.18 TB |
| `coding-agent` | Kimi, GLM Flash and Mistral inference variants; about 856 GB |
| `preservation-source-weights` | 21 canonical/upstream variants; about 5.49 TB; explicit opt-in |
| `coding-workstation` | 30B Q4_K_M + Next Q6_K; 84.17 GB; future 96 GB aggregate VRAM target |
| `all` | All 46 configured variants; multiple terabytes |

The 14B GGUF is a technically feasible but potentially slow Dell experiment; start at 4B or 8B. Retrieval models can run on CPU with a suitable runtime, but batch size matters. Profiles do not launch models together. Original weights of gpt-oss and other large models are archived separately from the current Dell collection. The term “original” means the publisher's native files, which may already use reduced precision, such as MXFP4.

## Dell upper-tier additions in v1.0.3

Added `gpt-oss-20b-gguf-mxfp4` from **ggml-org** (~12.11 GB, Apache-2.0) and `glm-4-7-flash-gguf-q4-k-m` from **Unsloth** (~18.31 GB, MIT). Both are labeled `third-party-derived`; they are not original OpenAI or Z.ai publisher weights. The original variants remain available.

The new `dell-upper-tier` profile contains exactly those two variants and the existing `qwen3-32b-gguf-q4-k-m` (~19.76 GB). No giant archival models are included. Other profile memberships remain unchanged; the Qwen entry only gains the requested new profile tag. This profile is available through `--profile dell-upper-tier` without changing the existing menu.

For the i7-8700 / 32 GB CPU-only Dell, run **one model at a time**, initially with a **4096-token runtime context**. This toolkit downloads files; it does not set runtime context or launch models. MoE active-parameter counts are not the total weight-memory requirement. gpt-oss is a high-interest reasoning/research candidate, but a model alone does not supply web research or library retrieval tools. CPU performance has not been benchmarked.

Dry runs:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model gpt-oss-20b-gguf-mxfp4 --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models --model glm-4-7-flash-gguf-q4-k-m --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile dell-upper-tier --dry-run
```

Acquire one at a time, or the entire profile:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model gpt-oss-20b-gguf-mxfp4
.venv/bin/python model_acquire.py --root /srv/community-library/models --model glm-4-7-flash-gguf-q4-k-m
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile dell-upper-tier
```

Choose the command you want; there is no need to run all three. The profile total is just above the existing 50 GB confirmation threshold, so the additional `LARGE` confirmation remains in effect even if some files already exist. Dry-run displays total, estimated new files, free space and required space with reserve. Matching recorded completed files reduce the estimated-new amount; full verification and reuse still happen during acquisition.

See [source selection, hardware and runtime notes](docs/DELL_UPPER_TIER.md) for exact filenames, pinned revisions, Harmony formatting and GLM runtime considerations.

## Higher-tier coding additions in v1.0.2

- **Qwen2.5-Coder-14B-Instruct:** official original BF16 Safetensors and official Q4_K_M GGUF, approximately 29.55 GB and 8.99 GB respectively.
- **Qwen3-Coder-30B-A3B-Instruct:** official original BF16 Safetensors (61.08 GB), plus **third-party Unsloth Q4_K_M GGUF** (18.56 GB). No publicly accessible official Qwen GGUF was found at review. The GGUF publisher is Unsloth, not Qwen.

Both quantized entries belong to `coding` and `coding-local`. Both original entries belong to `coding`, `coding-archive`, and `future`. Existing `dell` and `small-cpu` profiles and all previous model entries are unchanged. The menu's coding-local selection now includes four variants, so review its expanded size before downloading.

The Qwen3 coder has 30.5B total / 3.3B active parameters. Its full quantized weights still need memory. For a 32 GB Dell, use **one model/session at a time and start with 4096-token context**, leaving RAM for Ubuntu and runtime buffers. Native 262,144-token context is not a practical target on this machine. These are short-context feasibility estimates, not measured Dell performance. See [verified details and memory estimates](docs/CODING_ADDITIONS.md).

Preview the 14B coder:

```bash
.venv/bin/python model_acquire.py \
  --root /srv/community-library/models \
  --model qwen2-5-coder-14b-instruct-gguf-q4-k-m --dry-run
```

Preview the third-party 30B-A3B coder:

```bash
.venv/bin/python model_acquire.py \
  --root /srv/community-library/models \
  --model qwen3-coder-30b-a3b-instruct-gguf-q4-k-m --dry-run
```

Remove `--dry-run` to acquire after confirmation. For originals use `qwen2-5-coder-14b-instruct-original` or `qwen3-coder-30b-a3b-instruct-original` instead. No runtime installation or automatic model execution is added.

## Common commands

Show the Dell download plan (network metadata, no weights):

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile dell --dry-run
```

Use bundled estimates without a network connection or root writes:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile dell --offline-plan
```

Download an individual variant:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model qwen3-8b-gguf-q4-k-m
```

Resume after Ctrl+C, reboot, or network failure: **rerun the same command**. Completed files are hash-checked and skipped; Hugging Face manages reusable partial transfers. Do not delete `.cache/huggingface` inside the revision's payload folder while a download is incomplete.

Storage inventory (read-only, includes every on-disk revision, even if removed from the catalog):

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --sort size
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --superseded
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format csv > model-inventory.csv
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format json > model-inventory.json
```

CSV/JSON stdout contains only the export; the root notice goes to stderr. `>` saves the output to the file named after it. Group sorting keeps revisions of a variant together; `--sort size` puts the largest group first and its largest revision first. Filtered output still reports collection-wide summary totals. Inventory does not modify weights, manifests, or report files. During an active external writer its read-only snapshot may change; use the automatically generated reports for a snapshot made under the toolkit lock.

After each completed acquisition/repair and after verification, all three current reports are refreshed automatically under `_toolkit/inventory/current-inventory.{txt,csv,json}`. Normal status and handled interrupted/failed runs refresh them too. No report deletes anything. If a process is killed abruptly, these files may be stale; `--inventory` always scans anew.

See [storage and mount details](docs/STORAGE.md) for precise current/superseded definitions, disk accounting and recovery-estimate limitations.

Quick status and reports:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --status
```

Full offline integrity audit (reads every acquired byte; can take hours on a large HDD):

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --verify
```

Repair a damaged acquisition, preserving damaged files in a `quarantine` directory:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model qwen3-8b-gguf-q4-k-m --repair
```

Check upstream branches without replacing local revisions:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --status --check-updates
```

Inspect/download a newer revision while retaining the old one:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model qwen3-8b-gguf-q4-k-m --latest --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models --model qwen3-8b-gguf-q4-k-m --latest
```

The shipped catalog pins reviewed commit hashes. `--latest` explicitly resolves the tracking branch instead. If a newer revision stops matching configured filenames, the plan fails; inspect and edit the catalog rather than assuming compatibility.

For deliberate unattended downloads, `--yes` accepts the displayed plan. Plans totaling **50 GB or more** additionally require `--allow-large`. Without `--yes`, large plans require typing `LARGE`. There is no insufficient-space override: retain at least the estimated new size plus 10% and 1 GiB; repair reserves additional replacement space. Cache use and unknown files can still consume extra space; monitor the disk.

## What is preserved

```text
MODEL_ROOT/
  chat/<variant-id>/<full-commit>/
    payload/                 upstream files, including README/license when present
    manifest.json            selection, provenance, sizes, per-file SHA-256/evidence
    repository.json          Hugging Face metadata captured at acquisition
    quarantine/              only created during repair/invalid completed transfer
  coding/...                 same layout
  reasoning/...
  retrieval/...
  reranking/...
  _toolkit/
    logs/events.jsonl
    reports/<timestamp>.json
    reports/<timestamp>.txt
    inventory/current-inventory.txt
    inventory/current-inventory.csv
    inventory/current-inventory.json
    collection.lock
```

The category set is open-ended. Nothing automatically deletes older revisions, unknown files, or quarantined material. Back up the complete model root, including manifests. Read the full [operator guide](docs/OPERATOR_GUIDE.md) and [architecture](docs/ARCHITECTURE.md).

## Windows

Install Python 3.10+ with the `py` launcher and unzip the package. In **PowerShell**, change into the extracted folder and run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\setup-windows.ps1
```

The process-only execution setting does not permanently change your policy. Setup prompts for a root, such as `E:\Community Library\models`.

```powershell
.\.venv\Scripts\python.exe model_acquire.py --root "E:\Community Library\models" --profile small-cpu --dry-run
.\.venv\Scripts\python.exe model_acquire.py --root "E:\Community Library\models" --profile small-cpu
```

Use a short root on NTFS for long filenames. Do not use FAT32 (its individual file limit is too small for many models). Windows scripts are supplied, but were not executed on an actual Windows host during this build.

## Authentication

Public repositories normally need no account. For a gated/private repository, open its Hugging Face page, accept any required terms, and request access. Then use the official CLI:

```bash
.venv/bin/hf auth login
```

Paste the token into its prompt, not a command saved to shell history. The toolkit uses Hugging Face's credential handling or `HF_TOKEN`; it never writes a token to the catalog, manifest, or toolkit logs. The upstream credential store is not an encrypted vault; protect your OS account. Do not place credentials in repository identifiers or revision fields. Network exception details are suppressed in toolkit reports to avoid leaking tokens or signed URLs.

## Tests

```bash
.venv/bin/python -m unittest discover -s tests -v
```

See `docs/VALIDATION.md` for the actual build results and scope. No multi-GB model download is required by the tests.

## Limitations

- Acquisition and byte integrity only; no runtime, inference quality, or hardware benchmark validation.
- Hugging Face is the implemented adapter. Adding an ordinary model is a catalog edit; other providers require another adapter.
- Setup needs internet for dependencies. This ZIP is not yet an air-gapped Python/runtime installation bundle.
- Quick status checks recorded sizes/timestamps; only `--verify` proves current bytes still match recorded hashes. A clean verified record does not mean the model was tested in a runtime.
- Hashing costs disk I/O. Reruns read complete files to avoid unnecessary redownloads; they do not blindly trust filenames.
- Actual wire-transfer byte counts are not exposed reliably by the upstream downloader. Logs record completed file bytes and `wire_bytes: null`, not invented network totals.
- The mount guard checks mount presence, not device UUID/identity, and cannot guarantee safety if storage disappears after a check. Keep the drive connected during writes.
- Inventory counts regular files; directory overhead, filesystem snapshots/compression and shared extents may affect actual freed space. Hard-linked files are excluded from the conservative recoverable estimate.
- Root locking protects cooperating toolkit processes on one filesystem; network-share locking semantics are platform-dependent. Prefer the directly attached ext4 drive.
- No automatic dependency updates, weight conversion, license acceptance, cleanup, or model serving. Upstream licenses/cards remain authoritative.

## New archive profile examples

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile agentic-core-originals --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile agentic-core-runnable --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile preservation-source-weights --dry-run
```

After reviewing space and runtime needs, remove `--dry-run` for interactive confirmation. For unattended large downloads, both `--yes --allow-large` are required. The broad source profile is never implied by another profile. No pruning or deletion is added.

The existing `coding` profile retains its v1.0.3 membership; it is not an automatic category query. Use `coding-agent` for the newly added agent models.

## Qwen3-Coder-Next workstation tier

| ID | Purpose | Selected decimal GB |
|---|---|---:|
| `qwen3-coder-next-original` | Official canonical BF16 source for preservation/customization | 159.376 |
| `qwen3-coder-next-gguf-q6-k` | Third-party Unsloth Q6_K, all three GGUF shards | 65.614 |

`coding-workstation` selects the existing 30B-A3B Q4_K_M everyday coder plus Next Q6_K as the planned primary workstation coder. The 480B stays archival; this is a deployment hierarchy, not a benchmark ranking. Neither new variant belongs to the Dell profiles. See [runtime, exact artifacts and training caveats](docs/QWEN3_CODER_NEXT.md).

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model qwen3-coder-next-original --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models --model qwen3-coder-next-gguf-q6-k --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile coding-workstation --dry-run
# After reviewing the plan and confirming the storage mount:
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile coding-workstation --yes --allow-large
```

## Multimodal acquisition and accountability

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile multimodal-core --dry-run
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format json
```

Vision includes its matching projector; F5-TTS includes a pinned Vocos dependency. No runtime software or personal voice references are installed/acquired automatically. Expanded inventory is a separate interface; existing `--inventory` remains unchanged.
