# AI Scoring Platform — Automated Essay Scoring (AES)

> An end-to-end pipeline that scores argumentative essays (1–6) and generates
> actionable, label-aware feedback. It combines three modules:
>
> 1. **Discourse-move classifier** — a fine-tuned Qwen2.5-7B LoRA that labels
>    each sentence as *claim / data / counterclaim / rebuttal*.
> 2. **Scorer** — a grade-independent LightGBM model over 31 linguistic and
>    discourse features (TAALED / QuanSyn complexity metrics + move counts).
> 3. **Feedback generator** — always produces English feedback; the default is
>    local Qwen2.5-14B-Instruct through vLLM.

A Gradio web UI ties the three together: paste an essay (or batch-upload
`.txt` files), pick an inference backend, and get a score, confidence,
discourse breakdown, and feedback.

Batch uploads keep a summary table and add a file selector for inspecting each
essay's score, score confidence, all 31 linguistic features, discourse
features, raw classifier output, and feedback independently. A ZIP download
contains one folder per source file with `essay.txt`, `score.json`,
`linguistic_features.json`, `discourse_features.json`, `feedback.md`,
`result.json`, and `sentence_labels.csv`; the root `summary.csv` also contains
the score and all 31 features for every file.

---

## ⚠️ Responsible use

Automated essay scoring can inherit biases from its training data. Persuade 2.0
consists of US middle-school argumentative essays and may not generalize to
other populations or genres. This tool is intended for **research and
assistive** use, not for high-stakes automated decisions without human
oversight.

---

## Architecture

```
essay_score/                # Gradio frontend + orchestration
  app_gradio.py             # UI and pipeline orchestration
  infer/infer_qwen.py       # HF Qwen LoRA discourse-move classifier
  infer/backends.py         # HF / persistent-vLLM backend contract
  infer/vllm_classifier.py  # persistent vLLM LoRA service
  feedback/                 # feedback generation; model selected independently
  scoring_pipeline/         # LightGBM scorer + vendored TextComplexityToolkit
    scorer.py
    TextComplexityToolkit/  # MIT (TAALED / QuanSyn)
    models_full/            # trained LightGBM scorer + scaler
  deploy/adapter/           # LoRA adapter config + tokenizer (your IP; weights published separately)
qwen_move_classifier/        # (optional) LoRA training code + data prep
archive/                     # local-only training data, results, and legacy artifacts
```

Inference backends (selectable in the UI):
- **hf** — local HuggingFace + PEFT classifier loaded in-process.
- **vllm** — persistent HTTP classifier service with the frozen LoRA.
- **api** — OpenAI-compatible alternative backend for the always-generated feedback.

---

## Quick start

```bash
# 1. Create the environment (Python 3.13)
conda create -n essay_score python=3.13
conda activate essay_score
pip install -r requirements.txt

# 2. Download the fixed classifier base (Apache 2.0, NOT included here)
#    huggingface-cli download Qwen/Qwen2.5-7B-Instruct --local-dir /path/to/qwen2.5-7B-instruct
#    and the spaCy model:  python -m spacy download en_core_web_sm

# 3. Configure paths (copy and edit; paths are relative to this file)
cp config.example.yaml config.yaml

# Start feedback vLLM, classifier vLLM, and Gradio in one command.
bash essay_score/run_all_services.sh

# The launcher prints the browser URL and stores service logs in /tmp.
```

See **INSTALL.md** for full details (separate dependency locks, model
integrity checks, vLLM setup, health checks, and HF rollback).

---

## Tests

The repository ships a `tests/` suite that checks configuration wiring, the
scorer contract, the Gradio I/O contract, and the frozen adapter/config/tokenizer
assets.  Install the dev extras and run:

```bash
pip install -r requirements-dev.txt
pytest -q
```

Integration tests that need a live vLLM classifier (e.g.
`test_vllm_classifier_api.py`) are skipped automatically when no service is
reachable, so the suite runs offline.

## Data & licensing

| Asset | License | Distributed here? |
|-------|---------|-------------------|
| Source code / adapter config / scorer | Apache 2.0 | ✅ |
| `adapter_model.safetensors` | release artifact; publish via Git LFS or a download URL before public release | https://github.com/wwrwbs/AI_AWE/releases/download/v0.1.0/adapter_model.safetensors |
| TextComplexityToolkit (TAALED/QuanSyn) | MIT | ✅ (vendored, keep LICENSE) |
| Qwen2.5-7B-Instruct base model | Apache 2.0 | ❌ (download from HF) |
| Persuade 2.0 corpus | academic-use, attribution | ❌ (run `data/prepare_persuade.py`) |
| spaCy `en_core_web_sm` | MIT/CC | ❌ (download) |

Prepare the training/evaluation corpus outside the release tree with:

```bash
python qwen_move_classifier/data/prepare_persuade.py \
  --in /path/to/licensed/persuade_export.json \
  --out /tmp/ai_scoring_platform_data/train.jsonl
```

---

## Third-party software

- **TextComplexityToolkit** (`essay_score/scoring_pipeline/TextComplexityToolkit/`)
  — MIT License, Copyright (c) 2026
  TextComplexityToolkit contributors. Vendored with its `LICENSE` intact. It wraps
  open-source metrics: **TAALED** (Kyle & Crossley, vendored in `src/TAALED/`),
  **QuanSyn** (via `stanza` + `quansyn`), **L2SCA/neosca**, and **spaCy**.
  Closed-source Linguistic Analysis Tools (TAMMI, TAALES, TAASSC) are intentionally
  excluded.

---

## Citation

```bibtex
@misc{ai-scoring-platform,
  title  = {AI Scoring Platform: Automated Essay Scoring with Discourse-Move Classification},
  year   = {2026},
  url    = {https://github.com/<your-org>/ai-scoring-platform}
}
```
Please also cite the underlying resources: **Persuade 2.0**, **TAALED**
(Kyle & Crossley), **QuanSyn**, **Qwen2.5** (Alibaba), **LightGBM**,
**vLLM**, and **Gradio**.

## License

Apache License 2.0 — see [LICENSE](LICENSE).

