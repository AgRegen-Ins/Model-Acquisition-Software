---
language: en
tags:
- phi-3.5
- finetuned
- essay-evaluation
- education
- nlp
license: mit
datasets: private
base_model:
- microsoft/Phi-3.5-mini-instruct
---

# Essay Evaluator - Finetuned Phi-3.5-mini-instruct

This model is a fine-tuned version of microsoft/Phi-3.5-mini-instruct, specifically trained for evaluating student written essays and providing numerical scores on a scale of 1-6.

## Model Description

- **Model Architecture:** Based on Phi-3.5-mini-instruct (3.8B parameters)
- **Training Focus:** Essay evaluation and scoring
- **Input Format:** Essays in English
- **Output Format:** Numerical score (1-6)
- **Fine-tuning Focus:** Holistic essay assessment considering:
  - Content quality
  - Organization
  - Language use

## Intended Use

- **Primary Use:** Automated essay scoring in educational contexts
- **Target Users:** 
  - Educational institutions
  - Teachers
  - Students (for self-assessment)
- **Scope:** English academic essays

## Training Details

- **Base Model:** microsoft/Phi-3.5-mini-instruct
- **Training Type:** Supervised fine-tuning
- **Training Data:** Balanced dataset of scored academic essays
- **Parameters:**
  - Learning rate: 2e-5
  - Epochs: 2
  - Batch size: 1

## Performance and Limitations

### Strengths
- Consistent scoring across similar essays
- Fast evaluation time
- Structured numerical output

### Limitations
- Limited to English language essays
- Should be used as an assistive tool, not a replacement for human grading
- Best suited for students essay formats

## Example Usage

```python
# API request format
headers = {
    "Content-Type": "application/json",
    "Authorization": f"Bearer {API_KEY}"
}

data = {
    "messages": [
        {
            "role": "system",
            "content": "You are an experienced English teacher specializing in grading high school student essays. Read the following essay carefully and provide a holistic score from 1 to 6 based on content, organization, and language use. Provide only the numerical score."
        },
        {
            "role": "user",
            "content": "YOUR_ESSAY_TEXT"
        }
    ]
}