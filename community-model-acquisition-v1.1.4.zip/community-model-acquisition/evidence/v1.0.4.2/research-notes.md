# Supplemental research notes — 2026-10-04 UTC

The pinned official/Unsloth cards and API manifests establish architecture, license, artifact sizes and publisher relationship. The first Q6_K shard header was parsed without reading any weight-bearing shard; its zero tensor count and embedded template are recorded in runtime/gguf-first-shard-metadata.json.

Unsloth's current guide https://unsloth.ai/docs/models/qwen3-coder-next was opened through web retrieval on 2026-10-04. It documents BF16 LoRA for Qwen3-Coder-Next on a B200. This is used only as evidence of an available model-specific adapter workflow, not as evidence that the proposed dual-48-GB workstation can train it. The mutable guide could not be downloaded directly (403); it has no immutable revision asserted. Pinned Transformers source provides separate architecture-specific loss support evidence.

Exact source/derived revisions were fetched before catalog editing and then resolved again in live CLI dry runs. No converter-input commit was asserted. License declarations are preserved in both cards and GGUF metadata; no LICENSE artifact appears in either selected repository snapshot.
