---
base_model: huihui-ai/Huihui-gpt-oss-120b-BF16-abliterated
extra_gated_button_content: Submit
extra_gated_fields:
  X Account(@username): text
extra_gated_prompt: |-
  **Usage Warnings**

  “**Risk of Sensitive or Controversial Outputs**“: This model’s safety filtering has been significantly reduced, potentially generating sensitive, controversial, or inappropriate content. Users should exercise caution and rigorously review generated outputs.
  “**Not Suitable for All Audiences**:“ Due to limited content filtering, the model’s outputs may be inappropriate for public settings, underage users, or applications requiring high security.
  “**Legal and Ethical Responsibilities**“: Users must ensure their usage complies with local laws and ethical standards. Generated content may carry legal or ethical risks, and users are solely responsible for any consequences.
  “**Research and Experimental Use**“: It is recommended to use this model for research, testing, or controlled environments, avoiding direct use in production or public-facing commercial applications.
  “**Monitoring and Review Recommendations**“: Users are strongly advised to monitor model outputs in real-time and conduct manual reviews when necessary to prevent the dissemination of inappropriate content.
  “**No Default Safety Guarantees**“: Unlike standard models, this model has not undergone rigorous safety optimization. huihui.ai bears no responsibility for any consequences arising from its use.
language:
- en
library_name: transformers
license: apache-2.0
mradermacher:
  readme_rev: 1
quantized_by: mradermacher
tags:
- vllm
- unsloth
- abliterated
- uncensored
---
## About

<!-- ### quantize_version: 2 -->
<!-- ### output_tensor_quantised: 1 -->
<!-- ### convert_type: hf -->
<!-- ### vocab_type:  -->
<!-- ### tags:  -->
<!-- ### quants: x-f16 Q4_K_S Q2_K Q8_0 Q6_K Q3_K_M Q3_K_S Q3_K_L Q4_K_M Q5_K_S Q5_K_M IQ4_XS -->
<!-- ### quants_skip:  -->
<!-- ### skip_mmproj:  -->
static quants of https://huggingface.co/huihui-ai/Huihui-gpt-oss-120b-BF16-abliterated

<!-- provided-files -->

***For a convenient overview and download list, visit our [model page for this model](https://hf.tst.eu/model#Huihui-gpt-oss-120b-BF16-abliterated-GGUF).***

weighted/imatrix quants are available at https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-i1-GGUF
## Usage

If you are unsure how to use GGUF files, refer to one of [TheBloke's
READMEs](https://huggingface.co/TheBloke/KafkaLM-70B-German-V0.1-GGUF) for
more details, including on how to concatenate multi-part files.

## Provided Quants

(sorted by size, not necessarily quality. IQ-quants are often preferable over similar sized non-IQ quants)

| Link | Type | Size/GB | Notes |
|:-----|:-----|--------:|:------|
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q3_K_S.gguf.part1of2) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q3_K_S.gguf.part2of2) | Q3_K_S | 66.2 |  |
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q2_K.gguf.part1of2) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q2_K.gguf.part2of2) | Q2_K | 66.3 |  |
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.IQ4_XS.gguf.part1of2) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.IQ4_XS.gguf.part2of2) | IQ4_XS | 67.1 |  |
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q3_K_M.gguf.part1of2) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q3_K_M.gguf.part2of2) | Q3_K_M | 71.2 | lower quality |
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q3_K_L.gguf.part1of2) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q3_K_L.gguf.part2of2) | Q3_K_L | 73.5 |  |
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_S.gguf.part1of2) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_S.gguf.part2of2) | Q4_K_S | 81.0 | fast, recommended |
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf.part1of2) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf.part2of2) | Q4_K_M | 88.0 | fast, recommended |
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q5_K_S.gguf.part1of2) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q5_K_S.gguf.part2of2) | Q5_K_S | 88.1 |  |
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q5_K_M.gguf.part1of2) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q5_K_M.gguf.part2of2) | Q5_K_M | 94.0 |  |
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q6_K.gguf.part1of3) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q6_K.gguf.part2of3) [PART 3](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q6_K.gguf.part3of3) | Q6_K | 124.3 | very good quality |
| [PART 1](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q8_0.gguf.part1of3) [PART 2](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q8_0.gguf.part2of3) [PART 3](https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF/resolve/main/Huihui-gpt-oss-120b-BF16-abliterated.Q8_0.gguf.part3of3) | Q8_0 | 124.4 | fast, best quality |

Here is a handy graph by ikawrakow comparing some lower-quality quant
types (lower is better):

![image.png](https://www.nethype.de/huggingface_embed/quantpplgraph.png)

And here are Artefact2's thoughts on the matter:
https://gist.github.com/Artefact2/b5f810600771265fc1e39442288e8ec9

## FAQ / Model Request

See https://huggingface.co/mradermacher/model_requests for some answers to
questions you might have and/or if you want some other model quantized.

## Thanks

I thank my company, [nethype GmbH](https://www.nethype.de/), for letting
me use its servers and providing upgrades to my workstation to enable
this work in my free time.

<!-- end -->
