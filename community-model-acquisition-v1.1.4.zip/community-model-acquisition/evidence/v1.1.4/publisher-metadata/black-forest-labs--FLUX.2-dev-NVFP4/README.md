---
language:
- en
license: other
license_name: flux-dev-non-commercial-license
license_link: https://huggingface.co/black-forest-labs/FLUX.2-dev/blob/main/LICENSE.txt
extra_gated_prompt: >-
  By clicking "Agree", you agree to the [FLUX [dev] Non-Commercial License
  Agreement](https://huggingface.co/black-forest-labs/FLUX.2-dev/blob/main/LICENSE.txt)
  and acknowledge the [Acceptable Use
  Policy](https://bfl.ai/legal/usage-policy).
tags:
- image-generation
- image-editing
- flux
- diffusion-single-file
pipeline_tag: image-to-image
library_name: diffusers
---

![Teaser](./teaser_generation.png)
![Teaser](./teaser_editing.png)

`FLUX.2 [dev]` is a 32 billion parameter rectified flow transformer capable of generating, editing and combining images based on text instructions.
For more information, please read our [blog post](https://bfl.ai/blog/flux-2).

This repository holds an [NVFP4 version](https://huggingface.co/black-forest-labs/FLUX.2-dev-NVFP4/blob/main/flux2-dev-nvfp4.safetensors) and a [mixed NVFP4/BF16 version](https://huggingface.co/black-forest-labs/FLUX.2-dev-NVFP4/blob/main/flux2-dev-nvfp4-mixed.safetensors) of FLUX.2 [dev]. The mixed version has a small set of weights in BF16. The main repository of this model (full BF16 weights) can be found [here](https://huggingface.co/black-forest-labs/FLUX.2-dev).
