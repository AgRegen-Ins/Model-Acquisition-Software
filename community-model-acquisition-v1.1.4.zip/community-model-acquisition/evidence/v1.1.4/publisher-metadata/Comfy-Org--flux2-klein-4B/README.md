---
license: apache-2.0
tags:
- comfyui
- diffusion-single-file
base_model:
- black-forest-labs/FLUX.2-klein-4B
- black-forest-labs/FLUX.2-klein-base-4B
pipeline_tag: text-to-image
---

# Flux 2 Klein

Repackaged model files for ComfyUI.

Original model repository:

- https://huggingface.co/black-forest-labs/FLUX.2-klein-4B
- https://huggingface.co/black-forest-labs/FLUX.2-klein-base-4B

Place the files in the following folders:

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   ├── flux-2-klein-4b.safetensors
│   │   └── flux-2-klein-base-4b.safetensors
│   ├── 📂 text_encoders/
│   │   ├── qwen_3_4b.safetensors
│   │   └── qwen_3_4b_fp4_flux2.safetensors
│   ├── 📂 vae/
│   │   └── flux2-vae.safetensors
```

## Workflows

<table>
<thead>
<tr><th align="center" valign="middle" style="text-align:center;vertical-align:middle">Workflow</th><th colspan="2" align="center" valign="middle" style="text-align:center;vertical-align:middle">Thumb</th></tr>
</thead>
<tbody>
<tr><td align="center" valign="middle" style="text-align:center;vertical-align:middle"><a href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_flux2_klein_text_to_image.json">FLUX.2 [Klein] 4B: Text to Image</a></td><td colspan="2" align="center" valign="middle" style="text-align:center;vertical-align:middle"><a href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_flux2_klein_text_to_image.json"><img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/image_flux2_klein_text_to_image-1.webp" width="200" height="200" alt="FLUX.2 [Klein] 4B: Text to Image"></a></td></tr>
</tbody>
</table>