---
license: other
license_name: flux-1-dev-non-commercial-license
license_link: https://huggingface.co/black-forest-labs/FLUX.1-Krea-dev/blob/main/LICENSE.md
tags:
- comfyui
- diffusion-single-file
base_model:
- black-forest-labs/FLUX.2-dev
- ByteZSzn/Flux.2-Turbo-ComfyUI
pipeline_tag: text-to-image
---

# Flux 2 Dev

Repackaged model files for ComfyUI.

Original model repository: https://huggingface.co/black-forest-labs/FLUX.2-dev

Place the files in the following folders:

```
📂 ComfyUI/
├── 📂 models/
│   ├── 📂 diffusion_models/
│   │   └── flux2_dev_fp8mixed.safetensors
│   ├── 📂 loras/
│   │   ├── Flux2TurboComfyv2.safetensors
│   │   └── Flux_2-Turbo-LoRA_comfyui.safetensors
│   ├── 📂 text_encoders/
│   │   ├── mistral_3_small_flux2_bf16.safetensors
│   │   ├── mistral_3_small_flux2_fp4_mixed.safetensors
│   │   └── mistral_3_small_flux2_fp8.safetensors
│   ├── 📂 vae/
│   │   └── flux2-vae.safetensors
```

---

These are quantized weights. The original FLUX.2 repo is here: [FLUX.2-dev](https://huggingface.co/black-forest-labs/FLUX.2-dev/).


- Flux2TurboComfyv2.safetensors by [ByteZSzn](https://huggingface.co/ByteZSzn/Flux.2-Turbo-ComfyUI/)
- Flux_2-Turbo-LoRA_comfyui.safetensors by [ByteZSzn](https://huggingface.co/ByteZSzn/Flux.2-Turbo-ComfyUI/)

## Workflows

<table>
<thead>
<tr><th align="center" valign="middle" style="text-align:center;vertical-align:middle">Workflow</th><th colspan="2" align="center" valign="middle" style="text-align:center;vertical-align:middle">Thumb</th></tr>
</thead>
<tbody>
<tr><td align="center" valign="middle" style="text-align:center;vertical-align:middle"><a href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_flux2.json">Flux.2 Dev</a></td><td align="center" valign="middle" style="text-align:center;vertical-align:middle"><a href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_flux2.json"><img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/image_flux2-2.webp" width="200" height="200" alt="Flux.2 Dev"></a><div align="center">Before</div></td><td align="center" valign="middle" style="text-align:center;vertical-align:middle"><a href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_flux2.json"><img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/image_flux2-1.webp" width="200" height="200" alt="Flux.2 Dev"></a><div align="center">After</div></td></tr>
<tr><td align="center" valign="middle" style="text-align:center;vertical-align:middle"><a href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_flux2_text_to_image.json">Flux.2 Dev Text to Image</a></td><td colspan="2" align="center" valign="middle" style="text-align:center;vertical-align:middle"><a href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_flux2_text_to_image.json"><img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/image_flux2_text_to_image-1.webp" width="200" height="200" alt="Flux.2 Dev Text to Image"></a></td></tr>
<tr><td align="center" valign="middle" style="text-align:center;vertical-align:middle"><a href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_flux2_fp8.json">Product Mockup(Flux.2 Dev FP8)</a></td><td colspan="2" align="center" valign="middle" style="text-align:center;vertical-align:middle"><a href="https://github.com/Comfy-Org/workflow_templates/blob/main/templates/image_flux2_fp8.json"><img src="https://raw.githubusercontent.com/Comfy-Org/workflow_templates/main/templates/image_flux2_fp8-1.webp" width="200" height="200" alt="Product Mockup(Flux.2 Dev FP8)"></a></td></tr>
</tbody>
</table>