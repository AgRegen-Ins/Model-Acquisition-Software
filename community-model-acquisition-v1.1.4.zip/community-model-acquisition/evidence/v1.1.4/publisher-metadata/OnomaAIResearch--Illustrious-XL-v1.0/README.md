---
license: other
license_name: sdxl-license
license_link: >-
  https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/LICENSE.md
---

# Illustrious-XL-v1.0
---
Before we dive into the details of 'Illustrious-XL-v1.1', we’re excited to share that you can now generate images directly with our Illustrious XL models on our official site: [illustrious-xl.ai](http://illustrious-xl.ai/).

We’ve launched a full image generation platform featuring high-res outputs, natural language prompting, and custom presets - plus, several exclusive models you won’t find on any other hub.

Explore our updated model tiers and naming here: [Model Series](https://www.illustrious-xl.ai/updates/20).

Need help getting started? Check out our generation user guide: [ILXL Image Generation User Guide](https://www.illustrious-xl.ai/updates/21).

---

# Illustrious XL v1.0 – High-Resolution Focused Illustration Generative Model

## Overview

**Illustrious XL v1.0** is a cutting-edge generative model developed by **OnomaAI**, built upon the Stable Diffusion XL architecture. Trained from the previous checkpoint, Illustrious XL v0.1, this model is designed specifically to generate stunning, high-resolution images. It achieves an unprecedented native resolution of **1536×1536** within the SDXL framework, setting new standards for detail and clarity. The model integrates natural language understanding with Danbooru-style tag-based prompting, enabling flexible and robust prompt handling. Thus, Illustrious XL v1.0 serves as an ideal foundation for creators requiring versatility without sacrificing image fidelity.

## Knowledge Cutoff

Illustrious XL v1.0 was trained in **July 2024**, with knowledge available up to **June 2024**. Thanks to native support of v0.1 LoRA, knowledge limits are largely mitigated.

## Key Features

### 1536×1536 Native Resolution
- First-of-its-kind SDXL model supporting native **1536px resolution**.
- Produces images with exceptional detail, sharpness, and clarity at high resolutions previously unattainable in SDXL.
- Capable of handling resolutions ranging from **512x512** up to **1536x1536**, including non-standard resolutions like **1248x1824** without additional modifications.

### NLP + Tag-Based Prompting
- Combines advanced natural language processing with concise Danbooru tag-based prompts.
- Users can employ plain English descriptions, precise tags, or both, providing greater control and nuanced image generation.

### Extensive Compatibility
- Compatible with various extensions and add-ons.
- Supports seamless integration of LoRA, ControlNet modules, and other adaptation methods previously trained on Illustrious v0.1.
- Allows users to easily mix and match enhancements for style, pose, or composition.

### Pretrained Base Model
- Provided as a pretrained base checkpoint without fine-tuning on specific aesthetics or biases.
- Ideal for creators seeking a flexible foundation to apply their fine-tuning, such as LoRA training, for specialized art styles or outputs.

## Future Plans

### Higher Resolutions in v3
- Upcoming releases (Illustrious XL v3) aim to support higher resolutions, targeting up to **2k resolution and beyond**.
- Anticipate further enhancements in detail and scaling, enabling the generation of ultra-crisp, large-format images.

### v-Parameterization Models & Color Control
- A specialized v-parameterization variant is in preparation, designed to push beyond SD XL's known limits academically and practically.
- Future updates will emphasize enhanced color control, offering precise adjustments for color balance and consistency.

### Continuous Improvement
- The Illustrious roadmap commits to continuous integration of community feedback and incorporation of the latest research.
- Efforts in high-resolution research will persist, pushing boundaries with careful and innovative methods.

