---
base_model: HiDream-ai/HiDream-I1-Full
library_name: gguf
quantized_by: city96
tags:
- image-generation
- HiDream.ai
license: mit
language:
- en
pipeline_tag: text-to-image
---
This is a direct GGUF conversion of [HiDream-ai/HiDream-I1-Full](https://huggingface.co/HiDream-ai/HiDream-I1-Full)

The model files can be used with the [ComfyUI-GGUF](https://github.com/city96/ComfyUI-GGUF) custom node.

Place model files in `ComfyUI/models/diffusion_models` - see the GitHub readme for further install instructions.

The VAE and additional files can be downloaded from [Comfy-Org/HiDream-I1_ComfyUI](https://huggingface.co/Comfy-Org/HiDream-I1_ComfyUI/tree/main/split_files)

Please refer to [this chart](https://github.com/ggerganov/llama.cpp/blob/master/examples/perplexity/README.md#llama-3-8b-scoreboard) for a basic overview of quantization types.
