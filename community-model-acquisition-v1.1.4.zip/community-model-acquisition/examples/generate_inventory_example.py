#!/usr/bin/env python3
"""Generate a synthetic example, never read the production archive."""
import sys,tempfile,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit import core,archive_report

def generate(output):
    with tempfile.TemporaryDirectory(prefix='synthetic-inventory-') as t:
        base=Path(t);root=base/'archive';root.mkdir()
        entries=[]
        for name,fmt,status in [('example-complete-source','Safetensors','verified'),('example-partial-gguf','GGUF','partial'),('example-catalog-only','GGUF',None)]:
            e={'id':name,'family':'Synthetic demonstration','category':'fixture','repository':'fixtures/not-a-real-model','publisher':'Test fixture','revision':'a'*40,'format':fmt,'quantization':'Q4_K_M' if fmt=='GGUF' else None,'source_kind':'synthetic-test-fixture','estimated_bytes':16,'display_name':name,'profiles':[]}
            entries.append(e)
            if status is None:continue
            target=root/'fixture'/name/e['revision'];payload=target/'payload'/'inert.bin';payload.parent.mkdir(parents=True);payload.write_bytes(b'inert-demo-bytes')
            expected={'path':'inert.bin','size':payload.stat().st_size,'sha256':hashlib.sha256(payload.read_bytes()).hexdigest()}
            record=core.inspect_file(payload,expected)
            core.write(target/'manifest.json',{'schema_version':1,'entry':e,'revision':e['revision'],'created_at':'2026-10-21T00:00:00+00:00','verified_at':'2026-10-21T00:00:00+00:00' if status=='verified' else None,'status':status,'expected':[expected],'files':{'inert.bin':record} if status=='verified' else {}})
        settings=base/'settings.json';settings.write_text('{"mount_guards":[]}')
        data=archive_report.collect(root,{'models':entries},{'models':{}},settings)
        data['notes'].insert(0,'SYNTHETIC EXAMPLE. Not a report of Edmund-Library or its production migration. Tiny inert files only.')
        data['generated_at']='2026-10-21T00:00:00+00:00'
        # Portable display paths for this demonstration only, never production records.
        def portable(v):
            if isinstance(v,str):return v.replace(str(root),'/synthetic-example/archive')
            if isinstance(v,dict):return {k:portable(x) for k,x in v.items()}
            if isinstance(v,list):return [portable(x) for x in v]
            return v
        data=portable(data);output=Path(output)
        output.write_bytes(archive_report.workbook(data));output.with_suffix('.json').write_text(json.dumps(data,indent=2)+'\n')
if __name__=='__main__':generate(sys.argv[1])
