#!/usr/bin/env python3
"""Offline Model Acquisition Toolkit command line entry point."""
import argparse, os, sys
from pathlib import Path
from modelkit.core import ToolkitError,load_catalog,select,plan,space,human,acquire,inventory,report,friendly

from modelkit.mounts import expected_mount, require_mount
from modelkit.volume import public_data
from modelkit.storage import scan as storage_scan, view as storage_view, render as storage_render, refresh as refresh_inventory

BASE=Path(__file__).resolve().parent

def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--list-catalog',action='store_true',help='Read-only catalog/profile listing; no archive scan or network')
    p.add_argument('--verify-selected',action='store_true',help='Audit only explicitly selected pinned variants; writes audit records')
    p.add_argument('--catalog',type=Path,default=BASE/'catalog.json')
    p.add_argument('--settings',type=Path,default=BASE/'settings.json',help='Archive root and filesystem identity configuration')
    p.add_argument('--expected-mount',type=Path,help='Override expected storage mount for this run')
    p.add_argument('--inventory',action='store_true',help='Read-only storage inventory to stdout')
    p.add_argument('--format',choices=['text','csv','json'],default='text',help='Inventory output format')
    p.add_argument('--sort',choices=['name','size'],default='name',help='Inventory group order; size is descending')
    p.add_argument('--superseded',action='store_true',help='Show superseded revisions only; summary remains collection-wide')
    p.add_argument('--root',type=Path,help='Override the reviewed default_root in settings.json')
    g=p.add_mutually_exclusive_group();g.add_argument('--profile');g.add_argument('--model',action='append',help='Variant ID, repeat to select several')
    p.add_argument('--dry-run',action='store_true',help='Live metadata only; no payloads or root writes')
    p.add_argument('--offline-plan',action='store_true',help='Bundled estimates only; implies dry-run')
    p.add_argument('--latest',action='store_true',help='Resolve tracking revision; old revisions retained')
    p.add_argument('--status',action='store_true');p.add_argument('--verify',action='store_true')
    p.add_argument('--check-updates',action='store_true',help='Check main branches with status/verify')
    p.add_argument('--configure',action='store_true',help='Create root directories, no downloads')
    p.add_argument('--yes',action='store_true',help='Confirm the displayed download plan')
    p.add_argument('--allow-large',action='store_true',help='Required for noninteractive plans >=50 GB')
    p.add_argument('--repair',action='store_true',help='Preserve damaged files in quarantine before replacing')
    return p

def get_root(value,stream=None):
    if value is None:
        if not sys.stdin.isatty():raise ToolkitError('Provide --root explicitly in noninteractive use')
        value=Path(input('Model root (enter full path): ').strip()).expanduser()
        if str(value)=='.':raise ToolkitError('A root directory is required')
    from modelkit.volume import trusted_anchor
    value=value.expanduser().absolute()
    if trusted_anchor(value):
        from modelkit.volume import public_data
        print('Model root: '+public_data(str(value)),flush=True,file=stream)
        return value
    if value==Path(value.anchor):raise ToolkitError('Use a dedicated models directory, not a drive/filesystem root')
    if any(x.is_symlink() for x in [value,*value.parents]):raise ToolkitError('Choose the real root path, not a symlink')
    print('Model root: '+str(value),flush=True,file=stream)
    return value

def menu(catalog):
    choices=['small-cpu','dell','coding-local','retrieval','future','all']
    for i,x in enumerate(choices,1):print(f'[{i}] {x}: {catalog["profiles"][x]}')
    print('[7] Individual variants\n[8] Verify collection\n[9] Collection status')
    answer=input('Selection: ').strip()
    if answer in ('8','9'):return None,None,answer
    if answer=='7':
        for e in catalog['models']:print(e['id'])
        return None,input('Enter variant IDs separated by spaces: ').split(),answer
    if not answer.isdigit() or not 1<=int(answer)<=6:raise ToolkitError('Invalid selection')
    return choices[int(answer)-1],None,answer

def _main(argv=None):
    args=parser().parse_args(argv);catalog=load_catalog(args.catalog)
    if args.list_catalog:
        if args.verify_selected or args.verify or args.status or args.configure or args.inventory or args.dry_run or args.offline_plan:raise ToolkitError('Catalog listing must be used separately from other actions')
        import json
        entries=select(catalog,args.profile,args.model) if args.profile or args.model else catalog['models']
        data={'profiles':catalog['profiles'],'models':entries,'note':'Cataloged only; no archive access or acquisition performed.'}
        if args.format=='json':print(json.dumps(data,indent=2))
        else:
            for e in entries:print(e['id']+' | '+e.get('artifact_type','model')+' | '+e['repository']+' | '+human(e['estimated_bytes']))
            print('Profiles: '+', '.join(catalog['profiles']))
        return 0
    root=get_root(args.root,sys.stderr if args.inventory else None)
    if args.verify_selected:
        if not args.model or args.profile or args.status or args.verify or args.inventory or args.configure or args.dry_run or args.offline_plan or args.latest or args.check_updates:raise ToolkitError('--verify-selected requires explicit --model IDs and no other actions')
        from modelkit.selected_audit import verify_selected
        from filelock import FileLock
        entries=select(catalog,ids=args.model)
        require_mount(root,expected_mount(root,args.settings,args.expected_mount))
        (root/'_toolkit').mkdir(parents=True,exist_ok=True)
        with FileLock(root/'_toolkit'/'collection.lock',timeout=0):
            data=verify_selected(root,entries);report(root,data)
        return 0 if all(r['status']=='verified' for r in data['models']) else 1
    if args.inventory:
        if args.verify or args.status or args.configure or args.profile or args.model or args.check_updates:
            raise ToolkitError('--inventory is a read-only action; use it separately from acquisition/status/verify')
        print(storage_render(storage_view(storage_scan(root,catalog),args.sort,args.superseded),args.format),end='')
        return 0
    if args.format!='text' or args.sort!='name' or args.superseded:raise ToolkitError('--format, --sort and --superseded require --inventory')
    mount=expected_mount(root,args.settings,args.expected_mount)
    if mount is not None:print('Expected storage mount: '+str(mount))
    if args.configure:
        require_mount(root,mount)
        for d in ['_toolkit/logs','_toolkit/reports',*{e['category'] for e in catalog['models']}]: (root/d).mkdir(parents=True,exist_ok=True)
        print('Directories ready on approved storage. The default root comes from reviewed settings.json; --root may select another approved root.');return 0
    if not(args.profile or args.model or args.status or args.verify):
        if not sys.stdin.isatty():raise ToolkitError('Choose --profile, --model, --status, or --verify')
        args.profile,args.model,choice=menu(catalog);args.verify=choice=='8';args.status=choice=='9'
    if args.check_updates and not(args.status or args.verify):raise ToolkitError('--check-updates requires --status or --verify')
    if args.offline_plan and (args.status or args.verify):raise ToolkitError('--offline-plan is for acquisition selection')
    if args.dry_run and (args.status or args.verify):raise ToolkitError('Use --status or --verify without --dry-run')
    if args.status or args.verify:
        if not root.exists():raise ToolkitError('Model root does not exist; run --configure first')
        from filelock import FileLock,Timeout
        from modelkit.huggingface import HuggingFaceAdapter
        (root/'_toolkit').mkdir(exist_ok=True)
        with FileLock(root/'_toolkit'/'collection.lock',timeout=0):
            try:
                data=inventory(root,catalog,args.verify,HuggingFaceAdapter() if args.check_updates else None);report(root,data)
            finally:
                refresh_inventory(root,catalog)
        return 1 if args.verify and any(r['status'] in ('failed','partial') for r in data['models']) else 0
    entries=select(catalog,args.profile,args.model)
    if not entries:raise ToolkitError('Selection is empty')
    if args.offline_plan:
        for e in entries:print(f"{e['id']} | {e['repository']} | {e['format']} {e['quantization']} | ~{human(e['estimated_bytes'])} | gated={e.get('gated_at_review')}\n  {root/e['category']/e['id']/e['revision']}")
        total=sum(e['estimated_bytes'] for e in entries);free,reserve=space(root,total)
        print(f'Bundled estimates only: {human(total)}; free: {human(free)}. No network or disk writes.');return 0
    if not args.dry_run:require_mount(root,mount)
    from modelkit.huggingface import HuggingFaceAdapter
    adapter=HuggingFaceAdapter();plans=[]
    for e in entries:
        if args.latest:e={**e,'revision':e.get('tracking_revision','main')}
        print('Resolving '+e['id'],flush=True);p=plan(e,root,adapter);plans.append(p)
        print(f"  {e['repository']} | {e['format']} {e['quantization']} | {human(p['total_bytes'])} | gated={p['gated']}\n  {public_data(p['target'])}")
    total=sum(p['total_bytes'] for p in plans);needed=sum(p['estimated_new_bytes'] for p in plans);free,reserve=space(root,needed)
    print(f'Selected: {len(plans)} variants. Total: {human(total)}. Estimated new files: {human(needed)}. Free: {human(free)}. Required with reserve: {human(reserve)}.')
    if total>=50*10**9:print('LARGE ARCHIVE: may take hours/days; these weights may exceed your current hardware capabilities.')
    if free<reserve:print('INSUFFICIENT SPACE for this plan including the safety reserve.')
    if args.dry_run:return 0
    if free<reserve:raise ToolkitError('Insufficient space including safety reserve. Choose fewer models or another disk.')
    if not args.yes:
        if not sys.stdin.isatty():raise ToolkitError('Download requires confirmation; use --yes after reviewing --dry-run')
        if input('Proceed? [y/N] ').strip().lower()!='y':print('Cancelled.');return 0
        if total>=50*10**9 and input('Type LARGE to confirm archival download: ')!='LARGE':print('Cancelled.');return 0
    elif total>=50*10**9 and not args.allow_large:raise ToolkitError('Large downloads require --allow-large with --yes')
    require_mount(root,mount)
    from filelock import FileLock
    (root/'_toolkit').mkdir(parents=True,exist_ok=True)
    failed=False
    with FileLock(root/'_toolkit'/'collection.lock',timeout=0):
        for i,p in enumerate(plans,1):
            print(f"Model {i}/{len(plans)}: {p['entry']['id']}",flush=True)
            try:
                # Reserve enough for all remaining new files, even after repair.
                remaining=sum(x['estimated_new_bytes'] for x in plans[i-1:])
                if args.repair:remaining+=p['total_bytes']
                available,required=space(root,remaining)
                if available<required:raise ToolkitError('Insufficient remaining disk space')
                require_mount(root,mount)
                acquire(p,root,adapter,args.repair)
                refresh_inventory(root,catalog)
            except KeyboardInterrupt:
                refresh_inventory(root,catalog);report(root,inventory(root,catalog));print('Interrupted; rerun the same command to resume.');return 130
            except Exception as exc:
                failed=True;print(str(exc) if isinstance(exc,ToolkitError) else friendly(exc),file=sys.stderr)
        try:
            report(root,inventory(root,catalog))
            refresh_inventory(root,catalog)
        except Exception as exc:
            detail=str(exc) if isinstance(exc,ToolkitError) else friendly(exc)
            raise ToolkitError('Post-acquisition reporting failed; acquisition results remain recorded in per-model manifests. Retry --status after resolving the reporting error. Cause: '+detail) from exc
    return 1 if failed else 0

def main(argv=None):
    from modelkit.volume import configured_root, StorageSession
    args=parser().parse_args(argv)
    root=configured_root(args.root,args.settings)
    tokens=list(argv if argv is not None else sys.argv[1:])
    # Replace the parsed root without altering any other CLI option.
    for i in range(len(tokens)-1,-1,-1):
        if tokens[i]=='--root':del tokens[i:i+2]
        elif tokens[i].startswith('--root='):del tokens[i]
    if (args.configure or args.status or args.verify or args.verify_selected) and (args.dry_run or args.offline_plan):
        raise ToolkitError('Writing actions cannot be combined with planning flags; use --configure, --status or --verify separately')
    if args.verify_selected and (args.inventory or args.list_catalog):raise ToolkitError('--verify-selected cannot be combined with read-only actions')
    readonly=args.list_catalog or args.inventory or ((args.dry_run or args.offline_plan) and not (args.status or args.verify))
    if readonly:return _main(tokens+['--root',str(root)])
    with StorageSession(root,args.settings,args.expected_mount) as session:
        return _main(tokens+['--root',str(session.root)])

if __name__=='__main__':
    try:sys.exit(main())
    except KeyboardInterrupt:print('\nCancelled.');sys.exit(130)
    except Exception as exc:
        print('Error: '+(str(exc) if isinstance(exc,ToolkitError) else friendly(exc)),file=sys.stderr);sys.exit(1)
