#!/usr/bin/env python3
"""Read-only independent SHA-256 tree comparison. Never copies or deletes files."""
import argparse,hashlib,json,os,stat,sys
from pathlib import Path
from modelkit.core import ToolkitError
from modelkit.volume import configured_root,rule_for,identify,validate_location
from modelkit.recovery_directory import filesystem_recovery_directory
BASE=Path(__file__).resolve().parent

def tree(root,check=lambda:None,exclusions=None):
    check();root=Path(root);fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    result={};byte_count=0
    try:
        pinned=os.fstat(fd)
        def stable():
            check();visible=root.stat()
            if (visible.st_dev,visible.st_ino)!=(pinned.st_dev,pinned.st_ino):raise ToolkitError('Archive root changed during comparison')
        stable()
        def onerror(exc):raise exc
        # fwalk retains directory descriptors; file opens do not re-resolve mounts.
        for directory,dirs,files,dirfd in os.fwalk('.',topdown=True,follow_symlinks=False,dir_fd=fd,onerror=onerror):
            stable();prefix=Path(directory)
            if directory=='.' and 'lost+found' in dirs:
                recovery=filesystem_recovery_directory(root,fd)
                if recovery is not None:
                    dirs.remove('lost+found')
                    if exclusions is not None:exclusions.append(recovery)
            for name in sorted(dirs+files):
                s=os.stat(name,dir_fd=dirfd,follow_symlinks=False);key=(prefix/name).as_posix()
                if stat.S_ISDIR(s.st_mode):result[key]={'kind':'directory'};continue
                if not stat.S_ISREG(s.st_mode):raise ToolkitError('Non-regular entry requires manual review: '+key)
                digest=hashlib.sha256();stable()
                child=os.open(name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=dirfd)
                with os.fdopen(child,'rb') as stream:
                    before=os.fstat(stream.fileno())
                    if (before.st_dev,before.st_ino)!=(s.st_dev,s.st_ino):raise ToolkitError('Entry changed before comparison: '+key)
                    for block in iter(lambda:stream.read(8*1024*1024),b''):digest.update(block)
                    after=os.fstat(stream.fileno())
                stable()
                if (before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(after.st_size,after.st_mtime_ns,after.st_ctime_ns):raise ToolkitError('Entry changed while hashing: '+key)
                result[key]={'kind':'file','bytes':s.st_size,'sha256':digest.hexdigest()};byte_count+=s.st_size
        stable()
    finally:os.close(fd)
    return result,byte_count

def compare(source,destination,check_source=lambda:None,check_destination=lambda:None):
    excluded={'source':[],'destination':[]}
    left,bytes_left=tree(source,check_source,excluded['source']);right,bytes_right=tree(destination,check_destination,excluded['destination'])
    check_source();check_destination()
    missing=sorted(left.keys()-right.keys());extra=sorted(right.keys()-left.keys());changed=sorted(k for k in left.keys()&right.keys() if left[k]!=right[k])
    count=sum(v['kind']=='file' for v in left.values())
    return {'source':str(source),'destination':str(destination),'match':bool(count) and not(missing or extra or changed),'source_file_count':count,'destination_file_count':sum(v['kind']=='file' for v in right.values()),'source_bytes':bytes_left,'destination_bytes':bytes_right,'missing':missing,'extra':extra,'changed':changed,'excluded_filesystem_entries':excluded,'method':'Excludes confirmed standard ext4 recovery directories only. Independent SHA-256 of every regular file; exact relative file/directory membership; no writes; empty source cannot pass','metadata_scope':'Content and directory membership. Does not certify ownership, permissions, ACLs, xattrs or replication durability.'}

def validator(root,settings):
    rule=rule_for(root,settings,writing=False);mount=Path(rule['expected_mount'])
    first=identify(mount,rule['expected_uuid'],rule.get('filesystem'),writable=False)
    def check():
        if identify(mount,rule['expected_uuid'],rule.get('filesystem'),writable=False)!=first:raise ToolkitError('Mount changed during comparison')
        if any(p.is_symlink() for p in [root,*root.parents]):raise ToolkitError('Symlink archive root refused')
        validate_location(root,mount)
    return check

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);p.add_argument('--settings',type=Path,default=BASE/'settings.json');a=p.parse_args(argv)
    source=configured_root(a.source,a.settings);dest=configured_root(a.destination,a.settings)
    if source.is_relative_to(dest) or dest.is_relative_to(source):raise ToolkitError('Comparison roots must be separate non-overlapping directories')
    data=compare(source,dest,validator(source,a.settings),validator(dest,a.settings));print(json.dumps(data,indent=2));return 0 if data['match'] else 1
if __name__=='__main__':
    try:sys.exit(main())
    except (ToolkitError,OSError) as exc:print('Error: '+str(exc),file=sys.stderr);sys.exit(1)
