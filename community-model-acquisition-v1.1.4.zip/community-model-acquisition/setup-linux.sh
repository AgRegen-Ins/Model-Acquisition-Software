#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
# Installation never touches archive storage. Configuration is a separate command.
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python model_acquire.py --help
printf '%s\n' 'Installed. Review settings.json, then run model_storage.py before any archive writes.'
