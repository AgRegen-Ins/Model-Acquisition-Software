# v1.1.4 — 2026-11-07

- Added 27 image-model variants and 59 component records with exact immutable manifests across 31 repositories. Fifteen requested families supported; WAI provenance/license remains blocked.
- Explicit shared dependencies, image generation/editing capabilities, native/optimized roles, ten opt-in profiles, and manual report columns.
- Existing 68 entries, profiles, acquisition logic, UUID safety, selected audits and manual-only XLSX behavior preserved.
- Added focused qualification tests; historical catalog-size assertions updated and exact source guards extended without removing old tests.

# v1.1.3 — Educational assessment preservation

- Add eight pinned checkpoint/adapter/scorer/software selections and five opt-in profiles.
- Add inert public GitHub acquisition using existing guarded manifest/resume/verification architecture.
- Add catalog listing and selected-artifact hash auditing without whole-archive rehashing.
- Preserve all 60 prior entries, profiles, storage policies, registry and inventory behavior.
- Document unresolved licensing, missing base revisions and deliberate source/data exclusions.

## v1.1.2 — test portability maintenance

Correct the simulated ext4 recovery-directory ownership fixture for ordinary-user test runs. Production scanner and acquisition code are unchanged. See [v1.1.2 change report](docs/v1.1.2/CHANGE_REPORT.md). Write-enabled production activation remains pending operator authorization.

## v1.1.1 — 2026-10-23

Fix inventory and read-only archive comparison at an ext4 filesystem root: exclude only a confirmed conventional filesystem `lost+found` recovery directory. Exclusions are reported explicitly; other permission errors remain errors. All catalog entries, storage identity checks and acquisition behavior are unchanged. See [v1.1.1 maintenance notes](docs/v1.1.1/CHANGE_REPORT.md) for qualification and acceptance instructions.

# v1.1.0 — Dedicated model storage

- Default `/srv/ai-models`, configurable UUID-based approved storage rules.
- Guard acquisition, configure, status/audit reports and registry writes; pin
  directory handles to prevent unmounted-directory fallback during disconnects.
- Preserve all 60 model entries, profiles and relative manifests.
- Add read-only storage preflight, SHA-256 migration comparison and XLSX reporting.
- Installation creates software only; activation and original-archive retirement
  are explicit operator steps. No production migration or model downloads ran.
- Preserve v1.0.4.8.1 path-maintenance fix and inherited qualification cases;
  exact approved source deltas update historical byte guards for this release.
- Strict new writable-volume identity contract currently supports Linux only.

## v1.0.4.8.1 — repository-path maintenance

Fix legitimate underscore-prefixed payload paths such as `__init__.py` while retaining strict managed identifiers and path-security checks. Clarify final-reporting failures without changing acquisition results. All 60 model entries and profiles unchanged. See [path fix](docs/PATH_VALIDATION_FIX_V10481.md), [Ubuntu acceptance](docs/UBUNTU_ACCEPTANCE_V10481.md), and [release report](docs/RELEASE_REPORT_V10481.md).

## v1.0.4.8

Add five Q4_K_M refusal-reduced inference variants; all 55 historical entries and named profiles preserved. GPT-OSS uses two raw parts from the authorized public mradermacher alternative. Acquisition behavior unchanged. See [model manifests and resources](docs/LARGE_REFUSAL_REDUCED_MODELS_V1048.md), [Ubuntu commands](docs/UBUNTU_ACCEPTANCE_V1048.md), [benchmark plan](docs/MODEL_BENCHMARK_PLAN_V1048.md), and [release notes](docs/RELEASE_REPORT_V1048.md).

# v1.0.4.7 — two Huihui-derived Q4_K_M inference variants

- Add only Huihui GLM-4.7-Flash Abliterated (mradermacher GGUF) and Huihui Qwen3-32B Abliterated (RoadToNowhere GGUF), pinned with exact file/size/hash evidence.
- Both third-party-derived; document base → Huihui modification → converter chain, unknown conversion-source commits and gated Qwen source metadata limits. Do not substitute roslein's similarly named Qwen modification.
- All 53 existing entries and old profile memberships preserved; `all` grows to 55. Two additive inference-only policy records; no new profiles.
- 28 focused tests added, 270 total. All existing production code byte-identical except version metadata. No dependency, acquisition, verification, storage, mount or registry changes.
- No model execution or full payload download; runtime source/header verification and live dry-runs are distinct from real inference qualification.

# v1.0.4.6 — two-model reasoning GGUF inference release

- Based only on verified v1.0.4.5; adds official Qwen3-Next-80B-A3B-Thinking Q6_K and ggml-org GLM-4.5-Air Q4_K_M, with exact required filenames and immutable pins.
- Qwen is one weight file; GLM requires both metadata/tokenizer shard and tensor shard. No substituted quantizations, draft models, unrelated models or OpenScholar integrations.
- All 51 pre-existing model entries, policy values and historical profiles unchanged; `all` grows to 53. No new profiles; two additive inference-only preservation-policy records.
- All production Python, settings and dependencies byte-identical except `modelkit/__init__.py` version. No archive, mount, resume, verification, quarantine or registry behavior changes.
- 28 focused regression tests added; 242 total. Live metadata/header checks and three dry-runs; full models and HP inference untested. See release report for exact qualification.

# v1.0.4.5 — single gpt-oss-120b GGUF inference addition

- Added ggml-org gpt-oss-120b MXFP4 GGUF at immutable revision, one opt-in profile, and one additive preservation-policy record.
- Selected one unsharded weight plus README/source revision/conversion log; excluded optional Eagle3 drafts.
- Preserved all 50 existing entries and historical memberships. Original OpenAI checkpoint remains untouched.
- Added 21 focused regression cases (214 total), metadata/header/Harmony evidence, HP preparation and Ubuntu acceptance notes.
- No production code changes except version metadata; no real model downloads or inference tests.

# v1.0.4.4 — scientific research acquisition

- Added four exact-pinned variants: OpenScholar 8B BF16 PyTorch source/Bartowski Q4_K_M, ether0 24B FP32 Safetensors source/redponike Q4_K_M.
- Four explicit scientific/chemistry profiles and additive source-and-inference policy records; 46 legacy entries/policies and historical memberships unchanged.
- TensorBlock Q4_K_M not present in its current tree; documented alternative selected. OpenScholar licensing conflict and converter source-commit uncertainty retained.
- Added 27 focused regression cases (193 total), metadata/header/tokenizer evidence, HP deployment notes, software roadmap and Ubuntu acceptance guide. Final test/package results are in the release report.
- No production code changes except version metadata. No model execution, full payload downloads, runtime installs or destructive cleanup.

# Changelog

## 1.0.4.3 — 2026-10-11

- 166 automated tests, five supported Python versions, 14 live metadata-only dry runs; no real weight downloads or inference execution.

- Add the eight agreed vision/audio model/component items as seven complete inference systems plus an explicit Vocos dependency; preserve Qwen GGUF and projector together. Pin exact required files and document license conflicts/constraints.
- Add six opt-in profiles; all 38 existing entry values, pins, selections and old profile memberships unchanged.
- Add metadata-only preservation-policy overlay and independent project associations.
- Add separate model_registry.py for local/remote custody registration, explicit upstream hash comparison, non-destructive verified-copy import, and text/CSV/JSON accountability reports. Legacy inventory/accounting unchanged.
- Core changes are confined to load_catalog/select for explicit dependency validation/expansion. Preserve portable source guards and all other core functions. No changes to model_acquire.py, mount safety, adapter, retry/resume, verification, quarantine or retention.

## 1.0.4.2 — 2026-10-04

- Add official Qwen3-Coder-Next BF16 source and Unsloth Q6_K GGUF at immutable revisions, with exact file/byte manifests and artifact-specific provenance/runtime/training notes.
- Add `coding-workstation`: existing Qwen3-Coder-30B Q4_K_M plus Next Q6_K. Add only new IDs to applicable coding/archive/future/source profiles; no existing entry changes.
- Keep all operational files byte-identical; version metadata is the only production-file edit. Preserve the v1.0.4.1 source-based portability guard.
- Add 20 regressions (115 total). Three live metadata-only dry runs resolve exact files and pins; no weight-bearing payloads downloaded. Document 96 GB aggregate VRAM as a planning target and retain all large/mount/reserve interlocks.

## 1.0.4.1 — 2026-10-03

- Minimal test-portability maintenance release based on the verified v1.0.4 ZIP. Catalog, IDs, repositories, pins, profiles, metadata and operational code/configuration remain byte-identical.
- Replace interpreter-dependent `ast.dump()` hashes in `test_application_behavior_unchanged` with exact module-source comparison, excluding only the existing `load_catalog` and `select` definitions. The checked-in v1.0.3 source fixture is authenticated against its original package SHA-256. All other definitions, imports and module-level statements remain protected.
- Keep the historical AST-hash evidence unchanged but no longer use it as an executable regression baseline.
- Add four guard regression tests: no AST serialization, detection of protected/module changes, allowed profile changes, and rejection of missing/duplicate exceptions. All 95 tests pass on CPython 3.10.21, 3.11.16, 3.12.14, 3.13.15 and 3.14.7. The old guard reproduces the reported failure on every tested version except 3.12.14.
- Version, release documentation and package checksums updated. No production behavior change; no new model research or weight downloads.

## 1.0.4 — 2026-10-03 UTC

- Add 11 pinned variants across five frontier model families; preserve source, publisher quantization and portable GGUF roles, provenance, capabilities, priorities and hardware/runtime metadata.
- Prefer official GLM BF16 source checkpoints, preserve Mistral mixed FP8/BF16 and Kimi native INT4 accurately, add official Mistral NVFP4 and MiniMax MXFP8.
- Require every selected GGUF shard and each required projector; retain complete source repositories. GLM-5.3-Flash GGUF is explicitly experimental/converter-branch-dependent; defer MiniMax GGUF because the reviewed set lacks a complete multimodal projector.
- Add five opt-in archive profiles. Optional top-level `profile_members` extends schema 1 so existing entries stay identical. Existing profile memberships and acquisition/safety/inventory logic unchanged.
- Add 20 regression tests (91 total), 16 successful live dry runs, exact source inventories and reviewed runtime evidence. Document custom GLM-5.3, MiniMax Community and Modified MIT license conditions.

## 1.0.3 — 2026-09-28

- Add `gpt-oss-20b-gguf-mxfp4` from ggml-org and `glm-4-7-flash-gguf-q4-k-m` from Unsloth, both explicitly `third-party-derived` with exact files/commits pinned.
- Add `dell-upper-tier` containing exactly these variants plus the existing Qwen3-32B Q4_K_M. Existing original weights and all prior entries retained; Qwen's only entry change is the added profile membership.
- Preserve all other profile meanings/memberships. No CLI, acquisition, inventory, mount, verification, retention, setup or dependency code changes.
- Add 10 tests; 71 total pass. Existing assertions adjusted only for catalog size and the specifically requested Qwen profile tag. Include three live dry runs and no full model downloads.

## 1.0.2 — 2026-09-28 UTC

- Add official Qwen2.5-Coder-14B-Instruct original and official Q4_K_M GGUF entries.
- Add official Qwen3-Coder-30B-A3B-Instruct original and explicitly third-party-derived Unsloth Q4_K_M GGUF.
- Pin all four reviewed revisions, capture upstream evidence, sizes, licenses, architecture/context/parameter metadata, and document short-context CPU memory estimates.
- Expand coding-local to four GGUF variants and coding-archive to six originals; preserve all previous entries and other profile memberships.
- Add 10 catalog regression tests; retain all 51 existing tests with only expected catalog/profile counts updated. No acquisition, mount, inventory, verification, retention or setup logic changes.

## 1.0.1 — 2026-09-27

Targeted update to v1.0.0; acquisition/resume/hash/provenance logic retained.

- Configurable expected-mount protection before setup/acquisition writes; default POSIX rule for the Community Library drive, CLI override, portable Windows mount detection, Linux bind-mount recognition.
- Read-only inventory of all on-disk revision directories, including removed catalog entries, unknown/invalid manifests, partial/failed acquisitions and quarantine.
- Rich metadata and current/superseded classification, allocated/logical storage, category totals and conservative potential recoverable-space estimates.
- Text/CSV/JSON exports, grouped size sorting, superseded filtering, and automatic current inventory snapshots after state-changing CLI operations.
- Practical `coding-local` menu selection and separate `coding-archive`; explicit `coding` retains all coding variants.
- 24 added regression tests; all 27 original tests retained. No deletion or pruning added.

## 1.0.0 — 2026-09-27

Initial standalone release: 19 reviewed/pinned model variants covering all 13 requested base models; official GGUF CPU profiles; live/offline plans; explicit root selection; Hugging Face-backed resumable transfer; retries; upstream and local checksum evidence; immutable revision paths; quarantine repair; full offline audits; quick status and update checks; timestamped JSON/text reports; structured event logs; Linux and Windows setup; documentation and automated tests.
