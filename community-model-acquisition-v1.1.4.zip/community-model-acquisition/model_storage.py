#!/usr/bin/env python3
"""Read-only preflight. Does not approve migration or create any directories."""
import argparse,json,sys,os,shutil
from pathlib import Path
from modelkit.core import ToolkitError,space
from modelkit.volume import configured_root,rule_for,identify,validate_location
BASE=Path(__file__).resolve().parent

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path);p.add_argument('--settings',type=Path,default=BASE/'settings.json');p.add_argument('--expected-mount',type=Path);p.add_argument('--read-only',action='store_true',help='Validate identity without requiring a writable archive');p.add_argument('--required-new-bytes',type=int,default=0)
    a=p.parse_args(argv)
    if a.required_new_bytes<0:raise ToolkitError('required-new-bytes cannot be negative')
    root=configured_root(a.root,a.settings);rule=rule_for(root,a.settings,a.expected_mount,writing=not a.read_only)
    identity=identify(Path(rule['expected_mount']),rule['expected_uuid'],rule.get('filesystem'),writable=not a.read_only)
    validate_location(root,Path(rule['expected_mount']))
    if not root.is_dir():raise ToolkitError('Archive directory does not exist')
    if not a.read_only and not os.access(root,os.W_OK):raise ToolkitError('Archive is not writable by this user')
    available,required=space(root,a.required_new_bytes);usage=shutil.disk_usage(root)
    data={'root':str(root),'expected_uuid':rule['expected_uuid'],'mount_id':identity['id'],'identity_confirmed':True,'total_bytes':usage.total,'used_bytes':usage.used,'available_bytes':available,'required_with_reserve_bytes':required,'capacity_sufficient':available>=required,'migration_validated':False}
    print(json.dumps(data,indent=2));return 0 if a.read_only or available>=required else 1
if __name__=='__main__':
    try:sys.exit(main())
    except (ToolkitError,OSError) as exc:print('Error: '+str(exc),file=sys.stderr);sys.exit(1)
