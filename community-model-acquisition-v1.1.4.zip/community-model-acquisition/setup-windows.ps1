$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$modelRoot = Read-Host 'Choose the full model root (example E:\Community Library\models)'
if ([string]::IsNullOrWhiteSpace($modelRoot) -or $modelRoot -notmatch '^(?:[A-Za-z]:[\\/]|\\\\[^\\]+\\[^\\]+)') {
    throw 'Please enter an absolute directory path.'
}
py -3 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Python 3.10+ and venv are required.' }
& '.\.venv\Scripts\python.exe' -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
& '.\.venv\Scripts\python.exe' model_acquire.py --root $modelRoot --configure
if ($LASTEXITCODE -ne 0) { throw 'Root configuration failed.' }
