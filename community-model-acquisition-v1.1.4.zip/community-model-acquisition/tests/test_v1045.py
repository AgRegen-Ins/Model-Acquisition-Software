"""One gpt-oss GGUF variant; metadata snapshots and tiny inert payloads only."""
import contextlib,copy,csv,hashlib,io,json,pickle,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,select,plan,read,write,acquire,inventory,space,ToolkitError
from modelkit.huggingface import HuggingFaceAdapter
from modelkit import accountability as acc
from storage_test_support import main
from test_toolkit import Fake
ROOT=Path(__file__).resolve().parents[1];EV=ROOT/'evidence/v1.0.4.5';ID='gpt-oss-120b-gguf-mxfp4';SOURCE='gpt-oss-120b-original';PROFILE='gpt-oss-120b-local-inference';WEIGHT='gpt-oss-120b-MXFP4.gguf';PIN='238abdd290bb874b90a5da1b4549881b7d05c091'
class Metadata:
    def resolve(self,e):
        d=read(EV/'ggml-org--gpt-oss-120b-GGUF/api.json');assert e['revision']==d['sha']
        return {'revision':d['sha'],'metadata':d,'gated':False,'files':[{'path':f['rfilename'],'size':f['size'],'sha256':(f.get('lfs') or {}).get('sha256'),'git_blob_sha1':None if f.get('lfs') else f['blobId']} for f in d['siblings']]}
    def download(self,*a,**kw):raise AssertionError('No real payload in tests')
class Catalog1045Tests(unittest.TestCase):
    def setUp(self):self.c=load_catalog(ROOT/'catalog.json');self.by={e['id']:e for e in self.c['models']};self.e=self.by[ID]
    def test_exactly_one_addition_all_50_unchanged(self):
        old=read(EV/'baseline-catalog.json');self.assertEqual(self.c['models'][:50],old['models']);self.assertEqual(len(self.c['models']),154);self.assertEqual(self.c['models'][50]['id'],ID)
    def test_historical_profiles_unchanged_only_one_added(self):
        old=read(EV/'baseline-catalog.json');self.assertEqual(set(self.c['profiles'])-set(old['profiles'])-{p for p in self.c['profiles'] if p.startswith('image-')},{PROFILE,'educational-assessment','aiawe-preservation','autoscore-preservation','argulens-preservation','essay-evaluator-preservation'})
        for p in old['profiles']:
            self.assertEqual(self.c['profiles'][p],old['profiles'][p])
            if p!='all':self.assertEqual(select(self.c,p),select(old,p))
        self.assertEqual([e['id'] for e in select(self.c,'all')[:60]],[e['id'] for e in select(old,'all')]+[ID]+['qwen3-next-80b-a3b-thinking-gguf-q6-k', 'glm-4-5-air-gguf-q4-k-m']+['huihui-glm-4-7-flash-abliterated-gguf-q4-k-m', 'huihui-qwen3-32b-abliterated-gguf-q4-k-m']+['huihui-gpt-oss-120b-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m', 'huihui-qwen3-coder-next-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m', 'qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m'])
    def test_profile_only_gguf_not_original_or_dependency(self):
        self.assertEqual(select(self.c,PROFILE),[self.e]);self.assertEqual(select(self.c,ids=[ID,ID]),[self.e]);self.assertEqual(self.e['dependencies'],[])
    def test_repository_pin_and_adapter(self):
        self.assertEqual(self.e['repository'],'ggml-org/gpt-oss-120b-GGUF');self.assertEqual(self.e['revision'],PIN)
        with patch('huggingface_hub.HfApi') as api:
            api.return_value.model_info.return_value=SimpleNamespace(sha=PIN,gated=False,siblings=[]);HuggingFaceAdapter().resolve(self.e);api.return_value.model_info.assert_called_once_with(self.e['repository'],revision=PIN,files_metadata=True)
    def test_exact_manifest_and_size(self):
        p=plan(self.e,Path('/tmp/no1045write'),Metadata());expected=read(EV/'selected-files.json')[ID];self.assertEqual(sorted(p['files'],key=lambda f:f['path']),sorted(expected['files'],key=lambda f:f['path']));self.assertEqual(p['total_bytes'],63387561321);self.assertEqual(self.e['estimated_bytes'],p['total_bytes']);self.assertEqual(next(f for f in p['files'] if f['path']==WEIGHT)['size'],63387346208);self.assertEqual(next(f for f in p['files'] if f['path']==WEIGHT)['sha256'],'582bd40f6886200101f4c4ed9f25f3fe80cc14c86e9e2b37746cd8904a0c622d')
    def test_exact_unsharded_weight_and_no_eagle(self):
        self.assertEqual(self.e['required'],[WEIGHT,'README.md','.src_sha','convert.log']);self.assertEqual(self.e['include'],self.e['required']);self.assertFalse(any('eagle' in n.lower() for n in self.e['required']));self.assertFalse(self.e['companion_artifacts_required'])
    def test_missing_selected_file_refused(self):
        for missing in self.e['required']:
            a=Metadata();d=a.resolve(self.e);d['files']=[f for f in d['files'] if f['path']!=missing]
            with patch.object(a,'resolve',return_value=d),self.assertRaises(ToolkitError):plan(self.e,Path('/tmp/no1045write'),a)
    def test_moe_and_independent_metadata(self):
        e=self.e;self.assertEqual(e['parameter_count'],116829156672);self.assertEqual(e['active_parameter_count'],5100000000);self.assertEqual(e['architecture_type'],'MoE');self.assertEqual((e['expert_count'],e['experts_per_token']),(128,4));self.assertEqual(e['format'],'GGUF');self.assertEqual(e['quantization'],'MXFP4');self.assertEqual(e['source_kind'],'third-party-derived');self.assertEqual(e['variant_role'],'portable-gguf');self.assertEqual(e['license'],'apache-2.0');self.assertIn('Q8_0',e['tensor_precision']);self.assertIn('FP32',e['tensor_precision']);self.assertFalse(e['hp_inference_tested'])
    def test_source_relationship_matches_recorded_conversion(self):
        old=self.by[SOURCE];self.assertEqual(self.e['family'],old['family']);self.assertEqual(self.e['source_variant_id'],SOURCE);self.assertEqual(self.e['upstream_revision'],old['revision']);self.assertIn('PRIMARY='+old['revision'],(EV/'ggml-org--gpt-oss-120b-GGUF/.src_sha').read_text())
    def test_policy_additive(self):
        old=read(EV/'baseline-policy.json');new=acc.policies(ROOT/'preservation-policy.json')
        for k,v in old['models'].items():self.assertEqual(new['models'][k],v)
        self.assertEqual(set(new['models'])-set(old['models'])-set(__import__('json').loads((ROOT/'evidence/v1.1.3/new-ids.json').read_text()))-set(__import__('json').loads((ROOT/'evidence/v1.1.4/new-ids.json').read_text())),{ID,'qwen3-next-80b-a3b-thinking-gguf-q6-k','glm-4-5-air-gguf-q4-k-m','huihui-glm-4-7-flash-abliterated-gguf-q4-k-m','huihui-qwen3-32b-abliterated-gguf-q4-k-m','huihui-gpt-oss-120b-abliterated-gguf-q4-k-m','huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m','huihui-qwen3-coder-next-abliterated-gguf-q4-k-m','huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m','qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m'});self.assertEqual(new['models'][ID]['preservation_policy'],'source-and-inference')
    def test_header_and_harmony_metadata(self):
        d=read(EV/'ggml-org--gpt-oss-120b-GGUF/gguf-header-summary.json');m=d['metadata'];self.assertEqual(m['general.architecture'],'gpt-oss');self.assertEqual(d['parameter_count'],116829156672);self.assertEqual(d['tensor_types'],{'8':146,'0':433,'39':108});self.assertEqual(m['gpt-oss.expert_count'],128);self.assertEqual(m['gpt-oss.expert_used_count'],4);self.assertEqual(m['gpt-oss.context_length'],131072);self.assertIn('reasoning_effort',m['tokenizer.chat_template']);self.assertIn('functions.',m['tokenizer.chat_template'])
        t=read(EV/'tokenizer-comparison.json');self.assertEqual(t['token_mismatches'],0);self.assertTrue(t['merge_lists_identical']);self.assertTrue(t['chat_template_identical'])
    def test_model_and_profile_dry_run_no_writes(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'absent'
            for opts in [['--model',ID],['--profile',PROFILE]]:
                out=io.StringIO()
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),contextlib.redirect_stdout(out):self.assertEqual(main(['--root',str(root),*opts,'--dry-run']),0)
                self.assertIn('LARGE ARCHIVE',out.getvalue());self.assertIn('Required with reserve:',out.getvalue());self.assertFalse(root.exists())
    def test_yes_requires_allow_large(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'absent'
            for opts in [['--model',ID],['--profile',PROFILE]]:
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),patch('model_acquire.space',return_value=(10**15,70800059277)),contextlib.redirect_stdout(io.StringIO()),self.assertRaisesRegex(ToolkitError,'--allow-large'):main(['--root',str(root),*opts,'--yes'])
            self.assertFalse(root.exists())
    def test_real_acquisition_mount_guard_before_resolution(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'absent'
            with patch('modelkit.mounts.is_mounted',return_value=False),patch('modelkit.huggingface.HuggingFaceAdapter',side_effect=AssertionError('must refuse earlier')),contextlib.redirect_stdout(io.StringIO()),self.assertRaises(ToolkitError):main(['--root',str(root),'--expected-mount',t,'--model',ID,'--yes','--allow-large'])
            self.assertFalse(root.exists())
    def test_reserve_still_refuses_even_with_large_allowed(self):
        with tempfile.TemporaryDirectory() as t,patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),patch('model_acquire.space',return_value=(1,70800059277)),contextlib.redirect_stdout(io.StringIO()),self.assertRaisesRegex(ToolkitError,'Insufficient space'):main(['--root',t,'--model',ID,'--yes','--allow-large'])
        self.assertEqual(space(ROOT,self.e['estimated_bytes'])[1],70800059277)
    def test_all_production_modules_byte_identical_except_version(self):
        base=read(EV/'baseline-PACKAGE-CHECKSUMS.json')
        for n,h in base.items():
            if (n.endswith('.py') and not n.startswith(('tests/','evidence/')) and n!='modelkit/__init__.py') or n in ['settings.json','requirements.txt','setup-linux.sh','setup-windows.ps1','tests/fixtures/core-v1.0.3.py.txt']:self.assertEqual(hashlib.sha256(legacy_bytes(ROOT/n)).hexdigest(),h,n)

class Payload1045Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'models';self.c=load_catalog(ROOT/'catalog.json');self.e=next(e for e in self.c['models'] if e['id']==ID);self.data={n:b'Never execute: '+n.encode() for n in self.e['required']};self.a=Fake(self.data);self.a.rev=PIN;self.out=contextlib.redirect_stdout(io.StringIO());self.out.__enter__()
    def tearDown(self):self.out.__exit__(None,None,None);self.tmp.cleanup()
    def test_verified_rerun_reuses_and_does_not_execute(self):
        with patch.object(pickle,'loads',side_effect=AssertionError('never execute')),patch.object(pickle,'load',side_effect=AssertionError('never execute')):
            p=plan(self.e,self.root,self.a);acquire(p,self.root,self.a);acquire(plan(self.e,self.root,self.a),self.root,self.a);self.assertEqual(len(self.a.calls),4);self.assertEqual(plan(self.e,self.root,self.a)['estimated_new_bytes'],0);rows=inventory(self.root,self.c,verify=True)['models'];self.assertEqual(next(r for r in rows if r['id']==ID)['status'],'verified')
    def test_interruption_resume_without_duplicate_completed_files(self):
        p=plan(self.e,self.root,self.a);original=self.a.download
        def stop(e,r,n,t,force=False):
            if n=='README.md':raise KeyboardInterrupt
            return original(e,r,n,t,force)
        with patch.object(self.a,'download',side_effect=stop),self.assertRaises(KeyboardInterrupt):acquire(p,self.root,self.a)
        self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'partial');acquire(plan(self.e,self.root,self.a),self.root,self.a);self.assertEqual(self.a.calls.count(WEIGHT),1)
    def test_corrupted_download_rejected_and_quarantined(self):
        original=self.a.download
        def corrupt(e,r,n,t,force=False):
            original(e,r,n,t,force);p=t/n
            if n==WEIGHT:p.write_bytes(b'bad')
            return p
        p=plan(self.e,self.root,self.a)
        with patch.object(self.a,'download',side_effect=corrupt),patch('modelkit.core.time.sleep'),self.assertRaises(ToolkitError):acquire(p,self.root,self.a,retries=1)
        target=Path(p['target']);self.assertNotEqual(read(target/'manifest.json')['status'],'verified');self.assertTrue(list(target.glob('quarantine/*/'+WEIGHT)))
    def test_original_verified_does_not_mark_gguf_downloaded(self):
        old=next(e for e in self.c['models'] if e['id']==SOURCE);a=Fake({'config.json':b'{}','model.safetensors':b'old verified inert fixture'});a.rev=old['revision'];p=plan(old,self.root,a);acquire(p,self.root,a);before=(Path(p['target'])/'manifest.json').read_bytes();d=acc.collect(self.root,self.c);rows={r['id']:r for r in d['models']};self.assertEqual(rows[SOURCE]['status'],'downloaded-verified');self.assertEqual(rows[ID]['status'],'cataloged-not-downloaded');self.assertEqual((Path(p['target'])/'manifest.json').read_bytes(),before)
    def test_inventory_csv_json_text_new_variant(self):
        acquire(plan(self.e,self.root,self.a),self.root,self.a);d=acc.collect(self.root,self.c,acc.policies(ROOT/'preservation-policy.json'));rows=json.loads(acc.render(d,'json'))['models'];r=next(r for r in rows if r['id']==ID);self.assertEqual(r['status'],'downloaded-verified');self.assertEqual(r['preservation_policy'],'source-and-inference');self.assertEqual(r['active_parameters'],5100000000);self.assertGreaterEqual(r['storage_bytes'],sum(len(x) for x in self.data.values()));cs=list(csv.DictReader(io.StringIO(acc.render(d,'csv'))));self.assertEqual(next(r for r in cs if r['id']==ID)['source_kind'],'third-party-derived');self.assertIn(ID,acc.render(d))

from maintenance_guard import legacy_bytes
