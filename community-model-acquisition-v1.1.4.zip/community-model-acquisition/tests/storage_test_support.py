"""Old command tests isolate legacy behavior from the new volume boundary.

Only StorageSession is replaced here; inherited presence-guard tests still run.
The v1.1.0 tests exercise the actual session with controlled mount probes.
"""
from types import SimpleNamespace
from contextlib import contextmanager
from unittest.mock import patch
@contextmanager
def fixture_session(root,*args):yield SimpleNamespace(root=root)
def main(argv=None):
    from model_acquire import main as run
    with patch('modelkit.volume.StorageSession',fixture_session):return run(argv)
def registry_main(argv=None):
    from model_registry import main as run
    with patch('modelkit.volume.StorageSession',fixture_session):return run(argv)
