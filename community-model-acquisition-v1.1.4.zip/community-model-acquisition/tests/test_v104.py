"""Preservation expansion: metadata-only evidence and tiny payload regressions."""
import ast,contextlib,copy,hashlib,io,json,re,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,select,plan,acquire,read,write,ToolkitError,space
from modelkit.storage import scan
from storage_test_support import main
ROOT=Path(__file__).resolve().parents[1];EV=ROOT/'evidence/v1.0.4'
IDS=read(EV/'new-variant-ids.json');PROFILES=read(EV/'profile-membership.json')
def protected_core_source(source):
    """Compare source, not AST serialization; only two named definitions may vary.

    AST is used solely for source locations, supported on Python 3.10+.
    Keep all other characters, imports, definitions and module-level statements.
    Reject missing/duplicate allowed definitions instead of hiding extra code.
    """
    allowed = {'load_catalog', 'select'}
    definitions = [node for node in ast.parse(source).body
                   if isinstance(node, ast.FunctionDef) and node.name in allowed]
    if len(definitions) != 2 or {node.name for node in definitions} != allowed:
        raise ValueError('Expected exactly one load_catalog and one select definition')
    lines = source.splitlines(keepends=True)
    for node in sorted(definitions, key=lambda item: item.lineno, reverse=True):
        start = min([node.lineno] + [d.lineno for d in node.decorator_list]) - 1
        lines[start:node.end_lineno] = ['# permitted profile definition: ' + node.name + '\n']
    return ''.join(lines)

class Metadata:
    def __init__(self):self.requests=[]
    def resolve(self,e):
        p=EV/e['repository'].replace('/','--')/'api.json'
        if not p.exists():p=ROOT/'evidence/v1.0.4.2'/e['repository'].replace('/','--')/'api.json'
        if not p.exists():
            paths=[ROOT/'evidence/v1.0.3',ROOT/'evidence/v1.0.2',ROOT/'evidence']
            p=next(p/(e['repository'].replace('/','--')+'.json') for p in paths if (p/(e['repository'].replace('/','--')+'.json')).exists())
        d=read(p);self.requests.append((e['repository'],e['revision']));assert d['sha']==e['revision']
        return {'revision':d['sha'],'metadata':d,'gated':d.get('gated',False),'files':[{'path':f['rfilename'],'size':f['size'],'sha256':(f.get('lfs') or {}).get('sha256'),'git_blob_sha1':None if f.get('lfs') else f.get('blobId')} for f in d['siblings']]}
    def download(self,*args,**kwargs):raise AssertionError('No weight downloads allowed')
class Catalog104Tests(unittest.TestCase):
    def setUp(self):self.c=load_catalog(ROOT/'catalog.json');self.entries={e['id']:e for e in self.c['models']};self.new=[self.entries[i] for i in IDS]
    def test_all_variants_parse(self):
        self.assertEqual(len(self.new),11);self.assertEqual(len(self.c['models']),154);self.assertEqual(len({e['family'] for e in self.new}),5)
    def test_exact_repositories_and_pins(self):
        a=Metadata()
        for e in self.new:
            self.assertRegex(e['revision'],r'^[0-9a-f]{40}$');p=plan(e,Path('/tmp/no-v104-writes'),a);self.assertEqual(p['revision'],e['revision'])
        self.assertEqual(a.requests,[(e['repository'],e['revision']) for e in self.new])
    def test_repository_and_selected_sizes(self):
        for e in self.new:
            d=read(EV/e['repository'].replace('/','--')/'api.json');p=plan(e,Path('/tmp/no-v104-writes'),Metadata())
            self.assertEqual(sum(f['size'] for f in p['files']),e['estimated_bytes']);self.assertEqual(sum(s['size'] for s in d['siblings']),e['repository_total_bytes']);self.assertGreater(e['estimated_bytes'],50*10**9)
            self.assertTrue(all(f['sha256'] for f in p['files'] if f['path'].endswith(('.gguf','.safetensors'))))
    def test_every_source_file_preserved(self):
        for e in self.new:
            if e['format']=='GGUF':continue
            d=read(EV/e['repository'].replace('/','--')/'api.json');p=plan(e,Path('/tmp/no-v104-writes'),Metadata())
            self.assertEqual({f['path'] for f in p['files']},{s['rfilename'] for s in d['siblings']});self.assertEqual(set(e['required']),{f['path'] for f in p['files']})
    def test_index_shard_enumeration(self):
        for e in self.new:
            d=EV/e['repository'].replace('/','--');selected={f['path'] for f in plan(e,Path('/tmp/no-v104-writes'),Metadata())['files']}
            for idx in d.glob('*.safetensors.index.json'):self.assertTrue(set(read(idx)['weight_map'].values())<=selected,e['id'])
    def test_gguf_shards_and_no_unwanted_quants(self):
        for e in self.new:
            if e['format']!='GGUF':continue
            files=[f['path'] for f in plan(e,Path('/tmp/no-v104-writes'),Metadata())['files']];weights=[f for f in files if '/' in f and f.endswith('.gguf')]
            parts=[re.search(r'-(\d{5})-of-(\d{5})\.gguf$',f).groups() for f in weights];self.assertEqual({int(a) for a,b in parts},set(range(1,int(parts[0][1])+1)));self.assertTrue(all(int(b)==len(parts) for a,b in parts));self.assertFalse(any('Shard_Rewrite' in f or 'imatrix' in f for f in files))
    def test_multimodal_projectors_required(self):
        for e in self.new:
            if e['format']!='GGUF' or not e['multimodal']:continue
            self.assertEqual(len(e['multimodal_artifacts']),1);projector=e['multimodal_artifacts'][0];self.assertIn(projector,e['include']);self.assertIn(projector,e['required'])
            a=Metadata();meta=a.resolve(e);meta['files']=[f for f in meta['files'] if f['path']!=projector]
            with patch.object(a,'resolve',return_value=meta),self.assertRaises(ToolkitError):plan(e,Path('/tmp/no-v104-writes'),a)
    def test_multimodal_sources_have_integrated_vision(self):
        for e in self.new:
            if e['format']=='GGUF' or not e['multimodal']:continue
            d=EV/e['repository'].replace('/','--');indices=list(d.glob('*.safetensors.index.json'));self.assertTrue(indices)
            keys=[k for p in indices for k in read(p)['weight_map']];self.assertTrue(any(any(x in k.lower() for x in ['vision','visual']) for k in keys),e['id']);self.assertTrue(any('processor' in f for f in e['required']))
    def test_provenance_and_variant_roles(self):
        for e in self.new:
            role=e['variant_role'];expected={'source-weights':'official-upstream','official-quantized':'official-derived','portable-gguf':'third-party-derived'}[role];self.assertEqual(e['source_kind'],expected)
            self.assertEqual(e['publisher'],e['repository'].split('/')[0]);self.assertTrue(e['base_model']);self.assertTrue(e['training_suitability'])
            if role!='source-weights':self.assertTrue(e['quantizer_converter'])
        self.assertEqual(self.entries['mistral-small-4-119b-nvfp4']['format'],'Safetensors')
    def test_native_precision_and_licenses(self):
        self.assertIn('INT4',self.entries['kimi-k2-7-code-original']['tensor_precision']);self.assertIn('FP8',self.entries['mistral-small-4-119b-original']['tensor_precision'])
        self.assertEqual(self.entries['glm-5-3-original']['license'],'glm-5.3');self.assertEqual(self.entries['glm-5-3-flash-original']['license'],'mit');self.assertEqual(self.entries['minimax-m3-original']['license'],'minimax-community')
        for key in ['glm-5-3-original','glm-5-3-flash-original']:self.assertTrue(self.entries[key]['repository'].endswith('-BF16'))
    def test_taxonomy_priority_runtime(self):
        for e in self.new:
            self.assertIn('agentic-coding',e['capabilities']);self.assertIn('long-context',e['capabilities']);self.assertEqual(e['preservation_priority'],'high' if e['family']=='glm-5-3' else 'core');self.assertFalse(e['cpu_practical']);self.assertTrue(e['multi_gpu_expected'])
            for k in ['recommended_runtime','minimum_memory_note','preferred_hardware','llama_cpp_support','vllm_support','sglang_support']:self.assertTrue(e[k])
        e=self.entries['glm-5-3-flash-gguf-ud-q4-k-xl'];self.assertIn('experimental-runtime',e['capabilities']);self.assertTrue(e['experimental_runtime_notes']);self.assertNotIn('minimax-m3-gguf-ud-q4-k-m',self.entries)
    def test_new_profiles_exact_members(self):
        for p,ids in PROFILES.items():self.assertEqual([e['id'] for e in select(self.c,p) if e['id']!='qwen3-coder-next-original'],ids)
        self.assertEqual(len(select(self.c,'agentic-core-originals')),5);self.assertEqual(len(select(self.c,'agentic-core-runnable')),5);self.assertEqual(len(select(self.c,'research-agent')),4);self.assertEqual(len(select(self.c,'coding-agent')),3)
        self.assertTrue(all(e['variant_role']=='source-weights' for e in select(self.c,'agentic-core-originals')))
        self.assertTrue(all(e.get('variant_role')!='source-weights' for e in select(self.c,'agentic-core-runnable')))
    def test_old_models_and_profiles_unchanged(self):
        old=read(EV/'v1.0.3-catalog-baseline.json')
        for e in old['models']:self.assertEqual(self.entries[e['id']],e)
        for p in old['profiles']:
            self.assertEqual(self.c['profiles'][p],old['profiles'][p])
            if p!='all':self.assertEqual([e for e in select(self.c,p) if e['id'] not in {'qwen3-coder-next-original','qwen3-coder-next-gguf-q6-k'}],select(old,p))
    def test_profile_extension_validation_and_deduplication(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'c.json';c=copy.deepcopy(self.c);c['profile_members']['coding-agent']=['kimi-k2-7-code-gguf-ud-q4-k-xl']*2;write(p,c);self.assertEqual(len(select(load_catalog(p),'coding-agent')),3)
            for value in [['missing'],[12],'bad']:
                c['profile_members']['coding-agent']=value;write(p,c)
                with self.assertRaises(ToolkitError):load_catalog(p)
            for value in [None, [], 'invalid']:
                c['profile_members']=value;write(p,c)
                with self.assertRaisesRegex(ToolkitError,'profile_members'):load_catalog(p)
    def test_dry_run_every_variant_and_profile(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'not created'
            for opts in [['--model',i] for i in IDS]+[['--profile',p] for p in PROFILES]:
                out=io.StringIO()
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),contextlib.redirect_stdout(out):self.assertEqual(main(['--root',str(root),*opts,'--dry-run']),0)
                for word in ['LARGE ARCHIVE','Estimated new files:','Free:','Required with reserve:']:self.assertIn(word,out.getvalue())
                self.assertFalse(root.exists())
    def test_yes_never_bypasses_large_guard(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'not created'
            for opts in [['--model',i] for i in IDS]+[['--profile',p] for p in PROFILES]:
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),patch('model_acquire.space',return_value=(10**16,10**15)),contextlib.redirect_stdout(io.StringIO()):
                    with self.assertRaisesRegex(ToolkitError,'--allow-large'):main(['--root',str(root),*opts,'--yes'])
                self.assertFalse(root.exists())
    def test_terabyte_totals_and_reserve(self):
        entries=select(self.c,'agentic-core-originals');n=sum(plan(e,Path('/tmp/no-v104-writes'),Metadata())['total_bytes'] for e in entries);self.assertGreater(n,3*10**12);self.assertEqual(n,sum(e['estimated_bytes'] for e in entries));self.assertEqual(space(Path('/tmp'),n)[1],int(n*1.10)+1024**3)
    def test_application_behavior_unchanged(self):
        checks=read(EV/'v1.0.3-package-checksums.json')
        for name in ['model_acquire.py','modelkit/huggingface.py','modelkit/mounts.py','modelkit/storage.py','settings.json','requirements.txt','setup-linux.sh','setup-windows.ps1']:self.assertEqual(hashlib.sha256(legacy_bytes(ROOT/name)).hexdigest(),checks[name])
        baseline=(ROOT/'tests/fixtures/core-v1.0.3.py.txt').read_bytes()
        self.assertEqual(hashlib.sha256(baseline).hexdigest(),checks['modelkit/core.py'])
        actual=legacy_bytes(ROOT/'modelkit/core.py')
        self.assertEqual(protected_core_source(actual.decode('utf-8')),
                         protected_core_source(baseline.decode('utf-8')))
    def test_source_guard_does_not_serialize_ast(self):
        with patch('ast.dump',side_effect=AssertionError('AST serialization is forbidden')):
            self.test_application_behavior_unchanged()
    def test_source_guard_detects_protected_and_module_changes(self):
        source=(ROOT/'tests/fixtures/core-v1.0.3.py.txt').read_bytes().decode('utf-8')
        expected=protected_core_source(source)
        for node in ast.parse(source).body:
            if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name not in {'load_catalog','select'}:
                with self.subTest(definition=node.name):
                    prefix='class ' if isinstance(node,ast.ClassDef) else 'def '
                    changed=source.replace(prefix+node.name+'(',prefix+node.name+'_changed(',1)
                    self.assertNotEqual(protected_core_source(changed),expected)
        for changed in [source.replace('class ToolkitError(Exception)', 'class ToolkitError(RuntimeError)'),
                        source.replace("raise ToolkitError('Unknown file size; refusing unbounded download')", 'pass'),
                        source.replace('import hashlib, json', 'import json'),
                        source+'\nUNEXPECTED_STATE = True\n',
                        source.replace('class ToolkitError(Exception): pass\n','')]:
            self.assertNotEqual(protected_core_source(changed),expected)
    def test_source_guard_allows_only_named_profile_definitions(self):
        source=(ROOT/'tests/fixtures/core-v1.0.3.py.txt').read_bytes().decode('utf-8')
        expected=protected_core_source(source)
        lines=source.splitlines(keepends=True)
        nodes=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in {'load_catalog','select'}]
        for node in reversed(nodes):
            lines[node.lineno-1:node.end_lineno]=['def '+node.name+'(*args):\n    return None\n']
        self.assertEqual(protected_core_source(''.join(lines)),expected)
    def test_source_guard_rejects_missing_or_duplicate_exceptions(self):
        source=(ROOT/'tests/fixtures/core-v1.0.3.py.txt').read_bytes().decode('utf-8')
        for name in ['load_catalog','select']:
            for changed in [source.replace('def '+name+'(', 'def renamed_'+name+'(',1),
                            source+'\ndef '+name+'(*args):\n    pass\n']:
                with self.assertRaises(ValueError):protected_core_source(changed)
    def test_sharded_multimodal_acquisition_resume(self):
        from test_toolkit import Fake
        e=copy.deepcopy(self.entries['minimax-m3-mxfp8']);e.update(include=['*'],required=['model-00001.safetensors','model-00002.safetensors','processor_config.json','model.safetensors.index.json'])
        data={'model-00001.safetensors':b'tiny vision weights','model-00002.safetensors':b'tiny text weights','processor_config.json':b'{}','model.safetensors.index.json':json.dumps({'weight_map':{'vision':'model-00001.safetensors','text':'model-00002.safetensors'}}).encode()}
        a=Fake(data);a.rev=e['revision'];orig=a.download
        def stop(entry,rev,name,target,force=False):
            if name=='model-00002.safetensors':raise KeyboardInterrupt()
            return orig(entry,rev,name,target,force)
        with tempfile.TemporaryDirectory() as t,contextlib.redirect_stdout(io.StringIO()):
            root=Path(t)/'models';p=plan(e,root,a)
            with patch.object(a,'download',side_effect=stop),self.assertRaises(KeyboardInterrupt):acquire(p,root,a)
            self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'partial');self.assertLess(plan(e,root,a)['estimated_new_bytes'],p['total_bytes'])
            acquire(plan(e,root,a),root,a);self.assertEqual(a.calls.count('model-00001.safetensors'),1);self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'verified');self.assertEqual(plan(e,root,a)['estimated_new_bytes'],0)
    def test_gguf_multishard_and_projector_verified(self):
        from test_toolkit import Fake
        e=self.entries['glm-5-3-flash-gguf-ud-q4-k-xl'];a=Fake({name:('fixture '+name).encode() for name in e['include']});a.rev=e['revision']
        with tempfile.TemporaryDirectory() as t,contextlib.redirect_stdout(io.StringIO()):
            root=Path(t)/'models';p=plan(e,root,a);acquire(p,root,a);m=read(Path(p['target'])/'manifest.json');self.assertEqual(m['status'],'verified');self.assertIn('mmproj-BF16.gguf',m['files']);self.assertEqual(set(m['files']),set(e['required']));inventory=scan(root,self.c);self.assertEqual(inventory['summary']['revision_count'],1);self.assertEqual(inventory['models'][0]['status'],'verified');self.assertEqual(inventory['summary']['total_logical_bytes'],sum(f.stat().st_size for f in Path(p['target']).rglob('*') if f.is_file()))
if __name__=='__main__':unittest.main(verbosity=2)

from maintenance_guard import legacy_bytes
