import contextlib,hashlib,io,json,os,shutil,stat,sys,tempfile,unittest,zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit import core,volume,storage,registry,archive_report
from modelkit.workbook import xlsx
from model_acquire import main
from model_registry import main as registry_main
from test_toolkit import Fake,ENTRY,CAT
ROOT=Path(__file__).resolve().parents[1]

class VolumeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name);self.root=self.base/'archive';self.root.mkdir()
        self.settings=self.base/'settings.json';self.rule={'root':str(self.root),'expected_mount':str(self.root),'expected_uuid':'test-uuid','filesystem':'ext4'}
        self.settings.write_text(json.dumps({'default_root':str(self.root),'mount_guards':[self.rule]}))
        self.record={'mount':self.root,'id':'20','device':'8:1','fsroot':'/','fstype':'ext4','options':['rw'],'super_options':['rw']}
        self.catalog=self.base/'catalog.json';core.write(self.catalog,CAT)
        self.out=contextlib.redirect_stdout(io.StringIO());self.out.__enter__()
    def tearDown(self):self.out.__exit__(None,None,None);self.temp.cleanup()
    @contextlib.contextmanager
    def probes(self):
        with patch.object(volume,'identify',return_value=self.record),patch.object(volume,'mount_records',return_value=[self.record]):yield
    def args(self,*a):return ['--root',str(self.root),'--settings',str(self.settings),'--catalog',str(self.catalog),*a]
    def session(self):return volume.StorageSession(self.root,self.settings)
    def test_planning_flags_cannot_bypass_configure_guard(self):
        for flag in ['--dry-run','--offline-plan']:
            for action in ['--configure','--status','--verify']:
                with patch.object(volume,'identify',side_effect=AssertionError('no action')),self.assertRaisesRegex(core.ToolkitError,'cannot be combined'):main(self.args(action,flag))
        self.assertEqual(list(self.root.iterdir()),[])
    def test_readonly_preflight_allows_full_source_volume(self):
        import model_storage
        with self.probes(),patch('model_storage.identify',return_value=self.record),patch('model_storage.space',return_value=(0,1024**3)):
            self.assertEqual(model_storage.main(['--root',str(self.root),'--settings',str(self.settings),'--read-only']),0)
            self.assertEqual(model_storage.main(['--root',str(self.root),'--settings',str(self.settings)]),1)
    def test_default_root_is_dedicated(self):self.assertEqual(core.read(ROOT/'settings.json')['default_root'],'/srv/ai-models')
    def test_root_configurable(self):self.assertEqual(volume.configured_root(None,self.settings),self.root)
    def test_missing_identity_rule(self):
        with self.assertRaisesRegex(core.ToolkitError,'No approved'):volume.StorageSession(self.base/'other',self.settings)
    def test_override_cannot_bypass_uuid(self):
        with self.assertRaisesRegex(core.ToolkitError,'cannot override'):volume.StorageSession(self.root,self.settings,self.base)
    def test_original_archive_read_only(self):
        with self.assertRaisesRegex(core.ToolkitError,'read-only'):volume.StorageSession(Path('/srv/community-library/models'),ROOT/'settings.json')
    def test_backup_development_rule(self):
        rule=volume.rule_for(Path('/srv/system-backups/development/acquisition'),ROOT/'settings.json');self.assertEqual(rule['expected_uuid'],'ddee4515-4a57-4b2f-a074-89b49b87b7fd')
        with self.assertRaises(core.ToolkitError):volume.rule_for(Path('/srv/system-backups/backups'),ROOT/'settings.json')
    def test_missing_mount_exists_but_refused(self):
        with patch.object(volume,'mount_records',return_value=[]),self.assertRaisesRegex(core.ToolkitError,'No fallback'):volume.identify(self.root,'test-uuid')
    def test_wrong_uuid_device_refused(self):
        fake=SimpleNamespace(st_mode=stat.S_IFBLK,st_rdev=os.makedev(8,2),st_dev=os.makedev(8,1))
        with patch.object(volume,'mount_records',return_value=[self.record]),patch.object(Path,'is_symlink',return_value=False),patch.object(Path,'stat',return_value=fake),self.assertRaisesRegex(core.ToolkitError,'UUID mismatch'):volume.identify(self.root,'test-uuid')
    def test_correct_uuid_device(self):
        fake=SimpleNamespace(st_mode=stat.S_IFBLK,st_rdev=os.makedev(8,1),st_dev=os.makedev(8,1))
        with patch.object(volume,'mount_records',return_value=[self.record]),patch.object(Path,'is_symlink',return_value=False),patch.object(Path,'stat',return_value=fake):self.assertEqual(volume.identify(self.root,'test-uuid'),self.record)
    def test_missing_uuid_link(self):
        with patch.object(volume,'mount_records',return_value=[self.record]),self.assertRaisesRegex(core.ToolkitError,'Cannot confirm'):volume.identify(self.root,'not-a-real-uuid')
    def test_nonlinux_readonly_usable_write_refused(self):
        with patch.object(volume.sys,'platform','win32'),self.assertRaisesRegex(core.ToolkitError,'require Linux'):volume.identify(self.root,'test-uuid')
        self.assertEqual(main(self.args('--inventory')),0)
    def test_readonly_mount_refused(self):
        fake=SimpleNamespace(st_mode=stat.S_IFBLK,st_rdev=os.makedev(8,1),st_dev=os.makedev(8,1))
        with patch.object(volume,'mount_records',return_value=[{**self.record,'options':['ro']}]),patch.object(Path,'is_symlink',return_value=False),patch.object(Path,'stat',return_value=fake),self.assertRaisesRegex(core.ToolkitError,'read-only'):volume.identify(self.root,'test-uuid')
    def test_bind_subdirectory_refused(self):
        with patch.object(volume,'mount_records',return_value=[{**self.record,'fsroot':'/other'}]),self.assertRaisesRegex(core.ToolkitError,'Bind'):volume.identify(self.root,'test-uuid')
    def test_symlink_root_refused(self):
        link=self.base/'link';link.symlink_to(self.root,target_is_directory=True)
        with self.assertRaisesRegex(core.ToolkitError,'symlink'):volume.configured_root(link,self.settings)
    def test_nested_mount_refused(self):
        with patch.object(volume,'identify',return_value=self.record),patch.object(volume,'mount_records',return_value=[self.record,{**self.record,'mount':self.root/'other'}]),self.assertRaisesRegex(core.ToolkitError,'Nested'):self.session().__enter__()
    def test_intervening_mount_above_descendant_root_refused(self):
        root=self.root/'models'
        with patch.object(volume,'mount_records',return_value=[{**self.record,'mount':self.base},self.record]),self.assertRaisesRegex(core.ToolkitError,'intervening'):volume.validate_location(root,self.base)
    def test_permission_refused(self):
        with self.probes(),patch.object(os,'access',return_value=False),self.assertRaisesRegex(core.ToolkitError,'writable'):self.session().__enter__()
    def test_minimum_reserve_refused(self):
        with self.probes(),patch.object(os,'statvfs',return_value=SimpleNamespace(f_flag=0,f_bavail=0,f_frsize=4096)),self.assertRaisesRegex(core.ToolkitError,'reserve'):self.session().__enter__()
    def test_configure_pinned_and_no_fd_leak(self):
        with self.probes():self.assertEqual(main(self.args('--configure')),0)
        self.assertTrue((self.root/'_toolkit/logs').is_dir());self.assertIsNone(volume.active_session())
    def test_pinned_symlink_allowance_is_narrow(self):
        with self.probes(),self.session() as s:
            p=core.safe_path(s.root,'x/__init__.py');self.assertTrue(p.is_relative_to(s.root))
            link=s.root/'bad';os.symlink('/tmp',link)
            with self.assertRaises(core.ToolkitError):core.safe_path(s.root,'bad/data')
    def test_unpinned_archive_write_refused(self):
        with self.probes(),self.session():
            with self.assertRaisesRegex(core.ToolkitError,'Unpinned'):(self.root/'bad').write_bytes(b'x')
        self.assertFalse((self.root/'bad').exists())
    def test_guard_rechecks_at_each_write(self):
        with self.probes(),self.session() as s:
            with patch.object(volume,'identify',side_effect=core.ToolkitError('disconnected')):
                with self.assertRaisesRegex(core.ToolkitError,'disconnected'):core.write(s.root/'manifest.json',{'status':'verified'})
        self.assertFalse((self.root/'manifest.json').exists())
    def test_mount_instance_change_same_uuid_refused(self):
        with self.probes(),self.session() as s:
            with patch.object(volume,'identify',return_value={**self.record,'id':'21'}),self.assertRaisesRegex(core.ToolkitError,'changed'):s.check()
    def test_descriptor_never_falls_through_to_replacement(self):
        with self.probes(),self.session() as s:
            # Namespace replacement simulation, not an actual USB/hardware test.
            volume._LOCAL.checking=True
            try:os.rename(self.root,self.base/'detached');self.root.mkdir()
            finally:volume._LOCAL.checking=False
            with self.assertRaisesRegex(core.ToolkitError,'replaced'):core.write(s.root/'manifest.json',{'status':'verified'})
            # A raw already-held descriptor still names the old directory.
            self.assertEqual(os.fstat(s.fd).st_ino,(self.base/'detached').stat().st_ino)
        self.assertEqual(list(self.root.iterdir()),[])
    def test_successful_acquisition_and_public_report_paths(self):
        a=Fake()
        with self.probes(),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=a):self.assertEqual(main(self.args('--profile','small-cpu','--yes')),0)
        m=list(self.root.glob('*/*/*/manifest.json'));self.assertEqual(len(m),1);self.assertEqual(core.read(m[0])['status'],'verified')
        for p in self.root.rglob('*.json'):self.assertNotIn('/proc/self/fd',p.read_text())
    def test_reuse_completed_no_redownload(self):
        a=Fake()
        with self.probes(),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=a):
            self.assertEqual(main(self.args('--profile','small-cpu','--yes')),0)
            with patch.object(a,'download',side_effect=AssertionError('redownload')):self.assertEqual(main(self.args('--profile','small-cpu','--yes')),0)
    def test_disconnect_after_download_never_verified(self):
        a=Fake();download=a.download;lost=[False]
        def identify(*args):
            if lost[0]:raise core.ToolkitError('disconnected')
            return self.record
        def interrupted(*args,**kw):download(*args,**kw);lost[0]=True
        with patch.object(volume,'identify',side_effect=identify),patch.object(volume,'mount_records',return_value=[self.record]),self.session() as s:
            p=core.plan(ENTRY,s.root,a)
            with patch.object(a,'download',side_effect=interrupted),self.assertRaisesRegex(core.ToolkitError,'disconnected'):core.acquire(p,s.root,a)
        manifests=list(self.root.glob('*/*/*/manifest.json'));self.assertEqual(core.read(manifests[0])['status'],'downloading')
        lost[0]=False
        with self.probes(),self.session() as s:
            p=core.plan(ENTRY,s.root,a)
            def remaining(e,rev,name,target,force=False):
                self.assertNotEqual(name,p['files'][0]['path']);return download(e,rev,name,target,force)
            with patch.object(a,'download',side_effect=remaining):
                # Fake has one selected payload. Its upstream hash permits reuse.
                core.acquire(p,s.root,a)
        self.assertEqual(core.read(manifests[0])['status'],'verified')
    def test_status_and_verify_guarded(self):
        for flag in ['--status','--verify']:
            with patch.object(volume,'identify',side_effect=core.ToolkitError('bad UUID')),self.assertRaisesRegex(core.ToolkitError,'bad UUID'):main(self.args(flag))
        self.assertEqual(list(self.root.iterdir()),[])
    def test_registry_writes_guarded(self):
        with patch.object(volume,'identify',side_effect=core.ToolkitError('bad UUID')),self.assertRaisesRegex(core.ToolkitError,'bad UUID'):registry_main(self.args('--verify-instance','x'))
    def test_dryrun_and_inventory_do_not_require_mount(self):
        with patch.object(volume,'identify',side_effect=AssertionError('should not probe')),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Fake()):
            self.assertEqual(main(self.args('--profile','small-cpu','--dry-run')),0);self.assertEqual(main(self.args('--inventory')),0)
        self.assertEqual(list(self.root.iterdir()),[])
    def test_plan_capacity_interlock(self):
        with self.probes(),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Fake()),patch('model_acquire.space',return_value=(0,1024**3)),self.assertRaisesRegex(core.ToolkitError,'Insufficient space'):main(self.args('--profile','small-cpu','--yes'))
    def test_large_yes_does_not_bypass(self):
        a=Fake();p=core.plan(ENTRY,self.root,a);p['total_bytes']=60*10**9
        with self.probes(),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=a),patch('model_acquire.plan',return_value=p),patch('model_acquire.space',return_value=(10**12,10**9)),self.assertRaisesRegex(core.ToolkitError,'allow-large'):main(self.args('--profile','small-cpu','--yes'))
    def test_hub_pinned_engine_arguments(self):
        with self.probes(),self.session() as s,patch('huggingface_hub.file_download._hf_hub_download_to_local_dir',return_value='ok') as call:
            self.assertEqual(s.hub_download(ENTRY,'a'*40,'weights.safetensors',s.root/'payload',False),'ok')
            self.assertEqual(call.call_args.kwargs['local_dir'],s.root/'payload');self.assertEqual(call.call_args.kwargs['revision'],'a'*40);self.assertFalse(call.call_args.kwargs['force_download'])
    def test_hub_version_mismatch_refused(self):
        with self.probes(),self.session() as s,patch('huggingface_hub.__version__','future'),self.assertRaisesRegex(core.ToolkitError,'reviewed'):s.hub_download(ENTRY,'a'*40,'x',s.root,False)
    def test_migrated_archive_manifest_unchanged(self):
        a=Fake();p=core.plan(ENTRY,self.root,a);core.acquire(p,self.root,a)
        old=list(self.root.glob('*/*/*/manifest.json'))[0];before=old.read_bytes();dest=self.base/'migrated';shutil.copytree(self.root,dest,copy_function=shutil.copy2)
        result=core.inventory(dest,CAT);self.assertEqual(result['models'][0]['status'],'verified');self.assertEqual((dest/old.relative_to(self.root)).read_bytes(),before)
        self.assertEqual(core.plan(ENTRY,dest,a)['estimated_new_bytes'],0)
        copied=core.read(dest/old.relative_to(self.root))
        for f in copied['expected']:self.assertIsNotNone(core.inspect_file(dest/old.relative_to(self.root).parent/'payload'/f['path'],f,copied['files'][f['path']]))
        self.assertEqual((dest/old.relative_to(self.root)).read_bytes(),before)
    def test_inventory_report_states_and_xlsx(self):
        a=Fake();p=core.plan(ENTRY,self.root,a);core.acquire(p,self.root,a)
        catalog={**CAT,'models':[ENTRY,{**ENTRY,'id':'not-here'}]}
        data=archive_report.collect(self.root,catalog,{'models':{}},self.settings);rows={r['id']:r for r in data['models']}
        self.assertEqual(rows['not-here']['status'],'cataloged-not-downloaded');self.assertEqual(rows[ENTRY['id']]['status'],'downloaded-verified');self.assertTrue(rows[ENTRY['id']]['archive_relative_location']);self.assertEqual(rows[ENTRY['id']]['recorded_file_count'],len(p['files']))
        payload=archive_report.workbook(data)
        with zipfile.ZipFile(io.BytesIO(payload)) as z:self.assertIsNone(z.testzip());self.assertIn('downloaded-verified',z.read('xl/worksheets/sheet1.xml').decode())
        Path(p['target'],'payload',p['files'][0]['path']).unlink();data=archive_report.collect(self.root,catalog,{'models':{}},self.settings)
        self.assertEqual(data['models'][0]['status'],'incomplete')
    def test_spreadsheet_text_not_formula(self):
        payload=xlsx([('Test',[['Header'],['=HYPERLINK("evil")'],['+cmd'],[12]])])
        with zipfile.ZipFile(io.BytesIO(payload)) as z:
            xml=z.read('xl/worksheets/sheet1.xml').decode();self.assertNotIn('<f>',xml);self.assertIn('<v>12</v>',xml)
        self.assertEqual(payload,xlsx([('Test',[['Header'],['=HYPERLINK("evil")'],['+cmd'],[12]])]))
    def test_capacity_unconfirmed_not_ssd_numbers(self):
        d=archive_report.collect(self.root,CAT,{'models':{}},self.settings)
        self.assertEqual(d['capacity']['identity'],'unconfirmed');self.assertIsNone(d['capacity']['available_bytes'])
    def test_external_paths_preserved(self):
        spec={'instance_id':'external','model_id':ENTRY['id'],'artifact_kind':'model-artifacts','files':{'weights.safetensors':'/srv/community-library/models/old/payload/weights.safetensors'},'remote_reported':True,'host':'other'}
        registry.register(self.root,CAT,spec);p=registry.registry_path(self.root);before=p.read_bytes();d=archive_report.collect(self.root,CAT,{'models':{}},self.settings)
        self.assertEqual(p.read_bytes(),before);self.assertTrue(any('preserved' in r['path_review'] for r in d['models']))
    def test_catalog_policy_unchanged(self):
        for name in ['catalog.json','preservation-policy.json']:
            self.assertEqual(__import__('education_guard').baseline_bytes(ROOT/name),(ROOT/'evidence/v1.0.4.8.1'/('baseline-'+name)).read_bytes())
    def test_mountinfo_parse_failure_closed(self):
        with patch.object(Path,'read_text',return_value='malformed'),self.assertRaisesRegex(core.ToolkitError,'Cannot read'):volume.mount_records()
    def test_report_export_does_not_overwrite(self):
        import model_report
        out=self.base/'report.xlsx';args=self.args('--output',str(out))
        self.assertEqual(model_report.main(args),0)
        with self.assertRaises(FileExistsError):model_report.main(args)
    def test_report_cannot_write_archive(self):
        import model_report
        with self.assertRaisesRegex(core.ToolkitError,'outside'):model_report.main(self.args('--output',str(self.root/'report.xlsx')))

    # The integration case executes the pinned HF local-dir engine; only network
    # metadata and transport are replaced. No real weights or code are fetched.
    def test_real_hub_local_engine_retains_fd_paths(self):
        payload=b'tiny inert fixture';digest=hashlib.sha256(payload).hexdigest()
        def http(url,file,**kw):
            self.assertTrue(str(file.name).startswith('/proc/self/fd/'));file.write(payload)
        with self.probes(),self.session() as s,patch('huggingface_hub.file_download._get_metadata_or_catch_error',return_value=('https://fixture.invalid',digest,'a'*40,len(payload),None,None)),patch('huggingface_hub.file_download.http_get',side_effect=http) as transfer:
            result=s.hub_download(ENTRY,'a'*40,'tiny.bin',s.root/'payload',False)
            self.assertEqual(Path(result).read_bytes(),payload)
            result2=s.hub_download(ENTRY,'a'*40,'tiny.bin',s.root/'payload',False)
            self.assertEqual(result,result2);self.assertEqual(transfer.call_count,1)

class ComparisonTests(unittest.TestCase):
    def test_content_match_and_no_mutation(self):
        from compare_archives import compare
        with tempfile.TemporaryDirectory() as t:
            a=Path(t)/'a';b=Path(t)/'b';a.mkdir();(a/'__init__.py').write_bytes(b'inert');shutil.copytree(a,b)
            before=(a/'__init__.py').stat().st_mtime_ns
            result=compare(a,b);self.assertTrue(result['match']);self.assertEqual(result['source_file_count'],1);self.assertEqual(before,(a/'__init__.py').stat().st_mtime_ns)
    def test_corruption_missing_extra_empty(self):
        from compare_archives import compare
        with tempfile.TemporaryDirectory() as t:
            a=Path(t)/'a';b=Path(t)/'b';a.mkdir();b.mkdir();self.assertFalse(compare(a,b)['match'])
            (a/'x').write_bytes(b'good');(b/'x').write_bytes(b'evil');(a/'missing').touch();(b/'extra').touch()
            r=compare(a,b);self.assertFalse(r['match']);self.assertEqual(r['changed'],['x']);self.assertEqual(r['extra'],['extra']);self.assertEqual(r['missing'],['missing'])
    def test_symlink_refused(self):
        from compare_archives import tree
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);(p/'link').symlink_to('/tmp')
            with self.assertRaises(core.ToolkitError):tree(p)
    def test_disconnect_propagates_no_match(self):
        from compare_archives import tree
        with tempfile.TemporaryDirectory() as t,self.assertRaisesRegex(core.ToolkitError,'lost'):tree(Path(t),lambda: (_ for _ in ()).throw(core.ToolkitError('lost')))

if __name__=="__main__":unittest.main()
