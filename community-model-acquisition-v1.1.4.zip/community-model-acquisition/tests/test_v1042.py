"""Qwen3-Coder-Next expansion: captured metadata, exact legacy baselines, tiny payloads."""
import ast,contextlib,copy,hashlib,io,json,os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,select,plan,acquire,inventory,read,space,ToolkitError
from modelkit.huggingface import HuggingFaceAdapter
from storage_test_support import main
from test_v104 import Metadata
from test_toolkit import Fake
ROOT=Path(__file__).resolve().parents[1];EV=ROOT/'evidence/v1.0.4.2'
SOURCE='qwen3-coder-next-original';GGUF='qwen3-coder-next-gguf-q6-k'
EVERYDAY='qwen3-coder-30b-a3b-instruct-gguf-q4-k-m'
PINS={SOURCE:('Qwen/Qwen3-Coder-Next','a7fbcb5c0e12d62a448eaa0e260346bf5dcc0feb',159376351965),GGUF:('unsloth/Qwen3-Coder-Next-GGUF','ce09c67b53bc8739eef83fe67b2f5d293c270632',65614001999)}
class Catalog1042Tests(unittest.TestCase):
    def setUp(self):
        self.c=load_catalog(ROOT/'catalog.json');self.byid={e['id']:e for e in self.c['models']};self.entries=[self.byid[SOURCE],self.byid[GGUF]]
    def test_both_variants_parse(self):
        self.assertEqual(len(self.c['models']),154)
        self.assertEqual([e['family'] for e in self.entries],['Qwen3-Coder-Next']*2)
        self.assertEqual([e['format'] for e in self.entries],['Safetensors','GGUF'])
    def test_exact_repository_pins_and_bytes(self):
        for e in self.entries:
            repo,rev,size=PINS[e['id']];self.assertEqual((e['repository'],e['revision'],e['estimated_bytes']),(repo,rev,size))
            a=Metadata();p=plan(e,Path('/tmp/v1042-no-write'),a)
            self.assertEqual(p['revision'],rev);self.assertEqual(p['total_bytes'],size);self.assertEqual(a.requests,[(repo,rev)]);self.assertTrue(p['target'].endswith(rev))
    def test_hub_adapter_passes_exact_pin(self):
        from types import SimpleNamespace
        for e in self.entries:
            result=SimpleNamespace(sha=e['revision'],gated=False,card_data={},siblings=[])
            with patch('huggingface_hub.HfApi') as api:
                api.return_value.model_info.return_value=result
                HuggingFaceAdapter().resolve(e)
                self.assertEqual(api.return_value.model_info.call_args.kwargs['revision'],e['revision'])
    def test_source_preserves_every_file_and_all_shards(self):
        e=self.byid[SOURCE];d=read(EV/'Qwen--Qwen3-Coder-Next/api.json');p=plan(e,Path('/tmp/v1042-no-write'),Metadata());names={f['path'] for f in p['files']}
        self.assertEqual(names,{s['rfilename'] for s in d['siblings']});self.assertEqual(names,set(e['required']));self.assertEqual(len(names),52)
        index=read(EV/'Qwen--Qwen3-Coder-Next/model.safetensors.index.json');self.assertEqual(set(index['weight_map'].values()),{f for f in names if f.endswith('.safetensors')})
        self.assertTrue({'chat_template.jinja','tokenizer.json','tokenizer_config.json','generation_config.json','qwen3_coder_detector_sgl.py','qwen3coder_tool_parser_vllm.py'}<=names)
    def test_exact_q6_shards_and_metadata_only(self):
        e=self.byid[GGUF];expected={f'Q6_K/Qwen3-Coder-Next-Q6_K-{i:05d}-of-00003.gguf' for i in range(1,4)}|{'README.md'}
        p=plan(e,Path('/tmp/v1042-no-write'),Metadata());self.assertEqual({f['path'] for f in p['files']},expected);self.assertEqual(set(e['include']),expected);self.assertEqual(set(e['required']),expected)
        self.assertEqual(sum(f['size'] for f in p['files'] if f['path'].endswith('.gguf')),65613992288)
        self.assertFalse(e['multimodal']);self.assertEqual(e['multimodal_artifacts'],[])
    def test_missing_any_q6_shard_refused(self):
        e=self.byid[GGUF]
        for name in e['required']:
            a=Metadata();d=a.resolve(e);d['files']=[f for f in d['files'] if f['path']!=name]
            with patch.object(a,'resolve',return_value=d),self.assertRaises(ToolkitError):plan(e,Path('/tmp/v1042-no-write'),a)
    def test_embedded_gguf_metadata(self):
        d=read(EV/'runtime/gguf-first-shard-metadata.json')
        self.assertEqual(d['general.architecture'],'qwen3next');self.assertEqual(d['general.file_type'],18);self.assertEqual(d['split.count'],3);self.assertEqual(d['shard_tensor_count'],0)
        self.assertIn('tool_call',d['tokenizer.chat_template']);self.assertEqual(d['qwen3next.context_length'],262144)
    def test_provenance_roles_license_priority(self):
        self.assertEqual([(e['source_kind'],e['variant_role']) for e in self.entries],[('official-upstream','source-weights'),('third-party-derived','portable-gguf')])
        for e in self.entries:
            self.assertEqual(e['license'],'apache-2.0');self.assertEqual(e['preservation_priority'],'core');self.assertEqual(e['canonical_source_revision'],PINS[SOURCE][1])
        self.assertEqual(self.byid[GGUF]['quantizer_converter'],'Unsloth');self.assertIsNone(self.byid[GGUF]['conversion_base_revision'])
    def test_architecture_precision_and_context(self):
        for e in self.entries:
            self.assertEqual(e['architecture'],['Qwen3NextForCausalLM']);self.assertEqual(e['parameter_count'],79674391296);self.assertEqual(e['active_parameter_count'],3000000000);self.assertEqual(e['context_length'],262144)
        self.assertIn('BF16',self.byid[SOURCE]['tensor_precision']);self.assertEqual(self.byid[SOURCE]['hub_tensor_dtype_counts'],{'BF16':79674391296});self.assertEqual(self.byid[GGUF]['quantization'],'Q6_K')
    def test_capabilities_and_training_distinction(self):
        for e in self.entries:
            self.assertTrue({'agentic-coding','software-engineering','repository-scale-coding','long-horizon-agent','tool-use','function-calling','long-context','code-generation','reasoning'}<=set(e['capabilities']))
            self.assertNotIn('multimodal',e['capabilities']);self.assertIn('Non-thinking',e['runtime_notes'])
        self.assertIn('fine-tuning-source',self.byid[SOURCE]['capabilities']);self.assertIn('router auxiliary loss',self.byid[SOURCE]['training_suitability']);self.assertNotIn('fine-tuning-source',self.byid[GGUF]['capabilities']);self.assertIn('Inference-oriented',self.byid[GGUF]['training_suitability'])
    def test_artifact_specific_runtimes_and_hardware(self):
        s,g=self.entries;self.assertEqual(s['recommended_runtime'],['Transformers','vLLM','SGLang']);self.assertEqual(g['recommended_runtime'],['llama.cpp'])
        self.assertIn('not-selected',g['vllm_support']);self.assertIn('not-selected',g['sglang_support']);self.assertIn('96 GB',g['preferred_hardware']);self.assertEqual(g['cpu_practical'],'limited');self.assertTrue(g['multi_gpu_expected']);self.assertIn('not practical on a 32 GB Dell',g['hardware_notes']);self.assertIn('EXPERIMENTAL',g['runtime_notes'])
    def test_exact_workstation_profile(self):
        self.assertEqual([e['id'] for e in select(self.c,'coding-workstation')],[EVERYDAY,GGUF])
        self.assertNotIn(SOURCE,[e['id'] for e in select(self.c,'coding-workstation')])
        for name in ['dell','dell-upper-tier','coding-local']:self.assertFalse({SOURCE,GGUF}&{e['id'] for e in select(self.c,name)})
    def test_intentional_additive_profiles_only(self):
        old=read(EV/'v1.0.4.1-catalog-baseline.json')
        from image_guard import baseline_bytes
        current=__import__('json').loads(baseline_bytes(ROOT/'catalog.json'))
        additions={'all':[SOURCE,GGUF]+[e['id'] for e in current['models'][38:]],'coding':[SOURCE,GGUF],'coding-archive':[SOURCE],'future':[SOURCE],'preservation-source-weights':[SOURCE]}
        for name in old['profiles']:
            self.assertEqual(self.c['profiles'][name],old['profiles'][name]);self.assertEqual([e['id'] for e in select(current,name)],[e['id'] for e in select(old,name)]+additions.get(name,[]))
        self.assertEqual(set(self.c['profiles'])-set(old['profiles'])-{p for p in self.c['profiles'] if p.startswith('image-')}-{'educational-assessment','aiawe-preservation','autoscore-preservation','argulens-preservation','essay-evaluator-preservation'},{'coding-workstation','document-vision','audio-transcription','audiobook-narration','voice-customization','multimodal-core','multimodal-preservation','scientific-research-local','chemistry-research-local','scientific-research-preservation','scientific-research-inference','gpt-oss-120b-local-inference'})
    def test_all_36_legacy_entries_exactly_unchanged(self):
        old=read(EV/'v1.0.4.1-catalog-baseline.json');self.assertEqual(self.c['models'][:36],old['models']);self.assertEqual(len(old['models']),36)
        for name,ids in old['profile_members'].items():self.assertEqual(self.c['profile_members'][name],ids)
    def test_all_operational_files_byte_identical(self):
        old=read(EV/'v1.0.4.1-package-checksums.json')
        for name in ['model_acquire.py','modelkit/huggingface.py','modelkit/mounts.py','modelkit/storage.py','settings.json','requirements.txt','setup-linux.sh','setup-windows.ps1','sample-catalog.json','tests/fixtures/core-v1.0.3.py.txt']:
            self.assertEqual(hashlib.sha256(legacy_bytes(ROOT/name)).hexdigest(),old[name],name)
        from test_v104 import protected_core_source
        baseline=(ROOT/'evidence/v1.0.4.3/baseline-modelkit--core.py.txt').read_bytes()
        self.assertEqual(hashlib.sha256(baseline).hexdigest(),old['modelkit/core.py'])
        self.assertEqual(protected_core_source(legacy_bytes(ROOT/'modelkit/core.py').decode()),protected_core_source(baseline.decode()))
    def test_portable_source_guard_unchanged(self):
        # Compare exact source for guard and its tests against authenticated 1.0.4.1 snapshots.
        current=(ROOT/'tests/test_v104.py').read_text().replace('legacy_bytes(ROOT/name)', '(ROOT/name).read_bytes()').replace("legacy_bytes(ROOT/'modelkit/core.py')", "(ROOT/'modelkit/core.py').read_bytes()");saved=(EV/'portable-guard-baseline.py.txt').read_text()
        names={'protected_core_source','test_application_behavior_unchanged','test_source_guard_does_not_serialize_ast','test_source_guard_detects_protected_and_module_changes','test_source_guard_allows_only_named_profile_definitions','test_source_guard_rejects_missing_or_duplicate_exceptions'}
        def sections(source):return {n.name:ast.get_source_segment(source,n) for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef) and n.name in names}
        self.assertEqual(set(sections(current)),names);self.assertEqual(sections(current),sections(saved))
        old=read(EV/'v1.0.4.1-package-checksums.json');self.assertEqual(hashlib.sha256(saved.encode()).hexdigest(),old['tests/test_v104.py'])
    def test_dry_runs_and_reserve_without_payload_writes(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'absent'
            for opts in [['--model',SOURCE],['--model',GGUF],['--profile','coding-workstation']]:
                out=io.StringIO()
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),contextlib.redirect_stdout(out):self.assertEqual(main(['--root',str(root),*opts,'--dry-run']),0)
                for word in ['LARGE ARCHIVE','Estimated new files:','Free:','Required with reserve:']:self.assertIn(word,out.getvalue())
                self.assertFalse(root.exists())
            n=sum(e['estimated_bytes'] for e in select(self.c,'coding-workstation'));self.assertEqual(n,84170699980);self.assertEqual(space(root,n)[1],int(n*1.10)+1024**3)
    def test_yes_requires_allow_large_before_download(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'absent'
            for opts in [['--model',SOURCE],['--model',GGUF],['--profile','coding-workstation']]:
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),patch('model_acquire.space',return_value=(10**15,10**12)),contextlib.redirect_stdout(io.StringIO()):
                    with self.assertRaisesRegex(ToolkitError,'--allow-large'):main(['--root',str(root),*opts,'--yes'])
                self.assertFalse(root.exists())
    def test_interrupted_q6_resume_and_hash_verification(self):
        e=self.byid[GGUF];a=Fake({n:('tiny fixture '+n).encode() for n in e['required']});a.rev=e['revision'];download=a.download;stop=e['required'][1]
        with tempfile.TemporaryDirectory() as t,contextlib.redirect_stdout(io.StringIO()):
            root=Path(t)/'models';p=plan(e,root,a)
            def interrupt(entry,rev,name,target,force=False):
                if name==stop:raise KeyboardInterrupt()
                return download(entry,rev,name,target,force)
            with patch.object(a,'download',side_effect=interrupt),self.assertRaises(KeyboardInterrupt):acquire(p,root,a)
            self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'partial');self.assertLess(plan(e,root,a)['estimated_new_bytes'],p['total_bytes'])
            acquire(plan(e,root,a),root,a);self.assertEqual(a.calls.count(e['required'][0]),1);self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'verified');self.assertEqual(plan(e,root,a)['estimated_new_bytes'],0)
            self.assertEqual(inventory(root,self.c,verify=True)['models'][0]['status'],'verified')
            path=Path(p['target'])/'payload'/stop;st=path.stat();path.write_bytes(b'x'*st.st_size);os.utime(path,ns=(st.st_atime_ns,st.st_mtime_ns))
            self.assertEqual(inventory(root,self.c,verify=True)['models'][0]['status'],'failed')
    def test_whole_repo_is_not_selected_for_gguf(self):
        e=self.byid[GGUF];d=read(EV/'unsloth--Qwen3-Coder-Next-GGUF/api.json');self.assertEqual(e['repository_total_bytes'],sum(s['size'] for s in d['siblings']));self.assertEqual(e['repository_total_bytes'],1802394170046);self.assertLess(e['estimated_bytes'],e['repository_total_bytes']/20)
if __name__=='__main__':unittest.main(verbosity=2)

from maintenance_guard import legacy_bytes
