import contextlib,csv,io,json,os,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import read,write,load_catalog,select,ToolkitError
from modelkit import mounts,storage
from storage_test_support import main
from model_acquire import menu
from test_toolkit import Fake,ENTRY,CAT

class V101Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='v101 with spaces ');self.base=Path(self.temp.name);self.root=self.base/'models';self.catalog=self.base/'catalog.json';write(self.catalog,CAT)
        self.silent=contextlib.redirect_stdout(io.StringIO());self.silent.__enter__()
    def tearDown(self):self.silent.__exit__(None,None,None);self.temp.cleanup()
    def revision(self,rev,date,status='verified',size=200,category='other',ident='test-original',quarantine=0):
        p=self.root/category/ident/rev;payload=p/'payload'/'weights.safetensors';payload.parent.mkdir(parents=True);payload.write_bytes(b'x'*size)
        entry={**ENTRY,'id':ident,'category':category,'display_name':'Fixture, model','description':'Purpose with comma, and newline\nsecond line'}
        st=payload.stat();state={'schema_version':1,'entry':entry,'revision':rev,'created_at':date,'status':status,'files':{'weights.safetensors':{'size':size,'mtime_ns':st.st_mtime_ns,'sha256':'unused'}},'expected':[{'path':'weights.safetensors','size':size}]}
        write(p/'manifest.json',state)
        if quarantine:
            q=p/'quarantine'/'old';q.parent.mkdir();q.write_bytes(b'q'*quarantine)
        return p
    def usage(self,path):return sum(p.stat().st_blocks*512 if hasattr(p.stat(),'st_blocks') else p.stat().st_size for p in path.rglob('*') if p.is_file())
    def args(self,*extra):return ['--catalog',str(self.catalog),'--root',str(self.root),*extra]
    def test_mount_pass(self):
        with patch('modelkit.mounts.is_mounted',return_value=True):mounts.require_mount(self.root,self.base)
    def test_mount_absent_refuses_before_writes(self):
        with patch('modelkit.mounts.is_mounted',return_value=False),self.assertRaisesRegex(ToolkitError,'No fallback'):
            main(self.args('--expected-mount',str(self.base),'--profile','small-cpu','--yes'))
        self.assertFalse(self.root.exists())
    def test_configure_mount_absent_refuses(self):
        with patch('modelkit.mounts.is_mounted',return_value=False),self.assertRaises(ToolkitError):main(self.args('--expected-mount',str(self.base),'--configure'))
        self.assertFalse(self.root.exists())
    def test_mount_parent_containment(self):
        with patch('modelkit.mounts.is_mounted',return_value=True),self.assertRaisesRegex(ToolkitError,'not beneath'):mounts.require_mount(self.root,self.base/'elsewhere')
    def test_mount_settings_and_override(self):
        p=self.base/'settings.json';write(p,{'mount_guards':[{'root':str(self.root),'expected_mount':str(self.base)}]})
        self.assertEqual(mounts.expected_mount(self.root,p),self.base);self.assertEqual(mounts.expected_mount(self.root,p,self.root),self.root)
    def test_windows_skips_posix_default_rule(self):
        p=self.base/'settings.json';write(p,{'mount_guards':[{'platform':'posix','root':str(self.root),'expected_mount':str(self.base)}]})
        with patch.object(mounts,'os',SimpleNamespace(name='nt',path=os.path)):
            self.assertIsNone(mounts.expected_mount(self.root,p))
    def test_windows_mount_uses_portable_ismount(self):
        with patch('modelkit.mounts.sys.platform','win32'),patch('modelkit.mounts.os.path.ismount',return_value=True),patch('pathlib.Path.read_text',side_effect=AssertionError('No /proc on Windows')):
            self.assertTrue(mounts.is_mounted(self.base))
        with patch('modelkit.mounts.sys.platform','win32'),patch('modelkit.mounts.os.path.ismount',return_value=False),patch('pathlib.Path.read_text',side_effect=AssertionError('No /proc on Windows')):
            self.assertFalse(mounts.is_mounted(self.base))
    def test_linux_bind_mount_with_space(self):
        escaped=str(self.base).replace(' ','\\040')
        with patch('modelkit.mounts.sys.platform','linux'),patch('modelkit.mounts.os.path.ismount',return_value=False),patch('pathlib.Path.read_text',return_value=f'1 2 8:1 / {escaped} rw - ext4 /dev/test rw'):
            self.assertTrue(mounts.is_mounted(self.base))
    def test_missing_mount_dry_run_allowed(self):
        a=Fake()
        with patch('modelkit.mounts.is_mounted',return_value=False),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=a):
            self.assertEqual(main(self.args('--expected-mount',str(self.base),'--profile','small-cpu','--dry-run')),0)
        self.assertFalse(self.root.exists());self.assertFalse(a.calls)
    def test_inventory_missing_root_read_only(self):
        out=io.StringIO()
        with contextlib.redirect_stdout(out):self.assertEqual(main(self.args('--inventory','--format','json')),0)
        self.assertEqual(json.loads(out.getvalue())['summary']['revision_count'],0);self.assertFalse(self.root.exists())
    def test_multiple_revisions_current_and_superseded(self):
        self.revision('a'*40,'2026-01-01T00:00:00+00:00');self.revision('b'*40,'2026-02-01T00:00:00+00:00')
        data=storage.scan(self.root,CAT);roles={r['local_revision']:r['revision_role'] for r in data['models']}
        self.assertEqual(roles,{'a'*40:'superseded','b'*40:'current'})
        self.assertTrue(next(r for r in data['models'] if r['local_revision']=='a'*40)['catalog_revision_match'])
    def test_failed_new_revision_keeps_working_current(self):
        self.revision('a'*40,'2026-01-01T00:00:00+00:00');self.revision('b'*40,'2026-02-01T00:00:00+00:00','failed')
        rows=storage.scan(self.root,CAT)['models'];self.assertEqual([r['revision_role'] for r in rows],['current','pending'])
    def test_unknown_dates_not_superseded(self):
        self.revision('a'*40,None);self.revision('b'*40,'2026-02-01T00:00:00+00:00')
        self.assertEqual(storage.scan(self.root,CAT)['summary']['potential_recoverable_bytes'],0)
    def test_totals_categories_quarantine_recoverable(self):
        old=self.revision('a'*40,'2026-01-01T00:00:00+00:00',quarantine=100)
        new=self.revision('b'*40,'2026-02-01T00:00:00+00:00')
        failed=self.revision('c'*40,'2026-03-01T00:00:00+00:00','failed',category='coding',ident='other-model')
        s=storage.scan(self.root,CAT)['summary'];a,b,c=map(self.usage,[old,new,failed])
        self.assertEqual(s['total_model_storage_bytes'],a+b+c);self.assertEqual(s['by_category_bytes'],{'other':a+b,'coding':c})
        self.assertEqual(s['superseded_revision_bytes'],a);self.assertEqual(s['potential_recoverable_bytes'],a);self.assertEqual(s['current_revision_bytes'],b)
        self.assertEqual(s['partial_failed_bytes'],c);self.assertEqual(s['quarantine_bytes'],self.usage(old/'quarantine'))
    def test_old_entries_not_in_catalog(self):
        self.revision('a'*40,'2026-01-01T00:00:00+00:00')
        r=storage.scan(self.root,{'models':[]})['models'][0];self.assertFalse(r['configured']);self.assertEqual(r['display_name'],'Fixture, model')
    def test_malformed_and_missing_manifest(self):
        p=self.revision('a'*40,'2026-01-01T00:00:00+00:00');(p/'manifest.json').write_text('{bad')
        q=self.root/'other'/'orphan'/'orphan-rev'/'payload';q.mkdir(parents=True);(q/'file.incomplete').write_bytes(b'a')
        d=storage.scan(self.root,CAT);self.assertEqual(len(d['models']),2);self.assertTrue(all(r['warnings'] for r in d['models']));self.assertEqual(next(r for r in d['models'] if r['id']=='orphan')['status'],'partial')
    def test_csv_json_text_outputs(self):
        self.revision('a'*40,'2026-01-01T00:00:00+00:00');d=storage.view(storage.scan(self.root,CAT))
        rows=list(csv.DictReader(io.StringIO(storage.render(d,'csv'))));self.assertEqual(rows[0]['display_name'],'Fixture, model');self.assertIn('\n',rows[0]['description'])
        self.assertEqual(json.loads(storage.render(d,'json'))['models'][0]['id'],ENTRY['id']);self.assertIn('Potential recoverable',storage.render(d))
    def test_cli_json_and_csv_are_clean_stdout(self):
        self.revision('a'*40,'2026-01-01T00:00:00+00:00')
        for fmt in ('json','csv'):
            out=io.StringIO()
            with contextlib.redirect_stdout(out):main(self.args('--inventory','--format',fmt))
            if fmt=='json':self.assertEqual(len(json.loads(out.getvalue())['models']),1)
            else:self.assertEqual(len(list(csv.DictReader(io.StringIO(out.getvalue())))),1)
        self.assertFalse((self.root/'_toolkit').exists())
    def test_sort_and_superseded_filter(self):
        self.revision('a'*40,'2026-01-01T00:00:00+00:00');self.revision('b'*40,'2026-02-01T00:00:00+00:00');self.revision('c'*40,'2026-01-01T00:00:00+00:00',size=100000,ident='big')
        data=storage.scan(self.root,CAT);self.assertEqual(storage.view(data,'size')['models'][0]['id'],'big')
        d=storage.view(data,superseded=True);self.assertEqual(len(d['models']),1);self.assertEqual(d['summary']['revision_count'],3)
    def test_hardlinks_not_double_counted_or_recoverable(self):
        a=self.revision('a'*40,'2026-01-01T00:00:00+00:00');b=self.revision('b'*40,'2026-02-01T00:00:00+00:00')
        os.link(a/'payload/weights.safetensors',b/'shared-file')
        data=storage.scan(self.root,CAT);size=self.usage(a/'payload')
        self.assertEqual(data['summary']['total_model_storage_bytes'],self.usage(a)+self.usage(b)-size)
        self.assertEqual(data['summary']['potential_recoverable_bytes'],self.usage(a)-size)
    def test_symlink_not_followed(self):
        self.root.mkdir();external=self.base/'external';external.mkdir();(external/'big').write_bytes(b'x'*9999);(self.root/'link').symlink_to(external,target_is_directory=True)
        d=storage.scan(self.root,CAT);self.assertEqual(d['summary']['total_model_storage_bytes'],0);self.assertFalse(d['summary']['scan_complete'])
    def test_refresh_three_formats_no_payload_change(self):
        p=self.revision('a'*40,'2026-01-01T00:00:00+00:00');before=(p/'payload/weights.safetensors').stat().st_mtime_ns
        storage.refresh(self.root,CAT)
        for suffix in ('txt','csv','json'):self.assertTrue((self.root/'_toolkit/inventory'/('current-inventory.'+suffix)).exists())
        self.assertEqual((p/'payload/weights.safetensors').stat().st_mtime_ns,before)
    def test_automatic_after_acquire_verify_repair(self):
        fake=Fake()
        with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=fake):self.assertEqual(main(self.args('--profile','small-cpu','--yes')),0)
        out=self.root/'_toolkit/inventory/current-inventory.json';self.assertEqual(read(out)['models'][0]['status'],'verified');out.unlink()
        self.assertEqual(main(self.args('--verify')),0);self.assertTrue(out.exists())
        path=Path(read(out)['models'][0]['path'])/'payload/weights.safetensors';path.write_bytes(b'damaged')
        with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=fake):self.assertEqual(main(self.args('--profile','small-cpu','--yes','--repair')),0)
        self.assertGreater(read(out)['summary']['quarantine_bytes'],0)
    def test_coding_profiles(self):
        c=load_catalog(Path(__file__).resolve().parents[1]/'catalog.json');local=select(c,'coding-local');archive=select(c,'coding-archive')
        self.assertEqual(len(local),4);self.assertTrue(all(e['format']=='GGUF' for e in local));self.assertEqual(len(archive),7)
        self.assertEqual({e['id'] for e in local+archive}|{'qwen3-coder-next-gguf-q6-k'},{e['id'] for e in select(c,'coding')})
        with patch('builtins.input',return_value='3'):self.assertEqual(menu(c)[0],'coding-local')
if __name__=='__main__':unittest.main(verbosity=2)
