import contextlib,hashlib,io,json,tempfile,unittest,sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import *
from storage_test_support import main

DATA={'README.md':b'Fixture model card\n','config.json':b'{"architecture":"fixture"}', 'weights.safetensors':b'fake weights for acquisition tests only'}
ENTRY={'id':'test-original','category':'other','adapter':'huggingface','repository':'tests/fixture','display_name':'Test','publisher':'tests','source_kind':'third-party','format':'Safetensors','revision':'a'*40,'include':['*'],'required':['weights.safetensors'],'profiles':['small-cpu'],'quantization':None,'estimated_bytes':100}
CAT={'schema_version':1,'profiles':{'small-cpu':'test','all':'all'},'models':[ENTRY]}
class Fake:
    def __init__(self,data=None):self.data=data or DATA;self.calls=[];self.fail=None;self.rev='a'*40
    def resolve(self,e):return {'revision':self.rev,'metadata':{'license':'test'},'files':[{'path':n,'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha1':None} for n,b in self.data.items()]}
    def download(self,e,rev,name,target,force=False):
        self.calls.append(name)
        if self.fail:raise self.fail
        p=target/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(self.data[name])
class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='model tests with spaces ');self.root=Path(self.tmp.name)/'models';self.a=Fake();self.cat=Path(self.tmp.name)/'catalog.json';write(self.cat,CAT)
        self.output=contextlib.redirect_stdout(io.StringIO());self.output.__enter__()
    def tearDown(self):self.output.__exit__(None,None,None);self.tmp.cleanup()
    def acquire(self):
        p=plan(ENTRY,self.root,self.a);acquire(p,self.root,self.a);return Path(p['target'])
    def test_catalog_and_profiles(self):
        c=load_catalog(self.cat);self.assertEqual(select(c,'small-cpu'),[ENTRY]);self.assertEqual(select(c,'all'),[ENTRY]);self.assertEqual(select(c,ids=[ENTRY['id']]),[ENTRY])
        with self.assertRaises(ToolkitError):select(c,ids=['missing'])
    def test_duplicate_catalog(self):
        write(self.cat,{**CAT,'models':[ENTRY,ENTRY]})
        with self.assertRaises(ToolkitError):load_catalog(self.cat)
    def test_setup_directories(self):
        self.assertEqual(main(['--catalog',str(self.cat),'--root',str(self.root),'--configure']),0)
        self.assertTrue((self.root/'_toolkit/logs').is_dir())
    def test_offline_dry_run_no_writes(self):
        self.assertEqual(main(['--catalog',str(self.cat),'--root',str(self.root),'--profile','small-cpu','--offline-plan']),0);self.assertFalse(self.root.exists())
    def test_live_dry_run_mock_no_download(self):
        with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=self.a):
            self.assertEqual(main(['--catalog',str(self.cat),'--root',str(self.root),'--profile','small-cpu','--dry-run']),0)
        self.assertFalse(self.root.exists());self.assertEqual(self.a.calls,[])
    def test_acquisition_and_rerun_skip(self):
        t=self.acquire();calls=len(self.a.calls);self.acquire();self.assertEqual(len(self.a.calls),calls)
        s=read(t/'manifest.json');self.assertEqual(s['status'],'verified');self.assertEqual(len(s['files']),3)
        self.assertEqual(plan(ENTRY,self.root,self.a)['estimated_new_bytes'],0)
    def test_partial_recovery(self):
        p=plan(ENTRY,self.root,self.a);self.a.fail=KeyboardInterrupt()
        with self.assertRaises(KeyboardInterrupt):acquire(p,self.root,self.a)
        self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'partial')
        self.a.fail=None;acquire(p,self.root,self.a);self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'verified')
    def test_retry_failure_and_recovery(self):
        p=plan(ENTRY,self.root,self.a);self.a.fail=OSError('token=SECRET')
        with patch('modelkit.core.time.sleep'),self.assertRaises(OSError):acquire(p,self.root,self.a,retries=2)
        self.assertEqual(len(self.a.calls),2)
        self.assertNotIn('SECRET',(self.root/'_toolkit/logs/events.jsonl').read_text())
        self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'failed');self.a.fail=None;acquire(p,self.root,self.a)
    def test_corruption_repair_preserves_bytes(self):
        t=self.acquire();p=t/'payload/weights.safetensors';p.write_bytes(b'broken')
        with self.assertRaises(ToolkitError):self.acquire()
        acquire(plan(ENTRY,self.root,self.a),self.root,self.a,repair=True)
        self.assertEqual(next((t/'quarantine').glob('*/weights.safetensors')).read_bytes(),b'broken')
        self.assertEqual(p.read_bytes(),DATA['weights.safetensors'])
    def test_verify_same_size_corruption(self):
        t=self.acquire();p=t/'payload/weights.safetensors';st=p.stat();p.write_bytes(b'x'*st.st_size);os.utime(p,ns=(st.st_atime_ns,st.st_mtime_ns))
        data=inventory(self.root,CAT,verify=True);self.assertEqual(data['models'][0]['status'],'failed')
    def test_local_hash_distinction(self):
        path=Path(self.tmp.name)/'a';path.write_bytes(b'abc');rec=inspect_file(path,{'size':3});self.assertEqual(rec['integrity'],'local-sha256')
    def test_git_blob_hash(self):
        path=Path(self.tmp.name)/'a';path.write_bytes(b'abc');sha,git=hashes(path)
        self.assertEqual(inspect_file(path,{'size':3,'git_blob_sha1':git})['integrity'],'upstream-git-blob-sha1')
        self.assertIsNone(inspect_file(path,{'size':3,'git_blob_sha1':'0'*40}))
    def test_path_traversal(self):
        for name in ['../escape','/absolute','a\\b','C:bad','a/../../x']:
            with self.assertRaises(ToolkitError):safe_path(self.root,name)
        self.assertEqual(safe_path(self.root,'.gitattributes'),self.root/'.gitattributes')
    def test_symlink_rejection(self):
        self.root.mkdir();(self.root/'evil').symlink_to(Path(self.tmp.name),target_is_directory=True)
        with self.assertRaises(ToolkitError):safe_path(self.root,'evil/file')
    def test_missing_required(self):
        with self.assertRaises(ToolkitError):plan({**ENTRY,'required':['missing.gguf']},self.root,self.a)
    def test_unknown_size(self):
        with patch.object(self.a,'resolve',return_value={'revision':'a'*40,'metadata':{},'files':[{'path':'weights.safetensors','size':None}]}):
            with self.assertRaises(ToolkitError):plan(ENTRY,self.root,self.a)
    def test_update_retains_old_revision(self):
        first=self.acquire();self.a.rev='b'*40;second=self.acquire();self.assertNotEqual(first,second);self.assertTrue(first.exists());self.assertEqual(len(inventory(self.root,CAT)['models']),2)
    def test_changed_selection_requires_new_id(self):
        self.acquire()
        with self.assertRaises(ToolkitError):acquire(plan({**ENTRY,'exclude':['README.md']},self.root,self.a),self.root,self.a)
    def test_report_does_not_modify_payload(self):
        t=self.acquire();p=t/'payload/README.md';before=p.stat().st_mtime_ns;data=inventory(self.root,CAT);out=report(self.root,data)
        self.assertTrue(out.with_suffix('.txt').exists());self.assertEqual(read(out.with_suffix('.json'))['models'][0]['status'],'verified');self.assertEqual(p.stat().st_mtime_ns,before)
    def test_missing_index_shard_fails(self):
        self.a=Fake({'weights.safetensors':b'x','model.safetensors.index.json':b'{"weight_map":{"a":"absent.safetensors"}}'})
        with self.assertRaises(ToolkitError):self.acquire()
    def test_verify_rechecks_index_consistency(self):
        self.a=Fake({'weights.safetensors':b'x','model.safetensors.index.json':b'{"weight_map":{"a":"absent.safetensors"}}'})
        with self.assertRaises(ToolkitError):self.acquire()
        self.assertEqual(inventory(self.root,CAT,verify=True)['models'][0]['status'],'failed')
    def test_audit_refreshes_copied_timestamps(self):
        t=self.acquire();p=t/'payload/README.md';st=p.stat();os.utime(p,ns=(st.st_atime_ns,st.st_mtime_ns+100000))
        self.assertEqual(inventory(self.root,CAT)['models'][0]['status'],'partial')
        self.assertEqual(inventory(self.root,CAT,verify=True)['models'][0]['status'],'verified')
        self.assertEqual(inventory(self.root,CAT)['models'][0]['status'],'verified')
    def test_bad_upstream_checksum(self):
        p=plan(ENTRY,self.root,self.a);p['files'][0]['sha256']='0'*64
        with self.assertRaises(ToolkitError):acquire(p,self.root,self.a,retries=1)
        self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'failed')
    def test_disk_refusal(self):
        with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=self.a),patch('model_acquire.space',return_value=(1,1000)):
            with self.assertRaises(ToolkitError):main(['--catalog',str(self.cat),'--root',str(self.root),'--profile','small-cpu','--yes'])
        self.assertEqual(self.a.calls,[])
    def test_large_confirmation(self):
        p=plan(ENTRY,self.root,self.a);p.update(total_bytes=100*10**9,estimated_new_bytes=0)
        with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=self.a),patch('model_acquire.plan',return_value=p),patch('model_acquire.space',return_value=(10**12,10**9)):
            with self.assertRaises(ToolkitError):main(['--catalog',str(self.cat),'--root',str(self.root),'--profile','small-cpu','--yes'])
    def test_lock(self):
        from filelock import FileLock,Timeout
        self.root.mkdir();lock=self.root/'lock'
        with FileLock(lock):
            with self.assertRaises(Timeout):
                with FileLock(lock,timeout=0):pass
    def test_bundled_catalog(self):
        c=load_catalog(Path(__file__).resolve().parents[1]/'catalog.json');self.assertEqual(len(c['models']),154)
        self.assertTrue(all(e['format']=='GGUF' for e in select(c,'small-cpu')))
        self.assertTrue(all(e['estimated_bytes']<15*10**9 for e in select(c,'dell')))
if __name__=='__main__':unittest.main(verbosity=2)
