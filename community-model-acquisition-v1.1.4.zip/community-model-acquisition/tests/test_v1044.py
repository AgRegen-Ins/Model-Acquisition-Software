"""Scientific catalog expansion: metadata snapshots and inert tiny fixtures only."""
import contextlib,copy,csv,hashlib,io,json,pickle,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,select,plan,read,write,acquire,inventory,space,ToolkitError
from modelkit.huggingface import HuggingFaceAdapter
from modelkit import accountability as acc,registry as reg
from storage_test_support import main
from test_toolkit import Fake
ROOT=Path(__file__).resolve().parents[1];EV=ROOT/'evidence/v1.0.4.4';IDS=read(EV/'new-ids.json');PROFILES=read(EV/'profile-membership.json')
class ResearchMetadata:
    def __init__(self):self.requests=[]
    def resolve(self,e):
        d=read(EV/e['repository'].replace('/','--')/'api.json');self.requests.append((e['repository'],e['revision']));assert d['sha']==e['revision']
        return {'revision':d['sha'],'metadata':d,'gated':bool(d.get('gated',False)),'files':[{'path':f['rfilename'],'size':f['size'],'sha256':(f.get('lfs') or {}).get('sha256'),'git_blob_sha1':None if f.get('lfs') else f.get('blobId')} for f in d['siblings']]}
    def download(self,*a,**kw):raise AssertionError('Metadata test must never download')
class ScientificCatalogTests(unittest.TestCase):
    def setUp(self):self.c=load_catalog(ROOT/'catalog.json');self.by={e['id']:e for e in self.c['models']}
    def test_four_entries_and_families(self):
        self.assertEqual(len(self.c['models']),154);self.assertEqual(len(IDS),4);self.assertEqual([self.by[i]['family'] for i in IDS],['OpenScholar-8B']*2+['ether0-24B']*2)
    def test_all_46_legacy_values_identical(self):
        old=read(EV/'baseline-catalog.json');self.assertEqual(self.c['models'][:46],old['models'])
    def test_all_historical_profiles_identical(self):
        old=read(EV/'baseline-catalog.json')
        for p in old['profiles']:
            self.assertEqual(self.c['profiles'][p],old['profiles'][p])
            if p!='all':self.assertEqual(select(self.c,p),select(old,p))
        self.assertEqual([e['id'] for e in select(self.c,'all')[:60]],[e['id'] for e in select(old,'all')]+IDS+['gpt-oss-120b-gguf-mxfp4']+['qwen3-next-80b-a3b-thinking-gguf-q6-k', 'glm-4-5-air-gguf-q4-k-m']+['huihui-glm-4-7-flash-abliterated-gguf-q4-k-m', 'huihui-qwen3-32b-abliterated-gguf-q4-k-m']+['huihui-gpt-oss-120b-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m', 'huihui-qwen3-coder-next-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m', 'qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m'])
    def test_exact_new_profiles(self):
        for p,ids in PROFILES.items():self.assertEqual([e['id'] for e in select(self.c,p)],ids)
    def test_exact_repositories_and_pins(self):
        expected=[('OpenSciLM/Llama-3.1_OpenScholar-8B','8f9c03066206880174d24f083dc46afa61a0c7a7'),('bartowski/Llama-3.1_OpenScholar-8B-GGUF','b2f6c23c36212144e5b045d1d1a8441f0703da3f'),('futurehouse/ether0','d2155a6a6c992d0da6f6c49234f0a7cb4d780e94'),('redponike/ether0-GGUF','1cd2278fa01b3a24fb530fc84eb92737516f8795')]
        for id,pair in zip(IDS,expected):self.assertEqual((self.by[id]['repository'],self.by[id]['revision']),pair)
    def test_adapter_passes_immutable_pin(self):
        for id in IDS:
            e=self.by[id]
            with patch('huggingface_hub.HfApi') as api:
                api.return_value.model_info.return_value=SimpleNamespace(sha=e['revision'],gated=False,siblings=[])
                HuggingFaceAdapter().resolve(e);api.return_value.model_info.assert_called_once_with(e['repository'],revision=e['revision'],files_metadata=True)
    def test_exact_selected_manifests_and_bytes(self):
        d=read(EV/'selected-files.json')
        for id in IDS:
            e=self.by[id];a=ResearchMetadata();p=plan(e,Path('/tmp/no1044write'),a)
            self.assertEqual(p['files'],d[id]['files']);self.assertEqual(p['total_bytes'],d[id]['total_bytes']);self.assertEqual(p['total_bytes'],e['estimated_bytes']);self.assertEqual(a.requests,[(e['repository'],e['revision'])]);self.assertEqual(set(e['required']),{f['path'] for f in p['files']})
    def test_missing_any_selected_artifact_refused(self):
        for id in IDS:
            e=self.by[id]
            for missing in e['required']:
                a=ResearchMetadata();d=a.resolve(e);d['files']=[f for f in d['files'] if f['path']!=missing]
                with patch.object(a,'resolve',return_value=d),self.assertRaises(ToolkitError):plan(e,Path('/tmp/no1044write'),a)
    def test_all_21_source_shards_and_index(self):
        e=self.by[IDS[2]];index=read(EV/'futurehouse--ether0/model.safetensors.index.json');shards={n for n in e['required'] if n.endswith('.safetensors')};self.assertEqual(len(shards),21);self.assertEqual(shards,set(index['weight_map'].values()))
        headers=read(EV/'futurehouse--ether0/safetensors-header-summary.json');self.assertEqual({x['filename'] for x in headers},shards);self.assertEqual(sum(x['parameters_by_dtype']['F32'] for x in headers),23573058560)
    def test_one_quantization_no_duplicate_sources(self):
        for id in IDS[1::2]:
            e=self.by[id];self.assertEqual(len([n for n in e['required'] if n.endswith('.gguf')]),1);self.assertFalse(any('imatrix' in n for n in e['required']))
        self.assertEqual(self.by[IDS[0]]['required'].count('pytorch_model.bin'),1)
    def test_provenance_and_roles(self):
        for i,id in enumerate(IDS):
            self.assertEqual(self.by[id]['source_kind'],'official-upstream' if i%2==0 else 'third-party-derived');self.assertEqual(self.by[id]['variant_role'],'canonical-source' if i%2==0 else 'portable-gguf')
    def test_policy_additive_and_no_selection_effect(self):
        old=read(EV/'baseline-policy.json');new=acc.policies(ROOT/'preservation-policy.json')
        for id,v in old['models'].items():self.assertEqual(new['models'][id],v)
        self.assertEqual(set(new['models']),set(self.by))
        for id in IDS:self.assertEqual(new['models'][id]['preservation_policy'],'source-and-inference');self.assertEqual([e['id'] for e in select(self.c,ids=[id])],[id])
    def test_precision_dense_and_unknown_values(self):
        self.assertEqual([self.by[i]['tensor_precision'] for i in IDS],['BF16','Q4_K_M','FP32','Q4_K_M'])
        for id in IDS:self.assertEqual(self.by[id]['architecture_type'],'dense');self.assertIsNone(self.by[id]['active_parameter_count']);self.assertFalse(self.by[id]['hp_inference_tested'])
        self.assertEqual(acc.metadata({'id':'legacy'}, {})['training_suitability'],'unknown')
        for id in IDS[::2]:self.assertIn('not been loaded or fine-tuned',self.by[id]['training_suitability'])
    def test_scientific_capabilities_not_chat(self):
        for id in IDS[2:]:self.assertEqual(self.by[id]['category'],'chemistry-reasoning');self.assertIn('smiles-generation',self.by[id]['capabilities'])
        for id in IDS[:2]:self.assertIn('scientific-literature-synthesis',self.by[id]['capabilities'])
    def test_licensing_conflict_not_erased(self):
        for id in IDS[:2]:self.assertEqual(self.by[id]['license'],'llama3.1');self.assertIn('unresolved',self.by[id]['license_notes'])
        for id in IDS[2:]:self.assertEqual(self.by[id]['license'],'apache-2.0')
    def test_gguf_architecture_tokens_template(self):
        comparisons=read(EV/'tokenizer-comparison.json')
        for r in comparisons:self.assertEqual(r['token_id_mismatch_count'],0);self.assertTrue(r['merge_lists_identical']);self.assertTrue(r['chat_template_identical'])
        for id in IDS[1::2]:
            d=read(EV/self.by[id]['repository'].replace('/','--')/'gguf-header-summary.json');m=d['metadata'];self.assertEqual(d['gguf_version'],3);self.assertEqual(m['general.architecture'],'llama');self.assertEqual(m['general.file_type'],15);self.assertEqual(m['llama.context_length'],self.by[id]['context_length']);self.assertTrue(m['tokenizer.chat_template']);self.assertIn('unknown',self.by[id]['conversion_source_revision'])
    def test_all_eight_dry_runs_write_nothing(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'absent'
            for opts in [['--model',i] for i in IDS]+[['--profile',p] for p in PROFILES]:
                out=io.StringIO()
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=ResearchMetadata()),contextlib.redirect_stdout(out):self.assertEqual(main(['--root',str(root),*opts,'--dry-run']),0)
                self.assertIn('Required with reserve:',out.getvalue());self.assertFalse(root.exists())
    def test_large_source_and_profile_yes_still_requires_allow(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'absent'
            for opts in [['--model',IDS[2]],['--profile','scientific-research-preservation']]:
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=ResearchMetadata()),patch('model_acquire.space',return_value=(10**15,10**12)),contextlib.redirect_stdout(io.StringIO()),self.assertRaisesRegex(ToolkitError,'--allow-large'):main(['--root',str(root),*opts,'--yes'])
                self.assertFalse(root.exists())
    def test_mount_guard_before_metadata_for_real_acquisition(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'absent'
            with patch('modelkit.mounts.is_mounted',return_value=False),patch('modelkit.huggingface.HuggingFaceAdapter',side_effect=AssertionError('must stop earlier')),contextlib.redirect_stdout(io.StringIO()),self.assertRaises(ToolkitError):main(['--root',str(root),'--expected-mount',t,'--model',IDS[0],'--yes'])
            self.assertFalse(root.exists())
    def test_totals_reserve_and_dependency_dedup(self):
        es=select(self.c,'scientific-research-preservation');total=sum(e['estimated_bytes'] for e in es);self.assertEqual(total,129634502906);self.assertEqual(space(ROOT,total)[1],int(total*1.1)+1024**3)
        self.assertEqual(select(self.c,ids=[IDS[0],IDS[0]]),[self.by[IDS[0]]]);self.assertEqual([e['id'] for e in select(self.c,ids=['f5-tts-v1-base-inference'])],['f5-tts-vocos-mel-24khz','f5-tts-v1-base-inference'])
    def test_production_modules_byte_identical(self):
        checks=read(EV/'baseline-PACKAGE-CHECKSUMS.json')
        names=[n for n in checks if n.endswith('.py') and not n.startswith(('tests/','evidence/')) and n!='modelkit/__init__.py']+['requirements.txt','settings.json','setup-linux.sh','setup-windows.ps1','tests/fixtures/core-v1.0.3.py.txt']
        for n in names:self.assertEqual(hashlib.sha256(legacy_bytes(ROOT/n)).hexdigest(),checks[n],n)

class ScientificFixtureTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name);self.root=self.base/'models';c=load_catalog(ROOT/'catalog.json');self.e=copy.deepcopy(next(e for e in c['models'] if e['id']==IDS[0]));self.data={n:b'inert fixture: '+n.encode() for n in self.e['required']};self.data['pytorch_model.bin']=b"cos\nsystem\n(S'never execute this checkpoint'\ntR.";self.a=Fake(self.data);self.a.rev=self.e['revision'];self.c={'schema_version':1,'models':[self.e],'profiles':{'all':'all'}};self.out=contextlib.redirect_stdout(io.StringIO());self.out.__enter__()
    def tearDown(self):self.out.__exit__(None,None,None);self.tmp.cleanup()
    def test_pytorch_payload_acquired_verified_without_deserialization(self):
        with patch.object(pickle,'load',side_effect=AssertionError('no unpickle')),patch.object(pickle,'loads',side_effect=AssertionError('no unpickle')):
            p=plan(self.e,self.root,self.a);acquire(p,self.root,self.a);self.assertEqual(inventory(self.root,self.c,verify=True)['models'][0]['status'],'verified');self.assertEqual((Path(p['target'])/'payload/pytorch_model.bin').read_bytes(),self.data['pytorch_model.bin'])
    def test_resume_reuses_completed_artifact(self):
        p=plan(self.e,self.root,self.a);original=self.a.download
        def interrupt(e,r,n,t,force=False):
            if n=='pytorch_model.bin':raise KeyboardInterrupt
            return original(e,r,n,t,force)
        with patch.object(self.a,'download',side_effect=interrupt),self.assertRaises(KeyboardInterrupt):acquire(p,self.root,self.a)
        before=list(self.a.calls);acquire(plan(self.e,self.root,self.a),self.root,self.a)
        for n in before:self.assertEqual(self.a.calls.count(n),1)
        self.assertEqual(plan(self.e,self.root,self.a)['estimated_new_bytes'],0)
    def test_corruption_repair_quarantines_bin(self):
        p=plan(self.e,self.root,self.a);acquire(p,self.root,self.a);f=Path(p['target'])/'payload/pytorch_model.bin';f.write_bytes(b'corrupt')
        self.assertEqual(inventory(self.root,self.c,verify=True)['models'][0]['status'],'failed');acquire(plan(self.e,self.root,self.a),self.root,self.a,repair=True)
        self.assertEqual(next(Path(p['target']).glob('quarantine/*/pytorch_model.bin')).read_bytes(),b'corrupt');self.assertEqual(f.read_bytes(),self.data['pytorch_model.bin'])
    def test_new_entry_external_registry_compatible(self):
        ext=self.base/'external';ext.mkdir()
        for n,b in self.data.items():(ext/n).write_bytes(b)
        spec={'instance_id':'science','model_id':self.e['id'],'artifact_kind':'model-artifacts','files':{n:str(ext/n) for n in self.data},'associated_projects':['AgRegen']}
        self.assertEqual(reg.register(self.root,self.c,spec)['status'],'external-registered');self.assertEqual(reg.verify(self.root,self.c,'science',self.a)['status'],'external-verified')
    def test_inventory_export_training_and_storage(self):
        p=plan(self.e,self.root,self.a);acquire(p,self.root,self.a);d=acc.collect(self.root,self.c,acc.policies(ROOT/'preservation-policy.json'));r=d['models'][0];self.assertEqual(r['status'],'downloaded-verified');self.assertEqual(r['preservation_policy'],'source-and-inference');self.assertGreaterEqual(r['storage_bytes'],sum(len(b) for b in self.data.values()));self.assertEqual(json.loads(acc.render(d,'json'))['models'][0]['id'],self.e['id']);self.assertEqual(list(csv.DictReader(io.StringIO(acc.render(d,'csv'))))[0]['variant_role'],'canonical-source');self.assertIn('canonical-source',acc.render(d))

    def test_ether0_sharded_fixture_resume_and_index_verification(self):
        c=load_catalog(ROOT/'catalog.json');e=next(e for e in c['models'] if e['id']==IDS[2]);data={n:b'inert small shard' for n in e['required']};data['model.safetensors.index.json']=(EV/'futurehouse--ether0/model.safetensors.index.json').read_bytes();a=Fake(data);a.rev=e['revision'];p=plan(e,self.root,a);original=a.download
        def interrupted(entry,rev,name,target,force=False):
            if name=='model-00002-of-00021.safetensors':raise KeyboardInterrupt
            return original(entry,rev,name,target,force)
        with patch.object(a,'download',side_effect=interrupted),self.assertRaises(KeyboardInterrupt):acquire(p,self.root,a)
        acquire(plan(e,self.root,a),self.root,a);self.assertEqual(a.calls.count('model-00001-of-00021.safetensors'),1)
        manifest=read(Path(p['target'])/'manifest.json');self.assertEqual(manifest['status'],'verified');self.assertEqual(len([n for n in manifest['files'] if n.endswith('.safetensors')]),21)

from maintenance_guard import legacy_bytes
