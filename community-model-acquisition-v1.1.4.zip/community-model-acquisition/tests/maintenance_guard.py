"""Exact approved maintenance diff, not an exemption for entire functions/files."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def legacy_bytes(path):
    from education_guard import baseline_bytes
    path=Path(path);data=baseline_bytes(path)
    name=path.relative_to(ROOT).as_posix()
    recovery=ROOT/'tests/fixtures/recovery-maintenance-delta.json'
    assert hashlib.sha256(recovery.read_bytes()).hexdigest()=='c777d583121dec6b8eb3ad0e04439af8cbbde15d8f4f71c9a21e71e502ac1563', 'Approved recovery delta changed'
    recovery_changes=json.loads(recovery.read_text())
    if name in recovery_changes:
        import base64
        assert hashlib.sha256(data).hexdigest()==recovery_changes[name]['approved_sha256'], 'Unapproved recovery source change: '+name
        data=base64.b64decode(recovery_changes[name]['baseline_b64'])
    approved=ROOT/'tests/fixtures/storage-maintenance-delta.json'
    assert hashlib.sha256(approved.read_bytes()).hexdigest()=='fa99869df365b0fde68d7460c8b8dcccc38863ceeceaa52421239ceb72774548', 'Approved storage delta changed'
    changes=json.loads(approved.read_text())
    if name in changes:
        import base64
        assert hashlib.sha256(data).hexdigest()==changes[name]['approved_sha256'], 'Unapproved storage source change: '+name
        data=base64.b64decode(changes[name]['baseline_b64'])
    if name not in ('modelkit/core.py','model_acquire.py'):return data
    fixture=ROOT/'tests/fixtures/path-maintenance-delta.json'
    assert hashlib.sha256(fixture.read_bytes()).hexdigest()=="5c074f7bcb067b80bdfe08c1e096fe05c5df83757eed6b6bb4b9a6d774a7008f", 'Approved maintenance delta changed'
    delta=json.loads(fixture.read_text())[name]
    new=delta['new'].encode();old=delta['old'].encode()
    assert data.count(new)==1, 'Approved maintenance source changed or duplicated: '+name
    return data.replace(new,old,1)
