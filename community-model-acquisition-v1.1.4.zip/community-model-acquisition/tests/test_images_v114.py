"""Image preservation qualification; metadata and inert synthetic bytes, never inference."""
import contextlib,copy,hashlib,io,json,tempfile,unittest,zipfile
from pathlib import Path
from types import SimpleNamespace as N
from unittest.mock import patch
from modelkit import core,accountability,archive_report
from modelkit.huggingface import HuggingFaceAdapter
from modelkit.selected_audit import verify_selected
import model_acquire,model_report
ROOT=Path(__file__).resolve().parents[1]
NEW=json.loads((ROOT/'evidence/v1.1.4/new-ids.json').read_text())
PRIMARY=json.loads((ROOT/'evidence/v1.1.4/primary-ids.json').read_text())
class ImageCatalogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c=core.load_catalog(ROOT/'catalog.json');cls.by={e['id']:e for e in cls.c['models']};cls.new=[cls.by[i] for i in NEW]
    def test_all_new_entries(self):self.assertEqual(len(NEW),86);self.assertEqual(len(PRIMARY),27);self.assertEqual(len(self.c['models']),154)
    def test_all_requested_dispositions(self):
        d=core.read(ROOT/'evidence/v1.1.4/targets.json');self.assertEqual(len(d),16);self.assertEqual(sum(bool(x['model_ids']) for x in d),15)
        self.assertIn('blocked',next(x for x in d if x['target']=='WAI-NSFW-Illustrious')['disposition'])
    def test_old_68_values_identical(self):
        from image_guard import baseline_bytes
        self.assertEqual(self.c['models'][:68],json.loads(baseline_bytes(ROOT/'catalog.json'))['models'])
    def test_old_profiles_identical(self):
        from image_guard import baseline_bytes
        old=json.loads(baseline_bytes(ROOT/'catalog.json'))
        for p,v in old['profiles'].items():
            self.assertEqual(self.c['profiles'][p],v)
            if p!='all':self.assertEqual(core.select(self.c,p),core.select(old,p))
    def test_old_policy_identical(self):
        from image_guard import baseline_bytes
        old=json.loads(baseline_bytes(ROOT/'preservation-policy.json'));now=core.read(ROOT/'preservation-policy.json')
        for k,v in old['models'].items():self.assertEqual(v,now['models'][k])
    def test_protected_application_bytes(self):
        for name,sha in core.read(ROOT/'evidence/v1.1.4/protected-sha256.json').items():self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),sha,name)
    def test_revisions_and_manifest_sizes(self):
        for e in self.new:
            self.assertRegex(e['revision'],r'^[a-f0-9]{40}$');self.assertEqual(e['estimated_bytes'],sum(f['size'] for f in e['pinned_files']))
            self.assertEqual(e['include'],e['required']);self.assertEqual(e['include'],[f['path'] for f in e['pinned_files']])
            for f in e['pinned_files']:self.assertTrue(f['sha256'] or f['git_blob_sha1'])
    def test_reviewed_manifests_exact(self):
        d=core.read(ROOT/'evidence/v1.1.4/selected-manifests.json')
        for e in self.new:self.assertEqual(d[e['id']],dict(repository=e['repository'],revision=e['revision'],files=e['pinned_files']))
    def test_publishers(self):
        self.assertEqual(self.by['noobai-xl-1-1-original']['publisher'],'Laxhar');self.assertEqual(self.by['illustrious-xl-v1-0-original']['publisher'],'OnomaAIResearch')
    def test_provenance(self):
        for e in self.new:
            if e['repository'].startswith(('city96/','unsloth/','Comfy-Org/','comfyanonymous/')):self.assertEqual(e['source_kind'],'third-party-derived')
        self.assertEqual(self.by['flux2-klein-4b-fp8']['source_kind'],'official-derived')
        self.assertEqual(self.by['sd15-original']['source_kind'],'third-party-derived')
    def test_native_vs_optimized(self):
        self.assertEqual(self.by['flux2-dev-original']['variant_role'],'canonical-source');self.assertEqual(self.by['flux2-dev-nvfp4-mixed']['source_kind'],'official-derived');self.assertNotEqual(self.by['flux2-dev-nvfp4-mixed']['format'],'GGUF')
    def test_refiner_optional(self):self.assertNotIn('sdxl-refiner-1-0-original',[e['id'] for e in core.select(self.c,ids=['sdxl-base-1-0-original'])])
    def test_editing_same_checkpoint(self):
        for id in ('flux2-dev-original','flux2-klein-4b-original'):
            self.assertIn('text-to-image',self.by[id]['capabilities']);self.assertIn('instruction-image-editing',self.by[id]['capabilities'])
    def test_edit_version_explicit(self):self.assertEqual(self.by['qwen-image-edit-2511-original']['repository'],'Qwen/Qwen-Image-Edit-2511')
    def test_hidream_full_not_fast(self):self.assertEqual(self.by['hidream-i1-full-original']['repository'],'HiDream-ai/HiDream-I1-Full')
    def test_hidream_gated_llama_required(self):
        chosen=core.select(self.c,ids=['hidream-i1-full-original']);self.assertIn('hidream-llama3-1-8b-instruct-component',[e['id'] for e in chosen]);self.assertEqual(self.by['hidream-llama3-1-8b-instruct-component']['gated_at_review'],'manual')
    def test_gates_retained(self):self.assertEqual(self.by['flux1-dev-original']['gated_at_review'],'auto')
    def test_licenses_not_unrestricted(self):
        self.assertIn('noncommercial',self.by['noobai-xl-1-1-original']['license']);self.assertIn('Non-Commercial',self.by['flux2-dev-original']['license'])
    def test_safety_checker_preserved(self):self.assertTrue(any('safety-checker' in e['id'] for e in core.select(self.c,ids=['sd15-fp16'])))
    def test_no_payload_execution_formats(self):
        for e in self.new:self.assertFalse(any(p.endswith(('.py','.pkl','.pth','.ckpt','.bin')) for p in e['include']))
    def test_no_arbitrary_globs(self):
        for e in self.new:self.assertFalse(any('*' in p or '?' in p for p in e['include']))
    def test_gguf_runtime_not_llama_cpp(self):
        for e in self.new:
            if e['format']=='GGUF':self.assertIn('ComfyUI-GGUF',e['runtime_notes'])
    def test_shared_dependency_reused(self):
        a=core.select(self.c,ids=['flux2-klein-4b-fp8','z-image-turbo-bf16-comfy']);ids=[e['id'] for e in a]
        self.assertEqual(ids.count('image-qwen3-4b-comfy'),1);self.assertEqual(len(ids),len(set(ids)))
    def test_different_flux2_vae_not_substituted(self):
        a=set(self.by['flux2-klein-4b-fp8']['dependencies']);b=set(self.by['flux2-dev-gguf-q4-k-m']['dependencies']);self.assertIn('image-flux2-vae-comfy',a);self.assertNotIn('image-flux2-vae-comfy',b)
    def test_layout_references_selected_exact_files(self):
        for id in PRIMARY:
            selected={e['id']:e for e in core.select(self.c,ids=[id])}
            for m in self.by[id]['component_layout']:self.assertIn(m['source_path'],selected[m['model_id']]['include'])
    def test_deployment_layout_has_no_path_collisions(self):
        for id in PRIMARY:
            paths=[m['path'] for m in self.by[id]['component_layout']]
            self.assertEqual(len(paths),len(set(paths)),id)
    def test_no_identical_heavy_components_acquired_twice(self):
        seen={}
        for e in self.new:
            for f in e['pinned_files']:
                if f['path'].endswith('.safetensors'):
                    self.assertNotIn(f['sha256'],seen,(e['id'],seen.get(f['sha256'])));seen[f['sha256']]=e['id']
    def test_new_profiles_opt_in(self):
        profiles=[p for p in self.c['profiles'] if p.startswith('image-')];self.assertEqual(len(profiles),10)
        for p in profiles:
            chosen=core.select(self.c,p);self.assertTrue(chosen);self.assertEqual(len(chosen),len({e['id'] for e in chosen}))
    def test_profile_total_deduplicated(self):
        a=core.select(self.c,'image-generation-local-inference');self.assertEqual(sum(e['estimated_bytes'] for e in a),sum(self.by[i]['estimated_bytes'] for i in {e['id'] for e in a}))
    def test_offline_all_new_variants_no_network(self):
        with tempfile.TemporaryDirectory() as d,patch.object(HuggingFaceAdapter,'resolve',side_effect=AssertionError('network')),contextlib.redirect_stdout(io.StringIO()):
            for id in PRIMARY:self.assertEqual(model_acquire.main(['--root',d+'/absent','--model',id,'--offline-plan']),0)
            self.assertFalse((Path(d)/'absent').exists())
    def test_listing_no_archive_or_network(self):
        with tempfile.TemporaryDirectory() as d,patch.object(HuggingFaceAdapter,'resolve',side_effect=AssertionError('network')),contextlib.redirect_stdout(io.StringIO()):self.assertEqual(model_acquire.main(['--root',d+'/absent','--profile','image-editing','--list-catalog','--format','json']),0)
    def test_missing_dependency_rejected(self):
        from modelkit.dependencies import expand
        bad=copy.deepcopy(self.c);bad['models'][-1]['dependencies']=['missing']
        with self.assertRaises(core.ToolkitError):expand(bad,bad['models'])
    def test_pinned_metadata_mismatch_rejected(self):
        a=HuggingFaceAdapter();e=self.by['flux2-dev-gguf-q4-k-m']
        with patch.object(a.api,'model_info',return_value=N(sha=e['revision'],siblings=[],gated=False)),self.assertRaises(core.ToolkitError):a.resolve(e)
    def test_floating_response_rejected(self):
        a=HuggingFaceAdapter();e=self.by['sd15-original']
        with patch.object(a.api,'model_info',return_value=N(sha='main',siblings=[],gated=False)),self.assertRaises(core.ToolkitError):a.resolve(e)
    def test_uuid_guard_before_network(self):
        with tempfile.TemporaryDirectory() as d,patch.object(HuggingFaceAdapter,'resolve',side_effect=AssertionError('network')),self.assertRaisesRegex(core.ToolkitError,'No approved filesystem'):model_acquire.main(['--root',d,'--model','sd15-original','--yes'])
    def test_large_interlock(self):
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()),patch.object(model_acquire,'require_mount'),patch.object(model_acquire,'space',return_value=(10**13,10**12)),patch.object(model_acquire,'plan',return_value={'total_bytes':60*10**9,'estimated_new_bytes':60*10**9,'gated':False,'target':d}),patch.object(model_acquire,'acquire',side_effect=AssertionError('download')):
            with self.assertRaisesRegex(core.ToolkitError,'--allow-large'):model_acquire._main(['--root',d,'--model','flux2-dev-original','--yes'])
    def test_accountability_no_hashing(self):
        with tempfile.TemporaryDirectory() as d,patch.object(core,'hashes',side_effect=AssertionError('implicit hashing')):
            data=archive_report.collect(Path(d),self.c,accountability.policies(ROOT/'preservation-policy.json'),ROOT/'settings.json')
            r=next(r for r in data['models'] if r['id']=='flux2-dev-original');self.assertEqual(r['status'],'cataloged-not-downloaded');self.assertEqual(r['storage_bytes'],0);self.assertTrue(r['mandatory_dependencies']);self.assertTrue(all(v=='not-verified-local' for v in r['dependency_status'].values()))
    def test_manual_workbook_columns_preserved(self):
        with tempfile.TemporaryDirectory() as d:
            data=archive_report.collect(Path(d),self.c,{'models':{}},ROOT/'settings.json');raw=archive_report.workbook(data)
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                self.assertIsNone(z.testzip());sheet=z.read('xl/worksheets/sheet1.xml').decode();self.assertIn('Mandatory Dependencies',sheet);self.assertIn('flux2-dev-original',sheet);self.assertEqual(sum(p.startswith('xl/worksheets/sheet') for p in z.namelist()),3)
            self.assertFalse(list(Path(d).rglob('*.xlsx')))
    def test_no_automatic_workbook_path(self):self.assertNotIn('workbook(', (ROOT/'model_acquire.py').read_text())
    def test_report_old_columns_prefix(self):
        from image_guard import baseline_bytes
        import ast
        tree=ast.parse(baseline_bytes(ROOT/'modelkit/archive_report.py'))
        old=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FIELDS' for t in n.targets))
        self.assertEqual(archive_report.FIELDS[:len(old)],old)
    def test_unresolved_wai_not_acquirable(self):
        with self.assertRaises(core.ToolkitError):core.select(self.c,ids=['wai-nsfw-illustrious'])

class ImageTransferTests(unittest.TestCase):
    def setUp(self):
        from test_toolkit import Fake
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)/'archive'
        self.e=copy.deepcopy(core.load_catalog(ROOT/'catalog.json')['models'][-1]);self.e.update(id='image-test',repository='fixture/image',revision='a'*40,include=['transformer/a.safetensors','transformer/b.safetensors','transformer/model.safetensors.index.json'],required=['transformer/a.safetensors','transformer/b.safetensors','transformer/model.safetensors.index.json'],dependencies=[])
        self.a=Fake({'transformer/a.safetensors':b'inert fixture A','transformer/b.safetensors':b'inert fixture B','transformer/model.safetensors.index.json':json.dumps({'weight_map':{'a':'a.safetensors','b':'b.safetensors'}}).encode()});self.e['pinned_files']=self.a.resolve(self.e)['files'];self.p=core.plan(self.e,self.root,self.a)
        self.silence=contextlib.redirect_stdout(io.StringIO());self.silence.__enter__();self.addCleanup(self.silence.__exit__,None,None,None)
    def test_sharded_acquisition_and_selected_verification(self):
        core.acquire(self.p,self.root,self.a);self.assertEqual(verify_selected(self.root,[self.e])['models'][0]['status'],'verified')
    def test_missing_index_shard_never_complete(self):
        self.p['files']=[f for f in self.p['files'] if f['path']!='transformer/b.safetensors']
        with self.assertRaisesRegex(core.ToolkitError,'missing shard'):core.acquire(self.p,self.root,self.a)
        self.assertEqual(core.read(Path(self.p['target'])/'manifest.json')['status'],'failed')
    def test_interrupt_and_resume_reuses_completed_shard(self):
        original=self.a.download
        def transfer(e,r,n,t,force=False):
            if n.endswith('b.safetensors'):raise KeyboardInterrupt()
            return original(e,r,n,t,force)
        self.a.download=transfer
        with self.assertRaises(KeyboardInterrupt):core.acquire(self.p,self.root,self.a)
        self.assertEqual(core.read(Path(self.p['target'])/'manifest.json')['status'],'partial')
        self.a.download=original;core.acquire(self.p,self.root,self.a);self.assertEqual(self.a.calls.count('transformer/a.safetensors'),1)
    def test_corruption_quarantine_and_repair(self):
        core.acquire(self.p,self.root,self.a);p=Path(self.p['target'])/'payload/transformer/a.safetensors';p.write_bytes(b'bad')
        with self.assertRaises(core.ToolkitError):core.acquire(self.p,self.root,self.a)
        core.acquire(self.p,self.root,self.a,repair=True);self.assertEqual(next((Path(self.p['target'])/'quarantine').rglob('a.safetensors')).read_bytes(),b'bad')
    def test_dependency_missing_preserves_artifact_evidence(self):
        core.acquire(self.p,self.root,self.a);dep={**self.e,'id':'needed','dependencies':[]};parent={**self.e,'dependencies':['needed']};c={'models':[parent,dep]}
        rows=accountability.collect(self.root,c)['models'];row=next(r for r in rows if r['id']=='image-test')
        self.assertEqual(row['artifact_status'],'downloaded-verified');self.assertEqual(row['status'],'incomplete')
    def test_targeted_verification_ignores_other_payload(self):
        core.acquire(self.p,self.root,self.a)
        with patch.object(Path,'rglob',side_effect=AssertionError('unrelated scan')),patch.object(Path,'glob',side_effect=AssertionError('unrelated scan')):self.assertEqual(verify_selected(self.root,[self.e])['models'][0]['status'],'verified')
    def test_completed_acquisition_zero_new_bytes(self):
        core.acquire(self.p,self.root,self.a);self.assertEqual(core.plan(self.e,self.root,self.a)['estimated_new_bytes'],0)
