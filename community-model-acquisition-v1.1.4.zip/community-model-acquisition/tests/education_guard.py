"""Approved exact v1.1.3 deltas; protected historical source remains checked."""
import json,hashlib,base64
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def baseline_bytes(path):
    from image_guard import baseline_bytes as image_baseline
    path=Path(path);data=image_baseline(path);name=path.relative_to(ROOT).as_posix()
    f=ROOT/'tests/fixtures/education-maintenance-delta.json'
    assert hashlib.sha256(f.read_bytes()).hexdigest()=='7b1225b1ff8f6c668395be62894feb3d6e2b3df1730873679351702996fb9368', 'Education delta fixture changed'
    changes=json.loads(f.read_text())
    if name in changes:
        assert hashlib.sha256(data).hexdigest()==changes[name]['approved_sha256'], 'Unapproved education delta: '+name
        return base64.b64decode(changes[name]['baseline_b64'])
    return data
