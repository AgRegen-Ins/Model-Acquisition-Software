import contextlib,hashlib,io,json,os,tempfile,threading,unittest,urllib.request
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from modelkit import core,github,accountability
from modelkit.huggingface import HuggingFaceAdapter
from modelkit.selected_audit import verify_selected
import model_acquire
ROOT=Path(__file__).resolve().parents[1]
IDS=json.loads((ROOT/'evidence/v1.1.3/new-ids.json').read_text())

class CatalogEducationTests(unittest.TestCase):
    def setUp(self):self.c=core.load_catalog(ROOT/'catalog.json');self.new=[e for e in self.c['models'] if e['id'] in IDS]
    def test_eight_new_components(self):self.assertEqual(len(self.new),8);self.assertEqual(len([e for e in self.c['models'] if e['id'] not in json.loads((ROOT/'evidence/v1.1.4/new-ids.json').read_text())]),68)
    def test_existing_values_and_memberships_unchanged(self):
        from education_guard import baseline_bytes
        old=json.loads(baseline_bytes(ROOT/'catalog.json'))
        self.assertEqual(self.c['models'][:60],old['models'])
        for p in old['profiles']:
            if p!='all':self.assertEqual(core.select(self.c,p),core.select(old,p))
        self.assertEqual({p:self.c['profiles'][p] for p in old['profiles']},old['profiles'])
    def test_no_duplicate_or_generic_base_additions(self):
        identities=[(e['repository'],e['revision'],tuple(e['include'])) for e in self.c['models']]
        self.assertEqual(len(identities),len(set(identities)))
        self.assertFalse(any(e['repository'].startswith(('Qwen/','google/','microsoft/','openai/','deepseek-ai/')) for e in self.new))
    def test_immutable_identity_and_size(self):
        for e in self.new:
            self.assertRegex(e['revision'],r'^[a-f0-9]{40}$')
            self.assertEqual(e['estimated_bytes'],sum(f['size'] for f in e['pinned_files']))
            self.assertEqual(e['include'],e['required'])
            self.assertTrue(all(f.get('sha256') or f.get('git_blob_sha1') for f in e['pinned_files']))
    def test_classifications(self):
        self.assertEqual(sum(e['artifact_type']=='research-software' for e in self.new),3)
        self.assertEqual(sum(e['artifact_type']=='adapter' for e in self.new),3)
        self.assertTrue(all('educational-assessment' in e['capabilities'] for e in self.new))
    def test_dependencies_do_not_acquire_base_weights(self):
        chosen=core.select(self.c,ids=['argulens-qwen2-5-7b-classifier-lora'])
        self.assertEqual([e['id'] for e in chosen],['argulens-research-software','argulens-qwen2-5-7b-classifier-lora'])
        self.assertEqual(len(core.select(self.c,'argulens-preservation')),3)
        self.assertEqual(len(core.select(self.c,'educational-assessment')),8)
    def test_adapter_base_revision_unknown_explicit(self):
        for e in self.new:
            if e['artifact_type']=='adapter':
                self.assertTrue(e['base_model']);self.assertIsNone(e['runtime_dependencies'][0]['revision'])
    def test_release_asset_digest_matches_source(self):
        e=next(e for e in self.new if e['id']=='argulens-qwen2-5-7b-classifier-lora')
        self.assertEqual(e['pinned_files'][0]['asset_id'],493658128)
        self.assertEqual(e['pinned_files'][0]['sha256'],'7ab62b983fdc66085280b6418ee662a5f833831208a0cde79d1c959adb9660c0')
    def test_selected_snapshot_membership(self):
        evidence=core.read(ROOT/'evidence/v1.1.3/selected-manifests.json')
        for e in self.new:self.assertEqual(e['pinned_files'],evidence[e['id']]['files'])
        auto=next(e for e in self.new if e['id']=='autoscore-research-software')
        self.assertTrue(any(p.startswith('prompts/') for p in auto['include']))
        self.assertIn('utils/metrics.py',auto['include']);self.assertFalse(any(p.startswith('datasets/') for p in auto['include']))
    def test_listing_and_offline_plan_no_network_or_archive_write(self):
        with tempfile.TemporaryDirectory() as d,patch.object(HuggingFaceAdapter,'resolve',side_effect=AssertionError('network')),contextlib.redirect_stdout(io.StringIO()):
            root=Path(d)/'absent'
            self.assertEqual(model_acquire.main(['--root',str(root),'--profile','educational-assessment','--list-catalog','--format','json']),0)
            self.assertEqual(model_acquire.main(['--root',str(root),'--profile','educational-assessment','--offline-plan']),0)
            self.assertFalse(root.exists())
    def test_uuid_guard_before_new_acquisition(self):
        with tempfile.TemporaryDirectory() as d,patch.object(HuggingFaceAdapter,'resolve',side_effect=AssertionError('network')):
            with self.assertRaisesRegex(core.ToolkitError,'No approved filesystem'):model_acquire.main(['--root',d,'--model','autoscore-research-software','--yes'])
    def test_selected_verify_readonly_mix_refused(self):
        with self.assertRaises(core.ToolkitError):model_acquire.main(['--verify-selected','--inventory','--model','autoscore-research-software'])
    def test_inventory_reports_cataloged_not_downloaded(self):
        with tempfile.TemporaryDirectory() as d:
            rows=accountability.collect(Path(d),self.c)['models']
            for r in rows:
                if r['id'] in IDS:self.assertEqual(r['status'],'cataloged-not-downloaded')

    def test_existing_preservation_policy_unchanged(self):
        from education_guard import baseline_bytes
        old=json.loads(baseline_bytes(ROOT/'preservation-policy.json'))
        current=core.read(ROOT/'preservation-policy.json')
        for key,value in old['models'].items():self.assertEqual(current['models'][key],value)
        self.assertEqual(set(current['models'])-set(old['models'])-set(json.loads((ROOT/'evidence/v1.1.4/new-ids.json').read_text())),set(IDS))
    def test_xlsx_catalog_only_contains_each_component(self):
        import zipfile
        from modelkit.archive_report import collect,workbook
        with tempfile.TemporaryDirectory() as d:
            data=collect(Path(d),self.c,accountability.policies(ROOT/'preservation-policy.json'),ROOT/'settings.json')
            with zipfile.ZipFile(io.BytesIO(workbook(data))) as z:
                self.assertIsNone(z.testzip());sheet=z.read('xl/worksheets/sheet1.xml').decode()
                for id in IDS:self.assertIn(id,sheet)
                self.assertIn('cataloged-not-downloaded',sheet)
    def test_hf_pinned_manifest_tampering_refused(self):
        from types import SimpleNamespace as N
        e=next(e for e in self.new if e['adapter']=='huggingface')
        adapter=HuggingFaceAdapter()
        info=N(sha=e['revision'],siblings=[N(rfilename=e['pinned_files'][0]['path'],size=1,lfs=None,blob_id='a'*40)],gated=False)
        with patch.object(adapter.api,'model_info',return_value=info),self.assertRaises(core.ToolkitError):adapter.resolve(e)
    def test_large_interlock_before_acquisition(self):
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()),patch.object(model_acquire,'require_mount'),patch.object(model_acquire,'space',return_value=(10**12,10**11)),patch.object(model_acquire,'plan',return_value={'total_bytes':60*10**9,'estimated_new_bytes':60*10**9,'gated':False,'target':d}),patch.object(model_acquire,'acquire',side_effect=AssertionError('download')):
            with self.assertRaisesRegex(core.ToolkitError,'--allow-large'):
                model_acquire._main(['--root',d,'--model','autoscore-research-software','--yes'])

    def test_software_snapshot_coverage_against_publisher_trees(self):
        byid={e['id']:e for e in self.new}
        for family in ('aiawe','autoscore','argulens'):
            tree=core.read(ROOT/('evidence/v1.1.3/publisher-metadata/'+family+'-tree.json'))
            expected={f['path'] for f in tree['tree'] if f['type']=='blob'}
            entry=byid[family+'-research-software']
            actual=set(entry['include'])|{f['path'] for f in entry.get('withheld_files',[])}
            if family=='argulens':actual|=set(byid['argulens-lightgbm-scorer']['include'])
            self.assertEqual(actual,expected)

class GitHubFixtureTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)/'archive'
        self.data=b'print("never execute repository code")\n'*40;self.rev='a'*40;self.tree='b'*40
        self.f=dict(path='source.py',size=len(self.data),sha256=hashlib.sha256(self.data).hexdigest(),git_blob_sha1=hashlib.sha1(b'blob '+str(len(self.data)).encode()+b'\0'+self.data).hexdigest())
        self.e=dict(id='fixture',category='research-software',adapter='github',repository='publisher/source',revision=self.rev,pinned_files=[self.f],include=['source.py'],required=['source.py'],exclude=[],quantization='none')
        self.adapter=github.GitHubAdapter();self.requests=[];self.mode='normal'
        outer=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_GET(self):
                requested=self.headers.get('Range');outer.requests.append(requested)
                offset=int(requested.split('=')[1].split('-')[0]) if requested else 0
                data=outer.data
                self.send_response(206 if requested else 200)
                if requested:self.send_header('Content-Range',f'bytes {offset}-{len(data)-1}/{len(data)}')
                self.end_headers()
                if outer.mode=='interrupt':self.wfile.write(data[offset:offset+50])
                elif outer.mode=='corrupt':self.wfile.write(b'x'*(len(data)-offset))
                elif outer.mode=='excess':self.wfile.write(data[offset:]+b'x')
                else:self.wfile.write(data[offset:])
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler);self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.addCleanup(self.server.server_close);self.addCleanup(self.server.shutdown)
        def transport(url,headers=None):
            # Test-only local endpoint; production allowlist is not changed.
            return urllib.request.build_opener(urllib.request.ProxyHandler({})).open(urllib.request.Request('http://127.0.0.1:'+str(self.server.server_port),headers=headers or {}),timeout=5)
        self.transport=patch.object(github,'open_url',transport);self.transport.start();self.addCleanup(self.transport.stop)
        self.silence=contextlib.redirect_stdout(io.StringIO());self.silence.__enter__();self.addCleanup(self.silence.__exit__,None,None,None)
    def metadata(self,url):
        if '/commits/' in url:return {'sha':self.rev,'commit':{'tree':{'sha':self.tree}}}
        return {'sha':self.tree,'truncated':False,'tree':[{'path':'source.py','type':'blob','mode':'100644','size':len(self.data),'sha':self.f['git_blob_sha1']}]}
    def plan(self):
        with patch.object(github,'json_url',self.metadata):return core.plan(self.e,self.root,self.adapter)
    def test_pinned_tree_resolution_and_bytes(self):
        p=self.plan();self.assertEqual(p['total_bytes'],len(self.data));self.assertEqual(p['revision'],self.rev)
    def test_truncated_tree_refused(self):
        def meta(url):
            m=self.metadata(url)
            if 'tree' in m:m['truncated']=True
            return m
        with patch.object(github,'json_url',meta),self.assertRaises(core.ToolkitError):core.plan(self.e,self.root,self.adapter)
    def test_symlink_git_blob_refused(self):
        def meta(url):
            m=self.metadata(url)
            if 'tree' in m:m['tree'][0]['mode']='120000'
            return m
        with patch.object(github,'json_url',meta),self.assertRaises(core.ToolkitError):core.plan(self.e,self.root,self.adapter)
    def test_floating_revision_refused(self):
        self.e['revision']='main'
        with self.assertRaises(core.ToolkitError):self.plan()
    def test_tree_digest_mismatch_refused(self):
        self.f['git_blob_sha1']='c'*40
        with patch.object(github,'json_url',lambda url: {'sha':self.rev,'commit':{'tree':{'sha':self.tree}}} if '/commits/' in url else {'sha':self.tree,'truncated':False,'tree':[]}),self.assertRaises(core.ToolkitError):core.plan(self.e,self.root,self.adapter)
    def test_gated_inaccessible_no_manifest(self):
        with patch.object(github,'json_url',side_effect=PermissionError('403')),self.assertRaises(PermissionError):core.plan(self.e,self.root,self.adapter)
        self.assertFalse(self.root.exists())
    def test_payload_acquisition_inert_and_verified(self):
        p=self.plan();core.acquire(p,self.root,self.adapter,retries=1)
        self.assertEqual(core.read(Path(p['target'])/'manifest.json')['status'],'verified')
        self.assertEqual((Path(p['target'])/'payload/source.py').read_bytes(),self.data)
    def test_interruption_resume(self):
        p=self.plan();self.mode='interrupt'
        with self.assertRaises(core.ToolkitError):core.acquire(p,self.root,self.adapter,retries=1)
        self.assertEqual(core.read(Path(p['target'])/'manifest.json')['status'],'failed')
        self.assertFalse((Path(p['target'])/'payload/source.py').exists())
        self.mode='normal';core.acquire(p,self.root,self.adapter,retries=1)
        self.assertEqual(self.requests,[None,'bytes=50-'])
    def test_completed_rerun_no_download(self):
        p=self.plan();core.acquire(p,self.root,self.adapter,retries=1);core.acquire(p,self.root,self.adapter,retries=1)
        self.assertEqual(len(self.requests),1)
    def test_corrupt_payload_quarantined(self):
        p=self.plan();self.mode='corrupt'
        with self.assertRaises(core.ToolkitError):core.acquire(p,self.root,self.adapter,retries=1)
        self.assertEqual(core.read(Path(p['target'])/'manifest.json')['status'],'failed')
        self.assertTrue(list((Path(p['target'])/'quarantine').rglob('source.py')))
    def test_excess_response_refused(self):
        p=self.plan();self.mode='excess'
        with self.assertRaises(core.ToolkitError):core.acquire(p,self.root,self.adapter,retries=1)
        self.assertNotEqual(core.read(Path(p['target'])/'manifest.json')['status'],'verified')
    def test_selected_audit_never_scans_unrelated(self):
        p=self.plan();core.acquire(p,self.root,self.adapter,retries=1)
        unrelated=self.root/'other/revision';unrelated.mkdir(parents=True);(unrelated/'manifest.json').write_text('invalid')
        with patch.object(Path,'glob',side_effect=AssertionError('whole archive scan')),patch.object(Path,'rglob',side_effect=AssertionError('whole archive scan')):
            d=verify_selected(self.root,[self.e]);self.assertEqual(d['models'][0]['status'],'verified')
    def test_selected_audit_detects_corruption(self):
        p=self.plan();core.acquire(p,self.root,self.adapter,retries=1);(Path(p['target'])/'payload/source.py').write_bytes(b'x'*len(self.data))
        self.assertEqual(verify_selected(self.root,[self.e])['models'][0]['status'],'failed')
    def test_missing_selected_manifest_not_verified(self):self.assertEqual(verify_selected(self.root,[self.e])['models'][0]['status'],'not downloaded')
    def test_selected_manifest_identity_mismatch_refused(self):
        p=self.plan();core.acquire(p,self.root,self.adapter,retries=1);m=Path(p['target'])/'manifest.json';d=core.read(m);d['revision']='c'*40;core.write(m,d)
        with self.assertRaises(core.ToolkitError):verify_selected(self.root,[self.e])
    def test_redirect_allowlist(self):
        for url in ['http://github.com/x','https://evil.test/x','https://github.com@evil.test/x','file:///tmp/x']:
            with self.assertRaises(core.ToolkitError):github.checked_url(url)
    def test_symlink_partial_refused(self):
        p=self.plan();target=Path(p['target'])/'payload';target.mkdir(parents=True);(target/'.github-cache').symlink_to(Path(self.tmp.name))
        with self.assertRaises(core.ToolkitError):self.adapter.download(self.e,self.rev,'source.py',target)
    def test_capacity_reserve_unchanged(self):
        with patch('modelkit.core.shutil.disk_usage',return_value=type('Usage',(),{'free':1})()):free,needed=core.space(Path(self.tmp.name),100)
        self.assertEqual(free,1);self.assertEqual(needed,110+1024**3)

    def test_release_asset_digest_mismatch_refused(self):
        self.f['asset_id']=123
        def meta(url):
            if '/assets/' in url:return {'id':123,'name':'source.py','size':len(self.data),'digest':'sha256:'+'0'*64,'state':'uploaded'}
            return self.metadata(url)
        with patch.object(github,'json_url',meta),self.assertRaises(core.ToolkitError):core.plan(self.e,self.root,self.adapter)
    def test_storage_loss_never_commits_complete(self):
        p=self.plan()
        with patch.object(github,'checkpoint',side_effect=core.ToolkitError('storage unavailable')),self.assertRaises(core.ToolkitError):core.acquire(p,self.root,self.adapter,retries=1)
        self.assertNotEqual(core.read(Path(p['target'])/'manifest.json')['status'],'verified')
        self.assertFalse((Path(p['target'])/'payload/source.py').exists())
    def test_unselected_file_refused(self):
        with self.assertRaises(core.ToolkitError):self.adapter.download(self.e,self.rev,'other.py',self.root)
        self.assertFalse(self.root.exists())
    def test_selected_manifest_expected_tampering_refused(self):
        p=self.plan();core.acquire(p,self.root,self.adapter,retries=1);path=Path(p['target'])/'manifest.json';state=core.read(path);state['expected'][0]['size']=1;core.write(path,state)
        with self.assertRaises(core.ToolkitError):verify_selected(self.root,[self.e])
