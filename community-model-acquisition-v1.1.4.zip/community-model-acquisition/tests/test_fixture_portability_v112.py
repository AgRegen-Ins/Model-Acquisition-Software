"""Ownership-independent simulation; production owner checks remain unchanged."""
import hashlib,json,unittest
from pathlib import Path
from unittest.mock import patch
import test_recovery_v111 as previous

class FixturePortabilityTests(unittest.TestCase):
    def run_as_owner(self,uid,gid,mode,extra=None):
        # Inject the metadata seen by the fixture, without chown or privileges.
        script=previous.PERMISSION_SCRIPT.replace('p,v,e=real(root,physical,fd)',
            'p,v,e=real(root,physical,fd)\n    e=NS(st_dev=e.st_dev,st_mode=e.st_mode,st_uid='+str(uid)+',st_gid='+str(gid)+')')
        with patch.object(previous,'PERMISSION_SCRIPT',script):
            return previous.SimulatedPermissionTests().run_fixture(mode,extra)
    def test_recovery_simulation_independent_of_owner(self):
        for uid,gid in [(0,0),(1000,1000),(1000,0),(0,1000),(65534,65534)]:
            with self.subTest(uid=uid,gid=gid):
                inventory=self.run_as_owner(uid,gid,'inventory')
                comparison=self.run_as_owner(uid,gid,'compare')
                self.assertTrue(inventory['summary']['scan_complete'])
                self.assertEqual(inventory['warnings'],[])
                self.assertEqual(len(inventory['excluded_filesystem_entries']),1)
                self.assertTrue(comparison['match'])
                self.assertEqual(comparison['source_bytes'],3)
                self.assertEqual(comparison['destination_bytes'],3)
    def test_nonroot_simulation_preserves_unrelated_permission_errors(self):
        for extra in ('unexpected','category/lost+found'):
            with self.subTest(extra=extra):
                inventory=self.run_as_owner(1000,1000,'inventory',extra)
                comparison=self.run_as_owner(1000,1000,'compare',extra)
                self.assertFalse(inventory['summary']['scan_complete'])
                self.assertEqual(comparison,{'permission_error':Path(extra).name})
    def test_production_files_unchanged_from_v111(self):
        root=Path(__file__).resolve().parents[1]
        fixture=root/'tests/fixtures/v111-production-hashes.json'
        self.assertEqual(hashlib.sha256(fixture.read_bytes()).hexdigest(),'a129264916be04a5f537df379e07328354f6e9dd494342f50c46c9a34b506b46')
        for name,digest in json.loads(fixture.read_text()).items():
            with self.subTest(file=name):self.assertEqual(hashlib.sha256(__import__("education_guard").baseline_bytes(root/name)).hexdigest(),digest)
