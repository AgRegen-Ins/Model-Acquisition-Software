"""Optional small network smoke test; not part of offline unittest discovery.
Run: python tests/live_metadata_smoke.py
Uses a temporary directory; downloads only card/config/license (no weights).
"""
import sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,plan,acquire,inventory
from modelkit.huggingface import HuggingFaceAdapter
if __name__=='__main__':
    c=load_catalog(Path(__file__).resolve().parents[1]/'catalog.json')
    e=next(e for e in c['models'] if e['id']=='qwen3-4b-original')
    e={**e,'id':'metadata-smoke','include':['README.md','config.json','LICENSE'],'required':['README.md','config.json'],'exclude':[]}
    with tempfile.TemporaryDirectory(prefix='model live smoke ') as d:
        root=Path(d);a=HuggingFaceAdapter();p=plan(e,root,a)
        acquire(p,root,a);acquire(p,root,a)
        result=inventory(root,{'models':[e]},verify=True)
        assert result['models'][0]['status']=='verified'
        print('Live metadata download, rerun, and offline audit passed.')
