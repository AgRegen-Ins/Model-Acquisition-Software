"""Huihui-only Q4_K_M catalog additions. No real weights or inference in tests."""
import contextlib,copy,hashlib,io,json,pickle,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,select,plan,acquire,inventory,read,space,ToolkitError
from modelkit.huggingface import HuggingFaceAdapter
from modelkit import accountability as acc,storage
from storage_test_support import main
from test_toolkit import Fake
ROOT=Path(__file__).resolve().parents[1];EV=ROOT/'evidence/v1.0.4.8'
class Metadata:
    def resolve(self,e):
        d=read(EV/e['repository'].replace('/','--')/'api.json');assert e['revision']==d['sha']
        return {'revision':d['sha'],'metadata':d,'gated':bool(d.get('gated')),'files':[{'path':f['rfilename'],'size':f['size'],'sha256':(f.get('lfs') or {}).get('sha256'),'git_blob_sha1':None if f.get('lfs') else f['blobId']} for f in d['siblings']]}
    def download(self,*a,**kw):raise AssertionError('No network payloads in tests')
IDS=read(EV/'new-ids.json');G=IDS[0]
class Catalog1048Tests(unittest.TestCase):
    def setUp(self):self.c=load_catalog(ROOT/'catalog.json');self.es=self.c['models'][55:60]
    def test_five_new_and_55_unchanged(self):
        self.assertEqual(self.c['models'][:55],read(EV/'baseline-catalog.json')['models']);self.assertEqual([e['id'] for e in self.es],IDS);self.assertEqual(len(self.es),5);self.assertEqual(len({e['id'] for e in self.c['models']}),154)
    def test_historical_profiles_unchanged(self):
        old=read(EV/'baseline-catalog.json');self.assertEqual({k:self.c['profiles'][k] for k in old['profiles']},old['profiles']);self.assertEqual({k:self.c['profile_members'][k] for k in old['profile_members']},old['profile_members'])
        for p in old['profiles']:
            if p!='all':self.assertEqual(select(self.c,p),select(old,p))
        self.assertEqual(select(self.c,'all')[:60],old['models']+self.es)
    def test_pins_and_converter_lineage(self):
        pins=['1c169e33a4f278f10aca60a683a198e997ceb4d6','c2e26d259894d06f56b1b40cef9b89648ff76e70','1f6b22858800db92ac4b75d8396d44d6869031fa','21d45bfb1a0db79ff0328890b20a37782340c395','25a85ef6a9e95f8b0ee6778b4b96a54a4a0575b0']
        for e,pin in zip(self.es,pins):
            d=read(EV/e['repository'].replace('/','--')/'api.json');self.assertEqual(e['revision'],pin);self.assertEqual(d['id'],e['repository']);self.assertEqual(d['cardData']['base_model'],e['modification_source']);self.assertFalse(d['gated']);self.assertEqual(e['source_kind'],'third-party-derived')
            with patch('huggingface_hub.HfApi') as api:
                api.return_value.model_info.return_value=SimpleNamespace(sha=pin,gated=False,siblings=[]);HuggingFaceAdapter().resolve(e);api.return_value.model_info.assert_called_once_with(e['repository'],revision=pin,files_metadata=True)
    def test_manifest_bytes_and_reserve(self):
        for e,wb in zip(self.es,[87850987840,48410990624,48487032960,48410989216,48487030944]):
            p=plan(e,Path('/tmp/no1048write'),Metadata());m=read(EV/'selected-files.json')[e['id']];self.assertEqual(p['files'],m['files']);self.assertEqual(p['files'],e['selected_files']);self.assertEqual(p['total_bytes'],e['estimated_bytes']);self.assertEqual(e['weight_bytes'],wb);self.assertEqual(space(ROOT,p['total_bytes'])[1],m['reserve_bytes'])
        self.assertEqual(sum(e['weight_bytes'] for e in self.es),281647031584)
    def test_gpt_exact_raw_parts(self):
        e=self.es[0];self.assertEqual(e['gguf_shards'],['Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf.part1of2','Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf.part2of2']);self.assertEqual(e['split_layout'],'raw-concatenation-parts');self.assertFalse(read(EV/e['repository'].replace('/','--')/'second-part-probe.json')['starts_with_gguf_magic'])
    def test_exact_selection_no_wrong_quantization(self):
        for e in self.es:
            self.assertEqual(e['include'],e['required']);self.assertEqual(set(e['required']),set(e['gguf_shards'])|{'README.md'});self.assertEqual(e['quantization'],'Q4_K_M')
            a=Metadata();d=a.resolve(e)
            for f in d['files']:f['path']=f['path'].replace('Q4_K_M','Q5_K_M')
            with patch.object(a,'resolve',return_value=d),self.assertRaises(ToolkitError):plan(e,ROOT,a)
    def test_each_missing_part_refused(self):
        for e in self.es:
            for n in e['required']:
                a=Metadata();d=a.resolve(e);d['files']=[f for f in d['files'] if f['path']!=n]
                with patch.object(a,'resolve',return_value=d),self.assertRaises(ToolkitError):plan(e,ROOT,a)
    def test_licenses_roles_and_modification_types(self):
        self.assertEqual([e['license'] for e in self.es],['apache-2.0','mit','apache-2.0','mit','cc-by-nc-sa-4.0']);self.assertEqual(self.es[2]['category'],'coding');self.assertEqual(self.es[3]['primary_capability'],'instruction-following');self.assertEqual(self.es[4]['modification_type'],'supervised-fine-tuning-and-GRPO-with-LoRA');self.assertIn('Noncommercial',self.es[4]['commercial_use_note']);self.assertIn('share-alike',self.es[4]['commercial_use_note'])
        for e in self.es:self.assertEqual(e['base_license'],'apache-2.0');self.assertEqual(e['preservation_policy'],'inference-only');self.assertEqual(e['variant_role'],'portable-gguf');self.assertIn('refusal-reduced',e['capabilities']);self.assertFalse(e['hp_inference_tested'])
        for e in self.es[:4]:self.assertEqual(e['modification_type'],'abliterated')
        for e in [self.es[1],self.es[3]]:self.assertIn('does not supersede',e['license_notes']);self.assertIsNone(e['modification_source_revision_at_review'])
    def test_header_metadata_and_template(self):
        for e in self.es:
            h=read(EV/e['repository'].replace('/','--')/(e['gguf_shards'][0]+'.header.json'));self.assertEqual(h['gguf_version'],3);self.assertEqual(h['metadata']['general.file_type'],15);self.assertEqual(h['metadata']['general.architecture'],e['gguf_architecture']);self.assertEqual(h['parameter_count'],e['parameter_count']);self.assertIn('tokenizer.chat_template',h['metadata']);self.assertGreater(h['array_lengths']['tokenizer.ggml.tokens'],100000);self.assertEqual(e['architecture_type'],'MoE');self.assertGreater(e['parameter_count'],e['active_parameter_count']);self.assertEqual(h['sha256'],next(f['sha256'] for f in e['selected_files'] if f['path']==e['gguf_shards'][0]))
    def test_production_and_old_policy_unchanged(self):
        for n,h in read(EV/'baseline-PACKAGE-CHECKSUMS.json').items():
            if (n.endswith('.py') and not n.startswith(('tests/','evidence/')) and n!='modelkit/__init__.py') or n in ['settings.json','requirements.txt','setup-linux.sh','setup-windows.ps1','tests/fixtures/core-v1.0.3.py.txt']:self.assertEqual(hashlib.sha256(legacy_bytes(ROOT/n)).hexdigest(),h,n)
        old=read(EV/'baseline-preservation-policy.json');new=read(ROOT/'preservation-policy.json')
        for id,v in old['models'].items():self.assertEqual(new['models'][id],v)
        self.assertEqual(set(new['models'])-set(old['models'])-set(__import__('json').loads((ROOT/'evidence/v1.1.3/new-ids.json').read_text()))-set(__import__('json').loads((ROOT/'evidence/v1.1.4/new-ids.json').read_text())),set(IDS))
    def test_dependencies_and_repeated_selection(self):
        for e in self.es:self.assertEqual(e['dependencies'],[]);self.assertFalse(e['companion_artifacts_required']);self.assertEqual(select(self.c,ids=[e['id'],e['id']]),[e])
    def test_individual_combined_dry_runs_no_writes(self):
        for ids in [[id] for id in IDS]+[IDS]:
            with tempfile.TemporaryDirectory() as t:
                root=Path(t)/'absent';out=io.StringIO();args=['--root',str(root),'--dry-run']
                for id in ids:args+=['--model',id]
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),contextlib.redirect_stdout(out):self.assertEqual(main(args),0)
                self.assertFalse(root.exists());self.assertIn('Required with reserve:',out.getvalue())
    def test_real_large_interlock_yes_not_bypass(self):
        for ids in [[G],IDS]:
            with tempfile.TemporaryDirectory() as t:
                args=['--root',t+'/absent','--yes']
                for id in ids:args+=['--model',id]
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),patch('model_acquire.space',return_value=(10**15,10**12)),contextlib.redirect_stdout(io.StringIO()),self.assertRaisesRegex(ToolkitError,'--allow-large'):main(args)
                self.assertFalse((Path(t)/'absent').exists())
    def test_mount_guard_before_network(self):
        for id in IDS:
            with tempfile.TemporaryDirectory() as t,patch('modelkit.mounts.is_mounted',return_value=False),patch('modelkit.huggingface.HuggingFaceAdapter',side_effect=AssertionError('No network')),contextlib.redirect_stdout(io.StringIO()),self.assertRaises(ToolkitError):main(['--root',t+'/models','--expected-mount',t,'--model',id,'--yes','--allow-large'])
    def test_insufficient_space_not_bypassed(self):
        for id in IDS:
            with tempfile.TemporaryDirectory() as t,patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),patch('model_acquire.space',return_value=(1,10**12)),contextlib.redirect_stdout(io.StringIO()),self.assertRaisesRegex(ToolkitError,'Insufficient space'):main(['--root',t,'--model',id,'--yes','--allow-large'])

class Payload1048Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'models';self.c=load_catalog(ROOT/'catalog.json');self.entries=[e for e in self.c['models'] if e['id'] in IDS];self.out=contextlib.redirect_stdout(io.StringIO());self.out.__enter__()
    def tearDown(self):self.out.__exit__(None,None,None);self.tmp.cleanup()
    def fake(self,e):
        a=Fake({n:b'GGUF inert synthetic fixture: '+n.encode() for n in e['required']});a.rev=e['revision'];return a
    def test_verified_hashes_and_no_execution(self):
        for e in self.entries:
            a=self.fake(e);p=plan(e,self.root,a)
            with patch.object(pickle,'load',side_effect=AssertionError('No execution')),patch.object(pickle,'loads',side_effect=AssertionError('No execution')):acquire(p,self.root,a)
            m=read(Path(p['target'])/'manifest.json');self.assertEqual(m['status'],'verified')
            for n,r in m['files'].items():self.assertEqual(r['sha256'],hashlib.sha256(a.data[n]).hexdigest())
    def test_interruption_and_rerun_reuse(self):
        for e in self.entries:
            a=self.fake(e);orig=a.download;second=e['required'][1]
            def stop(entry,rev,n,t,force=False):
                if n==second:raise KeyboardInterrupt
                return orig(entry,rev,n,t,force)
            p=plan(e,self.root,a)
            with patch.object(a,'download',side_effect=stop),self.assertRaises(KeyboardInterrupt):acquire(p,self.root,a)
            self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'partial');acquire(plan(e,self.root,a),self.root,a);self.assertEqual(a.calls.count(e['gguf_shards'][0]),1)
    def test_corruption_rejected_and_quarantined(self):
        for e in self.entries:
            a=self.fake(e);orig=a.download;weight=e['gguf_shards'][0]
            def bad(entry,rev,n,t,force=False):
                orig(entry,rev,n,t,force)
                if n==weight:(t/n).write_bytes(b'bad')
            p=plan(e,self.root,a)
            with patch.object(a,'download',side_effect=bad),self.assertRaises(ToolkitError):acquire(p,self.root,a,retries=1)
            self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'failed');self.assertTrue(list((Path(p['target'])/'quarantine').glob('*/'+weight)))
    def test_missing_payload_fails_audit(self):
        e=self.entries[0];a=self.fake(e);p=plan(e,self.root,a);acquire(p,self.root,a);(Path(p['target'])/'payload'/e['gguf_shards'][0]).unlink();self.assertEqual(next(r for r in inventory(self.root,self.c,verify=True)['models'] if r['id']==G)['status'],'failed')
    def test_safe_rerun_no_duplicate_download(self):
        for e in self.entries:
            a=self.fake(e);acquire(plan(e,self.root,a),self.root,a);acquire(plan(e,self.root,a),self.root,a);self.assertEqual(len(a.calls),len(e['required']));self.assertEqual(plan(e,self.root,a)['estimated_new_bytes'],0)
    def test_cataloged_not_downloaded(self):
        d=acc.collect(self.root,self.c);rs={r['id']:r for r in d['models']}
        for id in IDS:self.assertEqual(rs[id]['status'],'cataloged-not-downloaded')
    def test_inventory_exports_and_storage(self):
        for e in self.entries:
            a=self.fake(e);acquire(plan(e,self.root,a),self.root,a)
        d=acc.collect(self.root,self.c,acc.policies(ROOT/'preservation-policy.json'))
        for fmt in ['json','csv','text']:
            out=acc.render(d,fmt)
            for id in IDS:self.assertIn(id,out)
        self.assertEqual(storage.scan(self.root,self.c)['summary']['revision_count'],5)
    def test_large_interlock_retained_for_aggregate(self):
        e=copy.deepcopy(self.entries[0]);e['id']='large-synthetic';e['estimated_bytes']=50000000000;c=copy.deepcopy(self.c);c['models'].append(e);a=self.fake(e);d=a.resolve(e);d['files'][0]['size']=50000000000
        with patch('model_acquire.load_catalog',return_value=c),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=a),patch.object(a,'resolve',return_value=d),patch('model_acquire.space',return_value=(10**15,10**12)),self.assertRaisesRegex(ToolkitError,'--allow-large'):main(['--root',str(self.root),'--model',e['id'],'--yes'])
        self.assertFalse(self.root.exists());self.assertEqual(a.calls,[])

from maintenance_guard import legacy_bytes
