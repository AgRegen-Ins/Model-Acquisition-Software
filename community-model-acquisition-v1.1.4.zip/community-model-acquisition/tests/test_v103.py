"""Two runnable variants and Dell profile; metadata-only regression fixtures."""
import contextlib,copy,hashlib,io,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,select,plan,read,write
from storage_test_support import main
ROOT=Path(__file__).resolve().parents[1]
GPT='gpt-oss-20b-gguf-mxfp4';GLM='glm-4-7-flash-gguf-q4-k-m';QWEN='qwen3-32b-gguf-q4-k-m'
class Adapter:
    def __init__(self,tiny=False):self.tiny=tiny;self.requests=[]
    def resolve(self,e):
        name=e['repository'].replace('/','--')+'.json';p=ROOT/'evidence/v1.0.3'/name
        if not p.exists():p=ROOT/'evidence'/name
        d=read(p);self.requests.append((e['repository'],e['revision']))
        assert e['revision']==d['sha']
        return {'revision':d['sha'],'metadata':d,'gated':d.get('gated',False),'files':[{'path':s['rfilename'],'size':3 if self.tiny else s['size'],'sha256':None if self.tiny else (s.get('lfs') or {}).get('sha256'),'git_blob_sha1':None if self.tiny or s.get('lfs') else s.get('blobId')} for s in d['siblings']]}
class Catalog103Tests(unittest.TestCase):
    def setUp(self):self.c=load_catalog(ROOT/'catalog.json');self.byid={e['id']:e for e in self.c['models']}
    def test_new_variants_parse(self):
        self.assertEqual(self.byid[GPT]['quantization'],'MXFP4');self.assertEqual(self.byid[GLM]['quantization'],'Q4_K_M')
        self.assertEqual(len(self.c['models']),154)
    def test_repositories_and_provenance(self):
        self.assertEqual(self.byid[GPT]['repository'],'ggml-org/gpt-oss-20b-GGUF');self.assertEqual(self.byid[GLM]['repository'],'unsloth/GLM-4.7-Flash-GGUF')
        for id in (GPT,GLM):self.assertEqual(self.byid[id]['source_kind'],'third-party-derived');self.assertEqual(self.byid[id]['format'],'GGUF')
        self.assertEqual(self.byid[GPT]['base_model'],'openai/gpt-oss-20b');self.assertEqual(self.byid[GLM]['base_model'],'zai-org/GLM-4.7-Flash')
    def test_exact_three_member_profile(self):
        self.assertEqual({e['id'] for e in select(self.c,'dell-upper-tier')},{GPT,GLM,QWEN})
        self.assertTrue(all(e['format']=='GGUF' for e in select(self.c,'dell-upper-tier')))
    def test_exact_weight_selection_excludes_draft(self):
        for id,name in [(GPT,'gpt-oss-20b-MXFP4.gguf'),(GLM,'GLM-4.7-Flash-Q4_K_M.gguf')]:
            p=plan(self.byid[id],Path('/tmp/v103-no-write'),Adapter());files=[f['path'] for f in p['files']]
            self.assertEqual([f for f in files if f.endswith('.gguf')],[name]);self.assertIn('README.md',files)
            self.assertFalse(any('eagle' in f.lower() or 'imatrix' in f.lower() for f in files))
    def test_revision_pin_and_sizes(self):
        for id in (GPT,GLM,QWEN):
            e=self.byid[id];a=Adapter();p=plan(e,Path('/tmp/v103-no-write'),a)
            self.assertRegex(e['revision'],r'^[a-f0-9]{40}$');self.assertEqual(p['revision'],e['revision']);self.assertEqual(p['total_bytes'],e['estimated_bytes']);self.assertEqual(a.requests,[(e['repository'],e['revision'])])
    def test_model_metadata(self):
        self.assertEqual(self.byid[GPT]['architecture'],['GptOssForCausalLM']);self.assertEqual(self.byid[GPT]['context_length'],131072);self.assertEqual(self.byid[GPT]['active_parameter_count'],3600000000)
        self.assertEqual(self.byid[GLM]['architecture'],['Glm4MoeLiteForCausalLM']);self.assertEqual(self.byid[GLM]['context_length'],202752);self.assertEqual(self.byid[GLM]['active_parameter_count'],3000000000)
        self.assertEqual(self.byid[GPT]['license'],'apache-2.0');self.assertEqual(self.byid[GLM]['license'],'mit')
    def test_dry_runs_models_and_profile(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'model root'
            for options in [ ['--model',GPT],['--model',GLM],['--profile','dell-upper-tier'] ]:
                out=io.StringIO()
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Adapter()),contextlib.redirect_stdout(out):
                    self.assertEqual(main(['--root',str(root),*options,'--dry-run']),0)
                self.assertIn('Estimated new files:',out.getvalue());self.assertIn('Free:',out.getvalue());self.assertIn('Required with reserve:',out.getvalue());self.assertFalse(root.exists())
    def test_present_files_reduce_estimate_without_writes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'models';a=Adapter(tiny=True);plans=[plan(e,root,a) for e in select(self.c,'dell-upper-tier')]
            for p in plans:
                target=Path(p['target']);records={}
                for f in p['files']:
                    path=target/'payload'/f['path'];path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b'abc');st=path.stat();records[f['path']]={'size':3,'mtime_ns':st.st_mtime_ns,'sha256':hashlib.sha256(b'abc').hexdigest()}
                write(target/'manifest.json',{'files':records})
            before={str(p):p.read_bytes() for p in root.rglob('*') if p.is_file()}
            for e in select(self.c,'dell-upper-tier'):self.assertEqual(plan(e,root,a)['estimated_new_bytes'],0)
            out=io.StringIO()
            with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=a),contextlib.redirect_stdout(out):main(['--root',str(root),'--profile','dell-upper-tier','--dry-run'])
            self.assertIn('Estimated new files: 0.00 B',out.getvalue());self.assertEqual(before,{str(p):p.read_bytes() for p in root.rglob('*') if p.is_file()})
    def test_old_entries_unchanged_except_requested_membership(self):
        baseline=read(ROOT/'evidence/v1.0.3/v1.0.2-catalog-baseline.json')
        for old in baseline['models']:
            actual=copy.deepcopy(self.byid[old['id']])
            if old['id']==QWEN:
                self.assertEqual(actual['profiles'],old['profiles']+['dell-upper-tier']);actual['profiles'].remove('dell-upper-tier')
            self.assertEqual(actual,old)
        for name in baseline['profiles']:
            self.assertEqual(self.c['profiles'][name],baseline['profiles'][name])
            if name!='all':self.assertEqual({e['id'] for e in select(self.c,name) if e['id'] not in {'qwen3-coder-next-original','qwen3-coder-next-gguf-q6-k'}},{e['id'] for e in select(baseline,name)})
    def test_protected_application_files_unchanged(self):
        checks=read(ROOT/'evidence/v1.0.3/v1.0.2-package-checksums.json')
        for name in ['model_acquire.py','modelkit/huggingface.py','modelkit/mounts.py','modelkit/storage.py','settings.json','requirements.txt','setup-linux.sh','setup-windows.ps1']:
            self.assertEqual(hashlib.sha256(legacy_bytes(ROOT/name)).hexdigest(),checks[name],name)
if __name__=='__main__':unittest.main(verbosity=2)

from maintenance_guard import legacy_bytes
