"""Multimodal metadata and custody regression fixtures. No real weights."""
import contextlib,copy,csv,hashlib,io,json,os,platform,shutil,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,select,plan,read,write,acquire,inventory,ToolkitError
from modelkit.dependencies import expand
from modelkit import registry as reg,accountability as acc
from test_toolkit import Fake
from test_v104 import Metadata,protected_core_source
from storage_test_support import main
from storage_test_support import registry_main
ROOT=Path(__file__).resolve().parents[1];EV=ROOT/'evidence/v1.0.4.3';IDS=read(EV/'new-ids.json')
VISION=IDS[0];VOCOS='f5-tts-vocos-mel-24khz';F5='f5-tts-v1-base-inference'
PROFILES={'document-vision':[VISION],'audio-transcription':IDS[1:3],'audiobook-narration':[IDS[3],IDS[7]],'voice-customization':[IDS[4],VOCOS,F5],'multimodal-core':[VISION,IDS[2],IDS[3]],'multimodal-preservation':IDS}
class NewMetadata(Metadata):
    def resolve(self,e):
        p=EV/e['repository'].replace('/','--')/'api.json'
        if not p.exists():return super().resolve(e)
        d=read(p);self.requests.append((e['repository'],e['revision']));assert d['sha']==e['revision']
        return {'revision':d['sha'],'metadata':d,'files':[{'path':f['rfilename'],'size':f['size'],'sha256':(f.get('lfs') or {}).get('sha256'),'git_blob_sha1':None if f.get('lfs') else f.get('blobId')} for f in d['siblings']]}
class MultimodalTests(unittest.TestCase):
    def setUp(self):self.c=load_catalog(ROOT/'catalog.json');self.by={e['id']:e for e in self.c['models']}
    def test_eight_entries_grouped_projector(self):
        self.assertEqual(len(IDS),8);self.assertEqual(len(self.c['models']),154);self.assertEqual(len(self.by[VISION]['components']),2);self.assertTrue(self.by[VOCOS]['is_component'])
    def test_exact_pins_files_sizes(self):
        expected=read(EV/'selected-files.json')
        for key in IDS:
            e=self.by[key];p=plan(e,Path('/tmp/no1043writes'),NewMetadata());d=expected[key]
            self.assertEqual(p['revision'],d['revision']);self.assertEqual(p['total_bytes'],d['total_bytes']);self.assertEqual(p['total_bytes'],e['estimated_bytes']);self.assertEqual({f['path'] for f in p['files']},set(e['required']));self.assertRegex(e['revision'],'^[0-9a-f]{40}$')
    def test_every_missing_companion_refused(self):
        for key in IDS:
            e=self.by[key]
            for missing in e['required']:
                a=NewMetadata();d=a.resolve(e);d['files']=[f for f in d['files'] if f['path']!=missing]
                with patch.object(a,'resolve',return_value=d),self.assertRaises(ToolkitError):plan(e,Path('/tmp/no1043writes'),a)
    def test_voice_and_projector_pairs(self):
        self.assertEqual(self.by[VISION]['required'],['Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf','mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf'])
        e=self.by[IDS[7]];self.assertEqual(len(e['voices']),2)
        for n in e['required']:
            if n.endswith('.onnx'):self.assertIn(n+'.json',e['required'])
        self.assertEqual(len([n for n in self.by[IDS[3]]['required'] if n.startswith('voices/')]),3)
    def test_dependency_before_parent_deduplicated(self):
        self.assertEqual([e['id'] for e in select(self.c,ids=[F5])],[VOCOS,F5]);self.assertEqual(len(select(self.c,'multimodal-preservation')),8)
    def test_invalid_dependency_and_cycle(self):
        for dep in ['missing',F5]:
            c=copy.deepcopy(self.c);next(e for e in c['models'] if e['id']==F5)['dependencies']=[dep]
            with self.assertRaises(ToolkitError):expand(c,c['models'])
    def test_profile_memberships(self):
        for p,ids in PROFILES.items():self.assertEqual([e['id'] for e in select(self.c,p)],ids)
    def test_old_38_entries_and_profiles_identical(self):
        old=read(EV/'baseline-catalog.json');self.assertEqual(self.c['models'][:38],old['models'])
        for p in old['profiles']:
            self.assertEqual(self.c['profiles'][p],old['profiles'][p])
            if p!='all':self.assertEqual(select(self.c,p),select(old,p))
    def test_policies_are_metadata_only(self):
        d=acc.policies(ROOT/'preservation-policy.json');self.assertEqual(set(d['models']),set(self.by));self.assertEqual(d['models']['qwen3-coder-next-original']['preservation_policy'],'source-and-inference')
        for key in IDS:self.assertEqual(self.by[key]['preservation_policy'],'inference-only')
    def test_licenses_and_provenance(self):
        self.assertEqual(self.by[VISION]['license'],'qwen-research');self.assertEqual(self.by[VISION]['source_kind'],'third-party-derived');self.assertIn('conflicting',self.by[VISION]['license_notes']);self.assertEqual(self.by[F5]['license'],'cc-by-nc-4.0');self.assertEqual(self.by[IDS[7]]['license'],'voice-specific')
    def test_runtime_metadata_and_no_personal_audio(self):
        for key in IDS:
            e=self.by[key];self.assertTrue(e['runtime_notes']);self.assertTrue(e['capabilities']);self.assertTrue(e['training_suitability']);self.assertFalse(any(Path(n).suffix.lower() in reg.PERSONAL_SUFFIXES for n in e['required']))
        self.assertIn('reference transcript',self.by[F5]['runtime_notes'])
    def test_all_metadata_dry_runs(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'absent'
            for opts in [['--model',i] for i in IDS]+[['--profile',p] for p in PROFILES]:
                out=io.StringIO()
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=NewMetadata()),contextlib.redirect_stdout(out):self.assertEqual(main(['--root',str(root),*opts,'--dry-run']),0)
                self.assertIn('Required with reserve:',out.getvalue());self.assertFalse(root.exists())
    def test_protected_production_and_portable_guard(self):
        baseline=(EV/'baseline-modelkit--core.py.txt').read_bytes();checks=read(EV/'baseline-PACKAGE-CHECKSUMS.json');self.assertEqual(hashlib.sha256(baseline).hexdigest(),checks['modelkit/core.py']);self.assertEqual(protected_core_source(legacy_bytes(ROOT/'modelkit/core.py').decode()),protected_core_source(baseline.decode()))
        for n in ['model_acquire.py','modelkit/huggingface.py','modelkit/mounts.py','modelkit/storage.py']:self.assertEqual(hashlib.sha256(legacy_bytes(ROOT/n)).hexdigest(),checks[n])

class RegistryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name);self.root=self.base/'models';self.ext=self.base/'external';self.ext.mkdir();self.data={'weights.gguf':b'GGUF inert weights','mmproj.gguf':b'GGUF inert projector'}
        for n,b in self.data.items():(self.ext/n).write_bytes(b)
        self.e=dict(id='vision-fixture',display_name='Fixture',category='vision-language',adapter='huggingface',repository='fixture/vision',publisher='fixture',source_kind='third-party-derived',format='GGUF',quantization='fixture',revision='a'*40,required=list(self.data),include=list(self.data),profiles=['test'],estimated_bytes=38)
        self.c={'schema_version':1,'models':[self.e],'profiles':{'test':'fixture','all':'all'}};self.a=Fake(self.data);self.spec={'instance_id':'vision','model_id':self.e['id'],'artifact_kind':'model-artifacts','files':{n:str(self.ext/n) for n in self.data},'associated_projects':['Sanitizer']};self.out=contextlib.redirect_stdout(io.StringIO());self.out.__enter__();self.space_patch=patch('modelkit.registry.space',return_value=(10**12,1024**3));self.space_patch.start();self.addCleanup(self.space_patch.stop)
    def tearDown(self):self.out.__exit__(None,None,None);self.tmp.cleanup()
    def register(self,spec=None):return reg.register(self.root,self.c,spec or self.spec)
    def verify(self):return reg.verify(self.root,self.c,'vision',self.a)
    def imp(self,**kw):return reg.import_instance(self.root,self.c,'vision',self.a,**kw)
    def test_register_hashes_no_upstream_claim_or_writes(self):
        before={p:p.stat().st_mtime_ns for p in self.ext.iterdir()};r=self.register();self.assertEqual(r['status'],'external-registered');self.assertIsNone(r['revision']);self.assertFalse(any(f['upstream_verified'] for f in r['files'].values()))
        for p,mtime in before.items():self.assertEqual(p.stat().st_mtime_ns,mtime);self.assertEqual(p.read_bytes(),self.data[p.name])
    def test_upstream_digest_match(self):
        self.register();r=self.verify();self.assertEqual(r['status'],'external-verified');self.assertEqual(r['revision'],'a'*40)
    def test_modified_same_size_fails(self):
        self.register();p=self.ext/'weights.gguf';p.write_bytes(b'x'*p.stat().st_size);self.assertEqual(self.verify()['status'],'verification-failed')
    def test_matching_name_size_not_enough(self):
        (self.ext/'weights.gguf').write_bytes(b'x'*len(self.data['weights.gguf']));self.register();self.assertEqual(self.verify()['status'],'verification-failed')
    def test_missing_companion(self):
        s=copy.deepcopy(self.spec);del s['files']['mmproj.gguf'];self.assertEqual(self.register(s)['status'],'incomplete');self.assertEqual(self.verify()['status'],'incomplete')
    def test_unknown_upstream(self):
        self.assertEqual(self.register({**self.spec,'model_id':'unknown'})['status'],'external-registered')
        with self.assertRaises(ToolkitError):self.verify()
    def test_no_trusted_hash_cannot_verify(self):
        self.register();m=self.a.resolve(self.e)
        for f in m['files']:f['sha256']=None;f['git_blob_sha1']=None
        with patch.object(self.a,'resolve',return_value=m):self.assertEqual(self.verify()['status'],'external-registered')
    def test_wrong_pin_refused(self):
        self.register();self.a.rev='b'*40
        with self.assertRaisesRegex(ToolkitError,'revision'):self.verify()
    def test_duplicate_project_merge(self):
        self.register();r=self.register({**self.spec,'associated_projects':['AgRegen','Sanitizer']});self.assertEqual(r['associated_projects'],['AgRegen','Sanitizer']);self.assertEqual(len(reg.load(self.root)['instances']),1)
    def test_duplicate_alias_and_conflict(self):
        self.register()
        for s in [{**self.spec,'instance_id':'alias'},{**self.spec,'model_id':'other'}]:
            with self.assertRaises(ToolkitError):self.register(s)
    def test_remote_report_not_probed(self):
        s={**self.spec,'remote_reported':True,'host':'remote','files':{n:'C:\\models\\'+n for n in self.data}}
        with patch('modelkit.registry.observe',side_effect=AssertionError('no remote probe')):r=self.register(s);d=acc.collect(self.root,self.c)
        self.assertEqual(r['observation'],'remote-reported');self.assertIsNone(d['models'][0]['storage_bytes'])
        with self.assertRaises(ToolkitError):self.verify()
    def test_personal_recordings_refused(self):
        for n in ['a.wav','a.mp3','a.flac']:
            with self.assertRaisesRegex(ToolkitError,'Personal audio'):self.register({**self.spec,'model_id':'unknown','files':{n:str(self.ext/n)}})
    def test_personal_data_not_scanned(self):
        (self.ext/'private.wav').write_bytes(b'private');self.assertNotIn('private.wav',self.register()['files'])
    def test_explicit_artifact_declaration(self):
        s=copy.deepcopy(self.spec);del s['artifact_kind']
        with self.assertRaises(ToolkitError):self.register(s)
    def test_symlink_not_verified(self):
        p=self.ext/'weights.gguf';p.unlink();p.symlink_to(self.ext/'mmproj.gguf');self.assertEqual(self.register()['status'],'missing')
    def test_quarantine_not_adopted(self):
        q=self.base/'quarantine';q.mkdir();p=q/'weights.gguf';p.write_bytes(b'data');s=copy.deepcopy(self.spec);s['files']['weights.gguf']=str(p);self.assertEqual(self.register(s)['status'],'missing')
    def test_python_is_not_executed(self):
        p=self.ext/'evil.py';p.write_text('raise Exception("must never execute")')
        with self.assertRaises(ToolkitError):self.register({**self.spec,'model_id':'unknown','files':{'evil.py':str(p)}})
    def test_registration_mount_guard(self):
        with patch('modelkit.mounts.is_mounted',return_value=False),self.assertRaises(ToolkitError):reg.register(self.root,self.c,self.spec,self.base)
        self.assertFalse(self.root.exists())
    def test_safe_import(self):
        self.register();r=self.imp(yes=True);p=Path(r['path']);self.assertEqual(r['status'],'downloaded-verified');self.assertEqual(read(p/'manifest.json')['acquisition_origin'],'verified-external-copy')
        for n,b in self.data.items():self.assertEqual((self.ext/n).read_bytes(),b);self.assertEqual((p/'payload'/n).read_bytes(),b)
        self.assertEqual(inventory(self.root,self.c,verify=True)['models'][0]['status'],'verified');self.assertEqual(self.a.calls,[])
    def test_import_no_overwrite(self):
        self.register();self.imp(yes=True)
        with self.assertRaisesRegex(ToolkitError,'already exists'):self.imp(yes=True)
    def test_import_confirmation(self):
        self.register()
        with self.assertRaisesRegex(ToolkitError,'--yes'):self.imp()
    def test_import_reserve(self):
        self.register()
        with patch('modelkit.registry.space',return_value=(0,100)),self.assertRaisesRegex(ToolkitError,'reserve'):self.imp(yes=True)
    def test_import_large_guard(self):
        self.register();original=reg.plan
        def large(*a,**kw):return {**original(*a,**kw),'total_bytes':50*10**9}
        with patch('modelkit.registry.plan',side_effect=large),self.assertRaisesRegex(ToolkitError,'--allow-large'):self.imp(yes=True)
    def test_corrupt_destination_not_promoted(self):
        self.register()
        def bad(adapter,entry,rev,name,target,force=False):p=target/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'bad')
        with patch.object(reg.CopyAdapter,'download',bad),self.assertRaises(ToolkitError):self.imp(yes=True)
        self.assertFalse(Path(plan(self.e,self.root,self.a)['target']).exists());self.assertTrue(list((self.root/'_toolkit/import-staging').glob('*/quarantine/*/*')))
    def test_interrupted_import_not_complete(self):
        self.register()
        with patch.object(reg.CopyAdapter,'download',side_effect=KeyboardInterrupt),self.assertRaises(KeyboardInterrupt):self.imp(yes=True)
        self.assertFalse(Path(plan(self.e,self.root,self.a)['target']).exists());self.assertTrue(list((self.root/'_toolkit/import-staging').glob('*/manifest.json')))
    def test_missing_drive(self):
        self.register();self.verify();shutil.rmtree(self.ext);self.assertEqual(acc.collect(self.root,self.c)['models'][0]['status'],'missing');self.assertFalse(self.ext.exists())
    def test_exports_do_not_hash(self):
        self.register();self.verify()
        with patch('modelkit.registry.hashes',side_effect=AssertionError('no scan')):d=acc.collect(self.root,self.c)
        self.assertEqual(json.loads(acc.render(d,'json'))['models'][0]['status'],'external-verified');rows=list(csv.DictReader(io.StringIO(acc.render(d,'csv'))));self.assertEqual(rows[0]['id'],self.e['id']);self.assertIn('Sanitizer',acc.render(d));self.assertIn('training_suitability_class',rows[0])
    def test_catalog_only_and_policy_validation(self):
        self.assertEqual(acc.collect(self.root,self.c)['models'][0]['status'],'cataloged-not-downloaded');self.assertFalse(self.root.exists());p=self.base/'policy.json';write(p,{'schema_version':1,'models':{'x':{'preservation_policy':'delete'}}})
        with self.assertRaises(ToolkitError):acc.policies(p)
    def test_changed_fingerprint_demotes(self):
        self.register();self.verify();(self.ext/'weights.gguf').write_bytes(b'changed');self.assertEqual(acc.collect(self.root,self.c)['models'][0]['status'],'downloaded-unverified')
    def test_historical_managed_revision_discovered(self):
        e={**self.e,'revision':'b'*40};a=Fake(self.data);a.rev='b'*40;acquire(plan(e,self.root,a),self.root,a);r=acc.collect(self.root,self.c)['models'][0];self.assertEqual(r['pinned_revision'],'b'*40);self.assertEqual(r['status'],'downloaded-verified')
    def test_multiple_instances_no_external_storage_sum(self):
        self.register();self.imp(yes=True);d=acc.collect(self.root,self.c);self.assertEqual(len(d['models']),2);self.assertEqual({r['location_kind'] for r in d['models']},{'canonical-archive','external-installation'})
    def test_dependency_completeness(self):
        e={**self.e,'dependencies':['vocoder']};c={**self.c,'models':[e,{**self.e,'id':'vocoder','revision':'b'*40}]};acquire(plan(e,self.root,self.a),self.root,self.a);r=acc.collect(self.root,c)['models'][0];self.assertEqual(r['artifact_status'],'downloaded-verified');self.assertEqual(r['status'],'incomplete')
    def test_verified_vision_resume_reuses_completed_companion(self):
        download=self.a.download
        def interrupt(entry,rev,name,target,force=False):
            if name=='mmproj.gguf':raise KeyboardInterrupt()
            return download(entry,rev,name,target,force)
        p=plan(self.e,self.root,self.a)
        with patch.object(self.a,'download',side_effect=interrupt),self.assertRaises(KeyboardInterrupt):acquire(p,self.root,self.a)
        acquire(plan(self.e,self.root,self.a),self.root,self.a)
        self.assertEqual(self.a.calls.count('weights.gguf'),1);self.assertEqual(inventory(self.root,self.c,verify=True)['models'][0]['status'],'verified')
    def test_quarantine_report_has_distinct_status(self):
        p=plan(self.e,self.root,self.a);acquire(p,self.root,self.a);dest=Path(p['target'])/'payload/weights.gguf';dest.write_bytes(b'bad');acquire(plan(self.e,self.root,self.a),self.root,self.a,repair=True)
        self.assertIn('quarantined',{r['status'] for r in acc.collect(self.root,self.c)['models']})
    def test_two_artifact_names_cannot_alias_same_path(self):
        s=copy.deepcopy(self.spec);s['files']['mmproj.gguf']=s['files']['weights.gguf']
        with self.assertRaises(ToolkitError):self.register(s)
    def test_import_source_permission_unchanged(self):
        p=self.ext/'weights.gguf';p.chmod(0o440);mode=p.stat().st_mode;self.register();self.imp(yes=True);self.assertEqual(p.stat().st_mode,mode)
    def test_legacy_glob_catalog_registration(self):
        self.e['include']=['*.gguf'];self.e['required']=['weights*.gguf','mmproj*.gguf']
        self.assertEqual(self.register()['status'],'external-registered');self.assertEqual(self.verify()['status'],'external-verified')
    def test_cli_register_and_inventory(self):
        s=self.base/'spec.json';c=self.base/'catalog.json';write(s,self.spec);write(c,self.c);self.assertEqual(registry_main(['--root',str(self.root),'--catalog',str(c),'--register',str(s)]),0);self.assertEqual(registry_main(['--root',str(self.root),'--catalog',str(c),'--inventory','--format','json']),0)
if __name__=='__main__':unittest.main(verbosity=2)

from maintenance_guard import legacy_bytes
