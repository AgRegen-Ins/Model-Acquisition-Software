"""Inert synthetic repositories; no network, production archive or model execution."""
import ast,contextlib,copy,hashlib,io,json,tempfile,traceback,types,unittest,sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit import core,storage,registry
from storage_test_support import main
from test_toolkit import Fake,ENTRY,CAT
from maintenance_guard import legacy_bytes
ROOT=Path(__file__).resolve().parents[1];EV=ROOT/'evidence/v1.0.4.8.1'
NAMES=['retriever/contriever/src/__init__.py','training/torchtune/__init__.py','training/torchtune/modules/__init__.py','training/torchtune/models/qwen2/__init__.py','training/tests/__init__.py','_private.py','__main__.py','_config.json']
DATA={n:b"raise RuntimeError('Archived source must never execute')\n" for n in NAMES}
def entry(id='openscholar-software'):return {**ENTRY,'id':id,'include':['*'],'required':list(DATA)}
def catalog(*es):return {**CAT,'models':list(es)}
def legacy_core():
    m=types.ModuleType('baseline_core');m.__file__=str(EV/'baseline-modelkit--core.py.txt');exec(compile(Path(m.__file__).read_text(),m.__file__,'exec'),m.__dict__);return m

def existing_fixture(root,e):
    """Create a compact historical-format fixture with real size/mtime/hash records."""
    folder=root/e['category']/e['id']/e['revision'];files={};expected=[]
    for n,b in DATA.items():
        p=folder/'payload'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);f={'path':n,'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha1':None};expected.append(f);files[n]=core.inspect_file(p,f)
    core.write(folder/'manifest.json',{'schema_version':1,'entry':e,'revision':e['revision'],'status':'verified','created_at':core.now(),'expected':expected,'files':files})
    return folder/'manifest.json'

class PathValidationTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'payload'
    def tearDown(self):self.tmp.cleanup()
    def test_python_names_and_deep_packages(self):
        for n in NAMES+['__init__.py','a/_b/___c/d/e/__init__.py']:
            self.assertEqual(core.safe_path(self.root,n),self.root/n)
    def test_ordinary_weights_metadata_and_hidden_components(self):
        for n in ['model.Q4_K_M.gguf','model-00001.safetensors','config.json','tokenizer.json','.gitattributes','.git/config','.cache/data','...notes','a-b.c_d']:
            self.assertEqual(core.safe_path(self.root,n),self.root/n)
    def test_traversal_absolute_and_normalization_aliases(self):
        for n in ['../outside','training/../../outside','/etc/passwd','//server/share','./weights.gguf','a/./b','a//b','a/','.', '..','']:
            with self.subTest(path=n),self.assertRaises(core.ToolkitError):core.safe_path(self.root,n)
    def test_windows_drives_unc_backslash_and_ads(self):
        for n in ['C:\\Windows','C:/Windows','\\\\server\\share','a\\..\\b','model.gguf:stream','file:stream:$DATA']:
            with self.assertRaises(core.ToolkitError):core.safe_path(self.root,n)
    def test_reserved_devices_including_hidden_spelling(self):
        for n in ['CON','con.txt','PRN','AUX.json','NUL','com1.py','LPT9.bin','.CON','..nul.txt','folder/Lpt1']:
            with self.assertRaises(core.ToolkitError):core.safe_path(self.root,n)
        self.assertEqual(core.safe_path(self.root,'_CON.py'),self.root/'_CON.py')
    def test_null_invalid_types_and_malformed_components(self):
        for n in [None,3,b'file','a\x00b','a\nb','a\tb','a*','a?','a|b','a<b','a>b','a"b','file.','file ','dir./f','dir /f','...','-leading','café.py']:
            with self.subTest(path=n),self.assertRaises(core.ToolkitError):core.safe_path(self.root,n)
    def test_symlink_root_parent_leaf_and_dangling(self):
        outside=Path(self.tmp.name)/'outside';outside.mkdir();self.root.mkdir();(self.root/'link').symlink_to(outside,target_is_directory=True)
        with self.assertRaises(core.ToolkitError):core.safe_path(self.root,'link/__init__.py')
        (self.root/'leaf').symlink_to(outside/'missing')
        with self.assertRaises(core.ToolkitError):core.safe_path(self.root,'leaf')
        alias=Path(self.tmp.name)/'alias';alias.symlink_to(self.root,target_is_directory=True)
        for root in [alias,alias/'nested']:
            with self.assertRaises(core.ToolkitError):core.safe_path(root,'__init__.py')
    def test_strict_identifiers_unchanged(self):
        old=legacy_core()
        for n in ['model-id','a1','revision.1','_model','__init__.py','.model','CON','model.','model/a','a b']:
            try:expected=old.safe_name(n)
            except old.ToolkitError:
                with self.assertRaises(core.ToolkitError):core.safe_name(n)
            else:self.assertEqual(core.safe_name(n),expected)
    def test_catalog_and_registry_ids_still_strict(self):
        e=entry();c=catalog(e);p=Path(self.tmp.name)/'catalog.json'
        for k in ['id','category']:
            core.write(p,catalog({**e,k:'_bad'}))
            with self.assertRaises(core.ToolkitError):core.load_catalog(p)
        for field in ['instance_id','model_id']:
            s={'artifact_kind':'model-artifacts','instance_id':'valid','model_id':e['id'],'files':{'_config.json':str(self.root/'config')}};s[field]='_bad'
            with self.assertRaises(core.ToolkitError):registry.validate_spec(s,c)
    def test_revision_pinning_still_strict(self):
        a=Fake(DATA);a.rev='_bad'
        with self.assertRaises(core.ToolkitError):core.plan(entry(),self.root,a)
    def test_old_validator_fails_all_python_package_examples(self):
        old=legacy_core()
        for n in NAMES:
            with self.assertRaisesRegex(old.ToolkitError,'Unsafe directory identifier'):old.safe_path(self.root,n)
    def test_previously_valid_canonical_alphabet_preserved(self):
        old=legacy_core()
        for prefix in ['a','Z','0','.git','..notes','...hidden']:
            for suffix in ['', '.json','_name','-suffix','.a_b-1']:
                n=prefix+suffix
                self.assertEqual(core.safe_path(self.root,n),old.safe_path(self.root,n))
    def test_exact_catalog_profiles_and_policy_preserved(self):
        for n in ['catalog.json','preservation-policy.json']:self.assertEqual(__import__('education_guard').baseline_bytes(ROOT/n),(EV/('baseline-'+n)).read_bytes())
        self.assertEqual(len(core.load_catalog(ROOT/'catalog.json')['models']),154)
    def test_authenticated_baseline_source_and_failure_evidence(self):
        checks=core.read(EV/'baseline-PACKAGE-CHECKSUMS.json')
        for n in ['modelkit/core.py','model_acquire.py']:
            self.assertEqual(hashlib.sha256((EV/('baseline-'+n.replace('/','--')+'.txt')).read_bytes()).hexdigest(),checks[n])
        state=core.read(EV/'baseline-failure-state.json');self.assertEqual(set(state['manifest_statuses'].values()),{'verified'});self.assertTrue(state['legacy_manifest_unchanged']);self.assertEqual(state['storage_report_status'],'partial')
    def test_exact_approved_delta_and_unchanged_production(self):
        checks=core.read(EV/'baseline-PACKAGE-CHECKSUMS.json')
        for n,h in checks.items():
            if n.endswith('.py') and not n.startswith(('tests/','evidence/')) and n!='modelkit/__init__.py':self.assertEqual(hashlib.sha256(legacy_bytes(ROOT/n)).hexdigest(),h,n)
        # Approved source edits are literal, not arbitrary ignored function bodies.
        p=ROOT/'modelkit/core.py';b=p.read_bytes()
        with patch.object(Path,'read_bytes',autospec=True,side_effect=lambda path: b.replace(b'def safe_payload_component(',b'def renamed_component(') if path==p else original_read(path)):
            with self.assertRaises(AssertionError):legacy_bytes(p)

original_read=Path.read_bytes
class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'models';self.e=entry();self.c=catalog(self.e);self.a=Fake(DATA);self.out=contextlib.redirect_stdout(io.StringIO());self.out.__enter__()
    def tearDown(self):self.out.__exit__(None,None,None);self.tmp.cleanup()
    def acquire(self):
        p=core.plan(self.e,self.root,self.a);core.acquire(p,self.root,self.a);return Path(p['target'])
    def test_inert_source_acquisition_sha256_and_publication(self):
        target=self.acquire();m=core.read(target/'manifest.json');self.assertEqual(m['status'],'verified');self.assertEqual(len(m['files']),len(DATA))
        for n,b in DATA.items():self.assertEqual(m['files'][n]['sha256'],hashlib.sha256(b).hexdigest());self.assertEqual(m['files'][n]['integrity'],'upstream-sha256');self.assertEqual((target/'payload'/n).read_bytes(),b)
    def test_git_blob_verification_for_python_file(self):
        d=self.a.resolve(self.e)
        for f in d['files']:f['sha256']=None;f['git_blob_sha1']=hashlib.sha1(b'blob '+str(f['size']).encode()+b'\0'+DATA[f['path']]).hexdigest()
        with patch.object(self.a,'resolve',return_value=d):target=self.acquire()
        self.assertEqual({v['integrity'] for v in core.read(target/'manifest.json')['files'].values()},{'upstream-git-blob-sha1'})
    def test_existing_manifest_inventory_read_only_and_verify(self):
        m=existing_fixture(self.root,self.e);saved=m.read_bytes();rows=core.inventory(self.root,self.c)['models'];self.assertEqual(rows[0]['status'],'verified');self.assertEqual(m.read_bytes(),saved)
        self.assertEqual(core.inventory(self.root,self.c,verify=True)['models'][0]['status'],'verified')
    def test_storage_exports_no_false_partial_and_no_manifest_changes(self):
        m=existing_fixture(self.root,self.e);saved=m.read_bytes();s=storage.scan(self.root,self.c);self.assertEqual(s['models'][0]['status'],'verified');self.assertEqual(s['models'][0]['warnings'],[])
        for fmt in ['text','csv','json']:self.assertIn(self.e['id'],storage.render(s,fmt))
        storage.refresh(self.root,self.c);self.assertEqual(m.read_bytes(),saved)
    def test_registry_registration_and_trusted_verification(self):
        m=existing_fixture(self.root,self.e);folder=m.parent/'payload';s={'artifact_kind':'model-artifacts','instance_id':'source-copy','model_id':self.e['id'],'files':{n:str(folder/n) for n in DATA}}
        r=registry.register(self.root,self.c,s);self.assertEqual(r['status'],'external-registered');r=registry.verify(self.root,self.c,'source-copy',self.a);self.assertEqual(r['status'],'external-verified')
    def test_multi_model_acquisition_final_reporting_and_status_retry(self):
        m=existing_fixture(self.root,self.e);saved=m.read_bytes();es=[{**ENTRY,'id':'new-one'},{**ENTRY,'id':'new-two'}];c=catalog(self.e,*es);a=Fake()
        with patch('model_acquire.load_catalog',return_value=c),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=a):
            self.assertEqual(main(['--root',str(self.root),'--model','new-one','--model','new-two','--yes']),0)
            calls=list(a.calls);self.assertEqual(main(['--root',str(self.root),'--status']),0);self.assertEqual(a.calls,calls)
        self.assertEqual(m.read_bytes(),saved);self.assertEqual({r['status'] for r in core.inventory(self.root,c)['models']},{'verified'});self.assertTrue(list((self.root/'_toolkit/reports').glob('*.json')))
    def test_baseline_final_failure_after_verified_commits(self):
        old=legacy_core();m=existing_fixture(self.root,self.e);saved=m.read_bytes();es=[{**ENTRY,'id':'new-one'},{**ENTRY,'id':'new-two'}];c=catalog(self.e,*es)
        # Execute the authenticated baseline CLI, not a reconstructed approximation.
        module=types.ModuleType('baseline_cli');module.__file__=str(ROOT/'model_acquire.py');exec(compile((EV/'baseline-model_acquire.py.txt').read_text(),'baseline-model_acquire.py','exec'),module.__dict__);module.inventory=old.inventory;module.load_catalog=lambda _:c
        with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Fake()),self.assertRaisesRegex(old.ToolkitError,'Unsafe directory identifier: __init__.py'):module.main(['--root',str(self.root),'--model','new-one','--model','new-two','--yes'])
        self.assertEqual(m.read_bytes(),saved)
        for e in es:self.assertEqual(core.read(self.root/e['category']/e['id']/e['revision']/'manifest.json')['status'],'verified')
    def test_reporting_error_explicit_and_verified_manifests_retained(self):
        with patch('model_acquire.load_catalog',return_value=self.c),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=self.a),patch('model_acquire.report',side_effect=core.ToolkitError('synthetic report failure')),self.assertRaisesRegex(core.ToolkitError,'Post-acquisition reporting failed; acquisition results remain recorded'):main(['--root',str(self.root),'--model',self.e['id'],'--yes'])
        m=self.root/self.e['category']/self.e['id']/self.e['revision']/'manifest.json';self.assertEqual(core.read(m)['status'],'verified');calls=list(self.a.calls)
        with patch('model_acquire.load_catalog',return_value=self.c),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=self.a):self.assertEqual(main(['--root',str(self.root),'--status']),0)
        self.assertEqual(self.a.calls,calls)
    def test_interruption_resume_reuses_completed_source_files(self):
        orig=self.a.download;stop=NAMES[1]
        def interrupted(e,rev,n,t,force=False):
            if n==stop:raise KeyboardInterrupt
            return orig(e,rev,n,t,force)
        p=core.plan(self.e,self.root,self.a)
        with patch.object(self.a,'download',side_effect=interrupted),self.assertRaises(KeyboardInterrupt):core.acquire(p,self.root,self.a)
        self.assertEqual(core.read(Path(p['target'])/'manifest.json')['status'],'partial');self.acquire();self.assertEqual(self.a.calls.count(NAMES[0]),1)
    def test_corrupt_source_rejected_and_quarantined(self):
        orig=self.a.download
        def bad(e,rev,n,t,force=False):orig(e,rev,n,t,force);(t/n).write_bytes(b'bad')
        with patch.object(self.a,'download',side_effect=bad),self.assertRaises(core.ToolkitError):core.acquire(core.plan(self.e,self.root,self.a),self.root,self.a,retries=1)
        target=self.root/self.e['category']/self.e['id']/self.e['revision'];self.assertEqual(core.read(target/'manifest.json')['status'],'failed');self.assertTrue(list((target/'quarantine').glob('*/retriever/contriever/src/__init__.py')))
    def test_missing_and_same_size_corrupt_source_detected(self):
        target=self.acquire();p=target/'payload'/NAMES[0];p.write_bytes(b'x'*p.stat().st_size);self.assertEqual(core.inventory(self.root,self.c,verify=True)['models'][0]['status'],'failed');p.unlink();self.assertEqual(core.inventory(self.root,self.c,verify=True)['models'][0]['status'],'failed')
    def test_completed_rerun_zero_downloads(self):
        self.acquire();calls=list(self.a.calls);self.acquire();self.assertEqual(self.a.calls,calls)
    def test_dry_run_no_write_or_execution(self):
        with patch('model_acquire.load_catalog',return_value=self.c),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=self.a):self.assertEqual(main(['--root',str(self.root),'--model',self.e['id'],'--dry-run']),0)
        self.assertFalse(self.root.exists());self.assertEqual(self.a.calls,[])
    def test_unsafe_legacy_path_still_fails_without_outside_read(self):
        m=existing_fixture(self.root,self.e);s=core.read(m);s['expected'][0]['path']='../outside';core.write(m,s)
        with self.assertRaises(core.ToolkitError):core.inventory(self.root,self.c)
        self.assertEqual(storage.scan(self.root,self.c)['models'][0]['status'],'partial')
