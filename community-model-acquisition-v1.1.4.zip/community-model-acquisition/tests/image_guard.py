"""Exact reviewed image-release deltas; historical assertions still check baseline bytes."""
import json,hashlib,base64
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def baseline_bytes(path):
    path=Path(path);data=path.read_bytes();name=path.relative_to(ROOT).as_posix()
    fixture=ROOT/'tests/fixtures/image-maintenance-delta.json'
    assert hashlib.sha256(fixture.read_bytes()).hexdigest()=='a2e81a0d92e931f0d94feb78ef6c778b5c8f5ff3f0dea0959e3ca6a01e7a0b82', 'Image delta fixture changed'
    changes=json.loads(fixture.read_text())
    if name in changes:
        assert hashlib.sha256(data).hexdigest()==changes[name]['approved_sha256'], 'Unapproved image delta: '+name
        return base64.b64decode(changes[name]['baseline_b64'])
    return data
