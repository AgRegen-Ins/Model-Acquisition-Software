"""Real traversal/permission fixtures; filesystem identity probes are simulated.
No privileged mounts or production paths are used.
"""
import json, os, stat, subprocess, sys, tempfile, unittest
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
import compare_archives
from modelkit import storage, recovery_directory as recovery
from modelkit.core import ToolkitError

ROOT=Path(__file__).resolve().parents[1]
CAT={'models':[]}

class RecoveryDirectoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.lost=self.root/'lost+found';self.lost.mkdir(mode=0o700)
        self.dev=self.root.stat().st_dev
        self.record=dict(mount=self.root,fsroot='/',fstype='ext4',device=f'{os.major(self.dev)}:{os.minor(self.dev)}',id='123')
        self.parent=NS(st_dev=self.dev,st_ino=2,st_mode=stat.S_IFDIR|0o755)
        self.child=NS(st_dev=self.dev,st_ino=11,st_mode=stat.S_IFDIR|0o700,st_uid=0,st_gid=0)
    @contextmanager
    def probes(self,records=None,stats=None):
        with patch.object(recovery.volume,'mount_records',return_value=[self.record] if records is None else records),patch.object(recovery,'_entry_stats',return_value=(self.parent,self.parent,self.child) if stats is None else stats):yield
    def recognized(self):
        with self.probes():return recovery.filesystem_recovery_directory(self.root)
    def test_standard_root_recovery_recognized(self):self.assertEqual(self.recognized()['inode'],11)
    def test_mode_zero_recognized(self):
        self.child.st_mode=stat.S_IFDIR;self.assertIsNotNone(self.recognized())
    def test_absent_mount_not_excluded(self):
        with self.probes(records=[]):self.assertIsNone(recovery.filesystem_recovery_directory(self.root))
    def test_ambiguous_mount_not_excluded(self):
        with self.probes(records=[self.record,self.record]):self.assertIsNone(recovery.filesystem_recovery_directory(self.root))
    def test_other_filesystems_not_excluded(self):
        for fs in ('ext2','ext3','xfs','overlay'):
            with self.subTest(fs=fs):self.record['fstype']=fs;self.assertIsNone(self.recognized())
    def test_bind_subdirectory_not_excluded(self):
        self.record['fsroot']='/models';self.assertIsNone(self.recognized())
    def test_archive_subdirectory_not_excluded(self):
        self.record['mount']=self.root.parent;self.assertIsNone(self.recognized())
    def test_nested_mount_not_excluded(self):
        with self.probes(records=[self.record,{**self.record,'mount':self.lost}]):self.assertIsNone(recovery.filesystem_recovery_directory(self.root))
    def test_wrong_device_not_excluded(self):
        self.record['device']='999:999';self.assertIsNone(self.recognized())
    def test_child_different_device_not_excluded(self):
        self.child.st_dev+=1;self.assertIsNone(self.recognized())
    def test_nonstandard_inode_not_excluded(self):
        self.child.st_ino=500;self.assertIsNone(self.recognized())
    def test_nonroot_inode_not_excluded(self):
        self.parent.st_ino=500;self.assertIsNone(self.recognized())
    def test_owner_and_permissions_not_excluded(self):
        for attr,value in [('st_uid',1000),('st_gid',1000),('st_mode',stat.S_IFDIR|0o755),('st_mode',stat.S_IFDIR|0o1700)]:
            with self.subTest(attr=attr,value=value),patch.object(self.child,attr,value):self.assertIsNone(self.recognized())
    def test_file_or_symlink_not_excluded(self):
        for kind in (stat.S_IFREG,stat.S_IFLNK):
            self.child.st_mode=kind|0o700;self.assertIsNone(self.recognized())
    def test_root_symlink_not_excluded(self):
        alias=self.root/'alias';alias.symlink_to(self.root)
        with self.probes():self.assertIsNone(recovery.filesystem_recovery_directory(alias))
    def test_metadata_probe_failure_not_excluded(self):
        with self.probes(),patch.object(recovery,'_entry_stats',side_effect=PermissionError('denied')):self.assertIsNone(recovery.filesystem_recovery_directory(self.root))
    def test_mount_probe_failure_not_excluded(self):
        with patch.object(recovery.volume,'mount_records',side_effect=ToolkitError('unknown')):self.assertIsNone(recovery.filesystem_recovery_directory(self.root))
    def test_mount_change_not_excluded(self):
        with self.probes(),patch.object(recovery.volume,'mount_records',side_effect=[[self.record],[]]):self.assertIsNone(recovery.filesystem_recovery_directory(self.root))
    def test_descriptor_mismatch_not_excluded(self):
        visible=NS(st_dev=self.dev,st_ino=900)
        with self.probes(stats=(self.parent,visible,self.child)):self.assertIsNone(recovery.filesystem_recovery_directory(self.root))
    def test_windows_does_not_probe_linux(self):
        with patch.object(recovery.sys,'platform','win32'),patch.object(recovery.volume,'mount_records',side_effect=AssertionError):self.assertIsNone(recovery.filesystem_recovery_directory(self.root))
    def test_active_descriptor_root_supported(self):
        session=NS(root=Path('/proc/self/fd/123456'),original=self.root,check=lambda:None)
        with self.probes(),patch.object(recovery.volume,'active_session',return_value=session):self.assertIsNotNone(recovery.filesystem_recovery_directory(session.root))
    def test_inventory_exclusion_auditable_and_bytes_unchanged(self):
        (self.root/'payload').write_bytes(b'abc');(self.lost/'recovered').write_bytes(b'excluded')
        with self.probes():data=storage.scan(self.root,CAT)
        self.assertTrue(data['summary']['scan_complete']);self.assertEqual(data['summary']['total_logical_bytes'],3)
        self.assertEqual(data['excluded_filesystem_entries'][0]['path'],'lost+found')
        self.assertIn('EXCLUDED: lost+found',storage.render(data,'text'))
        self.assertEqual(json.loads(storage.render(data,'json'))['excluded_filesystem_entries'],data['excluded_filesystem_entries'])
    def test_unrecognized_recovery_payload_accounted(self):
        (self.lost/'payload').write_bytes(b'abc')
        with self.probes(records=[]):data=storage.scan(self.root,CAT)
        self.assertEqual(data['summary']['total_logical_bytes'],3);self.assertEqual(data['excluded_filesystem_entries'],[])
    def test_nested_lost_found_accounted(self):
        nested=self.root/'category/lost+found';nested.mkdir(parents=True);(nested/'payload').write_bytes(b'abc')
        with self.probes():data=storage.scan(self.root,CAT);tree,size=compare_archives.tree(self.root)
        self.assertEqual(data['summary']['total_logical_bytes'],3);self.assertEqual(size,3);self.assertIn('category/lost+found/payload',tree)
    def test_comparison_excludes_only_confirmed_directory(self):
        (self.root/'payload').write_bytes(b'abc');(self.lost/'recovered').write_bytes(b'excluded')
        with tempfile.TemporaryDirectory() as d:
            destination=Path(d);(destination/'payload').write_bytes(b'abc')
            with self.probes():result=compare_archives.compare(self.root,destination)
        self.assertTrue(result['match']);self.assertEqual(result['source_bytes'],3)
        self.assertEqual(len(result['excluded_filesystem_entries']['source']),1)
        self.assertEqual(result['excluded_filesystem_entries']['destination'],[])
    def test_comparison_regular_file_named_lost_found_retained(self):
        self.lost.rmdir();self.lost.write_bytes(b'abc')
        with self.probes():data,size=compare_archives.tree(self.root)
        self.assertEqual(size,3);self.assertIn('lost+found',data)
    def test_comparison_symlink_named_lost_found_rejected(self):
        self.lost.rmdir();self.lost.symlink_to(self.root)
        with self.probes(stats=(self.parent,self.parent,NS(st_mode=stat.S_IFLNK))),self.assertRaises(ToolkitError):compare_archives.tree(self.root)

# Run mode-000 root-owned directories in a child with all capabilities dropped.
# Only ext4 mount/inode identification is simulated, not scandir/fwalk or EACCES.
# Capability changes affect only the disposable subprocess, never the parent.
CAP_DROP="import ctypes\nclass Header(ctypes.Structure):\n    _fields_=[('version',ctypes.c_uint32),('pid',ctypes.c_int)]\nclass Data(ctypes.Structure):\n    _fields_=[('effective',ctypes.c_uint32),('permitted',ctypes.c_uint32),('inheritable',ctypes.c_uint32)]\nlibc=ctypes.CDLL(None,use_errno=True)\nheader=Header(0x20080522,0);data=(Data*2)()\nif libc.capset(ctypes.byref(header),ctypes.byref(data))!=0:\n    raise OSError(ctypes.get_errno(),'Cannot drop child process capabilities')\n"
PERMISSION_SCRIPT=r'''
import json,os,sys,stat,errno
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
sys.path.insert(0,sys.argv[1])
from modelkit import storage,recovery_directory as r
import compare_archives
root=Path(sys.argv[2]);other=Path(sys.argv[3]);mode=sys.argv[4]
real=r._entry_stats
def stats(root,physical,fd):
    p,v,e=real(root,physical,fd)
    def copy(s,ino):return NS(st_dev=s.st_dev,st_ino=ino,st_mode=s.st_mode,st_uid=s.st_uid,st_gid=s.st_gid)
    entry=copy(e,11)
    if sys.argv[5]=='simulate':
        # This fixture represents a root-owned ext4 recovery directory even
        # when its temporary directory was created by an ordinary user.
        # Real-permission fixtures must retain the actual owner metadata.
        entry.st_uid=entry.st_gid=0
    return copy(p,2),copy(v,2),entry
if sys.argv[5]=='simulate':
    # Simulate an unprivileged scanner's EACCES on the real private directories.
    denied={p.stat().st_ino:p.name for p in root.rglob('*') if p.is_dir() and stat.S_IMODE(p.stat().st_mode)==0o700}
    real_scandir=os.scandir
    def scandir(path):
        s=os.fstat(path) if isinstance(path,int) else os.stat(path)
        if s.st_ino in denied:raise PermissionError(errno.EACCES,'Permission denied',denied[s.st_ino])
        return real_scandir(path)
    os.scandir=scandir

dev=root.stat().st_dev
record=dict(mount=root,fsroot='/',fstype='ext4',device=f'{os.major(dev)}:{os.minor(dev)}')
with patch.object(r.volume,'mount_records',return_value=[record]),patch.object(r,'_entry_stats',stats):
    if mode=='inventory':
        result=storage.scan(root,{'models':[]});print(json.dumps(result))
    else:
        try:print(json.dumps(compare_archives.compare(other,root)))
        except PermissionError as exc:print(json.dumps({'permission_error':exc.filename}))
'''
PERMISSION_SCRIPT=PERMISSION_SCRIPT.replace("root=Path(sys.argv[2])","if sys.argv[5]=='real':exec("+repr(CAP_DROP)+")\nroot=Path(sys.argv[2])")

class SimulatedPermissionTests(unittest.TestCase):
    permission_kind='simulate'
    def run_fixture(self,mode,extra=None):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);base.chmod(0o755);root=base/'archive';root.mkdir();source=base/'source';source.mkdir()
            (root/'payload').write_bytes(b'abc');(source/'payload').write_bytes(b'abc')
            lost=root/'lost+found';lost.mkdir(mode=0o700);lost.chmod(0 if self.permission_kind=='real' else 0o700)
            if extra:
                denied=root/extra;denied.mkdir(parents=True,exist_ok=True);denied.chmod(0 if self.permission_kind=='real' else 0o700)
            p=subprocess.run([sys.executable,'-c',PERMISSION_SCRIPT,str(ROOT),str(root),str(source),mode,self.permission_kind],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr);return json.loads(p.stdout)
    def test_inaccessible_ext4_recovery_inventory(self):
        d=self.run_fixture('inventory');self.assertTrue(d['summary']['scan_complete']);self.assertEqual(d['summary']['total_logical_bytes'],3)
    def test_inaccessible_ext4_recovery_comparison(self):
        d=self.run_fixture('compare');self.assertTrue(d['match']);self.assertEqual(d['destination_bytes'],3)
    def test_other_permission_errors_inventory_retained(self):
        d=self.run_fixture('inventory','unexpected');self.assertFalse(d['summary']['scan_complete']);self.assertTrue(any('unexpected' in w for w in d['warnings']))
    def test_other_permission_errors_comparison_retained(self):
        d=self.run_fixture('compare','unexpected');self.assertEqual(d['permission_error'],'unexpected')
    def test_nested_lost_found_permission_inventory_retained(self):
        d=self.run_fixture('inventory','category/lost+found');self.assertFalse(d['summary']['scan_complete'])
    def test_nested_lost_found_permission_comparison_retained(self):
        d=self.run_fixture('compare','category/lost+found');self.assertEqual(d['permission_error'],'lost+found')

class RealPermissionTests(SimulatedPermissionTests):
    permission_kind='real'
    def setUp(self):
        if not sys.platform.startswith('linux') or os.geteuid()!=0:
            raise unittest.SkipTest('Real root-owned EACCES fixture requires Linux root; ordinary-user runs use simulated EACCES cases')
        probe=subprocess.run([sys.executable,'-c',CAP_DROP],capture_output=True)
        if probe.returncode:
            raise unittest.SkipTest('Environment disallows dropping child capabilities; equivalent simulated EACCES cases run separately')

class BaselinePreservationTests(unittest.TestCase):
    def test_v110_protected_files_byte_identical(self):
        import hashlib
        fixture=ROOT/'tests/fixtures/v110-protected-files.json'
        self.assertEqual(hashlib.sha256(fixture.read_bytes()).hexdigest(),'73aae5a13a3016d4befa47e5d008971f761156ba2329056a824cb3be5460ca05')
        for name,digest in json.loads(fixture.read_text()).items():
            with self.subTest(file=name):self.assertEqual(hashlib.sha256(__import__("education_guard").baseline_bytes(ROOT/name)).hexdigest(),digest)
