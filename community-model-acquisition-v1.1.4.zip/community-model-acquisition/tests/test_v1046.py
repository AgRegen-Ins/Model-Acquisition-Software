"""Two exact GGUF variants; synthetic payloads only, never inference."""
import contextlib,copy,csv,hashlib,io,json,pickle,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,select,plan,read,acquire,inventory,space,ToolkitError
from modelkit.huggingface import HuggingFaceAdapter
from modelkit import accountability as acc,storage
from storage_test_support import main
from test_toolkit import Fake
ROOT=Path(__file__).resolve().parents[1];EV=ROOT/'evidence/v1.0.4.6'
Q='qwen3-next-80b-a3b-thinking-gguf-q6-k';G='glm-4-5-air-gguf-q4-k-m';IDS=[Q,G]
PINS={Q:('Qwen/Qwen3-Next-80B-A3B-Thinking-GGUF','de5795cd9a4f5538d1dd5c9823fdd73eacfae3fe'),G:('ggml-org/GLM-4.5-Air-GGUF','23a7a815a57a697e59f36fd8a897c632730a1fe9')}
class Metadata:
    def resolve(self,e):
        d=read(EV/e['repository'].replace('/','--')/'api.json');assert e['revision']==d['sha']
        return {'revision':d['sha'],'metadata':d,'gated':bool(d.get('gated')),'files':[{'path':f['rfilename'],'size':f['size'],'sha256':(f.get('lfs') or {}).get('sha256'),'git_blob_sha1':None if f.get('lfs') else f['blobId']} for f in d['siblings']]}
    def download(self,*a,**kw):raise AssertionError('Metadata-only test may not download')
class Catalog1046Tests(unittest.TestCase):
    def setUp(self):self.c=load_catalog(ROOT/'catalog.json');self.by={e['id']:e for e in self.c['models']}
    def test_exactly_two_additions_all_51_unchanged(self):
        old=read(EV/'baseline-catalog.json');self.assertEqual(len(self.c['models']),154);self.assertEqual(self.c['models'][:51],old['models']);self.assertEqual([e['id'] for e in self.c['models'][51:53]],IDS)
    def test_all_historical_profile_memberships_unchanged(self):
        old=read(EV/'baseline-catalog.json');self.assertEqual({k:self.c['profiles'][k] for k in old['profiles']},old['profiles']);self.assertEqual({k:self.c['profile_members'][k] for k in old['profile_members']},old['profile_members'])
        for p in old['profiles']:
            if p!='all':self.assertEqual(select(self.c,p),select(old,p))
        self.assertEqual(select(self.c,'all')[:51],select(old,'all'));self.assertEqual([e['id'] for e in select(self.c,'all')[51:60]],IDS+['huihui-glm-4-7-flash-abliterated-gguf-q4-k-m', 'huihui-qwen3-32b-abliterated-gguf-q4-k-m']+['huihui-gpt-oss-120b-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m', 'huihui-qwen3-coder-next-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m', 'qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m'])
    def test_repository_and_exact_pin(self):
        for id in IDS:self.assertEqual((self.by[id]['repository'],self.by[id]['revision']),PINS[id])
    def test_adapter_resolves_immutable_pin(self):
        for id in IDS:
            e=self.by[id]
            with patch('huggingface_hub.HfApi') as api:
                api.return_value.model_info.return_value=SimpleNamespace(sha=e['revision'],gated=False,siblings=[]);HuggingFaceAdapter().resolve(e);api.return_value.model_info.assert_called_once_with(e['repository'],revision=e['revision'],files_metadata=True)
    def test_exact_selection_and_byte_totals(self):
        for id in IDS:
            e=self.by[id];p=plan(e,Path('/tmp/no1046payload'),Metadata());m=read(EV/'selected-files.json')[id]
            self.assertEqual(p['files'],m['files']);self.assertEqual(p['files'],e['selected_files']);self.assertEqual(p['total_bytes'],m['total_bytes']);self.assertEqual(e['estimated_bytes'],m['total_bytes']);self.assertEqual(space(ROOT,p['total_bytes'])[1],m['reserve_bytes'])
    def test_required_exact_single_qwen_and_two_glm_shards(self):
        self.assertEqual(self.by[Q]['gguf_shards'],['Qwen3-Next-80B-A3B-Thinking-Q6_K.gguf'])
        self.assertEqual(self.by[G]['gguf_shards'],['GLM-4.5-Air-Q4_K_M-00001-of-00002.gguf','GLM-4.5-Air-Q4_K_M-00002-of-00002.gguf'])
        for id in IDS:self.assertEqual(self.by[id]['include'],self.by[id]['required']);self.assertTrue(set(self.by[id]['gguf_shards'])<=set(self.by[id]['required']))
    def test_missing_any_required_file_refused(self):
        for id in IDS:
            e=self.by[id]
            for missing in e['required']:
                a=Metadata();d=a.resolve(e);d['files']=[f for f in d['files'] if f['path']!=missing]
                with patch.object(a,'resolve',return_value=d),self.assertRaises(ToolkitError):plan(e,ROOT,a)
    def test_quantization_or_model_substitution_refused(self):
        for id in IDS:
            e=self.by[id];a=Metadata();d=a.resolve(e)
            for f in d['files']:
                if f['path'].endswith('.gguf'):f['path']=f['path'].replace('Q6_K','Q8_0').replace('Q4_K_M','Q5_K_M')
            with patch.object(a,'resolve',return_value=d),self.assertRaises(ToolkitError):plan(e,ROOT,a)
        with self.assertRaises(ToolkitError):select(self.c,ids=['qwen3-next-80b-a3b-instruct-gguf-q6-k'])
    def test_only_requested_quant_no_draft_or_other_shards(self):
        for id in IDS:
            e=self.by[id];fs=plan(e,ROOT,Metadata())['files'];self.assertEqual({f['path'] for f in fs},set(e['required']));self.assertFalse(any('mtp-' in f['path'] for f in fs))
    def test_every_gguf_has_upstream_sha256(self):
        for id in IDS:
            for f in self.by[id]['selected_files']:
                if f['path'].endswith('.gguf'):self.assertRegex(f['sha256'],r'^[0-9a-f]{64}$')
    def test_provenance_license_and_role(self):
        self.assertEqual(self.by[Q]['source_kind'],'official-derived');self.assertEqual(self.by[G]['source_kind'],'third-party-derived');self.assertEqual(self.by[Q]['license'],'apache-2.0');self.assertEqual(self.by[G]['license'],'mit')
        for id in IDS:self.assertEqual(self.by[id]['variant_role'],'portable-gguf');self.assertEqual(self.by[id]['preservation_policy'],'inference-only');self.assertFalse(self.by[id]['hp_inference_tested'])
    def test_architecture_context_active_parameters_independent(self):
        self.assertEqual([self.by[id]['active_parameter_count'] for id in IDS],[3000000000,12000000000]);self.assertEqual([self.by[id]['context_length'] for id in IDS],[262144,131072]);self.assertEqual([self.by[id]['quantization'] for id in IDS],['Q6_K','Q4_K_M'])
        for id in IDS:self.assertEqual(self.by[id]['architecture_type'],'MoE');self.assertGreater(self.by[id]['parameter_count'],self.by[id]['active_parameter_count'])
    def test_gguf_header_structure_and_split_consistency(self):
        for id in IDS:
            e=self.by[id];hs=[read(EV/e['repository'].replace('/','--')/(n+'.header.json')) for n in e['gguf_shards']]
            self.assertEqual(sum(h['parameter_count'] for h in hs),e['parameter_count']);self.assertTrue(all(h['gguf_version']==3 for h in hs));self.assertEqual(hs[0]['metadata']['general.architecture'],e['gguf_architecture'])
            names=[t['name'] for h in hs for t in h['tensors']];self.assertEqual(len(names),len(set(names)))
            if id==G:
                self.assertEqual([h['metadata']['split.no'] for h in hs],[0,1]);self.assertEqual([h['metadata']['split.count'] for h in hs],[2,2]);self.assertEqual(sum(h['tensor_count'] for h in hs),780);self.assertEqual(hs[0]['tensor_count'],0);self.assertTrue(all(h['metadata']['split.tensors.count']==780 for h in hs))
    def test_templates_embedded_no_external_companion(self):
        for id in IDS:
            e=self.by[id];h=read(EV/e['repository'].replace('/','--')/(e['gguf_shards'][0]+'.header.json'))
            self.assertIn('tokenizer.chat_template',h['metadata']);self.assertGreater(h['array_lengths']['tokenizer.ggml.tokens'],100000);self.assertFalse(e['companion_artifacts_required']);self.assertEqual(e['dependencies'],[])
    def test_policy_old_values_unchanged(self):
        old=read(EV/'baseline-preservation-policy.json');new=read(ROOT/'preservation-policy.json')
        for id,v in old['models'].items():self.assertEqual(new['models'][id],v)
        self.assertEqual(set(new['models'])-set(old['models'])-set(__import__('json').loads((ROOT/'evidence/v1.1.3/new-ids.json').read_text()))-set(__import__('json').loads((ROOT/'evidence/v1.1.4/new-ids.json').read_text())),set(IDS+['huihui-glm-4-7-flash-abliterated-gguf-q4-k-m', 'huihui-qwen3-32b-abliterated-gguf-q4-k-m']+['huihui-gpt-oss-120b-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m', 'huihui-qwen3-coder-next-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m', 'qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m']))
    def test_all_production_code_byte_identical_except_version(self):
        for n,h in read(EV/'baseline-PACKAGE-CHECKSUMS.json').items():
            if (n.endswith('.py') and not n.startswith(('tests/','evidence/')) and n!='modelkit/__init__.py') or n in ['requirements.txt','settings.json','setup-linux.sh','setup-windows.ps1','tests/fixtures/core-v1.0.3.py.txt']:self.assertEqual(hashlib.sha256(legacy_bytes(ROOT/n)).hexdigest(),h,n)
    def test_dry_run_individual_and_combined_read_only(self):
        for ids in [[Q],[G],IDS]:
            with tempfile.TemporaryDirectory() as t:
                root=Path(t)/'absent';out=io.StringIO();args=['--root',str(root),'--dry-run']
                for id in ids:args+=['--model',id]
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),contextlib.redirect_stdout(out):self.assertEqual(main(args),0)
                self.assertFalse(root.exists());self.assertIn('LARGE ARCHIVE',out.getvalue());self.assertIn('Required with reserve:',out.getvalue())
    def test_yes_cannot_bypass_allow_large(self):
        for id in IDS:
            with tempfile.TemporaryDirectory() as t,patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),patch('model_acquire.space',return_value=(10**15,10**12)),contextlib.redirect_stdout(io.StringIO()),self.assertRaisesRegex(ToolkitError,'--allow-large'):main(['--root',t,'--model',id,'--yes'])
    def test_mount_guard_before_network(self):
        for id in IDS:
            with tempfile.TemporaryDirectory() as t,patch('modelkit.mounts.is_mounted',return_value=False),patch('modelkit.huggingface.HuggingFaceAdapter',side_effect=AssertionError('No network')),contextlib.redirect_stdout(io.StringIO()),self.assertRaises(ToolkitError):main(['--root',t+'/models','--expected-mount',t,'--model',id,'--yes','--allow-large'])
    def test_space_safety_still_active(self):
        for id in IDS:
            with tempfile.TemporaryDirectory() as t,patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),patch('model_acquire.space',return_value=(1,10**12)),contextlib.redirect_stdout(io.StringIO()),self.assertRaisesRegex(ToolkitError,'Insufficient space'):main(['--root',t,'--model',id,'--yes','--allow-large'])

class Payload1046Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'models';self.c=load_catalog(ROOT/'catalog.json');self.entries=[e for e in self.c['models'] if e['id'] in IDS];self.out=contextlib.redirect_stdout(io.StringIO());self.out.__enter__()
    def tearDown(self):self.out.__exit__(None,None,None);self.tmp.cleanup()
    def fake(self,e):
        a=Fake({n:b'GGUF inert synthetic test data '+n.encode() for n in e['required']});a.rev=e['revision'];return a
    def test_complete_both_verified_hashes(self):
        for e in self.entries:
            a=self.fake(e);p=plan(e,self.root,a);acquire(p,self.root,a);m=read(Path(p['target'])/'manifest.json');self.assertEqual(m['status'],'verified');self.assertEqual(set(m['files']),set(e['required']))
            for n,r in m['files'].items():self.assertEqual(r['sha256'],hashlib.sha256(a.data[n]).hexdigest())
    def test_interruption_reuses_completed_glm_shard(self):
        e=self.entries[1];a=self.fake(e);p=plan(e,self.root,a);original=a.download;second=e['gguf_shards'][1]
        def stop(entry,rev,n,t,force=False):
            if n==second:raise KeyboardInterrupt
            return original(entry,rev,n,t,force)
        with patch.object(a,'download',side_effect=stop),self.assertRaises(KeyboardInterrupt):acquire(p,self.root,a)
        self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'partial');acquire(plan(e,self.root,a),self.root,a);self.assertEqual(a.calls.count(e['gguf_shards'][0]),1)
    def test_missing_downloaded_shard_not_verified(self):
        e=self.entries[1];a=self.fake(e);p=plan(e,self.root,a);acquire(p,self.root,a);(Path(p['target'])/'payload'/e['gguf_shards'][1]).unlink()
        r=next(r for r in inventory(self.root,self.c,verify=True)['models'] if r['id']==e['id']);self.assertEqual(r['status'],'failed');self.assertIn(e['gguf_shards'][1],r['problems'])
    def test_truncated_download_quarantined(self):
        for e in self.entries:
            a=self.fake(e);orig=a.download;weight=e['gguf_shards'][-1]
            def bad(entry,rev,n,t,force=False):
                orig(entry,rev,n,t,force)
                if n==weight:(t/n).write_bytes(b'bad')
            p=plan(e,self.root,a)
            with patch.object(a,'download',side_effect=bad),self.assertRaises(ToolkitError):acquire(p,self.root,a,retries=1)
            self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'failed');self.assertTrue(list((Path(p['target'])/'quarantine').glob('*/'+weight)))
    def test_same_size_corruption_hash_audit(self):
        for e in self.entries:
            a=self.fake(e);p=plan(e,self.root,a);acquire(p,self.root,a);f=Path(p['target'])/'payload'/e['gguf_shards'][0];f.write_bytes(b'x'*f.stat().st_size)
            self.assertEqual(next(r for r in inventory(self.root,self.c,verify=True)['models'] if r['id']==e['id'])['status'],'failed')
    def test_safe_rerun_and_no_execution(self):
        for e in self.entries:
            a=self.fake(e)
            with patch.object(pickle,'load',side_effect=AssertionError('No deserialization')),patch.object(pickle,'loads',side_effect=AssertionError('No deserialization')):
                acquire(plan(e,self.root,a),self.root,a);acquire(plan(e,self.root,a),self.root,a)
            self.assertEqual(len(a.calls),len(e['required']));self.assertEqual(plan(e,self.root,a)['estimated_new_bytes'],0)
    def test_cataloged_does_not_mean_downloaded(self):
        rows={r['id']:r for r in acc.collect(self.root,self.c)['models']}
        for id in IDS:self.assertEqual(rows[id]['status'],'cataloged-not-downloaded')
    def test_accountability_and_storage_exports(self):
        for e in self.entries:acquire(plan(e,self.root,self.fake(e)),self.root,self.fake(e))
        d=acc.collect(self.root,self.c,acc.policies(ROOT/'preservation-policy.json'));rs={r['id']:r for r in json.loads(acc.render(d,'json'))['models']};cs={r['id']:r for r in csv.DictReader(io.StringIO(acc.render(d,'csv')))}
        for id in IDS:self.assertEqual(rs[id]['status'],'downloaded-verified');self.assertIn(id,cs);self.assertIn(id,acc.render(d))
        s=storage.scan(self.root,self.c);self.assertEqual({r['id'] for r in s['models']},set(IDS));self.assertEqual(s['summary']['revision_count'],2);self.assertGreater(s['summary']['total_model_storage_bytes'],0)

from maintenance_guard import legacy_bytes
