"""Catalog-only expansion regression tests; uses captured upstream metadata."""
import contextlib,copy,io,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,select,plan
from storage_test_support import main
ROOT=Path(__file__).resolve().parents[1]
PREFIXES=('qwen2-5-coder-14b-instruct','qwen3-coder-30b-a3b-instruct')
class EvidenceAdapter:
    def resolve(self,e):
        d=json.loads((ROOT/'evidence/v1.0.2'/(e['repository'].replace('/','--')+'.json')).read_text())
        if e['revision']!=d['sha']:raise AssertionError('Revision not pinned to captured evidence')
        return {'revision':d['sha'],'metadata':d,'files':[{'path':s['rfilename'],'size':s['size'],'sha256':(s.get('lfs') or {}).get('sha256'),'git_blob_sha1':None if s.get('lfs') else s.get('blobId')} for s in d['siblings']]}
class Catalog102Tests(unittest.TestCase):
    def setUp(self):
        self.c=load_catalog(ROOT/'catalog.json');self.new=[e for e in self.c['models'] if e['id'].startswith(PREFIXES)]
    def test_families_parse(self):
        self.assertEqual(len(self.new),4)
        self.assertEqual({e['family'] for e in self.new},{'Qwen2.5-Coder','Qwen3-Coder'})
    def test_profiles(self):
        for e in self.new:
            self.assertIn('coding',e['profiles'])
            self.assertIn('coding-local' if e['format']=='GGUF' else 'coding-archive',e['profiles'])
        self.assertEqual(len(select(self.c,'coding-local')),4);self.assertEqual(len(select(self.c,'coding-archive')),7);self.assertEqual(len(select(self.c,'coding')),12)
    def test_provenance(self):
        for e in self.new:
            expected='third-party-derived' if e['publisher']=='unsloth' else 'official-derived' if e['format']=='GGUF' else 'official-upstream'
            self.assertEqual(e['source_kind'],expected);self.assertTrue(e['base_model'].startswith('Qwen/'));self.assertEqual(e['license'],'apache-2.0')
    def test_exact_gguf_selection(self):
        for e in self.new:
            if e['format']!='GGUF':continue
            p=plan(e,Path('/tmp/catalog102-no-writes'),EvidenceAdapter());weights=[f['path'] for f in p['files'] if f['path'].endswith('.gguf')]
            self.assertEqual(len(weights),1);self.assertTrue(weights[0].lower().endswith('q4_k_m.gguf'));self.assertNotIn('-of-',weights[0]);self.assertIn('README.md',[f['path'] for f in p['files']])
    def test_revision_pinning_and_size(self):
        for e in self.new:
            self.assertRegex(e['revision'],r'^[0-9a-f]{40}$');p=plan(e,Path('/tmp/catalog102-no-writes'),EvidenceAdapter())
            self.assertEqual(p['revision'],e['revision']);self.assertEqual(p['total_bytes'],e['estimated_bytes']);self.assertTrue(p['target'].endswith(e['revision']))
    def test_architecture_context_and_moe(self):
        for e in self.new:
            moe=e['family']=='Qwen3-Coder'
            self.assertEqual(e['architecture'],['Qwen3MoeForCausalLM' if moe else 'Qwen2ForCausalLM'])
            self.assertEqual(e['context_length'],262144 if moe else 32768)
            self.assertEqual(e['parameter_count'],30500000000 if moe else 14700000000)
            self.assertEqual(e['active_parameter_count'],3300000000 if moe else None)
    def test_dry_runs_no_weights_or_writes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'no writes'
            with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=EvidenceAdapter()),contextlib.redirect_stdout(io.StringIO()):
                for e in self.new:self.assertEqual(main(['--root',str(root),'--model',e['id'],'--dry-run']),0)
            self.assertFalse(root.exists())
    def test_offline_plans(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            for e in self.new:self.assertEqual(main(['--root',tmp,'--model',e['id'],'--offline-plan']),0)
    def test_existing_entries_unchanged(self):
        baseline=json.loads((ROOT/'evidence/v1.0.2/v1.0.1-catalog-baseline.json').read_text())
        current={e['id']:e for e in self.c['models']}
        for e in baseline['models']:
            actual=copy.deepcopy(current[e['id']])
            if e['id']=='qwen3-32b-gguf-q4-k-m':actual['profiles'].remove('dell-upper-tier')
            self.assertEqual(actual,e)
    def test_original_shard_selection(self):
        for e in self.new:
            if e['format']=='GGUF':continue
            p=plan(e,Path('/tmp/catalog102-no-writes'),EvidenceAdapter());names={f['path'] for f in p['files']}
            self.assertIn('model.safetensors.index.json',names);self.assertIn('tokenizer.json',names);self.assertIn('config.json',names)
            self.assertTrue(any(n.endswith('.safetensors') for n in names));self.assertFalse(any(n.endswith('.gguf') for n in names))
if __name__=='__main__':unittest.main(verbosity=2)
