"""Huihui-only Q4_K_M catalog additions. No real weights or inference in tests."""
import contextlib,copy,hashlib,io,json,pickle,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from modelkit.core import load_catalog,select,plan,acquire,inventory,read,space,ToolkitError
from modelkit.huggingface import HuggingFaceAdapter
from modelkit import accountability as acc,storage
from storage_test_support import main
from test_toolkit import Fake
ROOT=Path(__file__).resolve().parents[1];EV=ROOT/'evidence/v1.0.4.7'
G='huihui-glm-4-7-flash-abliterated-gguf-q4-k-m';Q='huihui-qwen3-32b-abliterated-gguf-q4-k-m';IDS=[G,Q]
PINS={G:('mradermacher/Huihui-GLM-4.7-Flash-abliterated-GGUF','2d925ab0fdaa279a87485f4786ca22661bf030b2'),Q:('RoadToNowhere/Qwen3-32B-abliterated-Q4_K_M-GGUF','36a6a1be225e6728acaec150ae944cf24491f684')}
class Metadata:
    def resolve(self,e):
        d=read(EV/e['repository'].replace('/','--')/'api.json');assert e['revision']==d['sha']
        return {'revision':d['sha'],'metadata':d,'gated':bool(d.get('gated')),'files':[{'path':f['rfilename'],'size':f['size'],'sha256':(f.get('lfs') or {}).get('sha256'),'git_blob_sha1':None if f.get('lfs') else f['blobId']} for f in d['siblings']]}
    def download(self,*a,**kw):raise AssertionError('No network payloads in tests')
class Catalog1047Tests(unittest.TestCase):
    def setUp(self):self.c=load_catalog(ROOT/'catalog.json');self.by={e['id']:e for e in self.c['models']}
    def test_exactly_two_added_all_53_unchanged(self):
        old=read(EV/'baseline-catalog.json');self.assertEqual(self.c['models'][:53],old['models']);self.assertEqual(len(self.c['models']),154);self.assertEqual([e['id'] for e in self.c['models'][53:55]],IDS)
    def test_all_existing_profiles_unchanged(self):
        old=read(EV/'baseline-catalog.json');self.assertEqual({k:self.c['profiles'][k] for k in old['profiles']},old['profiles']);self.assertEqual({k:self.c['profile_members'][k] for k in old['profile_members']},old['profile_members'])
        for p in old['profiles']:
            if p!='all':self.assertEqual(select(self.c,p),select(old,p))
        self.assertEqual(select(self.c,'all')[:53],select(old,'all'));self.assertEqual([e['id'] for e in select(self.c,'all')[53:60]],IDS+['huihui-gpt-oss-120b-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m', 'huihui-qwen3-coder-next-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m', 'qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m'])
    def test_exact_repositories_and_pins(self):
        for id in IDS:self.assertEqual((self.by[id]['repository'],self.by[id]['revision']),PINS[id])
    def test_adapter_uses_immutable_revision(self):
        for id in IDS:
            e=self.by[id]
            with patch('huggingface_hub.HfApi') as api:
                api.return_value.model_info.return_value=SimpleNamespace(sha=e['revision'],gated=False,siblings=[]);HuggingFaceAdapter().resolve(e);api.return_value.model_info.assert_called_once_with(e['repository'],revision=e['revision'],files_metadata=True)
    def test_exact_single_file_quantization(self):
        self.assertEqual(self.by[G]['gguf_shards'],['Huihui-GLM-4.7-Flash-abliterated.Q4_K_M.gguf']);self.assertEqual(self.by[Q]['gguf_shards'],['qwen3-32b-abliterated-q4_k_m.gguf'])
        for id in IDS:
            e=self.by[id];self.assertEqual(e['format'],'GGUF');self.assertEqual(e['quantization'],'Q4_K_M');self.assertEqual(e['include'],e['required']);self.assertEqual(set(e['required']),{e['gguf_shards'][0],'README.md'})
    def test_manifest_bytes_and_reserve(self):
        for id,expected in zip(IDS,[18132725887,19762152900]):
            e=self.by[id];p=plan(e,Path('/tmp/no1047write'),Metadata());m=read(EV/'selected-files.json')[id]
            self.assertEqual(p['files'],m['files']);self.assertEqual(p['files'],e['selected_files']);self.assertEqual(p['total_bytes'],expected);self.assertEqual(e['estimated_bytes'],expected);self.assertEqual(space(ROOT,expected)[1],m['reserve_bytes'])
    def test_missing_required_file_refused(self):
        for id in IDS:
            e=self.by[id]
            for n in e['required']:
                a=Metadata();d=a.resolve(e);d['files']=[f for f in d['files'] if f['path']!=n]
                with patch.object(a,'resolve',return_value=d),self.assertRaises(ToolkitError):plan(e,ROOT,a)
    def test_wrong_quantization_cannot_substitute(self):
        for id in IDS:
            e=self.by[id];a=Metadata();d=a.resolve(e)
            for f in d['files']:f['path']=f['path'].replace('Q4_K_M','Q5_K_M').replace('q4_k_m','q5_k_m')
            with patch.object(a,'resolve',return_value=d),self.assertRaises(ToolkitError):plan(e,ROOT,a)
    def test_huihui_lineage_not_roslein(self):
        for id in IDS:
            e=self.by[id];d=read(EV/e['repository'].replace('/','--')/'api.json');self.assertEqual(d['cardData']['base_model'],e['modification_source']);self.assertTrue(e['modification_source'].startswith('huihui-ai/'))
        rejected=read(EV/'mradermacher--Qwen3-32B-abliterated-GGUF/api.json');self.assertEqual(rejected['cardData']['base_model'],'roslein/Qwen3-32B-abliterated');self.assertNotEqual(self.by[Q]['repository'],rejected['id'])
    def test_source_snapshots_not_fabricated_conversion_commits(self):
        for id in IDS:
            e=self.by[id];d=read(EV/e['modification_source'].replace('/','--')/'api.json');self.assertEqual(e['modification_source_revision_at_review'],d['sha']);self.assertNotIn('upstream_revision',e);self.assertIn('not an asserted conversion-source commit',e['upstream_revision_note'])
    def test_gated_source_public_conversion_distinction(self):
        self.assertEqual(read(EV/'huihui-ai--Qwen3-32B-abliterated/api.json')['gated'],'auto');self.assertFalse(self.by[Q]['gated_at_review']);self.assertIn('401',self.by[Q]['source_access_note']);self.assertFalse((EV/'huihui-ai--Qwen3-32B-abliterated/config.json').exists())
    def test_provenance_license_and_roles(self):
        self.assertEqual([self.by[id]['license'] for id in IDS],['mit','apache-2.0'])
        for id in IDS:
            e=self.by[id];self.assertEqual(e['source_kind'],'third-party-derived');self.assertEqual(e['variant_role'],'portable-gguf');self.assertEqual(e['preservation_policy'],'inference-only');self.assertFalse(e['hp_inference_tested']);self.assertEqual(e['modification_type'],'abliterated')
    def test_moe_dense_independent_metadata(self):
        self.assertEqual(self.by[G]['architecture_type'],'MoE');self.assertEqual(self.by[G]['active_parameter_count'],3000000000);self.assertEqual(self.by[Q]['architecture_type'],'dense');self.assertIsNone(self.by[Q]['active_parameter_count']);self.assertEqual([self.by[id]['parameter_count'] for id in IDS],[29943393920,32762123264]);self.assertEqual([self.by[id]['context_length'] for id in IDS],[202752,40960])
    def test_header_identity_and_templates(self):
        for id in IDS:
            e=self.by[id];h=read(EV/e['repository'].replace('/','--')/(e['gguf_shards'][0]+'.header.json'));self.assertEqual(h['gguf_version'],3);self.assertEqual(h['metadata']['general.file_type'],15);self.assertEqual(h['metadata']['general.architecture'],e['gguf_architecture']);self.assertEqual(h['parameter_count'],e['parameter_count']);self.assertGreater(h['array_lengths']['tokenizer.ggml.tokens'],100000);self.assertIn('tokenizer.chat_template',h['metadata']);self.assertEqual(h['sha256'],next(f['sha256'] for f in e['selected_files'] if f['path'].endswith('.gguf')))
    def test_dependencies_and_repeat_selection(self):
        for id in IDS:
            e=self.by[id];self.assertEqual(e['dependencies'],[]);self.assertFalse(e['companion_artifacts_required']);self.assertEqual(select(self.c,ids=[id,id]),[e])
    def test_old_policy_values_unchanged(self):
        old=read(EV/'baseline-preservation-policy.json');new=read(ROOT/'preservation-policy.json')
        for id,v in old['models'].items():self.assertEqual(new['models'][id],v)
        self.assertEqual(set(new['models'])-set(old['models'])-set(__import__('json').loads((ROOT/'evidence/v1.1.3/new-ids.json').read_text()))-set(__import__('json').loads((ROOT/'evidence/v1.1.4/new-ids.json').read_text())),set(IDS+['huihui-gpt-oss-120b-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m', 'huihui-qwen3-coder-next-abliterated-gguf-q4-k-m', 'huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m', 'qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m']))
    def test_production_and_configuration_byte_identical(self):
        for n,h in read(EV/'baseline-PACKAGE-CHECKSUMS.json').items():
            if (n.endswith('.py') and not n.startswith(('tests/','evidence/')) and n!='modelkit/__init__.py') or n in ['settings.json','requirements.txt','setup-linux.sh','setup-windows.ps1','tests/fixtures/core-v1.0.3.py.txt']:self.assertEqual(hashlib.sha256(legacy_bytes(ROOT/n)).hexdigest(),h,n)
    def test_live_style_dry_runs_no_writes(self):
        for ids in [[G],[Q],IDS]:
            with tempfile.TemporaryDirectory() as t:
                root=Path(t)/'absent';out=io.StringIO();args=['--root',str(root),'--dry-run']
                for id in ids:args+=['--model',id]
                with patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),contextlib.redirect_stdout(out):self.assertEqual(main(args),0)
                self.assertFalse(root.exists());self.assertIn('Required with reserve:',out.getvalue());self.assertNotIn('LARGE ARCHIVE',out.getvalue())
    def test_mount_refusal_before_metadata(self):
        for id in IDS:
            with tempfile.TemporaryDirectory() as t,patch('modelkit.mounts.is_mounted',return_value=False),patch('modelkit.huggingface.HuggingFaceAdapter',side_effect=AssertionError('No network')),contextlib.redirect_stdout(io.StringIO()),self.assertRaises(ToolkitError):main(['--root',t+'/models','--expected-mount',t,'--model',id,'--yes'])
    def test_storage_reserve_not_bypassed(self):
        for id in IDS:
            with tempfile.TemporaryDirectory() as t,patch('modelkit.huggingface.HuggingFaceAdapter',return_value=Metadata()),patch('model_acquire.space',return_value=(1,10**12)),contextlib.redirect_stdout(io.StringIO()),self.assertRaisesRegex(ToolkitError,'Insufficient space'):main(['--root',t,'--model',id,'--yes','--allow-large'])

class Payload1047Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'models';self.c=load_catalog(ROOT/'catalog.json');self.entries=[e for e in self.c['models'] if e['id'] in IDS];self.out=contextlib.redirect_stdout(io.StringIO());self.out.__enter__()
    def tearDown(self):self.out.__exit__(None,None,None);self.tmp.cleanup()
    def fake(self,e):
        a=Fake({n:b'GGUF inert synthetic fixture: '+n.encode() for n in e['required']});a.rev=e['revision'];return a
    def test_verified_hashes_and_no_execution(self):
        for e in self.entries:
            a=self.fake(e);p=plan(e,self.root,a)
            with patch.object(pickle,'load',side_effect=AssertionError('No execution')),patch.object(pickle,'loads',side_effect=AssertionError('No execution')):acquire(p,self.root,a)
            m=read(Path(p['target'])/'manifest.json');self.assertEqual(m['status'],'verified')
            for n,r in m['files'].items():self.assertEqual(r['sha256'],hashlib.sha256(a.data[n]).hexdigest())
    def test_interruption_and_rerun_reuse(self):
        for e in self.entries:
            a=self.fake(e);orig=a.download;second=e['required'][1]
            def stop(entry,rev,n,t,force=False):
                if n==second:raise KeyboardInterrupt
                return orig(entry,rev,n,t,force)
            p=plan(e,self.root,a)
            with patch.object(a,'download',side_effect=stop),self.assertRaises(KeyboardInterrupt):acquire(p,self.root,a)
            self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'partial');acquire(plan(e,self.root,a),self.root,a);self.assertEqual(a.calls.count(e['gguf_shards'][0]),1)
    def test_corruption_rejected_and_quarantined(self):
        for e in self.entries:
            a=self.fake(e);orig=a.download;weight=e['gguf_shards'][0]
            def bad(entry,rev,n,t,force=False):
                orig(entry,rev,n,t,force)
                if n==weight:(t/n).write_bytes(b'bad')
            p=plan(e,self.root,a)
            with patch.object(a,'download',side_effect=bad),self.assertRaises(ToolkitError):acquire(p,self.root,a,retries=1)
            self.assertEqual(read(Path(p['target'])/'manifest.json')['status'],'failed');self.assertTrue(list((Path(p['target'])/'quarantine').glob('*/'+weight)))
    def test_missing_payload_fails_audit(self):
        e=self.entries[0];a=self.fake(e);p=plan(e,self.root,a);acquire(p,self.root,a);(Path(p['target'])/'payload'/e['gguf_shards'][0]).unlink();self.assertEqual(next(r for r in inventory(self.root,self.c,verify=True)['models'] if r['id']==G)['status'],'failed')
    def test_safe_rerun_no_duplicate_download(self):
        for e in self.entries:
            a=self.fake(e);acquire(plan(e,self.root,a),self.root,a);acquire(plan(e,self.root,a),self.root,a);self.assertEqual(len(a.calls),2);self.assertEqual(plan(e,self.root,a)['estimated_new_bytes'],0)
    def test_cataloged_not_downloaded(self):
        d=acc.collect(self.root,self.c);rs={r['id']:r for r in d['models']}
        for id in IDS:self.assertEqual(rs[id]['status'],'cataloged-not-downloaded')
    def test_inventory_exports_and_storage(self):
        for e in self.entries:
            a=self.fake(e);acquire(plan(e,self.root,a),self.root,a)
        d=acc.collect(self.root,self.c,acc.policies(ROOT/'preservation-policy.json'))
        for fmt in ['json','csv','text']:
            out=acc.render(d,fmt)
            for id in IDS:self.assertIn(id,out)
        self.assertEqual(storage.scan(self.root,self.c)['summary']['revision_count'],2)
    def test_large_interlock_retained_for_aggregate(self):
        e=copy.deepcopy(self.entries[0]);e['id']='large-synthetic';e['estimated_bytes']=50000000000;c=copy.deepcopy(self.c);c['models'].append(e);a=self.fake(e);d=a.resolve(e);d['files'][0]['size']=50000000000
        with patch('model_acquire.load_catalog',return_value=c),patch('modelkit.huggingface.HuggingFaceAdapter',return_value=a),patch.object(a,'resolve',return_value=d),patch('model_acquire.space',return_value=(10**15,10**12)),self.assertRaisesRegex(ToolkitError,'--allow-large'):main(['--root',str(self.root),'--model',e['id'],'--yes'])
        self.assertFalse(self.root.exists());self.assertEqual(a.calls,[])

from maintenance_guard import legacy_bytes
