"""Source-agnostic preservation core. Payloads are never executed."""
from __future__ import annotations
import hashlib, json, os, re, shutil, time, uuid
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from fnmatch import fnmatch

class ToolkitError(Exception): pass

def now(): return datetime.now(timezone.utc).isoformat()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def write(path, data):
    from .volume import checkpoint, public_data
    checkpoint(); data=public_data(data)
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    with tmp.open('w',encoding='utf-8') as f:
        json.dump(data,f,indent=2,ensure_ascii=False); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)
def safe_name(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',value) or value.endswith('.'):
        raise ToolkitError('Unsafe directory identifier: '+str(value))
    if value.split('.')[0].upper() in {'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}:
        raise ToolkitError('Reserved Windows directory identifier')
    return value

def safe_payload_component(value):
    """Validate an inert repository component, not a managed identifier.

    Retain the ASCII filename alphabet and leading-dot handling; additionally
    accept leading underscores used by Python packages. Do not use this for
    catalog IDs, categories, revisions or registry identifiers.
    """
    if not isinstance(value,str) or not re.fullmatch(r'\.*[A-Za-z0-9_][A-Za-z0-9_.-]*',value) or value.endswith('.'):
        raise ToolkitError('Unsafe repository path component: '+str(value))
    if value.lstrip('.').split('.')[0].upper() in {'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}:
        raise ToolkitError('Reserved Windows repository path component')
    return value

def safe_path(root, name):
    # Inspect the raw spelling before PurePosixPath can collapse dot/empty parts.
    if not isinstance(name,str) or not name or '\\' in name or ':' in name:
        raise ToolkitError('Unsafe repository path')
    parts=name.split('/')
    if any(p in ('','.','..') for p in parts):
        raise ToolkitError('Unsafe repository path')
    for p in parts:
        safe_payload_component(p)
    result=root.joinpath(*parts)
    from .volume import trusted_parent
    if any(p.is_symlink() and not trusted_parent(p,root) for p in [root,result,*result.parents]): raise ToolkitError('Symlinks are not supported in managed payload paths')
    if not result.resolve().is_relative_to(root.resolve()): raise ToolkitError('Path escapes root')
    return result

def load_catalog(path):
    data=read(path)
    if data.get('schema_version')!=1: raise ToolkitError('Unsupported catalog schema')
    seen=set()
    for e in data['models']:
        for k in ('id','category'): safe_name(e[k])
        if e['id'] in seen: raise ToolkitError('Duplicate model variant ID')
        seen.add(e['id'])
        if e.get('adapter') not in ('huggingface','github'): raise ToolkitError('Unsupported adapter')
        if e['adapter']=='github':
            from .github import validate
            validate(e)
        if not re.fullmatch(r'[\w.-]+/[\w.-]+',e['repository']): raise ToolkitError('Invalid repository identifier')
        if not isinstance(e['include'],list) or not e['include']: raise ToolkitError('include patterns required')
        if any(p not in data['profiles'] for p in e['profiles']): raise ToolkitError('Unknown profile')
        for k in ('display_name','publisher','source_kind','format','revision','required'): 
            if k not in e: raise ToolkitError('Missing catalog field '+k)
    # Optional explicit memberships keep existing variant metadata unchanged.
    memberships = data.get('profile_members', {})
    if not isinstance(memberships, dict):
        raise ToolkitError('profile_members must be an object')
    for profile, members in memberships.items():
        if profile not in data['profiles'] or profile == 'all':
            raise ToolkitError('Invalid explicit profile membership')
        if not isinstance(members, list) or any(not isinstance(m, str) or m not in seen for m in members):
            raise ToolkitError('Unknown model in explicit profile membership')
    from .dependencies import expand
    expand(data, data['models'])  # validate explicit dependencies, without acquisition
    return data

def select(catalog, profile=None, ids=None):
    from .dependencies import expand
    if ids:
        wanted=set(ids); found=[e for e in catalog['models'] if e['id'] in wanted]
        if wanted-{e['id'] for e in found}: raise ToolkitError('Unknown model ID(s)')
        return expand(catalog, found)
    if profile=='all': return expand(catalog, catalog['models'])
    if profile not in catalog['profiles']: raise ToolkitError('Choose a valid profile or --model ID')
    explicit = catalog.get('profile_members', {}).get(profile, [])
    return expand(catalog, [e for e in catalog['models'] if profile in e['profiles'] or e['id'] in explicit])

def human(n):
    for u in ('B','MB','GB','TB'):
        divisor={'B':1,'MB':10**6,'GB':10**9,'TB':10**12}[u]
        if n<divisor*1000 or u=='TB':return f'{n/divisor:,.2f} {u}'

def hashes(path):
    size=path.stat().st_size
    sha=hashlib.sha256(); git=hashlib.sha1(f'blob {size}\0'.encode())
    with path.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):sha.update(block); git.update(block)
    return sha.hexdigest(),git.hexdigest()

def inspect_file(path, expected, previous=None):
    if not path.is_file() or path.stat().st_size!=expected['size']:return None
    sha,git=hashes(path)
    upstream=expected.get('sha256'); blob=expected.get('git_blob_sha1')
    if upstream and sha!=upstream:return None
    if blob and git!=blob:return None
    if previous and sha!=previous['sha256']:return None
    return {'size':path.stat().st_size,'mtime_ns':path.stat().st_mtime_ns,'sha256':sha,
            'integrity':'upstream-sha256' if upstream else 'upstream-git-blob-sha1' if blob else 'local-sha256', 'verified_at':now()}

def plan(entry,root,adapter):
    meta=adapter.resolve(entry)
    rev=meta['revision']
    if not re.fullmatch('[a-fA-F0-9]{40,64}',rev):raise ToolkitError('Upstream did not return a full commit hash')
    files=[f for f in meta['files'] if any(fnmatch(f['path'],p) for p in entry['include']) and not any(fnmatch(f['path'],p) for p in entry.get('exclude',[]))]
    if not files:raise ToolkitError('No files matched selection for '+entry['id'])
    for pattern in entry['required']:
        if not any(fnmatch(f['path'],pattern) for f in files):raise ToolkitError('Required file pattern missing: '+pattern)
    target=safe_path(root,f"{entry['category']}/{entry['id']}/{rev}")
    for f in files:
        safe_path(target/'payload',f['path'])
        if not isinstance(f.get('size'),int) or f['size']<0:raise ToolkitError('Unknown file size; refusing unbounded download')
    # Count only recognized, completed files as reusable; partial chunks not deducted.
    manifest=target/'manifest.json'; old=read(manifest) if manifest.exists() else {}
    reusable=0
    for f in files:
        p=target/'payload'/f['path']; record=old.get('files',{}).get(f['path'])
        if record and p.is_file() and p.stat().st_size==record['size'] and p.stat().st_mtime_ns==record['mtime_ns']:reusable+=f['size']
    return {'entry':entry,'revision':rev,'target':str(target),'files':files,'repository_metadata':meta['metadata'],
            'total_bytes':sum(f['size'] for f in files),'estimated_new_bytes':sum(f['size'] for f in files)-reusable,'gated':meta.get('gated',False)}

def space(root,needed):
    ancestor=root
    while not ancestor.exists():ancestor=ancestor.parent
    free=shutil.disk_usage(ancestor).free
    return free, int(needed*1.10)+1024**3

def event(root, **fields):
    from .volume import checkpoint
    checkpoint()
    path=root/'_toolkit'/'logs'/'events.jsonl';path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8') as f:f.write(json.dumps({'timestamp':now(),**fields})+'\n')

def friendly(exc):
    # Never persist exception text, URLs, headers, or tokens from network libraries.
    name=type(exc).__name__
    if name in ('GatedRepoError','RepositoryNotFoundError','HfHubHTTPError'):
        return name+': check repository access; accept required terms on its Hugging Face page and run hf auth login.'
    return name+': operation failed; check network, disk space, permissions, and catalog. Rerun to resume.'

def acquire(p,root,adapter,repair=False,retries=3):
    from .volume import checkpoint
    checkpoint()
    target=Path(p['target']);target.mkdir(parents=True,exist_ok=True)
    manifest=target/'manifest.json'; previous=read(manifest) if manifest.exists() else {}
    if previous and (previous['entry']['repository']!=p['entry']['repository'] or previous['revision']!=p['revision']):raise ToolkitError('Existing provenance conflict')
    if previous and previous.get('expected')!=p['files']:raise ToolkitError('Selection changed at this revision. Give the variant a new catalog ID.')
    state=previous or {'schema_version':1,'entry':p['entry'],'revision':p['revision'],'created_at':now(),'expected':p['files'],'files':{}}
    state.update(status='downloading',updated_at=now())
    write(manifest,state);write(target/'repository.json',p['repository_metadata'])
    log={'model':p['entry']['id'],'variant':p['entry'].get('quantization'),'source':p['entry']['repository'],'revision':p['revision']}
    event(root,**log,event='start')
    try:
        for index,f in enumerate(p['files'],1):
            dest=safe_path(target/'payload',f['path']);rec=state['files'].get(f['path'])
            print(f"  [{index}/{len(p['files'])}] {f['path']} ({human(f['size'])})",flush=True)
            good=inspect_file(dest,f,rec) if dest.exists() else None
            if good and (rec or f.get('sha256') or f.get('git_blob_sha1')):
                state['files'][f['path']]=good;write(manifest,state);continue
            if dest.exists():
                if not repair:raise ToolkitError('Existing file failed verification: '+f['path']+'. Use --repair to preserve it in quarantine and download a replacement.')
                backup=safe_path(target/'quarantine'/uuid.uuid4().hex,f['path']);backup.parent.mkdir(parents=True,exist_ok=True)
                os.replace(dest,backup);event(root,**log,event='quarantined',file=f['path'])
            for attempt in range(1,retries+1):
                event(root,**log,event='attempt',file=f['path'],attempt=attempt)
                try:
                    checkpoint()
                    adapter.download(p['entry'],p['revision'],f['path'],target/'payload',force=repair)
                    checkpoint()
                    good=inspect_file(dest,f)
                    if not good:raise ToolkitError('Downloaded file failed upstream size/hash verification')
                    break
                except KeyboardInterrupt:raise
                except Exception as exc:
                    event(root,**log,event='retry_error',file=f['path'],attempt=attempt,error=friendly(exc))
                    # Preserve a completed-but-invalid file; do not silently overwrite it.
                    if dest.exists():
                        backup=safe_path(target/'quarantine'/uuid.uuid4().hex,f['path']);backup.parent.mkdir(parents=True,exist_ok=True);os.replace(dest,backup)
                    if attempt==retries or type(exc).__name__ in ('GatedRepoError','RepositoryNotFoundError','RevisionNotFoundError','EntryNotFoundError'):raise
                    time.sleep(min(2**attempt,8))
            state['files'][f['path']]=good;write(manifest,state)
            event(root,**log,event='file_verified',file=f['path'],completed_file_bytes=f['size'],wire_bytes=None,integrity=good['integrity'])
        checkpoint()
        check_indexes(target, state)
        state.update(status='verified',updated_at=now(),verified_at=now());write(manifest,state)
        event(root,**log,event='end',status='verified')
    except BaseException as exc:
        checkpoint()  # Never write failure metadata onto unavailable/replaced storage.
        state.update(status='partial' if isinstance(exc,KeyboardInterrupt) else 'failed',updated_at=now(),error=str(exc) if isinstance(exc,ToolkitError) else friendly(exc))
        write(manifest,state);event(root,**log,event='end',status=state['status'],error=state['error']);raise

def check_indexes(target,state):
    for f in state['expected']:
        if f['path'].endswith('.index.json'):
            idx=read(safe_path(target/'payload',f['path']))
            for shard in set(idx.get('weight_map',{}).values()):
                name=(PurePosixPath(f['path']).parent/shard).as_posix()
                if name not in state['files']:raise ToolkitError('Index references missing shard: '+name)

def inventory(root,catalog,verify=False,adapter=None):
    rows=[]
    # Discover all recorded revisions, including entries removed from the catalog.
    known={e['id']:e for e in catalog['models']};seen=set()
    for manifest in sorted(root.glob('*/*/*/manifest.json')):
        if manifest.is_symlink():raise ToolkitError('Symlink manifest not supported')
        s=read(manifest);e=s['entry'];seen.add(e['id']);status=s['status'];problems=[]
        for f in s['expected']:
            path=safe_path(manifest.parent/'payload',f['path']);rec=s['files'].get(f['path'])
            if verify:
                check=inspect_file(path,f,rec) if rec else None
                if not check:problems.append(f['path'])
                else:s['files'][f['path']]=check
            elif not rec or not path.is_file() or path.stat().st_size!=rec['size'] or path.stat().st_mtime_ns!=rec['mtime_ns']:problems.append(f['path'])
        if verify and not problems:
            try:check_indexes(manifest.parent,s)
            except (ToolkitError,ValueError,TypeError):problems.append('index consistency check failed')
        if problems:status='failed' if verify else 'partial'
        elif verify:status='verified'
        if verify:
            s.update(status=status,last_audit_at=now(),audit_problems=problems);write(manifest,s)
        row={'id':e['id'],'repository':e['repository'],'local_revision':s['revision'],'status':status,'path':str(manifest.parent),'problems':problems,'evidence':'full hash audit' if verify else 'recorded status + size/mtime check'}
        if adapter:
            try:
                upstream=adapter.resolve({**e,'revision':'main'})['revision'];row.update(upstream_revision=upstream,update_available=upstream!=s['revision'])
            except Exception as exc:row['update_check_error']=friendly(exc)
        rows.append(row)
    rows.extend({'id':i,'status':'not downloaded','repository':e['repository'],'configured':True} for i,e in known.items() if i not in seen)
    return {'generated_at':now(),'root':str(root),'models':rows}

def report(root,data):
    from .volume import checkpoint, public_data
    checkpoint(); data=public_data(data)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:6]
    out=root/'_toolkit'/'reports'/stamp
    write(out.with_suffix('.json'),data)
    lines=['Offline Model Acquisition Toolkit — collection report',data['generated_at'],'Root: '+public_data(str(root)),'']
    for r in data['models']:lines.append(f"{r['id']}: {r['status']} | revision={r.get('local_revision','—')} | update={r.get('update_available','not checked')}")
    out.with_suffix('.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines));return out
