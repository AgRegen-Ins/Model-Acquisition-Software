"""Configurable pre-write mount protection; no subprocess or Linux-only dependency."""
import os, sys, re
from pathlib import Path
from .core import ToolkitError, read

def expected_mount(root, settings, override=None):
    from .volume import active_session
    session=active_session()
    if session is not None:return session.mount
    if override is not None:return Path(override).expanduser().absolute()
    if not settings.exists():raise ToolkitError('Settings file missing: '+str(settings))
    rules=read(settings).get('mount_guards',[])
    matches=[]
    for rule in rules:
        if rule.get('platform','any') not in ('any',os.name):continue
        prefix=Path(rule['root']).expanduser()
        mount=Path(rule['expected_mount']).expanduser()
        if not prefix.is_absolute() or not mount.is_absolute():raise ToolkitError('Mount guard settings require absolute paths')
        if root.is_relative_to(prefix):matches.append((len(prefix.parts),mount))
    return max(matches,key=lambda x:x[0])[1] if matches else None

def is_mounted(path):
    if not path.is_dir():return False
    if os.path.ismount(path):return True  # Includes Windows drive roots and UNC shares.
    if sys.platform.startswith('linux'):
        # Linux bind mounts may share st_dev with their parent; consult mountinfo too.
        try:
            for line in Path('/proc/self/mountinfo').read_text().splitlines():
                fields=line.split()
                if len(fields)>4:
                    point=re.sub(r'\\([0-7]{3})',lambda m:chr(int(m[1],8)),fields[4])
                    if Path(point)==path:return True
        except OSError:pass
    return False

def require_mount(root,mount):
    from .volume import active_session
    session=active_session()
    if session is not None:
        session.check();return
    if mount is None:return
    root=Path(os.path.abspath(root));mount=Path(os.path.abspath(mount))
    if not root.is_relative_to(mount):raise ToolkitError(f'Model root {root} is not beneath expected mount {mount}. Correct --expected-mount or settings.json.')
    if any(p.is_symlink() for p in [mount,*mount.parents]):raise ToolkitError('Expected mount must use its real path, not a symlink')
    if not is_mounted(mount):
        raise ToolkitError(f'Refusing model writes: expected storage mount {mount} is not mounted. Mount the intended storage drive there, then rerun. Model root: {root}. No fallback to the internal/root filesystem is allowed.')
