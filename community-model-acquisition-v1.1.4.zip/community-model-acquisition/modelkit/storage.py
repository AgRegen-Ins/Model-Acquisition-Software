"""Read-only storage inventory plus explicit current-report writeback.
No weight reads, deletion, network access, or manifest changes are performed.
"""
import csv, io, json, os, stat, uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from .core import now, read, human, safe_path, ToolkitError
from .recovery_directory import filesystem_recovery_directory

FIELDS=['display_name','id','category','description','repository','publisher','source_kind','format','quantization','local_revision','acquisition_date','age_days','status','recorded_status','revision_role','configured','catalog_revision','catalog_revision_match','disk_bytes','logical_bytes','quarantine_bytes','recoverable_bytes','path','warnings']

def timestamp(value):
    try:
        dt=datetime.fromisoformat(value)
        if dt.tzinfo is None:dt=dt.replace(tzinfo=timezone.utc)
        return dt.timestamp()
    except (TypeError,ValueError):return None

def scan(root,catalog):
    root=Path(root); warnings=[]; rows={}; files={}; category_keys=defaultdict(set); exclusions=[]
    known={e['id']:e for e in catalog['models']}
    from .volume import trusted_anchor
    if root.is_symlink() and not trusted_anchor(root):raise ValueError('Inventory root cannot be a symlink')
    if not root.exists():warnings.append('Model root does not exist; no local files found.')
    def error(exc):warnings.append('Cannot fully scan: '+str(exc.filename))
    # One traversal includes incomplete/cache files, quarantine, and malformed revisions.
    for directory,dirs,names in os.walk(root,followlinks=False,onerror=error):
        base=Path(directory)
        if base==root and 'lost+found' in dirs:
            recovery=filesystem_recovery_directory(root)
            if recovery is not None:
                dirs.remove('lost+found');exclusions.append(recovery)
        warnings.extend('Skipped symlink directory: '+str(base/d) for d in dirs if (base/d).is_symlink())
        dirs[:]=sorted(d for d in dirs if not (base/d).is_symlink() and not(base==root and d=='_toolkit'))
        parts=base.relative_to(root).parts
        if len(parts)==3:rows[parts]={'_keys':set(),'_quarantine':set(),'_valid':False,'warnings':[]}
        for name in names:
            path=base/name;rel=path.relative_to(root).parts
            try:
                s=path.lstat()
                if not stat.S_ISREG(s.st_mode):
                    warnings.append('Skipped non-regular file: '+str(path));continue
            except OSError:error(type('ScanError',(),{'filename':str(path)})());continue
            key=(s.st_dev,s.st_ino) if s.st_ino else ('path',str(path))
            disk=s.st_blocks*512 if hasattr(s,'st_blocks') else s.st_size
            files.setdefault(key,{'disk':disk,'logical':s.st_size,'links':s.st_nlink,'paths':[]})['paths'].append(rel)
            category_keys[rel[0] if len(rel)>=4 else '_unclassified'].add(key)
            if len(rel)>=4:
                row=rows.setdefault(rel[:3],{'_keys':set(),'_quarantine':set(),'_valid':False,'warnings':[]})
                row['_keys'].add(key)
                if rel[3]=='quarantine':row['_quarantine'].add(key)
    def total(keys,field='disk'):return sum(files[k][field] for k in keys)
    for parts,row in rows.items():
        folder=root.joinpath(*parts);manifest=folder/'manifest.json';s={};e={}
        try:
            if manifest.is_symlink():raise ValueError('symlink manifest')
            s=read(manifest);e=s['entry']
            if not isinstance(e,dict) or not isinstance(s['expected'],list) or not isinstance(s['files'],dict) or s.get('schema_version')!=1:raise ValueError('invalid manifest')
            if e['id']!=parts[1] or e['category']!=parts[0] or s['revision']!=parts[2]:raise ValueError('manifest/path conflict')
            row['_valid']=True
        except (OSError,ValueError,KeyError,TypeError):
            row['warnings'].append('Missing, unreadable, or invalid manifest; preserved as unclassified revision.');s={};e={}
        configured=known.get(parts[1]);date=s.get('created_at');ts=timestamp(date)
        status=s.get('status','unknown');problems=[]
        if not row['_valid'] and any(path[-1].endswith('.incomplete') for k in row['_keys'] for path in files[k]['paths']):status='partial'
        if row['_valid']:
            for f in s['expected']:
                try:
                    p=safe_path(folder/'payload',f['path']);record=s['files'].get(f['path']);st=p.stat()
                    if not record or st.st_size!=record['size'] or st.st_mtime_ns!=record['mtime_ns']:problems.append(f['path'])
                except (OSError,ValueError,KeyError,TypeError,ToolkitError):
                    # Metadata-only scan: malformed paths are reported, never followed.
                    problems.append(f.get('path','invalid expected file') if isinstance(f,dict) else 'invalid expected file')
            if problems and status!='failed':status='partial'
        row.update(display_name=e.get('display_name',parts[1]),id=parts[1],category=parts[0],description=e.get('description') or e.get('intended_role') or e.get('notes'),repository=e.get('repository'),publisher=e.get('publisher'),source_kind=e.get('source_kind'),format=e.get('format'),quantization=e.get('quantization'),local_revision=parts[2],acquisition_date=date,age_days=round(max(0,(datetime.now(timezone.utc).timestamp()-ts)/86400),2) if ts is not None else None,status=status,recorded_status=s.get('status','unknown'),revision_role='unknown',configured=bool(configured),catalog_revision=configured.get('revision') if configured else None,catalog_revision_match=bool(configured and configured.get('revision')==parts[2]),disk_bytes=total(row['_keys']),logical_bytes=total(row['_keys'],'logical'),quarantine_bytes=total(row['_quarantine']),recoverable_bytes=0,path=str(folder),_timestamp=ts)
        if problems:row['warnings'].append('Missing/changed files: '+', '.join(problems))
    groups=defaultdict(list)
    for r in rows.values():groups[(r['category'],r['id'],r['repository'])].append(r)
    for group in groups.values():
        usable=[r for r in group if r['_valid'] and r['status']=='verified' and r['_timestamp'] is not None]
        current=max(usable,key=lambda r:(r['_timestamp'],r['catalog_revision_match'],r['local_revision'])) if usable else None
        for r in group:
            if r is current:r['revision_role']='current'
            elif current and r['_valid'] and r['_timestamp'] is not None and r['_timestamp']<current['_timestamp']:r['revision_role']='superseded'
            elif r['_valid']:r['revision_role']='pending' if r['status'] in ('partial','failed','downloading') else 'undetermined'
    def keys_for(predicate):return set().union(*(r['_keys'] for r in rows.values() if predicate(r))) if rows else set()
    all_keys=set(files);assigned=keys_for(lambda r:True)
    current=keys_for(lambda r:r['revision_role']=='current');superseded=keys_for(lambda r:r['revision_role']=='superseded')
    partial=keys_for(lambda r:r['status'] in ('partial','failed','downloading'))
    quarantine=set().union(*(r['_quarantine'] for r in rows.values())) if rows else set()
    # Conservative estimate: exclude every hard-linked file, even within superseded data.
    recoverable={k for k in superseded if files[k]['links']==1}
    for r in rows.values():r['recoverable_bytes']=total(r['_keys']&recoverable) if r['revision_role']=='superseded' else 0
    summary={'revision_count':len(rows),'total_model_storage_bytes':total(all_keys),'total_logical_bytes':total(all_keys,'logical'),'by_category_bytes':{c:total(keys) for c,keys in sorted(category_keys.items())},'current_revision_bytes':total(current),'superseded_revision_bytes':total(superseded),'partial_failed_bytes':total(partial),'quarantine_bytes':total(quarantine),'potential_recoverable_bytes':total(recoverable),'unclassified_bytes':total(all_keys-assigned),'measurement':'allocated regular-file bytes when st_blocks is available; logical file size fallback otherwise; hard links deduplicated','scan_complete':not warnings}
    clean=[{k:v for k,v in r.items() if not k.startswith('_')} for r in rows.values()]
    return {'schema_version':1,'generated_at':now(),'root':str(root),'summary':summary,'warnings':warnings,'excluded_filesystem_entries':exclusions,'models':clean,'notes':['Current = newest locally acquired verified revision by creation date, not upstream commit chronology. Equal/unknown dates remain undetermined.','Catalog pin shown separately; entries absent from catalog remain inventoried.','Totals exclude _toolkit metadata; include payload cache, revision metadata, unknown files and quarantine.','Quarantine and partial/failed totals overlap revision totals; do not add them together. Shared hard links can overlap category/revision subtotals.','Recoverable space is an estimate, excluding hard links; snapshots, deduplication and filesystem overhead can affect actual freed space. No deletion is performed.','Inventory checks metadata only; use --verify for a full hash audit.']}

def view(data,sort='name',superseded=False):
    rows=[r for r in data['models'] if not superseded or r['revision_role']=='superseded']
    groups=defaultdict(list)
    for r in rows:groups[(r['category'],r['id'],r['repository'] or '')].append(r)
    order=sorted(groups,key=lambda g:(-sum(r['disk_bytes'] for r in groups[g]),g) if sort=='size' else g)
    ordered=[]
    for g in order:ordered.extend(sorted(groups[g],key=lambda r:(-r['disk_bytes'],r['local_revision']) if sort=='size' else (r['acquisition_date'] or '',r['local_revision']),reverse=False))
    return {**data,'models':ordered,'view':{'sort':sort,'superseded_only':superseded,'summary_scope':'entire collection'}}

def render(data,format='text'):
    from .volume import public_data
    data=public_data(data)
    if format=='json':return json.dumps(data,indent=2,ensure_ascii=False)+'\n'
    if format=='csv':
        out=io.StringIO(newline='');writer=csv.DictWriter(out,fieldnames=FIELDS,extrasaction='ignore');writer.writeheader()
        for row in data['models']:writer.writerow({**row,'warnings':'; '.join(row['warnings'])})
        return out.getvalue()
    s=data['summary'];lines=['Community Model Acquisition Toolkit — storage inventory',f"Root: {data['root']}",f"Generated: {data['generated_at']}",f"Total: {human(s['total_model_storage_bytes'])} | Current: {human(s['current_revision_bytes'])} | Superseded: {human(s['superseded_revision_bytes'])}",f"Partial/failed: {human(s['partial_failed_bytes'])} | Quarantine: {human(s['quarantine_bytes'])} | Potential recoverable: {human(s['potential_recoverable_bytes'])}",'Categories: '+', '.join(f'{c}={human(b)}' for c,b in s['by_category_bytes'].items()),'Summary covers the entire collection; overlapping totals must not be added.','']
    previous=None
    for r in data['models']:
        group=(r['category'],r['id'],r['repository'])
        if group!=previous:lines.extend([f"{r['category']} / {r['id']} — {r['display_name']}",f"  {r['description'] or 'Purpose unknown'} | {r['repository'] or 'Repository unknown'} | publisher={r['publisher']} | {r['source_kind']}"]);previous=group
        lines.extend([f"  {r['local_revision']} | {r['revision_role']} | {r['status']} | {human(r['disk_bytes'])} | quarantine={human(r['quarantine_bytes'])}",f"    {r['format']} {r['quantization']} | acquired={r['acquisition_date']} | age={r['age_days']} days | catalog pin match={r['catalog_revision_match']}",f"    {r['path']}"])
        lines.extend('    WARNING: '+w for w in r['warnings'])
    if not data['models']:lines.append('No matching local revisions.')
    lines.extend('EXCLUDED: '+e['path']+' — '+e['reason'] for e in data.get('excluded_filesystem_entries',[]))
    lines.extend('WARNING: '+w for w in data['warnings']);lines.extend(data['notes'])
    return '\n'.join(lines)+'\n'

def refresh(root,catalog):
    data=view(scan(root,catalog));out=root/'_toolkit'/'inventory';out.mkdir(parents=True,exist_ok=True)
    # Atomic per-file replacement; common generated_at ties the three files together.
    for fmt,suffix in [('text','txt'),('csv','csv'),('json','json')]:
        path=out/('current-inventory.'+suffix);tmp=out/(path.name+'.'+uuid.uuid4().hex+'.tmp')
        with tmp.open('w',encoding='utf-8',newline='') as f:f.write(render(data,fmt));f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    return data
