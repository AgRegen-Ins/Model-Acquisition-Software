"""Conservative recognition of the conventional ext4 filesystem recovery directory.

This is not a name-based ignore list. Nonstandard/recreated recovery directories
remain subject to normal scanning and errors. No directory contents are read,
changed or declared verified by this check.
"""
import os
import stat
import sys
from pathlib import Path
from . import volume
from .core import ToolkitError


def _entry_stats(root, physical, root_fd):
    parent = os.fstat(root_fd) if root_fd is not None else root.stat()
    visible = physical.stat()
    entry = (os.stat('lost+found', dir_fd=root_fd, follow_symlinks=False)
             if root_fd is not None else (root / 'lost+found').lstat())
    return parent, visible, entry


def filesystem_recovery_directory(root, root_fd=None):
    """Return an auditable exclusion only for the conventional root lost+found.

    Require Linux mountinfo, an ext4 volume root (inode 2), same-device inode 11,
    root ownership and private directory permissions. Bind subdirectories,
    nested mounts, symlinks, other filesystems and uncertain probes never qualify.
    root_fd lets the comparison scanner use its already-pinned descriptor.
    """
    if not sys.platform.startswith('linux'):
        return None
    root = Path(root)
    session = volume.active_session()
    physical = session.original if session is not None and root == session.root else root.absolute()
    try:
        if session is not None and root == session.root:
            session.check()
        if any(p.is_symlink() for p in (physical, *physical.parents)):
            return None
        records = volume.mount_records()
        matches = [r for r in records if r['mount'] == physical]
        if len(matches) != 1:
            return None
        record = matches[0]
        if record['fstype'] != 'ext4' or record['fsroot'] != '/':
            return None
        child = physical / 'lost+found'
        if any(r['mount'] == child or r['mount'].is_relative_to(child) for r in records):
            return None
        parent, visible, entry = _entry_stats(root, physical, root_fd)
        if (parent.st_dev, parent.st_ino) != (visible.st_dev, visible.st_ino):
            return None
        if parent.st_ino != 2 or not stat.S_ISDIR(parent.st_mode):
            return None
        if record['device'] != f'{os.major(parent.st_dev)}:{os.minor(parent.st_dev)}':
            return None
        if not (stat.S_ISDIR(entry.st_mode) and entry.st_dev == parent.st_dev
                and entry.st_ino == 11 and entry.st_uid == 0 and entry.st_gid == 0
                and stat.S_IMODE(entry.st_mode) & 0o7077 == 0):
            return None
        if volume.mount_records() != records:
            return None
        return {'path': 'lost+found', 'reason': 'Standard ext4 filesystem recovery directory',
                'filesystem': 'ext4', 'inode': 11,
                'scope': 'Excluded from model archive scan; recovery contents are not inspected or verified.'}
    except (OSError, ToolkitError):
        # Uncertainty is not permission to exclude. The scanner retains its
        # normal permission/error handling for this entry.
        return None
