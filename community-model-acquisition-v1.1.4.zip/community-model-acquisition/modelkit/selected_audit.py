"""Explicit pinned-variant audit; never enumerates unrelated archive revisions."""
from pathlib import Path
from .core import ToolkitError,read,safe_path,inspect_file,check_indexes,write,now
from .volume import checkpoint

def verify_selected(root,entries):
    rows=[]
    for entry in entries:
        checkpoint()
        target=safe_path(Path(root),entry['category']+'/'+entry['id']+'/'+entry['revision'])
        manifest=target/'manifest.json'
        if manifest.is_symlink():raise ToolkitError('Symlink manifest refused')
        if not manifest.exists():
            rows.append({'id':entry['id'],'status':'not downloaded','repository':entry['repository']});continue
        state=read(manifest)
        if state.get('revision')!=entry['revision'] or state.get('entry',{}).get('repository')!=entry['repository'] or state.get('entry',{}).get('id')!=entry['id']:raise ToolkitError('Selected manifest identity mismatch')
        expected=state.get('expected',[])
        if entry.get('pinned_files'):
            pinned=[{k:f.get(k) for k in ('path','size','sha256','git_blob_sha1')} for f in entry['pinned_files']]
            if expected!=pinned:raise ToolkitError('Selected manifest differs from reviewed file inventory')
        if not expected:raise ToolkitError('Empty selected manifest refused')
        problems=[]
        for f in expected:
            checkpoint();record=state.get('files',{}).get(f['path'])
            good=inspect_file(safe_path(target/'payload',f['path']),f,record) if record else None
            if good:state['files'][f['path']]=good
            else:problems.append(f['path'])
        if not problems:
            try:check_indexes(target,state)
            except (ToolkitError,ValueError,TypeError):problems.append('index consistency check failed')
        state.update(status='failed' if problems else 'verified',last_audit_at=now(),audit_problems=problems)
        write(manifest,state)
        rows.append({'id':entry['id'],'repository':entry['repository'],'local_revision':entry['revision'],'status':state['status'],'problems':problems,'path':str(target),'evidence':'selected full hash audit'})
    return {'generated_at':now(),'root':str(root),'models':rows,'scope':'selected pinned variants only; no whole-archive scan'}
