"""Read-only archive accountability, migration diagnostics and capacity snapshot."""
import json,shutil
from pathlib import Path
from . import accountability
from .core import read,ToolkitError
from .volume import rule_for,identify,validate_location,RESERVE_BYTES
from .workbook import xlsx
FIELDS=['id','family','category','status','verification','catalog_inclusion','format','precision','source_kind','repository','pinned_revision','expected_file_count','recorded_file_count','storage_bytes','catalog_estimated_bytes','archive_relative_location','primary_storage_root','last_verification_time','last_successful_acquisition_or_verification','location_kind','instance_id','path_review','display_name','capabilities','variant_role','mandatory_dependencies','dependency_status','publisher','license','hardware_notes','runtime_notes']

def collect(root,catalog,policy,settings):
    data=accountability.collect(root,catalog,policy);known={e['id'] for e in catalog['models']}
    entries={e['id']:e for e in catalog['models']}
    for row in data['models']:
        entry=entries.get(row['id'],{})
        row.update(mandatory_dependencies=entry.get('dependencies',[]),publisher=entry.get('publisher'),license=entry.get('license'),hardware_notes=entry.get('hardware_notes'),runtime_notes=entry.get('runtime_notes'))
        row.update(catalog_inclusion=row['id'] in known,primary_storage_root=str(root),archive_relative_location='',expected_file_count=None,recorded_file_count=None,path_review='',last_successful_acquisition_or_verification=None)
        row['catalog_estimated_bytes']=next((e.get('estimated_bytes') for e in catalog['models'] if e['id']==row['id']),None)
        if row['observation']=='catalog-only':row['storage_bytes']=0
        if row['location_kind']=='canonical-archive' and row['instance_id'].startswith('managed:'):
            path=Path(row['local_paths'][0]);row['archive_relative_location']=str(path.relative_to(root))
            try:
                manifest=read(path/'manifest.json');row['last_successful_acquisition_or_verification']=(manifest.get('last_audit_at') if manifest.get('status')=='verified' and not manifest.get('audit_problems') else None) or manifest.get('verified_at');row['expected_file_count']=len(manifest['expected']);row['recorded_file_count']=len(manifest['files'])
            except (OSError,ValueError,KeyError,TypeError):row['path_review']='Manifest unavailable or malformed'
        elif row.get('local_paths'):
            row['path_review']='External custody paths preserved; review separately after migration: '+json.dumps(row['local_paths'])
    capacity={'root':str(root),'identity':'unconfirmed','total_bytes':None,'used_bytes':None,'available_bytes':None,'base_reserve_bytes':RESERVE_BYTES,'download_reserve_formula':'int(remaining_new_bytes * 1.10) + 1073741824','migration_checksum_validation':'Not established by this report; independent source/destination comparison required'}
    try:
        rule=rule_for(root,settings,writing=False);identify(Path(rule['expected_mount']),rule['expected_uuid'],rule.get('filesystem'),writable=False);validate_location(root,Path(rule['expected_mount']));usage=shutil.disk_usage(root)
        capacity.update(identity='expected UUID observed (read-only snapshot)',expected_uuid=rule['expected_uuid'],total_bytes=usage.total,used_bytes=usage.used,available_bytes=usage.free)
    except (ToolkitError,OSError) as exc:capacity['diagnostic']=str(exc)
    capacity['managed_model_storage_bytes']=data['managed_storage_summary']['total_model_storage_bytes']
    capacity['managed_partial_failed_bytes']=data['managed_storage_summary']['partial_failed_bytes']
    capacity['managed_quarantine_bytes']=data['managed_storage_summary']['quarantine_bytes']
    data['capacity']=capacity
    data['notes']=['Metadata snapshot, not a fresh full-payload hash audit. Missing or changed size/mtime is incomplete, not verified.','Catalog estimates are not stored bytes. External/remote custody does not count as a second authoritative archive.','Legacy manifests stay byte-for-byte unchanged during this report. Absolute external paths are reported, never rewritten.','Capacity is shown only when the configured filesystem identity is confirmed. Migration verification remains an operator gate.']
    return data

def workbook(data):
    return xlsx([('Models',[[f.replace('_',' ').title() for f in FIELDS]]+[[r.get(f) for f in FIELDS] for r in data['models']]),('Capacity',[['Metric','Value']]+[[k,v] for k,v in data['capacity'].items()]),('Read me',[['Scope','Detail'],['Archive',data['root']],['Generated',data['generated_at']]]+[['Note',v] for v in data['notes']])])
