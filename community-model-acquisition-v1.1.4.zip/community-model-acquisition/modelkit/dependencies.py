"""Explicit required model components only; preservation policies never select files."""
from .core import ToolkitError

def expand(catalog, entries):
    known={e['id']:e for e in catalog['models']};ordered=[];done=set();active=set()
    def visit(entry):
        key=entry['id']
        if key in active:raise ToolkitError('Cyclic model dependencies: '+key)
        if key in done:return
        active.add(key)
        deps=entry.get('dependencies',[])
        if not isinstance(deps,list) or any(not isinstance(d,str) or d not in known for d in deps):
            raise ToolkitError('Invalid required component for '+key)
        for dep in deps:visit(known[dep])
        active.remove(key);done.add(key);ordered.append(entry)
    for entry in entries:visit(entry)
    return ordered
