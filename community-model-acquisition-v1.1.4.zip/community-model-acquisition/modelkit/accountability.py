"""Unified read-only catalog/managed/external view; legacy storage interfaces unchanged."""
import csv,io,json,platform
from pathlib import Path
from .core import read,now,ToolkitError
from .storage import scan
from .registry import load,current_status
POLICIES={'inference-only','source-and-inference','source-priority','selective'}
FIELDS=['id','instance_id','display_name','family','category','purpose','total_parameters','active_parameters','architecture','architecture_type','precision','format','variant_role','preservation_policy','training_suitability','training_suitability_class','inference_suitability','status','artifact_status','storage_bytes','size_basis','local_paths','repository','pinned_revision','verification','last_verification_time','associated_projects','location_kind','host','observation','acquisition_origin','source_kind','capabilities','dependency_status','quarantine_bytes']

def policies(path):
    if path is None:return {'models':{}}
    d=read(path)
    if d.get('schema_version')!=1 or not isinstance(d.get('models'),dict):raise ToolkitError('Invalid policy metadata')
    for v in d['models'].values():
        if v.get('preservation_policy') not in POLICIES:raise ToolkitError('Unknown preservation policy')
        if not isinstance(v.get('associated_projects',[]),list):raise ToolkitError('associated_projects must be a list')
    return d

def metadata(entry,policy):
    p=policy.get('models',{}).get(entry['id'],{})
    return dict(id=entry['id'],display_name=entry.get('display_name',entry['id']),family=entry.get('family','unknown'),category=entry.get('category','unknown'),purpose=entry.get('description',entry.get('intended_role','unknown')),total_parameters=entry.get('parameter_count'),active_parameters=entry.get('active_parameter_count'),architecture=entry.get('architecture','unknown'),architecture_type=entry.get('architecture_type','unknown'),precision=entry.get('tensor_precision',entry.get('quantization','unknown')),format=entry.get('format','unknown'),variant_role=entry.get('variant_role','unknown'),preservation_policy=p.get('preservation_policy',entry.get('preservation_policy','selective')),training_suitability=entry.get('training_suitability','unknown'),training_suitability_class=p.get('training_suitability_class',entry.get('training_suitability_class','unknown')),inference_suitability=entry.get('runtime_notes','unknown'),repository=entry.get('repository'),pinned_revision=entry.get('revision'),associated_projects=p.get('associated_projects',entry.get('associated_projects',[])),source_kind=entry.get('source_kind','unknown'),capabilities=entry.get('capabilities',[]))

def collect(root,catalog,policy=None):
    root=Path(root);policy=policy or {'models':{}};known={e['id']:e for e in catalog['models']};storage=scan(root,catalog);rows=[];seen=set()
    for r in storage['models']:
        try:m=read(Path(r['path'])/'manifest.json');entry=m['entry']
        except (OSError,ValueError,KeyError):m={};entry=known.get(r['id'],{'id':r['id']})
        entry={**known.get(r['id'],{}),**entry};seen.add(r['id'])
        status={'verified':'downloaded-verified','partial':'incomplete','downloading':'incomplete','failed':'verification-failed'}.get(r['status'],'downloaded-unverified')
        # Distinguish locally hashed managed records from trusted upstream verification.
        trusted=m.get('files') and all(f.get('integrity','').startswith('upstream-') for f in m['files'].values())
        if status=='downloaded-verified' and not trusted:status='downloaded-unverified'
        row={**metadata(entry,policy),'instance_id':'managed:'+r['id']+':'+r['local_revision'],'status':status,'artifact_status':status,'storage_bytes':r['disk_bytes'],'size_basis':'actual allocated managed revision bytes','local_paths':[r['path']],'pinned_revision':r['local_revision'],'verification':'recorded upstream hashes + size/mtime check' if trusted else 'local/unverified provenance','last_verification_time':m.get('last_audit_at',m.get('verified_at')),'location_kind':'canonical-archive','host':platform.node(),'observation':'local-observed','acquisition_origin':m.get('acquisition_origin','toolkit-acquisition'),'quarantine_bytes':r['quarantine_bytes']}
        rows.append(row)
        if r['quarantine_bytes']:rows.append({**row,'instance_id':row['instance_id']+':quarantine','status':'quarantined','artifact_status':'quarantined','storage_bytes':r['quarantine_bytes'],'size_basis':'subset of managed revision; do not add to total','local_paths':[str(Path(r['path'])/'quarantine')]})
    for record in load(root)['instances'].values():
        entry=record.get('entry') or known.get(record['model_id'],{'id':record['model_id']});status,evidence=current_status(record);seen.add(record['model_id']);local=record['observation']=='local-observed' and record['host']==platform.node()
        rows.append({**metadata(entry,policy),'instance_id':record['instance_id'],'inference_suitability':record.get('runtime_requirements','unknown'),'status':status,'artifact_status':status,'storage_bytes':sum(f.get('size',0) for f in record.get('files',{}).values()) if local else None,'size_basis':'last-hashed logical bytes; not a fresh disk measurement' if local else 'remote report; no local size claim','local_paths':list(record['paths'].values()),'repository':record.get('repository'),'pinned_revision':record.get('revision'),'verification':record.get('verification_scope','unknown')+'; '+evidence,'last_verification_time':record.get('last_verification_time'),'associated_projects':sorted(set(record.get('associated_projects',[])+policy.get('models',{}).get(entry['id'],{}).get('associated_projects',[]))),'location_kind':record['location_kind'],'host':record['host'],'observation':record['observation'] if local else 'remote-reported','acquisition_origin':'external-registration','quarantine_bytes':0})
    for e in catalog['models']:
        if e['id'] not in seen:rows.append({**metadata(e,policy),'instance_id':'catalog:'+e['id'],'status':'cataloged-not-downloaded','artifact_status':'cataloged-not-downloaded','storage_bytes':e.get('estimated_bytes'),'size_basis':'catalog estimate; not local storage','local_paths':[],'verification':'not observed','last_verification_time':None,'location_kind':'not-installed','host':None,'observation':'catalog-only','acquisition_origin':'catalog','quarantine_bytes':0})
    for row in rows:
        e=known.get(row['id'],{});deps={}
        for dep in e.get('dependencies',[]):
            pin=known[dep]['revision'];matches=[r for r in rows if r['id']==dep and r['host']==row['host'] and r['observation']=='local-observed' and r['pinned_revision']==pin and r['artifact_status'] in {'downloaded-verified','external-verified'}]
            deps[dep]='verified-local' if matches else 'not-verified-local'
        row['dependency_status']=deps
        if deps and any(v!='verified-local' for v in deps.values()) and row['status'] in {'downloaded-verified','external-verified'}:row['status']='incomplete'
    return {'schema_version':1,'generated_at':now(),'root':str(root),'managed_storage_summary':storage['summary'],'models':rows,'notes':['Read-only accountability view; no full hashes or remote probes.','Managed allocated totals retain legacy accounting. External logical sizes and remote reports are not added to managed totals.','Personal voice recordings and inference runtime installations are outside this registry.','Verified status is as of the recorded audit; fingerprints do not detect every same-size/mtime edit. Run explicit verification for assurance.']}

def render(data,format='text'):
    if format=='json':return json.dumps(data,indent=2,ensure_ascii=False)+'\n'
    if format=='csv':
        out=io.StringIO(newline='');w=csv.DictWriter(out,FIELDS,extrasaction='ignore');w.writeheader()
        for row in data['models']:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in row.items()})
        return out.getvalue()
    lines=['Community Model Accountability — '+data['generated_at']]
    for r in data['models']:
        lines.extend([f"{r['display_name']} [{r['id']}] | {r['status']} | {r['location_kind']} | {r['host'] or 'not installed'}",f"  {r['format']} / {r['precision']} | policy={r['preservation_policy']} | role={r['variant_role']} | total/active={r['total_parameters']}/{r['active_parameters']}",f"  Training: {r['training_suitability_class']} — {r['training_suitability']}",f"  Runtime: {r['inference_suitability']}",f"  {r['repository']} @ {r['pinned_revision']} | {r['storage_bytes']} bytes ({r['size_basis']})",f"  Projects: {', '.join(r['associated_projects'])} | paths={r['local_paths']}",f"  Verification: {r['verification']} | dependencies={r['dependency_status']}"])
    return '\n'.join(lines+data['notes'])+'\n'
