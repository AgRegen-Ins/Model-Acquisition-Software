"""Fail-closed Linux filesystem identity and descriptor-pinned write sessions.

A pinned directory descriptor cannot fall through to the root disk after a lazy
unmount. All CLI archive writes use that descriptor. Identity is rechecked at
Python mutation boundaries and before/after downloads and manifest commits.
No production mount, partition, permission or archive is changed here.
"""
import os, re, stat, sys, threading
from pathlib import Path
from .core import ToolkitError, read

_ACTIVE=None
_HOOK=False
_LOCAL=threading.local()
RESERVE_BYTES=1024**3

def active_session():return _ACTIVE

def checkpoint():
    if _ACTIVE is not None:_ACTIVE.check()

def trusted_anchor(path):
    return _ACTIVE is not None and Path(path)==_ACTIVE.root

def trusted_parent(path,root):
    return _ACTIVE is not None and Path(root).is_relative_to(_ACTIVE.root) and Path(path) in [_ACTIVE.root,*_ACTIVE.root.parents]

def public_data(value):
    if _ACTIVE is None:return value
    if isinstance(value,str):
        anchor=str(_ACTIVE.root)
        if value==anchor or value.startswith(anchor+'/'):return str(_ACTIVE.original)+value[len(anchor):]
        return value
    if isinstance(value,dict):return {k:public_data(v) for k,v in value.items()}
    if isinstance(value,list):return [public_data(v) for v in value]
    return value

def configured_root(root,settings):
    if root is None:root=read(settings).get('default_root')
    if not root:raise ToolkitError('Supply --root or configure default_root in settings.json')
    root=Path(root).expanduser().absolute()
    if root==Path(root.anchor):raise ToolkitError('Use a dedicated model archive, not the filesystem root')
    if any(p.is_symlink() for p in [root,*root.parents]):raise ToolkitError('Archive root must not traverse a symlink')
    return root

def rule_for(root,settings,override=None,writing=True):
    rules=read(settings).get('mount_guards',[])
    matches=[r for r in rules if r.get('platform','any') in ('any',os.name) and root.is_relative_to(Path(r['root']))]
    if not matches:raise ToolkitError('No approved filesystem identity configured for '+str(root)+'. Add an explicit mount_guards rule with expected_mount and expected_uuid; writes refused.')
    rule=max(matches,key=lambda r:len(Path(r['root']).parts))
    mount=Path(rule['expected_mount'])
    if not mount.is_absolute() or not root.is_relative_to(mount):raise ToolkitError('Configured archive must be beneath an absolute expected_mount')
    if override is not None and Path(override).expanduser().absolute()!=mount:raise ToolkitError('--expected-mount cannot override the approved filesystem identity; edit reviewed settings instead')
    if not re.fullmatch(r'[A-Za-z0-9-]+',rule.get('expected_uuid','')):raise ToolkitError('An expected_uuid is mandatory for archive writes')
    if writing and rule.get('read_only'):raise ToolkitError('This archive is configured read-only; original migration source is preserved')
    return rule

def mount_records():
    def unescape(s):return re.sub(r'\\([0-7]{3})',lambda m:chr(int(m[1],8)),s)
    result=[]
    try:
        for line in Path('/proc/self/mountinfo').read_text().splitlines():
            left,right=line.split(' - ',1);a=left.split();b=right.split()
            result.append(dict(id=a[0],device=a[2],fsroot=unescape(a[3]),mount=Path(unescape(a[4])),options=a[5].split(','),fstype=b[0],super_options=b[2].split(',')))
    except (OSError,ValueError,IndexError) as exc:raise ToolkitError('Cannot read Linux mount identity; refusing writes') from exc
    return result

def identify(mount,expected_uuid,filesystem=None,writable=True):
    if not sys.platform.startswith('linux'):raise ToolkitError('UUID-guarded writes currently require Linux. Read-only planning and inventory remain available.')
    if any(p.is_symlink() for p in [mount,*mount.parents]):raise ToolkitError('Expected mount must not traverse a symlink')
    records=mount_records();matches=[r for r in records if r['mount']==mount]
    if len(matches)!=1:raise ToolkitError(f'Expected mount {mount} is absent or ambiguous. No fallback to the internal/root filesystem is allowed.')
    record=matches[0]
    if record['fsroot']!='/':raise ToolkitError('Bind/subdirectory mounts are not approved storage volumes')
    if filesystem and record['fstype']!=filesystem:raise ToolkitError('Unexpected filesystem type at '+str(mount))
    try:
        device=Path('/dev/disk/by-uuid')/expected_uuid
        dev=device.stat();mounted=mount.stat()
        if not stat.S_ISBLK(dev.st_mode) or f'{os.major(dev.st_rdev)}:{os.minor(dev.st_rdev)}'!=record['device'] or mounted.st_dev!=dev.st_rdev:
            raise ToolkitError('Filesystem UUID mismatch at '+str(mount)+'; expected '+expected_uuid)
    except OSError as exc:raise ToolkitError('Cannot confirm expected filesystem UUID '+expected_uuid+'; no archive writes permitted') from exc
    if writable and ('ro' in record['options'] or 'ro' in record['super_options']):raise ToolkitError('Archive filesystem is read-only')
    return record

def validate_location(root,mount):
    # Reject both nested mounts inside the archive and intervening mounts
    # between an approved volume and a configured descendant archive root.
    for record in mount_records():
        point=record['mount']
        if point!=mount and point.is_relative_to(mount) and (point.is_relative_to(root) or root.is_relative_to(point)):
            raise ToolkitError('Nested/intervening mounts on the archive path are not approved')
    if root.exists() and root.stat().st_dev!=mount.stat().st_dev:raise ToolkitError('Archive root is on a different filesystem from the approved mount')

class StorageSession:
    def __init__(self,root,settings,override=None):
        self.original=Path(root);self.rule=rule_for(self.original,settings,override)
        self.mount=Path(self.rule['expected_mount']);self.fd=None;self.root=None;self.identity=None
    def check(self):
        current=identify(self.mount,self.rule['expected_uuid'],self.rule.get('filesystem'))
        if self.identity is not None and current!=self.identity:raise ToolkitError('Storage mount changed during operation; rerun only after restoring the approved volume')
        if any(p.is_symlink() for p in [self.original,*self.original.parents]):raise ToolkitError('Archive path changed to a symlink')
        validate_location(self.original,self.mount)
        target=self.original if self.fd is None else self.root
        if self.fd is not None:
            pinned=os.fstat(self.fd);visible=self.original.stat()
            if (pinned.st_dev,pinned.st_ino)!=(visible.st_dev,visible.st_ino):raise ToolkitError('Archive root was replaced or disconnected')
        probe=target
        while not probe.exists():probe=probe.parent
        usage=os.statvfs(probe)
        if usage.f_flag & os.ST_RDONLY or not os.access(probe,os.W_OK):raise ToolkitError('Archive filesystem is not writable')
        if usage.f_bavail*usage.f_frsize<RESERVE_BYTES:raise ToolkitError('Archive free space is below the 1 GiB safety reserve')
        return current
    def __enter__(self):
        global _ACTIVE,_HOOK
        if _ACTIVE is not None:raise ToolkitError('Nested storage sessions are unsupported')
        self.identity=self.check()
        flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW
        fd=os.open(self.mount,flags)
        try:
            self.check()
            mounted=self.mount.stat();held=os.fstat(fd)
            if (held.st_dev,held.st_ino)!=(mounted.st_dev,mounted.st_ino):raise ToolkitError('Storage changed while opening mount handle')
            for component in self.original.relative_to(self.mount).parts:
                self.check()
                try:os.mkdir(component,dir_fd=fd)
                except FileExistsError:pass
                child=os.open(component,flags,dir_fd=fd);os.close(fd);fd=child
                if os.fstat(fd).st_dev!=mounted.st_dev:raise ToolkitError('Archive component crossed onto an unapproved filesystem')
            self.fd=fd;self.root=Path('/proc/self/fd')/str(fd)
            self.check()
        except BaseException:
            os.close(fd);self.fd=None;raise
        if not _HOOK:sys.addaudithook(_audit);_HOOK=True
        _ACTIVE=self
        self.previous_xet_cache=os.environ.get('HF_XET_CACHE')
        os.environ['HF_XET_CACHE']=str(self.root/'_toolkit'/'xet-cache')
        return self
    def __exit__(self,*exc):
        global _ACTIVE
        # Finish/abort native transfer groups before releasing their directory.
        if 'huggingface_hub.utils._xet' in sys.modules:
            sys.modules['huggingface_hub.utils._xet'].abort_xet_session()
        if self.previous_xet_cache is None:os.environ.pop('HF_XET_CACHE',None)
        else:os.environ['HF_XET_CACHE']=self.previous_xet_cache
        _ACTIVE=None
        if self.fd is not None:os.close(self.fd);self.fd=None
    def hub_download(self,entry,revision,filename,target,force):
        # Public hf_hub_download resolves /proc/self/fd to the mount pathname,
        # defeating pinning. Use the same pinned dependency's local-dir engine.
        # Refuse unreviewed versions rather than silently use an unsafe fallback.
        import huggingface_hub
        if huggingface_hub.__version__!='1.33.0':raise ToolkitError('Guarded downloads require reviewed huggingface_hub==1.33.0')
        from huggingface_hub import constants
        from huggingface_hub.utils import build_hf_headers
        from huggingface_hub.file_download import _hf_hub_download_to_local_dir
        self.check()
        result=_hf_hub_download_to_local_dir(local_dir=target,repo_id=entry['repository'],repo_type='model',filename=filename,revision=revision,endpoint=None,etag_timeout=constants.HF_HUB_ETAG_TIMEOUT,headers=build_hf_headers(token=None),token=None,cache_dir=str(self.root/'_toolkit'/'hub-cache'),force_download=force,local_files_only=False,tqdm_class=None,dry_run=False)
        self.check()
        return result

def _audit(event,args):
    session=_ACTIVE
    if session is None or getattr(_LOCAL,'checking',False):return
    paths=[]
    if event=='open':
        path,mode,flags=args
        if flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):paths=[path]
    elif event in ('os.mkdir','os.remove','os.rmdir','os.chmod','os.utime','os.truncate'):paths=[args[0]]
    elif event in ('os.rename','os.link','os.symlink'):paths=list(args[:2])
    else:return
    for value in paths:
        if not isinstance(value,(str,bytes,os.PathLike)):continue
        path=Path(os.fsdecode(value)).absolute()
        anchored=path.is_relative_to(session.root)
        lexical=path.is_relative_to(session.original)
        if not(anchored or lexical):continue
        if lexical and not anchored:raise ToolkitError('Unpinned archive write refused')
        _LOCAL.checking=True
        try:
            session.check()
            for p in [path,*path.parents]:
                if p==session.root:break
                if p.is_symlink():raise ToolkitError('Symlink within archive write path refused')
        finally:_LOCAL.checking=False
