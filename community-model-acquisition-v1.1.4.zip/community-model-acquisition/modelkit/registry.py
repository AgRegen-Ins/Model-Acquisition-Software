"""Explicit, non-executing external model custody and verified copy import.
No scanning external directories; no payload deserialization; no remote-host probes.
"""
import hashlib,os,platform,re,shutil,uuid
from pathlib import Path
from fnmatch import fnmatch
from filelock import FileLock
from .core import ToolkitError,read,write,now,hashes,plan,inspect_file,acquire,space,safe_name,safe_path
from .mounts import require_mount

PERSONAL_SUFFIXES={'.wav','.mp3','.flac','.ogg','.m4a','.mp4','.webm','.aiff','.opus'}
ARTIFACT_SUFFIXES={'.gguf','.safetensors','.onnx','.json','.yaml','.yml','.txt','.pt','.pth','.bin','.model','.tiktoken','.jinja'}

def registry_path(root):return safe_path(Path(root)/'_toolkit','registry/instances.json')
def load(root):
    p=registry_path(root)
    if not p.exists():return {'schema_version':1,'instances':{}}
    d=read(p)
    if d.get('schema_version')!=1 or not isinstance(d.get('instances'),dict):raise ToolkitError('Unsupported registry format')
    return d

def regular(path):
    path=Path(path)
    if any(part.lower() in {'quarantine','import-staging'} for part in path.parts):raise ToolkitError('Quarantined or staged artifacts cannot be adopted')
    if not path.is_absolute():raise ToolkitError('External artifact paths must be absolute')
    if any(p.is_symlink() for p in [path,*path.parents]):raise ToolkitError('Symlink external artifact paths are not supported')
    if not path.is_file():raise ToolkitError('External artifact missing or not a regular file: '+str(path))
    return path

def fingerprint(p):
    s=p.stat();return [s.st_size,s.st_mtime_ns,s.st_dev,s.st_ino]

def observe(path):
    p=regular(path);before=fingerprint(p);sha,git=hashes(p)
    if before!=fingerprint(p):raise ToolkitError('External file changed during hashing')
    return {'size':before[0],'mtime_ns':before[1],'fingerprint':before,'sha256':sha,'git_blob_sha1':git,'observed_at':now()}

def locked(root,mount):
    root=Path(root);require_mount(root,mount)
    lock=safe_path(root/'_toolkit','collection.lock');lock.parent.mkdir(parents=True,exist_ok=True)
    return FileLock(lock,timeout=0)

def validate_spec(spec,catalog):
    if spec.get('artifact_kind')!='model-artifacts':raise ToolkitError('Declare artifact_kind=model-artifacts; personal voice data is excluded')
    safe_name(spec['instance_id']);safe_name(spec['model_id'])
    files=spec.get('files');known={e['id']:e for e in catalog['models']};entry=known.get(spec['model_id'])
    if not isinstance(files,dict) or not files:raise ToolkitError('Explicit filename-to-absolute-path mapping required; no directory scans')
    if any(not isinstance(p,str) for p in files.values()):raise ToolkitError('Artifact paths must be strings')
    if len(set(files.values()))!=len(files):raise ToolkitError('One physical path cannot represent multiple artifact names')
    if not isinstance(spec.get('associated_projects',[]),list) or any(not isinstance(x,str) for x in spec.get('associated_projects',[])):raise ToolkitError('associated_projects must be a list of names')
    for name,path in files.items():
        safe_path(Path('/registry-validation'),name)
        if not isinstance(path,str) or not path:raise ToolkitError('Artifact path required')
        if Path(path).suffix.lower() in PERSONAL_SUFFIXES or Path(name).suffix.lower() in PERSONAL_SUFFIXES:raise ToolkitError('Personal audio recordings are not model artifacts')
        if entry and (not any(fnmatch(name,p) for p in entry['include']) or any(fnmatch(name,p) for p in entry.get('exclude',[]))):raise ToolkitError('File is outside the catalog artifact selection: '+name)
        if not entry and Path(name).suffix.lower() not in ARTIFACT_SUFFIXES:raise ToolkitError('Unrecognized model artifact; personal profiles/recordings are not accepted')
        if not spec.get('remote_reported') and not Path(path).is_absolute():raise ToolkitError('Local paths must be absolute')
        if spec.get('remote_reported') and not (Path(path).is_absolute() or re.match(r'^[A-Za-z]:[\\/]',path) or path.startswith('\\\\')):raise ToolkitError('Reported remote paths must be absolute')
    if spec.get('location_kind','external-installation') not in {'external-installation','deployment','canonical-archive'}:raise ToolkitError('Invalid location_kind')
    return entry

def assess(record,catalog,adapter=None):
    """Explicit hash operation; trusted upstream evidence comes only from adapter."""
    if record['observation']=='remote-reported':raise ToolkitError('Cannot verify a remotely reported artifact on this computer')
    if record['host']!=platform.node():raise ToolkitError('Run verification on the recorded host')
    entry=next((e for e in catalog['models'] if e['id']==record['model_id']),None)
    expected={};upstream=False
    if adapter is not None:
        if entry is None:raise ToolkitError('Unknown catalog ID: cannot establish trusted upstream identity')
        if not re.fullmatch('[0-9a-fA-F]{40,64}',entry['revision']):raise ToolkitError('Upstream verification requires an immutable catalog revision')
        p=plan(entry,Path('/registry-metadata-only'),adapter)
        if p['revision']!=entry['revision']:raise ToolkitError('Resolved revision differs from pinned catalog revision')
        expected={f['path']:f for f in p['files']};upstream=True
        record['repository']=entry['repository'];record['revision']=p['revision']
    results={};failed=False;missing=False
    for name,path in record['paths'].items():
        try:obs=observe(path)
        except (OSError,ToolkitError) as exc:
            results[name]={'status':'missing','path':path,'reason':str(exc)};missing=True;continue
        previous=record.get('files',{}).get(name,{})
        changed=bool(previous.get('sha256') and obs['sha256']!=previous['sha256'])
        trusted=False;expected_file=expected.get(name)
        mismatch=False
        if upstream:
            if not expected_file:mismatch=True
            else:
                mismatch=obs['size']!=expected_file['size']
                if expected_file.get('sha256'):mismatch |= obs['sha256']!=expected_file['sha256'];trusted=True
                elif expected_file.get('git_blob_sha1'):mismatch |= obs['git_blob_sha1']!=expected_file['git_blob_sha1'];trusted=True
        status='verification-failed' if mismatch or changed else 'external-verified' if trusted else 'external-registered'
        results[name]={**obs,'path':path,'status':status,'upstream_verified':trusted and not mismatch and not changed,'baseline_sha256':previous.get('baseline_sha256',previous.get('sha256',obs['sha256']))}
        failed |= status=='verification-failed'
    required=set(expected) if upstream else set(entry['required']) if entry else set(record['paths'])
    incomplete=any(not any(fnmatch(name,pattern) for name in results) for pattern in required)
    status='verification-failed' if failed else 'missing' if missing else 'incomplete' if incomplete else 'external-verified' if results and all(f.get('upstream_verified') for f in results.values()) else 'external-registered'
    record.update(files=results,status=status,last_verification_time=now(),verification_scope='trusted pinned upstream digest match' if upstream else 'local SHA-256 identity only',required_files=sorted(required),entry=entry or record.get('entry'))
    # A changed baseline is sticky until a new explicit custody instance is created.
    if any(f.get('baseline_sha256') and f.get('sha256')!=f['baseline_sha256'] for f in results.values()):record['status']='verification-failed'
    return record

def register(root,catalog,spec,mount=None):
    entry=validate_spec(spec,catalog)
    with locked(root,mount):
        data=load(root);key=spec['instance_id'];old=data['instances'].get(key)
        observation='remote-reported' if spec.get('remote_reported') else 'local-observed'
        host=spec.get('host') if spec.get('remote_reported') else platform.node()
        if not host:raise ToolkitError('Remote report requires a host name')
        if old and (old['model_id']!=spec['model_id'] or old['paths']!=spec['files'] or old['host']!=host or old['observation']!=observation):raise ToolkitError('Instance ID conflict; use a distinct ID for a distinct installation')
        # Same path set on same host cannot be hidden under another instance ID.
        for k,r in data['instances'].items():
            if k!=key and r['host']==host and r['paths']==spec['files']:raise ToolkitError('Already registered as '+k)
        r=old or {'instance_id':key,'model_id':spec['model_id'],'host':host,'observation':observation,'created_at':now(),'paths':spec['files'],'files':{},'status':'external-registered','repository':entry['repository'] if entry else spec.get('repository'),'revision':None,'entry':entry,'verification_scope':'unverified report','last_verification_time':None}
        r.update(associated_projects=sorted(set(r.get('associated_projects',[])+spec.get('associated_projects',[]))),location_kind=spec.get('location_kind','external-installation'),custody_notes=spec.get('custody_notes',''),runtime_requirements=spec.get('runtime_requirements',entry.get('runtime_notes','unknown') if entry else 'unknown'),reported_file_metadata=spec.get('reported_file_metadata',{}) if observation=='remote-reported' else {},updated_at=now())
        if observation=='local-observed':assess(r,catalog)
        data['instances'][key]=r;write(registry_path(root),data);return r

def verify(root,catalog,instance_id,adapter=None,mount=None):
    with locked(root,mount):
        d=load(root)
        if instance_id not in d['instances']:raise ToolkitError('Unknown instance')
        r=assess(d['instances'][instance_id],catalog,adapter);write(registry_path(root),d);return r

def current_status(record):
    """Cheap availability/fingerprint check, never a full hash audit."""
    if record['observation']=='remote-reported' or record['host']!=platform.node():return record['status'],'remote-reported; not observed here'
    for name,path in record['paths'].items():
        try:
            p=regular(path);f=record.get('files',{}).get(name,{})
            if not f.get('fingerprint') or fingerprint(p)!=f['fingerprint']:return 'downloaded-unverified','external file changed since last hash audit'
        except (OSError,ToolkitError):return 'missing','path unavailable; may be an unmounted drive'
    return record['status'],'recorded hash audit + current file fingerprint; not a new hash audit'

class CopyAdapter:
    """Used only after upstream comparison; writes exclusively inside staging."""
    def __init__(self,paths):self.paths=paths
    def download(self,entry,revision,filename,target,force=False):
        src=regular(self.paths[filename]);before=fingerprint(src);dest=safe_path(target,filename);dest.parent.mkdir(parents=True,exist_ok=True)
        with src.open('rb') as source,dest.open('xb') as output:
            shutil.copyfileobj(source,output,8*1024*1024);output.flush();os.fsync(output.fileno())
        if before!=fingerprint(src):raise ToolkitError('Source changed while copying; import refused')

def import_instance(root,catalog,instance_id,adapter,mount=None,yes=False,allow_large=False):
    root=Path(root)
    with locked(root,mount):
        d=load(root)
        if instance_id not in d['instances']:raise ToolkitError('Unknown instance')
        r=assess(d['instances'][instance_id],catalog,adapter);write(registry_path(root),d)
        if r['status']!='external-verified':raise ToolkitError('Import requires a complete independently upstream-verified artifact set')
        e=next(e for e in catalog['models'] if e['id']==r['model_id']);p=plan(e,root,adapter)
        if p['revision']!=e['revision']:raise ToolkitError('Pinned revision changed')
        target=Path(p['target'])
        if target.exists():raise ToolkitError('Managed target already exists; import never overwrites. Use ordinary status/verify or acquisition resume.')
        if not yes:raise ToolkitError('Import requires explicit --yes after review')
        if p['total_bytes']>=50*10**9 and not allow_large:raise ToolkitError('Import >=50 GB requires --allow-large even with --yes')
        free,reserve=space(root,p['total_bytes'])
        if free<reserve:raise ToolkitError('Insufficient storage including safety reserve')
        staging=safe_path(root/'_toolkit','import-staging/'+uuid.uuid4().hex);pstage={**p,'target':str(staging)}
        try:
            acquire(pstage,root,CopyAdapter(r['paths']),retries=1)
            m=read(staging/'manifest.json');m['acquisition_origin']='verified-external-copy';m['external_instance_id']=instance_id;write(staging/'manifest.json',m)
            if target.exists():raise ToolkitError('Target appeared during import; refusing overwrite')
            target.parent.mkdir(parents=True,exist_ok=True);os.rename(staging,target)
        except BaseException:
            # Keep staging and manifests for inspection; never expose as complete.
            raise
        r['managed_copy']=str(target);r['imported_at']=now();write(registry_path(root),d)
        from .storage import refresh
        refresh(root,catalog)
        return {'status':'downloaded-verified','path':str(target),'originals_unchanged':True}
