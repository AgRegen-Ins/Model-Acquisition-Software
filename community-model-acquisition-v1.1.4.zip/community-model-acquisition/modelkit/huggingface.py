"""All Hugging Face specifics live here; core consumes a small adapter protocol."""
from dataclasses import asdict
import json
class HuggingFaceAdapter:
    def __init__(self):
        from huggingface_hub import HfApi
        self.api=HfApi()
    def resolve(self,entry):
        if entry.get("adapter")=="github":
            from .github import GitHubAdapter
            return GitHubAdapter().resolve(entry)
        info=self.api.model_info(entry['repository'],revision=entry.get('revision','main'),files_metadata=True)
        files=[]
        for s in info.siblings:
            lfs=s.lfs
            files.append({'path':s.rfilename,'size':s.size,'sha256':lfs.sha256 if lfs else None,'git_blob_sha1':s.blob_id if not lfs else None})
        if entry.get('pinned_files'):
            from .core import ToolkitError
            if info.sha!=entry['revision']:raise ToolkitError('Educational artifact requires its reviewed immutable revision')
            indexed={f['path']:f for f in files}
            for expected in entry['pinned_files']:
                if indexed.get(expected['path'])!=expected:raise ToolkitError('Pinned Hugging Face file manifest changed')
        metadata=json.loads(json.dumps(info.__dict__,default=lambda x:x.to_dict() if hasattr(x,'to_dict') else x.__dict__ if hasattr(x,'__dict__') else str(x)))
        return {'revision':info.sha,'files':files,'gated':info.gated,'metadata':metadata}
    def download(self,entry,revision,filename,target,force=False):
        if entry.get("adapter")=="github":
            from .github import GitHubAdapter
            return GitHubAdapter().download(entry,revision,filename,target,force)
        from .volume import active_session
        session=active_session()
        if session is not None:
            return session.hub_download(entry,revision,filename,target,force)
        from huggingface_hub import hf_hub_download
        return hf_hub_download(repo_id=entry['repository'],revision=revision,filename=filename,local_dir=target,force_download=force)
