"""Pinned public GitHub artifacts as inert bytes, using the existing core protocol.
No git checkout, archive extraction, package installation or source execution.
"""
import hashlib,json,os,re
from pathlib import Path
from urllib.parse import urlsplit,quote
from urllib.request import Request,build_opener,HTTPRedirectHandler
from .core import ToolkitError,safe_path,inspect_file
from .volume import checkpoint

HOSTS={'api.github.com','raw.githubusercontent.com','github.com','release-assets.githubusercontent.com','objects.githubusercontent.com'}
def checked_url(url):
    p=urlsplit(url)
    if p.scheme!='https' or p.hostname not in HOSTS or p.username or p.password or p.port not in (None,443):
        raise ToolkitError('Unapproved GitHub transport destination')
    return url
class Redirects(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        checked_url(newurl)
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def open_url(url,headers=None):
    return build_opener(Redirects()).open(Request(checked_url(url),headers={'User-Agent':'community-model-acquisition','Accept-Encoding':'identity',**(headers or {})}),timeout=60)

def json_url(url):
    with open_url(url,{'Accept':'application/vnd.github+json'}) as r:
        raw=r.read(16*1024*1024+1)
        if len(raw)>16*1024*1024:raise ToolkitError('GitHub metadata exceeds limit')
        return json.loads(raw)

def validate(entry):
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',entry['repository']):raise ToolkitError('Invalid GitHub repository')
    if not re.fullmatch('[0-9a-f]{40}',entry['revision']):raise ToolkitError('GitHub artifacts require an immutable commit; --latest is not supported')
    files=entry.get('pinned_files')
    if not isinstance(files,list) or not files:raise ToolkitError('GitHub pinned file manifest required')
    seen=set()
    for f in files:
        path=f['path'];safe_path(Path('/validated-artifact'),path)
        if path in seen:raise ToolkitError('Duplicate pinned artifact path')
        seen.add(path)
        if type(f.get('size')) is not int or f['size']<0:raise ToolkitError('Bounded artifact size required')
        if not (re.fullmatch('[0-9a-f]{64}',f.get('sha256') or '') or re.fullmatch('[0-9a-f]{40}',f.get('git_blob_sha1') or '')):raise ToolkitError('Pinned digest required')
        if f.get('asset_id') is not None and (type(f['asset_id']) is not int or f['asset_id']<=0 or not f.get('sha256')):raise ToolkitError('Release asset requires ID and SHA-256')
    return files

class GitHubAdapter:
    def resolve(self,entry):
        expected=validate(entry);repo=entry['repository'];rev=entry['revision'];api='https://api.github.com/repos/'+repo
        commit=json_url(api+'/commits/'+rev)
        if commit.get('sha')!=rev:raise ToolkitError('GitHub commit identity mismatch')
        tree_sha=commit['commit']['tree']['sha']
        tree=json_url(api+'/git/trees/'+tree_sha+'?recursive=1')
        if tree.get('truncated') or tree.get('sha')!=tree_sha:raise ToolkitError('Incomplete or mismatched GitHub tree')
        nodes={f['path']:f for f in tree['tree']};assets=[]
        for f in expected:
            if f.get('asset_id'):
                a=json_url(api+'/releases/assets/'+str(f['asset_id']));assets.append(a)
                if a.get('id')!=f['asset_id'] or a.get('name')!=f['path'].split('/')[-1] or a.get('size')!=f['size'] or a.get('digest')!='sha256:'+f['sha256'] or a.get('state')!='uploaded':raise ToolkitError('Release asset identity/digest mismatch')
            else:
                n=nodes.get(f['path'],{})
                if n.get('type')!='blob' or n.get('mode') not in ('100644','100755') or n.get('size')!=f['size'] or n.get('sha')!=f['git_blob_sha1']:raise ToolkitError('Pinned source tree mismatch: '+f['path'])
        return {'revision':rev,'files':[{k:f.get(k) for k in ('path','size','sha256','git_blob_sha1')} for f in expected],'gated':False,'metadata':{'repository':repo,'requested_repository':entry.get('requested_repository',repo),'commit':commit,'tree':tree,'assets':assets}}

    def download(self,entry,revision,filename,target,force=False):
        files=validate(entry)
        if revision!=entry['revision']:raise ToolkitError('Revision mismatch')
        f=next((f for f in files if f['path']==filename),None)
        if f is None:raise ToolkitError('Unselected artifact refused')
        target=Path(target);dest=safe_path(target,filename)
        if dest.exists():raise ToolkitError('Existing destination must be handled by core verification/quarantine')
        checkpoint();dest.parent.mkdir(parents=True,exist_ok=True)
        key=hashlib.sha256((entry['repository']+'\n'+revision+'\n'+filename+'\n'+str(f)).encode()).hexdigest()
        partial=safe_path(target,'.github-cache/'+key+'.partial');partial.parent.mkdir(parents=True,exist_ok=True)
        offset=partial.stat().st_size if partial.exists() else 0
        if offset>f['size']:raise ToolkitError('Oversized partial artifact; manual review required')
        if offset<f['size'] or not partial.exists():
            repo=entry['repository']
            url=('https://api.github.com/repos/'+repo+'/releases/assets/'+str(f['asset_id']) if f.get('asset_id') else 'https://raw.githubusercontent.com/'+repo+'/'+revision+'/'+quote(filename,safe='/'))
            headers={'Accept':'application/octet-stream'}
            if offset:headers['Range']='bytes='+str(offset)+'-'
            checkpoint()
            with open_url(url,headers) as response:
                status=response.status
                if status==206:
                    expected='bytes '+str(offset)+'-'+str(f['size']-1)+'/'+str(f['size'])
                    if response.headers.get('Content-Range')!=expected:raise ToolkitError('Unexpected resume range')
                elif status==200:offset=0
                else:raise ToolkitError('Unexpected download response')
                checkpoint()
                with partial.open('ab' if offset else 'wb') as output:
                    count=offset
                    while True:
                        checkpoint();block=response.read(min(1024*1024,f['size']-count+1))
                        if not block:break
                        if count+len(block)>f['size']:raise ToolkitError('Response exceeds pinned size')
                        output.write(block);count+=len(block)
                    output.flush();os.fsync(output.fileno())
                if count!=f['size']:raise ToolkitError('Interrupted/truncated artifact; rerun to resume')
        checkpoint()
        if not inspect_file(partial,f):
            # Core quarantines an invalid final object on retry; never marks it verified.
            os.replace(partial,dest)
            raise ToolkitError('Downloaded artifact digest mismatch')
        os.replace(partial,dest);checkpoint();return str(dest)
