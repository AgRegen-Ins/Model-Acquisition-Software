#!/usr/bin/env python3
"""Check installed release files against PACKAGE-CHECKSUMS.json (no network)."""
import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
checks=json.loads((root/'PACKAGE-CHECKSUMS.json').read_text())
errors=[]
for name,expected in checks.items():
    path=root/name
    if path.is_symlink() or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:errors.append(name)
if errors:print('Mismatched or missing packaged files: '+', '.join(errors));sys.exit(1)
print(f'Verified {len(checks)} packaged file SHA-256 hashes. Local caches/venv are not release files.')
