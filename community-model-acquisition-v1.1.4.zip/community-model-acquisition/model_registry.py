#!/usr/bin/env python3
"""Cross-project model registration and accountability; never loads model code."""
import argparse,json,sys
from pathlib import Path
from modelkit.core import load_catalog,read,ToolkitError,friendly
from modelkit.mounts import expected_mount
from modelkit import registry,accountability
BASE=Path(__file__).resolve().parent

def _main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',required=True,type=Path);p.add_argument('--catalog',type=Path,default=BASE/'catalog.json');p.add_argument('--policy',type=Path,default=BASE/'preservation-policy.json');p.add_argument('--settings',type=Path,default=BASE/'settings.json');p.add_argument('--expected-mount',type=Path)
    actions=p.add_mutually_exclusive_group(required=True);actions.add_argument('--register',type=Path,metavar='SPEC.json');actions.add_argument('--verify-instance');actions.add_argument('--import-instance');actions.add_argument('--inventory',action='store_true')
    p.add_argument('--upstream',action='store_true',help='Resolve pinned repository hashes for explicit verification');p.add_argument('--yes',action='store_true');p.add_argument('--allow-large',action='store_true');p.add_argument('--format',choices=['text','json','csv'],default='text')
    a=p.parse_args(argv);root=a.root.expanduser().absolute()
    if root==Path(root.anchor):raise ToolkitError('Use a dedicated model root')
    if a.upstream and not a.verify_instance:raise ToolkitError('--upstream requires --verify-instance')
    if a.format!='text' and not a.inventory:raise ToolkitError('--format requires --inventory')
    if (a.yes or a.allow_large) and not a.import_instance:raise ToolkitError('Import confirmation flags require --import-instance')
    c=load_catalog(a.catalog)
    if a.inventory:print(accountability.render(accountability.collect(root,c,accountability.policies(a.policy)),a.format),end='');return 0
    mount=expected_mount(root,a.settings,a.expected_mount)
    if a.register:result=registry.register(root,c,read(a.register),mount)
    elif a.verify_instance:
        adapter=None
        if a.upstream:
            from modelkit.huggingface import HuggingFaceAdapter
            adapter=HuggingFaceAdapter()
        result=registry.verify(root,c,a.verify_instance,adapter,mount)
    else:
        from modelkit.huggingface import HuggingFaceAdapter
        result=registry.import_instance(root,c,a.import_instance,HuggingFaceAdapter(),mount,a.yes,a.allow_large)
    from modelkit.volume import public_data
    print(json.dumps(public_data(result),indent=2));return 1 if result.get('status') in {'verification-failed','missing','incomplete'} else 0
def main(argv=None):
    from modelkit.volume import configured_root, StorageSession
    # Parse storage options without duplicating registry action validation.
    p=argparse.ArgumentParser(add_help=False)
    p.add_argument('--root',type=Path);p.add_argument('--settings',type=Path,default=BASE/'settings.json');p.add_argument('--expected-mount',type=Path);p.add_argument('--inventory',action='store_true')
    a,_=p.parse_known_args(argv)
    if '--help' in (argv if argv is not None else sys.argv[1:]):return _main(argv)
    root=configured_root(a.root,a.settings)
    tokens=list(argv if argv is not None else sys.argv[1:])
    for i in range(len(tokens)-1,-1,-1):
        if tokens[i]=='--root':del tokens[i:i+2]
        elif tokens[i].startswith('--root='):del tokens[i]
    if a.inventory:return _main(tokens+['--root',str(root)])
    with StorageSession(root,a.settings,a.expected_mount) as session:
        return _main(tokens+['--root',str(session.root)])

if __name__=='__main__':
    try:sys.exit(main())
    except ToolkitError as exc:print('Error: '+str(exc),file=sys.stderr);sys.exit(1)
    except Exception as exc:print('Error: '+friendly(exc),file=sys.stderr);sys.exit(1)

