#!/usr/bin/env python3
"""Export catalog and actual archive accountability without changing the archive."""
import argparse,json,sys,os
from pathlib import Path
from modelkit.core import load_catalog,ToolkitError,read
from modelkit.accountability import policies
from modelkit.archive_report import collect,workbook
from modelkit.volume import configured_root
BASE=Path(__file__).resolve().parent

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path);p.add_argument('--settings',type=Path,default=BASE/'settings.json');p.add_argument('--catalog',type=Path,default=BASE/'catalog.json');p.add_argument('--policy',type=Path,default=BASE/'preservation-policy.json');p.add_argument('--output',type=Path,help='New .xlsx file outside archive mount(s); refuses overwrite')
    a=p.parse_args(argv);root=configured_root(a.root,a.settings)
    data=collect(root,load_catalog(a.catalog),policies(a.policy),a.settings)
    if a.output:
        out=a.output.expanduser().absolute()
        if out.suffix.lower()!='.xlsx':raise ToolkitError('--output must end in .xlsx')
        if any(p.is_symlink() for p in [out,*out.parents]):raise ToolkitError('Output must not traverse a symlink')
        forbidden=[root]+[Path(r['expected_mount']) for r in read(a.settings).get('mount_guards',[])]
        if any(out.is_relative_to(p) for p in forbidden):raise ToolkitError('Export outside the archive/guarded mounts; this command is read-only against storage')
        payload=workbook(data)
        with out.open('xb') as f:f.write(payload);f.flush();os.fsync(f.fileno())
        print(str(out))
    else:print(json.dumps(data,indent=2))
    return 0
if __name__=='__main__':
    try:sys.exit(main())
    except (ToolkitError,OSError) as exc:print('Error: '+str(exc),file=sys.stderr);sys.exit(1)
