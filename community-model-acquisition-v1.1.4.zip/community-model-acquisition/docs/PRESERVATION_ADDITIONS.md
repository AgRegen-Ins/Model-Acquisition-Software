# v1.0.4 preservation additions

Reviewed 2026-10-03 UTC from public pinned Hub API inventories, cards, configs, indexes and small Safetensors precision headers; no full weights downloaded. This is a catalog expansion of the supplied v1.0.3 ZIP (SHA-256 `dbc40bb2eb90677c942eccba4473438ea54dc6cdc891607bfe80bd12b3f80420`), not a rebuilt toolkit.

## Exact variants

| Model ID | Repository | Revision | Role / provenance | Selected GB | Whole repo GB | Precision |
|---|---|---|---|---:|---:|---|
| `glm-5-3-flash-original` | [zai-org/GLM-5.3-Flash-BF16](https://huggingface.co/zai-org/GLM-5.3-Flash-BF16/tree/a5b45eb41df6402735dedc900be14a42e8d5e538) | `a5b45eb41df6402735dedc900be14a42e8d5e538` | source-weights / official-upstream | 642.676 | 642.676 | BF16 weights with F32 auxiliary tensors |
| `glm-5-3-flash-gguf-ud-q4-k-xl` | [unsloth/GLM-5.3-Flash-GGUF](https://huggingface.co/unsloth/GLM-5.3-Flash-GGUF/tree/621d456e93e926e4b52f85cff5f634358c1828f9) | `621d456e93e926e4b52f85cff5f634358c1828f9` | portable-gguf / third-party-derived | 200.871 | 2,545.637 | UD-Q4_K_XL mixed GGUF tensors; quantizer recipe, not uniform 4-bit |
| `mistral-small-4-119b-original` | [mistralai/Mistral-Small-4-119B-2603](https://huggingface.co/mistralai/Mistral-Small-4-119B-2603/tree/a11f36bebf709121056b1dbcc943d1c6afbe494d) | `a11f36bebf709121056b1dbcc943d1c6afbe494d` | source-weights / official-upstream | 241.890 | 241.890 | FP8 E4M3 + BF16; both consolidated and Transformers exports |
| `mistral-small-4-119b-nvfp4` | [mistralai/Mistral-Small-4-119B-2603-NVFP4](https://huggingface.co/mistralai/Mistral-Small-4-119B-2603-NVFP4/tree/45331841b631f4e281df8e959ea3cc9beb84298a) | `45331841b631f4e281df8e959ea3cc9beb84298a` | official-quantized / official-derived | 70.847 | 70.847 | NVFP4 packed U8 + FP8 E4M3 scales + BF16/F32 unquantized tensors |
| `mistral-small-4-119b-gguf-ud-q4-k-m` | [unsloth/Mistral-Small-4-119B-2603-GGUF](https://huggingface.co/unsloth/Mistral-Small-4-119B-2603-GGUF/tree/bd93c721735aa32c035c0f19e738cb3371fd56ff) | `bd93c721735aa32c035c0f19e738cb3371fd56ff` | portable-gguf / third-party-derived | 74.620 | 1,768.025 | UD-Q4_K_M mixed GGUF tensors; quantizer recipe, not uniform 4-bit |
| `minimax-m3-original` | [MiniMaxAI/MiniMax-M3](https://huggingface.co/MiniMaxAI/MiniMax-M3/tree/f0e1c1e04d40177e4673a22097036854f536e9c0) | `f0e1c1e04d40177e4673a22097036854f536e9c0` | source-weights / official-upstream | 854.201 | 854.201 | BF16 weights + F32 auxiliary tensors |
| `minimax-m3-mxfp8` | [MiniMaxAI/MiniMax-M3-MXFP8](https://huggingface.co/MiniMaxAI/MiniMax-M3-MXFP8/tree/c5454eb03678d8710e54a4e0fc681b9f3b4a3dba) | `c5454eb03678d8710e54a4e0fc681b9f3b4a3dba` | official-quantized / official-derived | 443.776 | 443.776 | MXFP8 E4M3 + U8 scales, BF16 and F32 unquantized tensors |
| `kimi-k2-7-code-original` | [moonshotai/Kimi-K2.7-Code](https://huggingface.co/moonshotai/Kimi-K2.7-Code/tree/74797c9c62378b951a1f6fcf5c4631024e9b8bef) | `74797c9c62378b951a1f6fcf5c4631024e9b8bef` | source-weights / official-upstream | 595.205 | 595.205 | Native INT4 MoE packed in I32 tensors, BF16 remaining weights, F32 auxiliary tensors |
| `kimi-k2-7-code-gguf-ud-q4-k-xl` | [unsloth/Kimi-K2.7-Code-GGUF](https://huggingface.co/unsloth/Kimi-K2.7-Code-GGUF/tree/46352ca8dc32aa60f9754f5bd3fb778deeb9e430) | `46352ca8dc32aa60f9754f5bd3fb778deeb9e430` | portable-gguf / third-party-derived | 584.663 | 4,304.158 | UD-Q4_K_XL mixed GGUF tensors; quantizer recipe, not uniform 4-bit |
| `glm-5-3-original` | [zai-org/GLM-5.3-BF16](https://huggingface.co/zai-org/GLM-5.3-BF16/tree/9d2398f478cab2de883137db3a36ad2c96205e24) | `9d2398f478cab2de883137db3a36ad2c96205e24` | source-weights / official-upstream | 1,506.693 | 1,506.693 | BF16 weights + F32 auxiliary tensors |
| `glm-5-3-gguf-ud-q4-k-xl` | [unsloth/GLM-5.3-GGUF](https://huggingface.co/unsloth/GLM-5.3-GGUF/tree/346b3591c7f28d1a23716f97a065ecf12ec14771) | `346b3591c7f28d1a23716f97a065ecf12ec14771` | portable-gguf / third-party-derived | 467.289 | 5,952.235 | UD-Q4_K_XL mixed GGUF tensors; quantizer recipe, not uniform 4-bit |

Whole GGUF repositories contain many quantizations. The toolkit downloads only the listed variant, its required projector and available small root metadata. It does not acquire every quantization. Source and official optimized variants preserve whole repositories, including all integrated vision weights, indexes, processors, tokenizers, templates and supplied code. Model code is preserved but never executed.

## Model and runtime decisions

### GLM-5.3-Flash canonical upstream

Native multimodal MoE for reasoning, research and agentic coding; hybrid linear attention and DeepSeek sparse attention with mHC.

Parameters: 321,323,031,390 stored/model count; approximately 18B active. Hub safetensors count 321.323B including auxiliary tensors; publisher markets 320B / 18B active. Context: 1,048,576 tokens. Architecture: Glm5NextForConditionalGeneration. License: `mit`.

Official BF16 checkpoint is preferred over the main FP8/BF16/F32 representation for conversion and re-quantization. Z.ai lists Slime >=0.3.0 and ms-swift >=4.4.0 for GLM-5-series training; exact architecture/version and adapter targets must be checked before training. No training run was performed.

Capabilities: reasoning, agentic-coding, software-engineering, tool-use, long-context, agentic-research, research, multimodal, vision, function-calling, report-writing, fine-tuning-source, re-quantization-source.

Runtime: Publisher links current GLM-5.3-Flash recipe; requires hybrid linear/sparse attention and vision support. Publisher links GLM-5.3-Flash cookbook; use compatible hybrid-attention build.

Hardware: Archive/future-hardware only. Not practical on the 32 GB Dell. Disk bytes are not a RAM minimum. Runtime/KV/vision buffers and context add memory; multi-GPU or very large RAM expected. No speed claim.

### Mistral Small 4 119B 2603 canonical upstream

119B MoE with 128 experts / 4 routed experts per token, MLA, vision, optional reasoning and native function calling.

Parameters: 119,401,317,952 stored/model count; approximately 6.5B active. Hub Transformers export count 119.401B; publisher 119B / 6.5B active. Card supports 256K despite config max_position_embeddings=1048576. Context: 262,144 tokens. Architecture: Mistral3ForConditionalGeneration. License: `apache-2.0`.

Canonical publisher checkpoint is mixed FP8 E4M3 and BF16, NOT an all-BF16 source. Publisher links Axolotl examples/mistral4 for fine-tuning. Use format-aware loading/dequantization and validated adapter targets; dequantization cannot restore pre-quantization information. Both publisher consolidated and Transformers exports are retained.

Capabilities: reasoning, agentic-coding, software-engineering, tool-use, long-context, general-chat, agentic-research, research, multimodal, vision, function-calling, report-writing, fine-tuning-source, re-quantization-source.

Runtime: Publisher recommended; mistral tool/reasoning parsers and compatible MLA backend. Publisher documented support; use current Mistral Small 4 backend.

Hardware: Archive/future-hardware only. Not practical on the 32 GB Dell. Disk bytes are not a RAM minimum. Runtime/KV/vision buffers and context add memory; multi-GPU or very large RAM expected. No speed claim.

### MiniMax-M3 canonical upstream

Native text/image/video MoE with MiniMax Sparse Attention, 128 experts / 4 routed experts plus shared expert; long-horizon coding and cowork.

Parameters: 427,040,140,160 stored/model count; approximately 23B active. Hub count 427.040B including auxiliary tensors; publisher rounds to ~428B / ~23B active. Context: 1,048,576 tokens. Architecture: MiniMaxM3SparseForConditionalGeneration. License: `minimax-community`.

BF16/F32 canonical checkpoint preserves floating-point inputs for future customization and conversion. Architecture-aware training and MSA tooling are needed. No model-specific LoRA/QLoRA recipe was verified, so training compatibility is unverified rather than guaranteed.

Capabilities: reasoning, agentic-coding, software-engineering, tool-use, long-context, long-horizon-agent, agentic-research, research, multimodal, vision, function-calling, fine-tuning-source, re-quantization-source.

Runtime: Official recipe covers BF16 and publisher MXFP8 with minimax_m3 tool/reasoning parsers and MSA; MXFP8 prefers Blackwell or AMD CDNA4. Publisher links MiniMax-M3 cookbook; check selected precision and MSA backend.

Hardware: Archive/future-hardware only. Not practical on the 32 GB Dell. Disk bytes are not a RAM minimum. Runtime/KV/vision buffers and context add memory; multi-GPU or very large RAM expected. No speed claim.

### Kimi-K2.7-Code canonical upstream

Native INT4, 1T MoE with MLA and MoonViT; long-horizon agentic software engineering, interleaved reasoning and multi-step tool use. Thinking-only.

Parameters: 1,000,000,000,000 stored/model count; approximately 32B active. Publisher 1T / 32B active. Hub tensor-storage count is not a direct dense parameter count for packed INT4. Context: 262,144 tokens. Architecture: KimiK25ForConditionalGeneration. License: `modified-mit`.

Canonical upstream is native INT4 with BF16 non-MoE tensors, not recoverable full BF16. Official deployment guide documents KTransformers + LLaMA-Factory LoRA SFT; use that specialized path and validate exact architecture. No generic QLoRA/full training compatibility is asserted. Re-quantization may compound loss.

Capabilities: reasoning, agentic-coding, software-engineering, tool-use, long-context, repository-scale-coding, long-horizon-agent, multimodal, vision, function-calling, code-generation, code-review, fine-tuning-source, re-quantization-source.

Runtime: Official guide verifies vLLM 0.19.1; kimi_k2 reasoning/tool parsers; H200 TP8 example. Official guide specifies SGLang >=0.5.10.post1; kimi_k2 parsers.

Hardware: Archive/future-hardware only. Not practical on the 32 GB Dell. Disk bytes are not a RAM minimum. Runtime/KV/vision buffers and context add memory; multi-GPU or very large RAM expected. No speed claim.

### GLM-5.3 canonical upstream

Very large text-only MoE with DeepSeek Sparse Attention; reasoning, agentic research and long-horizon coding. Archive/future-hardware target.

Parameters: 753,329,940,480 stored/model count; approximately 40B active. Hub count 753.330B includes stored auxiliary/MTP tensors; publisher family designation 744B-A40B. These counts are not interchangeable. Context: 1,048,576 tokens. Architecture: GlmMoeDsaForCausalLM. License: `glm-5.3`.

Official BF16/F32 checkpoint selected instead of the optimized main FP8/BF16/F32 repository. Z.ai lists Slime >=0.3.0 and ms-swift >=4.4.0 for GLM-5-series fine-tuning. Suitable preservation input for compatible training/conversion tools; training has not been exercised.

Capabilities: reasoning, agentic-coding, software-engineering, tool-use, long-context, agentic-research, research, long-horizon-agent, repository-scale-coding, report-writing, function-calling, fine-tuning-source, re-quantization-source.

Runtime: Publisher documented GLM-5.3 recipe with DSA support. Publisher documented GLM-5.3 cookbook with DSA support.

Hardware: Archive/future-hardware only. Not practical on the 32 GB Dell. Disk bytes are not a RAM minimum. Runtime/KV/vision buffers and context add memory; multi-GPU or very large RAM expected. No speed claim.

### Deliberate inference selections

- **GLM-5.3-Flash:** UD-Q4_K_XL is a mixed-precision quality-oriented approximately four-bit choice (~200.87 GB with BF16 projector). Both the normal six shards and `mmproj-BF16.gguf` are required; `Shard_Rewrite/` is excluded. The pinned conversion is **experimental**: PR #27754 is closed without merge, and the 2026-10-01 maintainer comment says mainline support does not work with these Unsloth files until updated. Use a converter-compatible branch, its precision flags and a validated vision backend; no released-build compatibility is promised. The inspected llama.cpp v0.5.0 release lacks glm5-next; newer main has that architecture but a different layout. Native sparse/linear attention and mHC support are required.
- **Mistral Small 4:** profiles prefer official NVFP4 (~70.85 GB), produced with Mistral, vLLM/Red Hat and llm-compressor; Safetensors, not GGUF. Target precision-compatible datacenter GPUs (native NVFP4 favors Blackwell). The additional Unsloth UD-Q4_K_M (~74.62 GB including F16 projector) offers llama.cpp portability with three shards. The upstream card explicitly links it. Main original retains both consolidated and Transformers exports (~241.89 GB) deliberately; both inspected first shards contain FP8 E4M3 and BF16. NVFP4 header shows U8-packed weights, FP8 scales, BF16 and F32 tensors. The supported context is 256K despite 1M in config.
- **MiniMax-M3:** official publisher MXFP8 (~443.78 GB) is the primary compressed option, preserving integrated vision. Its config records E4M3 weights with U8 scales and BF16/F32 exceptions. The vLLM recipe names NVIDIA as converter and recommends Blackwell or AMD CDNA4 for native MX kernels; TP8 is an example, not an exact minimum. `MiniMaxAI/MiniMax-M3-MXFP4` returned 401 (not proof of nonexistence); publisher search lists original and MXFP8. NVIDIA offers NVFP4, but its reviewed card requires nightly vLLM; it is documented as an alternative, not included in this release.
- **MiniMax GGUF deferred:** Unsloth repository resolves, with ~264 GB UD-Q4_K_M, but the pinned tree has **no mmproj**. Its card still describes preliminary support/dense-attention fallback; that card is stale about mainline status because inspected v0.5.0 source includes minimax-m3 language and vision code. Neither this fact nor a working text-only conversion establishes a complete compatible multimodal artifact set. No incomplete variant is labeled fully runnable. Preserve original + official MXFP8 now.
- **Kimi-K2.7-Code:** UD-Q4_K_XL (~584.66 GB including F16 projector) keeps native INT4 expert weights and uses higher precision elsewhere. It is not a conventional 1T BF16-to-4-bit conversion and saves little versus the ~595.20 GB canonical repository. The converter describes UD-Q8_K_XL as lossless and ~11 GB larger; Q4 is chosen as the requested practical near-native option, with the canonical repository separately preserved. All 14 shards and the projector are required. Current llama.cpp conversion/vision paths and the converter guide support this family; use thinking-only template and kimi_k2 tool parser. Full 256K context is not a memory guarantee.
- **GLM-5.3:** UD-Q4_K_XL (~467.29 GB), eleven shards, no vision projector because this is text-only. The converter recommends Q4_K_XL/Q5_K_XL based on its quantization analysis. Current llama.cpp has glm-dsa; use a current build and the correct reasoning/tool template. This remains an enormous future-hardware target.

These compatibility labels describe documented software support, not a toolkit-run inference benchmark. All five families exceed the Dell 32 GB RAM target. No throughput or exact memory minimum is fabricated. Full context can require substantially more memory than resident weight bytes.

## Sources and preserved evidence

Each variant links an immutable source revision above. `evidence/v1.0.4/` includes the candidate API trees, cards, configs, licenses when published, indexes and precision headers. The exact selected file manifest is also in `selected-files.json`; all selected weight files have upstream LFS SHA-256 metadata.

- [Z.ai model/runtime/fine-tuning guidance](https://github.com/zai-org/GLM-5): publisher model table distinguishes FP8 and BF16, and lists Slime/ms-swift.
- [Mistral upstream model card](https://huggingface.co/mistralai/Mistral-Small-4-119B-2603): tensor formats, supported context and Axolotl link.
- [MiniMax vLLM recipe](https://recipes.vllm.ai/MiniMaxAI/MiniMax-M3): MXFP8 precision/backend and serving examples.
- [MiniMax SGLang cookbook](https://docs.sglang.io/cookbook/autoregressive/MiniMax/MiniMax-M3).
- [Kimi official deployment guide](https://huggingface.co/moonshotai/Kimi-K2.7-Code/blob/74797c9c62378b951a1f6fcf5c4631024e9b8bef/docs/deploy_guidance.md): supported inference and specialized LoRA SFT.
- [Unsloth GLM-5.3-Flash guide](https://unsloth.ai/docs/models/glm-5.3-flash), [full GLM-5.3 guide](https://unsloth.ai/docs/models/glm-5.3), [Kimi guide](https://unsloth.ai/docs/models/kimi-k2.7-code).
- [llama.cpp v0.5.0](https://github.com/ggml-org/llama.cpp/releases/tag/v0.5.0), [GLM Flash PR #27754](https://github.com/ggml-org/llama.cpp/pull/27754), [MiniMax PR #24523](https://github.com/ggml-org/llama.cpp/pull/24523). Both old PRs are closed/unmerged; inspect replacement/mainline and artifact compatibility separately.
- [NVIDIA MiniMax NVFP4 alternative](https://huggingface.co/nvidia/MiniMax-M3-NVFP4), reviewed but not added.

## Individual acquisition examples

Run these commands from the extracted toolkit after `bash setup-linux.sh`. Each command is a metadata-only dry run. For interactive acquisition, remove `--dry-run`; unattended acquisition additionally requires `--yes --allow-large`. Check the mount and reserve first.

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model glm-5-3-flash-original --dry-run
```

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model glm-5-3-flash-gguf-ud-q4-k-xl --dry-run
```

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model mistral-small-4-119b-original --dry-run
```

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model mistral-small-4-119b-nvfp4 --dry-run
```

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model mistral-small-4-119b-gguf-ud-q4-k-m --dry-run
```

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model minimax-m3-original --dry-run
```

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model minimax-m3-mxfp8 --dry-run
```

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model kimi-k2-7-code-original --dry-run
```

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model kimi-k2-7-code-gguf-ud-q4-k-xl --dry-run
```

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model glm-5-3-original --dry-run
```

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model glm-5-3-gguf-ud-q4-k-xl --dry-run
```


## v1.0.4.2 addition

v1.0.4.2 adds canonical Qwen3-Coder-Next BF16 and Unsloth Q6_K. The source is preserved for architecture-aware customization/conversion; GGUF is an inference copy. See [training, runtime and workstation notes](QWEN3_CODER_NEXT.md).

## v1.0.4.3

The new [tiered preservation policy](PRESERVATION_POLICY.md) prioritizes source and inference for coding/research, inference for other capabilities, and selective general LLM source retention.
