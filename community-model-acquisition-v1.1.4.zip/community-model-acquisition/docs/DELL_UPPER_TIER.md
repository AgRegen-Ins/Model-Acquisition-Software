# Dell upper-tier testing — v1.0.3

This is a three-model acquisition profile for one-at-a-time CPU benchmarking on the i7-8700 / 32 GB Ubuntu Dell. It does not install a runtime or change existing download/verification behavior. Start at 4096 context tokens; do not automatically allocate the model maximum.

| Variant | Conversion source | Format | Selected bytes | Pin |
|---|---|---|---:|---|
| `qwen3-32b-gguf-q4-k-m` | [Qwen/Qwen3-32B-GGUF](https://huggingface.co/Qwen/Qwen3-32B-GGUF) | GGUF Q4_K_M | 19,762,168,065 | `938a7432affaec9157f883a87164e2646ae17555` |
| `gpt-oss-20b-gguf-mxfp4` | [ggml-org/gpt-oss-20b-GGUF](https://huggingface.co/ggml-org/gpt-oss-20b-GGUF) | GGUF MXFP4 | 12,109,723,097 | `ef9b12f2ff56c69cf32153a02784e7a3c88bf524` |
| `glm-4-7-flash-gguf-q4-k-m` | [unsloth/GLM-4.7-Flash-GGUF](https://huggingface.co/unsloth/GLM-4.7-Flash-GGUF) | GGUF Q4_K_M | 18,312,348,405 | `0d32489ecb9db6d2a4fc93bd27ef01519f95474d` |

Total: **50,184,239,567 bytes (50.18 GB)**. With no reusable completed files, the existing reserve calculation is 10% plus 1 GiB: about **56.28 GB** required free space. The recorded-present-file estimate and safety rules are unchanged.

## gpt-oss-20b

Selected artifact: **`gpt-oss-20b-MXFP4.gguf`**, exact case. The repository also has Eagle3 draft-model files; those are excluded. Small `.src_sha`, model card and conversion log are preserved. Repository metadata records Apache-2.0; no license file is fabricated if absent in the conversion repository. The official base is `openai/gpt-oss-20b`. ggml-org is the llama.cpp project organization, but its GGUF is still `third-party-derived` relative to OpenAI.

The publisher card describes approximately **21B total / 3.6B active** parameters. Pinned config uses `GptOssForCausalLM`, 24 layers, 32 experts, four experts/token, and alternating sliding/full attention. Configured maximum context is 131,072 using YaRN; 4096 is the initial Dell test setting. Native MXFP4 applies to MoE weights while some other tensors keep higher precision. The llama.cpp project specifically recommends retaining this representation and supports it on CPU.

The file is ~11.28 GiB. OpenAI describes the model fitting within 16 GB under supported conditions; that is not a universal allocation cap for every runtime/context. Leave memory for the OS, KV cache and compute buffers. A current compatible llama.cpp build and the **Harmony** chat format/template are required. Model acquisition does not itself provide web browsing, RAG, document rendering or a report-generation workflow. No CPU speed claim is made.

Primary references:

- https://huggingface.co/openai/gpt-oss-20b
- https://huggingface.co/ggml-org/gpt-oss-20b-GGUF
- https://github.com/ggml-org/llama.cpp/discussions/15396
- https://github.com/ggml-org/llama.cpp/discussions/15095

## GLM-4.7-Flash

Selected artifact: **`GLM-4.7-Flash-Q4_K_M.gguf`** from Unsloth, MIT license. The official publisher is Z.ai (`zai-org/GLM-4.7-Flash`), not Unsloth. The public publisher search returned the original repository only; the anticipated official GGUF URL returned 401, which alone cannot distinguish private from nonexistent. No public official GGUF was verified.

ggml-org **does** publish a conversion: its inspected tree has `GLM-4.7-Flash-Q4_K.gguf` and `GLM-4.7-Flash-Q8_0.gguf`. We do not infer that a `Q4_K` filename guarantees the requested Q4_K_M recipe. This release selects the explicitly labeled Q4_K_M from Unsloth instead. It excludes other quantizations and the optional importance-matrix generation asset. Conversion base commit identity is not asserted.

Publisher calls it **30B-A3B**; the catalog records rounded **30B total / 3B active** with that basis. Unsloth estimates roughly 3.6B active, so these figures should not be treated as exact tensor counts. Official config identifies `Glm4MoeLiteForCausalLM` (`glm4_moe_lite`), 47 layers, 64 routed experts, four routed experts/token plus a shared expert, and multi-head latent attention (MLA). Maximum configured context is **202,752**.

Q4_K_M weighs ~17.06 GiB, leaving room on 32 GB for a limited-context experiment. MoE reduces per-token active computation; it does not remove the need for the full weights. MLA cache/runtime allocation differs from ordinary GQA, so no simplistic cache-memory guarantee is claimed. Begin with one 4096-token session, close other large programs, and inspect actual runtime allocation. Large-context operation and speed on this CPU are unverified.

Use a recent llama.cpp build supporting GLM4 MoE Lite and the corrected **sigmoid** routing behavior. The converter documents an earlier routing bug that caused looping and updated GGUFs. Preserve its chat template. Converter sampling guidance includes repeat penalty 1.0 and min-p 0.01; tune other sampling settings for reasoning versus tool use. The toolkit does not enforce runtime parameters.

Primary references:

- https://huggingface.co/zai-org/GLM-4.7-Flash
- https://huggingface.co/ggml-org/GLM-4.7-Flash-GGUF
- https://huggingface.co/unsloth/GLM-4.7-Flash-GGUF
- https://unsloth.ai/docs/models/tutorials/glm-4.7-flash.md

## Existing Qwen3-32B

Same official Q4_K_M files, source, pin, notes and size as v1.0.2; only the new profile tag is appended. Treat this as an upper-tier CPU experiment with restricted context. Existing originals and every other profile membership are retained. The new GGUFs are selectable individually, through `dell-upper-tier`, or through `all`; this update intentionally does not expand the existing `dell`, `coding-local` or archival profiles.

## Dry-run and reuse evidence

Live dry runs for both new variants and the profile are in `evidence/v1.0.3/`. The profile showed exactly three variants, all pinned, and the total/new/free/reserve figures. The testing environment correctly warned that its disk was too small for the whole real download; dry-run itself succeeded and created no model root. A tiny-file fixture using the same file names verifies that matching recorded completed files reduce estimated new bytes to zero without writes. It is a planning test, not a claim that full model weights were already acquired in this workspace.
