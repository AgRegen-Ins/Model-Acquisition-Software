# Multimodal additions — v1.0.4.3

Reviewed 2026-10-11 UTC. Seven deployable inference selections cover the eight requested model/component items by grouping Qwen's required projector with its language GGUF. One extra required Vocos component supplies F5-TTS's complete inference dependency. There are eight new catalog entries, 46 total. No full-precision vision duplicate or additional audio model conversion is selected.

No real model was executed. Hub inventories and pinned cards/runtime source establish selection; no full payload hash verification was performed. Research read only safetensors headers for Chatterbox/F5 precision. PyTorch/ONNX formats with no verified dtype evidence retain explicit unknown precision/counts rather than guesses. These are tested acquisition configurations, not GPU-tested runtime bundles. Required OS/Python libraries and phonemizer package resources must be installed/preserved separately; acquisition never installs them.

| Model ID | Repository | Commit | Selected bytes | License |
|---|---|---|---:|---|
| `qwen2-5-vl-3b-instruct-gguf-q4-k-m` | `ggml-org/Qwen2.5-VL-3B-Instruct-GGUF` | `5037fcf163dd95d1e41d1974465f0898ed108ca2` | 2,774,658,784 | qwen-research |
| `whisper-large-v3-inference` | `openai/whisper-large-v3` | `06f233fe06e710322aca913c1bc4249a0d71fce1` | 3,091,541,593 | apache-2.0 |
| `whisper-large-v3-turbo-inference` | `openai/whisper-large-v3-turbo` | `41f01f3fe87f28c78e2fbf8b568835947dd65ed9` | 1,622,464,535 | mit |
| `kokoro-82m-inference` | `hexgrad/Kokoro-82M` | `f3ff3571791e39611d31c381e3a41a3af07b4987` | 328,798,830 | apache-2.0 |
| `chatterbox-tts-english-inference` | `ResembleAI/chatterbox` | `5bb1f6ee58e50c3b8d408bc82a6d3740c2db6e18` | 3,191,977,073 | mit |
| `f5-tts-vocos-mel-24khz` | `charactr/vocos-mel-24khz` | `0feb3fdd929bcd6649e0e7c5a688cf7dd012ef21` | 54,368,282 | mit |
| `f5-tts-v1-base-inference` | `SWivid/F5-TTS` | `84e5a410d9cead4de2f847e7c9369a6440bdfaca` | 1,348,450,191 | cc-by-nc-4.0 |
| `piper-english-voices-inference` | `rhasspy/piper-voices` | `c10ece1aade47bb51c153c893d14e5bf8e5b7117` | 126,413,036 | voice-specific |

## Per-model artifacts and runtime notes

### qwen2 5 vl 3b instruct gguf q4 k m

Role: `portable-gguf`; provenance: `third-party-derived`; policy: inference-only. Format/precision: GGUF / Q4_K_M + Q8_0 projector. Architecture: Qwen2_5_VLForConditionalGeneration. Total parameters: 3754622976; active parameters: not applicable/unknown.

Document pages, figures, diagrams and image interpretation; not guaranteed faithful OCR.

Load GGUF with matching --mmproj from this same pinned ggml-org repository; llama.cpp mtmd supports Qwen2.5-VL. No projector-only model family.

Small vision model; CPU possible but image resolution/context add memory. GPU useful; no measured minimum or speed claim.

Upstream Qwen Research License restricts noncommercial research/evaluation and asks commercial users to request a license. Converter card says Apache-2.0; that conflicting tag does not establish relicensing of base weights. Upstream license retained in evidence.

Capabilities: `vision-language`, `document-understanding`, `image-understanding`, `gpu-inference`.

Required selected files:

- `Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf` — 1,929,901,056 bytes
- `mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf` — 844,757,728 bytes

[Immutable repository tree](https://huggingface.co/ggml-org/Qwen2.5-VL-3B-Instruct-GGUF/tree/5037fcf163dd95d1e41d1974465f0898ed108ca2).

### whisper large v3 inference

Role: `inference-optimized`; provenance: `official-upstream`; policy: inference-only. Format/precision: Safetensors / FP16. Architecture: WhisperForConditionalGeneration. Total parameters: 1543490560; active parameters: not applicable/unknown.

Multilingual offline audio transcription with timestamp-capable decoding.

Use local AutoProcessor and AutoModelForSpeechSeq2Seq with local_files_only=True. These are Transformers Safetensors, not whisper.cpp GGML or faster-whisper CTranslate2 artifacts; conversion required for those engines. Resample input to 16 kHz; chunk long recordings; timestamps are estimates.

GPU recommended for throughput; CPU supported with appropriate float32 runtime casting. Memory exceeds checkpoint bytes; no exact minimum tested.

Selected repository card declaration; original OpenAI Whisper code/checkpoints use MIT. large-v3 HF card declares Apache-2.0; preserve both evidence sources.

Multilingual Whisper vocabulary (~100 languages). Turbo has 4 decoder layers instead of 32, trades some accuracy for speed and is not trained for speech translation; use transcribe.

Audio sample rate: 16,000 Hz.

Capabilities: `speech-recognition`, `audio-transcription`, `multilingual-transcription`, `cpu-inference`, `gpu-inference`.

Required selected files:

- `README.md` — 21,829 bytes
- `added_tokens.json` — 34,648 bytes
- `config.json` — 1,272 bytes
- `generation_config.json` — 3,903 bytes
- `merges.txt` — 493,869 bytes
- `model.safetensors` — 3,087,130,976 bytes
- `normalizer.json` — 52,666 bytes
- `preprocessor_config.json` — 340 bytes
- `special_tokens_map.json` — 2,072 bytes
- `tokenizer.json` — 2,480,617 bytes
- `tokenizer_config.json` — 282,843 bytes
- `vocab.json` — 1,036,558 bytes

[Immutable repository tree](https://huggingface.co/openai/whisper-large-v3/tree/06f233fe06e710322aca913c1bc4249a0d71fce1).

### whisper large v3 turbo inference

Role: `inference-optimized`; provenance: `official-upstream`; policy: inference-only. Format/precision: Safetensors / FP16. Architecture: WhisperForConditionalGeneration. Total parameters: 808878080; active parameters: not applicable/unknown.

Multilingual offline audio transcription with timestamp-capable decoding.

Use local AutoProcessor and AutoModelForSpeechSeq2Seq with local_files_only=True. These are Transformers Safetensors, not whisper.cpp GGML or faster-whisper CTranslate2 artifacts; conversion required for those engines. Resample input to 16 kHz; chunk long recordings; timestamps are estimates.

GPU recommended for throughput; CPU supported with appropriate float32 runtime casting. Memory exceeds checkpoint bytes; no exact minimum tested.

Selected repository card declaration; original OpenAI Whisper code/checkpoints use MIT. large-v3 HF card declares Apache-2.0; preserve both evidence sources.

Multilingual Whisper vocabulary (~100 languages). Turbo has 4 decoder layers instead of 32, trades some accuracy for speed and is not trained for speech translation; use transcribe.

Audio sample rate: 16,000 Hz.

Capabilities: `speech-recognition`, `audio-transcription`, `multilingual-transcription`, `cpu-inference`, `gpu-inference`.

Required selected files:

- `README.md` — 21,196 bytes
- `added_tokens.json` — 34,648 bytes
- `config.json` — 1,256 bytes
- `generation_config.json` — 3,772 bytes
- `merges.txt` — 493,869 bytes
- `model.safetensors` — 1,617,824,864 bytes
- `normalizer.json` — 52,666 bytes
- `preprocessor_config.json` — 340 bytes
- `special_tokens_map.json` — 2,186 bytes
- `tokenizer.json` — 2,710,337 bytes
- `tokenizer_config.json` — 282,843 bytes
- `vocab.json` — 1,036,558 bytes

[Immutable repository tree](https://huggingface.co/openai/whisper-large-v3-turbo/tree/41f01f3fe87f28c78e2fbf8b568835947dd65ed9).

### kokoro 82m inference

Role: `inference-optimized`; provenance: `official-upstream`; policy: inference-only. Format/precision: PyTorch / unknown (PyTorch checkpoint; not deserialized during research). Architecture: StyleTTS2-derived Kokoro / ISTFTNet. Total parameters: 82000000; active parameters: not applicable/unknown.

Non-cloned English audiobook and article narration.

Use local KModel(config=..., model=...) and pass explicit local voice .pt path; English Misaki G2P needs its package resources, spaCy en_core_web_sm and espeak-ng fallback installed separately. For strictly offline phoneme input use generate_from_tokens. Runtime packages/data are not auto-installed.

82M-class CPU-capable TTS; model+voice data selected. No throughput guarantee.

Selected voices cover US/UK English. Other supported languages/voices intentionally not selected.

Audio sample rate: 24,000 Hz.

Capabilities: `text-to-speech`, `audiobook-narration`, `cpu-inference`, `gpu-inference`.

Required selected files:

- `README.md` — 6,348 bytes
- `VOICES.md` — 7,625 bytes
- `config.json` — 2,351 bytes
- `kokoro-v1_0.pth` — 327,212,226 bytes
- `voices/af_heart.pt` — 523,425 bytes
- `voices/am_michael.pt` — 523,435 bytes
- `voices/bf_emma.pt` — 523,420 bytes

[Immutable repository tree](https://huggingface.co/hexgrad/Kokoro-82M/tree/f3ff3571791e39611d31c381e3a41a3af07b4987).

### chatterbox tts english inference

Role: `inference-optimized`; provenance: `official-upstream`; policy: inference-only. Format/precision: Safetensors + PyTorch conditioning / FP32 safetensors plus integer state; builtin conditioning .pt not deserialized. Architecture: T3 text-to-speech transformer, S3Gen flow vocoder, VoiceEncoder. Total parameters: unknown / not independently established; active parameters: not applicable/unknown.

Expressive English TTS with optional locally authorized reference voice.

Select original English ChatterboxTTS, not multilingual or Turbo. from_local uses all selected safetensors, tokenizer and publisher builtin conds.pt. Runtime applies Perth watermarking. User reference audio is an optional inference input kept outside registry.

GPU recommended; runtime supports CPU/MPS paths. No measured VRAM minimum.

English variant; 23-language multilingual files deliberately excluded.

Audio sample rate: 24,000 Hz.

Capabilities: `text-to-speech`, `audiobook-narration`, `voice-cloning`, `voice-conditioning`, `gpu-inference`.

Required selected files:

- `README.md` — 10,081 bytes
- `conds.pt` — 107,374 bytes
- `s3gen.safetensors` — 1,056,484,620 bytes
- `t3_cfg.safetensors` — 2,129,653,744 bytes
- `tokenizer.json` — 25,470 bytes
- `ve.safetensors` — 5,695,784 bytes

[Immutable repository tree](https://huggingface.co/ResembleAI/chatterbox/tree/5bb1f6ee58e50c3b8d408bc82a6d3740c2db6e18).

### f5 tts vocos mel 24khz

Role: `inference-optimized`; provenance: `official-upstream`; policy: inference-only. Format/precision: PyTorch / unknown (not deserialized). Architecture: VocosBackbone / ISTFTHead. Total parameters: unknown / not independently established; active parameters: not applicable/unknown.

Required 24 kHz / 100-mel vocoder component for F5TTS_v1_Base; not a standalone TTS model.

F5 load_vocoder(vocoder_name="vocos", is_local=True, local_path=PAYLOAD); config.yaml and pytorch_model.bin both required.

Small companion; shares parent runtime.

Audio sample rate: 24,000 Hz.

Capabilities: `multimodal-component`.

Required selected files:

- `README.md` — 1,830 bytes
- `config.yaml` — 461 bytes
- `pytorch_model.bin` — 54,365,991 bytes

[Immutable repository tree](https://huggingface.co/charactr/vocos-mel-24khz/tree/0feb3fdd929bcd6649e0e7c5a688cf7dd012ef21).

### f5 tts v1 base inference

Role: `inference-optimized`; provenance: `official-upstream`; policy: inference-only. Format/precision: Safetensors / FP32 (see tensor header evidence). Architecture: DiT conditional flow matching. Total parameters: 337096836; active parameters: not applicable/unknown.

English/Chinese reference-audio and transcript-conditioned synthesis.

Use the F5TTS_v1_Base config supplied by pinned SWivid runtime (in evidence), local checkpoint/vocab, and local Vocos. Supply reference transcript explicitly to avoid automatic ASR model downloads. User reference audio/transcripts are not archive artifacts.

GPU preferred; no measured VRAM minimum. Reference audio and text are separately controlled runtime inputs.

Model weights CC-BY-NC-4.0 (noncommercial, attribution); runtime code MIT does not relicense weights.

English and Chinese base checkpoint.

Audio sample rate: 24,000 Hz.

Capabilities: `text-to-speech`, `voice-cloning`, `voice-conditioning`, `gpu-inference`.

Required selected files:

- `F5TTS_v1_Base/model_1250000.safetensors` — 1,348,435,761 bytes
- `F5TTS_v1_Base/vocab.txt` — 13,800 bytes
- `README.md` — 630 bytes

[Immutable repository tree](https://huggingface.co/SWivid/F5-TTS/tree/84e5a410d9cead4de2f847e7c9369a6440bdfaca).

### piper english voices inference

Role: `inference-optimized`; provenance: `official-upstream`; policy: inference-only. Format/precision: ONNX + JSON / ONNX checkpoint precision unverified without loading. Architecture: VITS voice models. Total parameters: unknown / not independently established; active parameters: not applicable/unknown.

Lightweight CPU narration using two individually identified voices.

Use each ONNX with its same-name .onnx.json configuration. Install Piper separately; current OHF engine is GPL-3.0, distinct from voice/dataset licenses. espeak-ng phonemization/runtime resources required.

CPU-oriented medium voices; no GPU required.

Repository MIT label is not a substitute for voice-specific dataset terms. lessac license: https://www.cstr.ed.ac.uk/projects/blizzard/2013/lessac_blizzard2013/license.html ; alba CC-BY-4.0. Model cards do not supply separate complete weight-license grants; operator review needed.

Audio sample rate: 22,050 Hz.

Capabilities: `text-to-speech`, `audiobook-narration`, `cpu-inference`.

Required selected files:

- `en/en_GB/alba/medium/MODEL_CARD` — 324 bytes
- `en/en_GB/alba/medium/en_GB-alba-medium.onnx` — 63,201,294 bytes
- `en/en_GB/alba/medium/en_GB-alba-medium.onnx.json` — 4,888 bytes
- `en/en_US/lessac/medium/MODEL_CARD` — 351 bytes
- `en/en_US/lessac/medium/en_US-lessac-medium.onnx` — 63,201,294 bytes
- `en/en_US/lessac/medium/en_US-lessac-medium.onnx.json` — 4,885 bytes

[Immutable repository tree](https://huggingface.co/rhasspy/piper-voices/tree/c10ece1aade47bb51c153c893d14e5bf8e5b7117).

## Deliberate choices and unresolved limits

Whisper uses each official Transformers Safetensors export once, including tokenizer, processor and generation config. Large-v3 supports multilingual transcription and translation with appropriate decoding; turbo has a shallower decoder and favors transcription speed, with an accuracy tradeoff and no equivalent translation claim. whisper.cpp and faster-whisper require different containers/conversion, so this release does not silently download them too. Long audio needs chunking/overlap and timestamp review.

Qwen2.5-VL GGUF and Q8_0 projector are from one pinned ggml-org repository, which llama.cpp's maintained mtmd documentation identifies as a supported architecture. That establishes a reproducible matched artifact source, not a GPU execution test or proof of the user's historical file identity. The converter's Apache label conflicts with the upstream Qwen Research License; the latter is retained explicitly. Do not assume commercial use is authorized by the converter tag.

Kokoro selects public US English af_heart/am_michael and UK English bf_emma voices, plus core/config. Its integrated vocoder needs no separate vocoder checkpoint. Misaki/espeak-ng and spaCy English language resources are runtime requirements. Existing local voice paths prevent lazy voice downloads. Raw phoneme input is available through generate_from_tokens when preparing a strictly offline pipeline.

Chatterbox selects the original English implementation's exact from_local file set, including the publisher default conditioning file, not multilingual or Turbo weights. The 0.5B advertised count describes T3 rather than the whole system. Reference voice audio is supplied independently and never registered automatically. Runtime watermarking is retained; this toolkit does not remove it.

F5TTS_v1_Base selects the explicit Vocos configuration and vocabulary; its runtime config is preserved as inert evidence from the pinned SWivid source. `load_vocoder(is_local=True, local_path=...)` must point to the managed Vocos payload. Supply reference text to avoid implicit Whisper downloads. Its CC-BY-NC weights are distinct from MIT runtime code. No user's voice/transcript is required in the archive.

Piper is an engine and voice ecosystem. Only lessac medium and alba medium ONNX/config/model-card sets are selected. Dataset-specific voice terms are preserved; the repository MIT label and current GPL-3.0 engine must not be conflated with them. The upstream voice cards do not independently supply a complete, uniform weights-license grant; review the linked dataset terms before a deployment involving rights beyond personal evaluation. No replacement voices were silently substituted.

No real historical `~/vision-models/qwen2.5-vl-3b/` files were available in this execution environment. Their identity, hashes, custody and upstream match await operator registration on the host holding them. No existing file is declared verified based on the historical description.

## Pinned runtime evidence

- [resemble-ai/chatterbox @ 5de7a54aa4e5e2baadb0182dde554908b48b85c2](https://github.com/resemble-ai/chatterbox/tree/5de7a54aa4e5e2baadb0182dde554908b48b85c2) — reviewed source snapshots in `evidence/v1.0.4.3/runtime/`.
- [SWivid/F5-TTS @ d852486451313ab31924303f6120e1aa19a208ce](https://github.com/SWivid/F5-TTS/tree/d852486451313ab31924303f6120e1aa19a208ce) — reviewed source snapshots in `evidence/v1.0.4.3/runtime/`.
- [hexgrad/kokoro @ dfb907a02bba8152ca444717ca5d78747ccb4bec](https://github.com/hexgrad/kokoro/tree/dfb907a02bba8152ca444717ca5d78747ccb4bec) — reviewed source snapshots in `evidence/v1.0.4.3/runtime/`.
- [OHF-Voice/piper1-gpl @ 35b0f1ec67b289de553555645140e48f1f104b2d](https://github.com/OHF-Voice/piper1-gpl/tree/35b0f1ec67b289de553555645140e48f1f104b2d) — reviewed source snapshots in `evidence/v1.0.4.3/runtime/`.
- [openai/whisper @ 86098128c0b4f24f0e2aa2994de830614b474227](https://github.com/openai/whisper/tree/86098128c0b4f24f0e2aa2994de830614b474227) — reviewed source snapshots in `evidence/v1.0.4.3/runtime/`.
- [ggml-org/llama.cpp @ 5c8854fd88319125125dc4b836c98b1b215b0f23](https://github.com/ggml-org/llama.cpp/tree/5c8854fd88319125125dc4b836c98b1b215b0f23) — reviewed source snapshots in `evidence/v1.0.4.3/runtime/`.
