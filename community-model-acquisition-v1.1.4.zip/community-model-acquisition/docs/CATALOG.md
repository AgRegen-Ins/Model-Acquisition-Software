# Catalog — v1.0.4.2

New entries reviewed 2026-10-03 UTC. Decimal GB; selected bytes differ from whole multi-quant GGUF repository size. Exact filenames, sizes and upstream hashes are retained in `evidence/v1.0.4/*/api.json` and catalog `required`. Existing entries retain their earlier review dates.

| Variant ID | Source repository | License | Selected GB | Pinned commit |
|---|---|---|---:|---|
| `bge-m3-original` | [BAAI/bge-m3](https://huggingface.co/BAAI/bge-m3) | mit | 2.298 | `5617a9f61b028005a4858fdac845db406aefb181` |
| `bge-reranker-v2-m3-original` | [BAAI/bge-reranker-v2-m3](https://huggingface.co/BAAI/bge-reranker-v2-m3) | apache-2.0 | 2.294 | `953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e` |
| `qwen2-5-coder-1-5b-instruct-gguf-q4-k-m` | [Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF](https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF) | apache-2.0 | 1.117 | `f86cb2c1fa58255f8052cc32aeede1b7482d4361` |
| `qwen2-5-coder-1-5b-instruct-original` | [Qwen/Qwen2.5-Coder-1.5B-Instruct](https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct) | apache-2.0 | 3.099 | `2e1fd397ee46e1388853d2af2c993145b0f1098a` |
| `qwen2-5-coder-7b-instruct-gguf-q4-k-m` | [Qwen/Qwen2.5-Coder-7B-Instruct-GGUF](https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct-GGUF) | apache-2.0 | 4.683 | `13fb94bfda8c8cf22497dc57b78f391a9acb426a` |
| `qwen2-5-coder-7b-instruct-original` | [Qwen/Qwen2.5-Coder-7B-Instruct](https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct) | apache-2.0 | 15.243 | `c03e6d358207e414f1eca0bb1891e29f1db0e242` |
| `qwen3-14b-gguf-q4-k-m` | [Qwen/Qwen3-14B-GGUF](https://huggingface.co/Qwen/Qwen3-14B-GGUF) | apache-2.0 | 9.002 | `530227a7d994db8eca5ab5ced2fb692b614357fd` |
| `qwen3-14b-original` | [Qwen/Qwen3-14B](https://huggingface.co/Qwen/Qwen3-14B) | apache-2.0 | 29.553 | `40c069824f4251a91eefaf281ebe4c544efd3e18` |
| `qwen3-32b-gguf-q4-k-m` | [Qwen/Qwen3-32B-GGUF](https://huggingface.co/Qwen/Qwen3-32B-GGUF) | apache-2.0 | 19.762 | `938a7432affaec9157f883a87164e2646ae17555` |
| `qwen3-32b-original` | [Qwen/Qwen3-32B](https://huggingface.co/Qwen/Qwen3-32B) | apache-2.0 | 65.540 | `9216db5781bf21249d130ec9da846c4624c16137` |
| `qwen3-4b-gguf-q4-k-m` | [Qwen/Qwen3-4B-GGUF](https://huggingface.co/Qwen/Qwen3-4B-GGUF) | apache-2.0 | 2.497 | `bc640142c66e1fdd12af0bd68f40445458f3869b` |
| `qwen3-4b-original` | [Qwen/Qwen3-4B](https://huggingface.co/Qwen/Qwen3-4B) | apache-2.0 | 8.061 | `1cfa9a7208912126459214e8b04321603b3df60c` |
| `qwen3-8b-gguf-q4-k-m` | [Qwen/Qwen3-8B-GGUF](https://huggingface.co/Qwen/Qwen3-8B-GGUF) | apache-2.0 | 5.028 | `7c41481f57cb95916b40956ab2f0b139b296d974` |
| `qwen3-8b-original` | [Qwen/Qwen3-8B](https://huggingface.co/Qwen/Qwen3-8B) | apache-2.0 | 16.397 | `b968826d9c46dd6066d109eabc6255188de91218` |
| `qwen3-coder-480b-a35b-instruct-original` | [Qwen/Qwen3-Coder-480B-A35B-Instruct](https://huggingface.co/Qwen/Qwen3-Coder-480B-A35B-Instruct) | apache-2.0 | 960.328 | `9d90cf8fca1bf7b7acca42d3fc9ae694a2194069` |
| `deepseek-v4-flash-original` | [deepseek-ai/DeepSeek-V4-Flash](https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash) | mit | 159.630 | `60d8d70770c6776ff598c94bb586a859a38244f1` |
| `gpt-oss-120b-original` | [openai/gpt-oss-120b](https://huggingface.co/openai/gpt-oss-120b) | apache-2.0 | 65.277 | `b5c939de8f754692c1647ca79fbf85e8c1e70f8a` |
| `gpt-oss-20b-original` | [openai/gpt-oss-20b](https://huggingface.co/openai/gpt-oss-20b) | apache-2.0 | 13.789 | `6cee5e81ee83917806bbde320786a8fb61efebee` |
| `glm-4-7-flash-original` | [zai-org/GLM-4.7-Flash](https://huggingface.co/zai-org/GLM-4.7-Flash) | mit | 62.465 | `7dd20894a642a0aa287e9827cb1a1f7f91386b67` |
| `qwen2-5-coder-14b-instruct-original` | [Qwen/Qwen2.5-Coder-14B-Instruct](https://huggingface.co/Qwen/Qwen2.5-Coder-14B-Instruct) | apache-2.0 | 29.552 | `aedcc2d42b622764e023cf882b6652e646b95671` |
| `qwen2-5-coder-14b-instruct-gguf-q4-k-m` | [Qwen/Qwen2.5-Coder-14B-Instruct-GGUF](https://huggingface.co/Qwen/Qwen2.5-Coder-14B-Instruct-GGUF) | apache-2.0 | 8.988 | `d0a692ef765eefbf2fabb130b3cb2e8917e3d225` |
| `qwen3-coder-30b-a3b-instruct-original` | [Qwen/Qwen3-Coder-30B-A3B-Instruct](https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct) | apache-2.0 | 61.080 | `b2cff646eb4bb1d68355c01b18ae02e7cf42d120` |
| `qwen3-coder-30b-a3b-instruct-gguf-q4-k-m` | [unsloth/Qwen3-Coder-30B-A3B-Instruct-GGUF](https://huggingface.co/unsloth/Qwen3-Coder-30B-A3B-Instruct-GGUF) | apache-2.0 | 18.557 | `b17cb02dd882d5b6ab62fc777ad2995f19668350` |
| `gpt-oss-20b-gguf-mxfp4` | [ggml-org/gpt-oss-20b-GGUF](https://huggingface.co/ggml-org/gpt-oss-20b-GGUF) | apache-2.0 | 12.110 | `ef9b12f2ff56c69cf32153a02784e7a3c88bf524` |
| `glm-4-7-flash-gguf-q4-k-m` | [unsloth/GLM-4.7-Flash-GGUF](https://huggingface.co/unsloth/GLM-4.7-Flash-GGUF) | mit | 18.312 | `0d32489ecb9db6d2a4fc93bd27ef01519f95474d` |
| `glm-5-3-flash-original` | [zai-org/GLM-5.3-Flash-BF16](https://huggingface.co/zai-org/GLM-5.3-Flash-BF16) | mit | 642.676 | `a5b45eb41df6402735dedc900be14a42e8d5e538` |
| `glm-5-3-flash-gguf-ud-q4-k-xl` | [unsloth/GLM-5.3-Flash-GGUF](https://huggingface.co/unsloth/GLM-5.3-Flash-GGUF) | mit | 200.871 | `621d456e93e926e4b52f85cff5f634358c1828f9` |
| `mistral-small-4-119b-original` | [mistralai/Mistral-Small-4-119B-2603](https://huggingface.co/mistralai/Mistral-Small-4-119B-2603) | apache-2.0 | 241.890 | `a11f36bebf709121056b1dbcc943d1c6afbe494d` |
| `mistral-small-4-119b-nvfp4` | [mistralai/Mistral-Small-4-119B-2603-NVFP4](https://huggingface.co/mistralai/Mistral-Small-4-119B-2603-NVFP4) | apache-2.0 | 70.847 | `45331841b631f4e281df8e959ea3cc9beb84298a` |
| `mistral-small-4-119b-gguf-ud-q4-k-m` | [unsloth/Mistral-Small-4-119B-2603-GGUF](https://huggingface.co/unsloth/Mistral-Small-4-119B-2603-GGUF) | apache-2.0 | 74.620 | `bd93c721735aa32c035c0f19e738cb3371fd56ff` |
| `minimax-m3-original` | [MiniMaxAI/MiniMax-M3](https://huggingface.co/MiniMaxAI/MiniMax-M3) | minimax-community | 854.201 | `f0e1c1e04d40177e4673a22097036854f536e9c0` |
| `minimax-m3-mxfp8` | [MiniMaxAI/MiniMax-M3-MXFP8](https://huggingface.co/MiniMaxAI/MiniMax-M3-MXFP8) | minimax-community | 443.776 | `c5454eb03678d8710e54a4e0fc681b9f3b4a3dba` |
| `kimi-k2-7-code-original` | [moonshotai/Kimi-K2.7-Code](https://huggingface.co/moonshotai/Kimi-K2.7-Code) | modified-mit | 595.205 | `74797c9c62378b951a1f6fcf5c4631024e9b8bef` |
| `kimi-k2-7-code-gguf-ud-q4-k-xl` | [unsloth/Kimi-K2.7-Code-GGUF](https://huggingface.co/unsloth/Kimi-K2.7-Code-GGUF) | modified-mit | 584.663 | `46352ca8dc32aa60f9754f5bd3fb778deeb9e430` |
| `glm-5-3-original` | [zai-org/GLM-5.3-BF16](https://huggingface.co/zai-org/GLM-5.3-BF16) | glm-5.3 | 1,506.693 | `9d2398f478cab2de883137db3a36ad2c96205e24` |
| `glm-5-3-gguf-ud-q4-k-xl` | [unsloth/GLM-5.3-GGUF](https://huggingface.co/unsloth/GLM-5.3-GGUF) | glm-5.3 | 467.289 | `346b3591c7f28d1a23716f97a065ecf12ec14771` |

## Profile totals

| Profile | Variants | Selected GB |
|---|---:|---:|
| small-cpu | 2 | 3.615 |
| dell | 7 | 26.918 |
| coding | 12 | 1,390.102 |
| retrieval | 2 | 4.591 |
| future | 15 | 1,669.152 |
| all | 46 | 7,514.922 |
| coding-local | 4 | 33.345 |
| coding-archive | 7 | 1,291.143 |
| dell-upper-tier | 3 | 50.184 |
| agentic-core-originals | 5 | 3,840.664 |
| agentic-core-runnable | 5 | 1,767.446 |
| research-agent | 4 | 1,182.783 |
| coding-agent | 3 | 856.381 |
| preservation-source-weights | 21 | 5,494.646 |
| coding-workstation | 2 | 84.171 |
| document-vision | 1 | 2.775 |
| audio-transcription | 2 | 4.714 |
| audiobook-narration | 2 | 0.455 |
| voice-customization | 3 | 4.595 |
| multimodal-core | 3 | 4.726 |
| multimodal-preservation | 8 | 12.539 |

## Representation choices

Earlier Qwen GGUF entries select Q4_K_M; Next selects Q6_K. For the earlier entries, the Coder 7B repository contains both split and unsplit copies, so the unsplit file is selected. Original Qwen, GLM, and DeepSeek entries preserve their upstream file trees. gpt-oss entries omit `original/` and `metal/` alternate exports and preserve the primary Safetensors representation. BGE-M3 keeps its PyTorch weights and auxiliary sparse/ColBERT heads but omits the redundant ONNX export. BGE-reranker-v2-m3 preserves its Safetensors representation.

The 19 original entries are retained; v1.0.3 adds only the Dell-upper-tier profile tag to the existing Qwen3-32B GGUF. v1.0.2 adds three official-source entries and one explicitly third-party-derived Unsloth GGUF. The catalog distinguishes `official-upstream`, `official-derived`, and `third-party-derived`. Upstream model cards, licenses, and runtime requirements can evolve; pinned revisions document the intended baseline.

DeepSeek-V4-Flash and GLM-4.7-Flash were directly confirmed under `deepseek-ai` and `zai-org`, respectively; no substitute model names were necessary.

Detailed new model metadata, full pinned commits, available quantizations, and CPU-memory assumptions: [CODING_ADDITIONS.md](CODING_ADDITIONS.md).

The two v1.0.3 conversions are also `third-party-derived`: ggml-org for gpt-oss and Unsloth for GLM. Full selection details: [DELL_UPPER_TIER.md](DELL_UPPER_TIER.md).


## v1.0.4 metadata

Optional capabilities, variant_role, preservation_priority, precision, runtime and canonical-source relationships are described in [PROVENANCE.md](PROVENANCE.md). New profiles and explicit memberships are in [PROFILES.md](PROFILES.md). Full addition details are in [PRESERVATION_ADDITIONS.md](PRESERVATION_ADDITIONS.md).

## v1.0.4.2 addition

Two Qwen3-Coder-Next variants added in v1.0.4.2; all prior entries unchanged. See [exact files, pins, bytes and capabilities](QWEN3_CODER_NEXT.md).

- `qwen3-coder-next-original` — `Qwen/Qwen3-Coder-Next` @ `a7fbcb5c0e12d62a448eaa0e260346bf5dcc0feb`; 159,376,351,965 bytes; `apache-2.0`.

- `qwen3-coder-next-gguf-q6-k` — `unsloth/Qwen3-Coder-Next-GGUF` @ `ce09c67b53bc8739eef83fe67b2f5d293c270632`; 65,614,001,999 bytes; `apache-2.0`.

## v1.0.4.3

See [multimodal entries, exact pins and files](MULTIMODAL_ADDITIONS.md). All 38 v1.0.4.2 entries are unchanged; total 46 entries. Policy overlays avoid editing existing identities.


## v1.0.4.4 scientific additions

Current catalog: 50 variants. Four new entries only; all 46 v1.0.4.3 JSON values preserved. See [exact files, pins, sizes and metadata](SCIENTIFIC_MODELS.md). No schema change. `canonical-source` is descriptive role metadata; policies remain in the existing overlay. Acquisition status is observed by inventory, never fabricated in the catalog.


## v1.0.4.5

Current catalog has 51 entries. Exactly one new gpt-oss GGUF; all 50 previous entries remain identical. See [exact artifact and source relationship](GPT_OSS_120B_GGUF.md).
# v1.0.4.6 reasoning additions

The same schema now contains 53 entries: 51 unchanged plus Qwen3-Next Thinking Q6_K and GLM-4.5-Air Q4_K_M. Exact selections, pins, provenance, tensor/header evidence and storage totals are documented in [REASONING_GGUF_V1046.md](REASONING_GGUF_V1046.md). No new catalog system or acquisition behavior. `selected_files` records the reviewed metadata; existing acquisition resolves the immutable repository and verifies upstream size/hashes. `include` and `required` both list every exact selected filename. Historical catalog notes below remain historical.

# v1.0.4.7 catalog additions

55 entries using the same schema: 53 unchanged plus two explicit Huihui-derived Q4_K_M inference variants. [Exact artifact manifest and provenance](HUIHUI_MODELS_V1047.md). Historical sections below apply to their named releases.

