# Provenance, roles and customization — v1.0.4

The archive intentionally keeps more than one variant of a model: the publisher’s canonical release is the preservation reference, official quantizations serve precision-specific deployment, and community GGUFs provide portability. Compression may discard information; expanding a quantized tensor to BF16 does not recreate the original unquantized weights.

## Independent metadata axes

All new fields are optional schema-1 metadata. Existing catalog entries need not be rewritten. The toolkit preserves entry metadata in acquisition manifests; existing inventory formats/columns are unchanged in this release. Inspect the catalog or manifest for the new fields.

| Field | Meaning |
|---|---|
| `category` | Existing directory category, retained for compatibility |
| `capabilities` | Multiple task/use-case labels; not a benchmark ranking or guarantee |
| `variant_role` | `source-weights`, `official-quantized`, or `portable-gguf` in this release; `inference-optimized`/`archival` can describe later entries |
| `preservation_priority` | `core`, `high`, `normal`, or `experimental`; archival metadata only, no scheduling/deletion/safety effect |
| `source_kind` | `official-upstream`, `official-derived`, or `third-party-derived` |
| `canonical_source_repository`, `canonical_source_revision` | The archive’s chosen canonical checkpoint; not evidence of the converter’s input commit |
| `base_model` | Published upstream family relationship |
| `conversion_base_revision` | Null when an immutable converter-input commit was not documented; never inferred from latest main |
| `quantizer_converter` | Publisher/converter named by source evidence, separate from hosting publisher |
| `tensor_precision`, `upstream_quantization_config` | Actual representation, including mixed tensors and packed formats |
| `hub_tensor_dtype_counts` | Hub storage metadata, not universally a parameter count (especially packed quantization) |
| `repository_total_bytes`, `estimated_bytes` | Whole repository versus selected download bytes at the pinned revision |
| `multimodal_artifacts` | Separate required GGUF projector, or source processor/tokenizer/code components; integrated vision weights remain in source shards |
| `recommended_runtime`, `llama_cpp_support`, `vllm_support`, `sglang_support` | Artifact-specific guidance, not toolkit-installed software |
| `minimum_memory_note`, `preferred_hardware` | Qualitative/attributed hardware guidance; no fabricated exact minimum |
| `cpu_practical` | False for these archive targets on the current 32 GB Dell; does not claim CPU execution is impossible on future servers |
| `gpu_practical` | `future-hardware` for these entries |
| `multi_gpu_expected`, `experimental_runtime_notes` | Hardware expectation and explicit runtime exceptions |
| `training_suitability` | Tooling/precision caveats rather than an assumption that all upstream releases are easy to train |

Capabilities used include general-chat, reasoning, research, agentic-research, agentic-coding, software-engineering, long-horizon-agent, tool-use, function-calling, multimodal, vision, long-context, report-writing, code-generation, code-review, repository-scale-coding, fine-tuning-source, re-quantization-source, inference-optimized and experimental-runtime. Retrieval/reranking remain available concepts in existing categories. Tags describe documented capabilities or intended archive workflows; they do not prove performance. `fine-tuning-source` indicates preservation intent and must be read with `training_suitability`.

## Source versus deployment

- **GLM source copies:** dedicated official BF16 repositories preserve BF16 weights and F32 exceptions. Main repositories are optimized FP8/BF16/F32. Publisher GLM-series Slime/ms-swift guidance supports investigation of fine-tuning; exact version/model compatibility still needs validation.
- **Mistral source copy:** canonical release is mixed FP8/BF16. The publisher links Axolotl training examples. NVFP4 is a distinct official deployment checkpoint; it is not labeled source or GGUF.
- **MiniMax source copy:** BF16/F32 archive with code/processors and integrated image/video tensors. Compatible MSA-aware training code is required; no specific LoRA/QLoRA training recipe was verified. Official MXFP8 is deployment-oriented.
- **Kimi source copy:** canonical native INT4 release with BF16 and F32 exceptions. Official documentation supplies a specialized KTransformers/LLaMA-Factory LoRA path. Canonical does not mean lossless pre-quantization BF16, or universal continued-training support.
- **GGUF copies:** Unsloth conversions are `third-party-derived` even when linked by a publisher. They are inference-oriented; preserving them does not replace canonical sources for adapter training, re-quantization, conversion or research. This release has not run training or inference.

Source files and license notices are retained. No repository code is executed by the acquisition toolkit. No claim is made that the archive includes complete training data, optimizer states, pretraining checkpoints or every external runtime dependency.

## License summary

The preserved license text at the pinned revision governs; these are operational summaries.

| Family | License | Notable conditions |
|---|---|---|
| GLM-5.3-Flash | MIT | Preserve copyright/permission notices |
| Mistral Small 4 | Apache-2.0 | Preserve applicable notices and comply with Apache terms |
| MiniMax-M3 | MiniMax Community License | Commercial use requires attribution and a one-time notice; products/services above US$20M annual revenue require prior written authorization. Includes prohibited uses, notably military purposes, unlawful content, harm to minors, harmful misinformation and discrimination |
| Kimi-K2.7-Code | Modified MIT | Above 100M monthly active users or US$20M monthly revenue, applicable commercial products/services must display Kimi K2.7 Code attribution |
| GLM-5.3 full | GLM-5.3 custom license | Not plain MIT. Model-as-a-Service operators and affiliates exceeding US$10B aggregate revenue over any consecutive 12 months require Z.ai security review before commercial use; retain notices and comply with law |

Original and derived copies retain the upstream model license obligations. Provenance labels do not grant extra permissions. The toolkit does not accept licenses on the user’s behalf or bypass repository access controls.

## v1.0.4.2 addition

Qwen3-Coder-Next BF16 is `official-upstream` / `source-weights`; Unsloth Q6_K is `third-party-derived` / `portable-gguf`. Both carry the declared Apache-2.0 license. The converter input revision is unknown, distinct from the pinned preserved canonical source. See [evidence and limitations](QWEN3_CODER_NEXT.md).

## v1.0.4.3

See [registry trust and custody](CROSS_PROJECT_REGISTRY.md) and [model/license notes](MULTIMODAL_ADDITIONS.md). Local SHA-256 is identity evidence, not proof of matching trusted upstream bytes.


## v1.0.4.4 scientific provenance

OpenSciLM and FutureHouse canonical entries are official-upstream; Bartowski and redponike GGUFs are third-party-derived. Converter source commit is unknown and is recorded as such; current canonical pins are not claimed to be their exact tensor inputs. OpenScholar licensing conflict remains explicit. [Technical and licensing evidence](SCIENTIFIC_MODELS.md).


## v1.0.4.5

ggml-org is the llama.cpp project organization; its conversion is third-party-derived, not OpenAI upstream. `.src_sha` PRIMARY matches the existing official checkpoint revision. [Mixed precision, license and verification limits](GPT_OSS_120B_GGUF.md). 
# v1.0.4.6 provenance additions

Qwen's own Thinking Q6_K GGUF is `official-derived`; ggml-org's GLM-4.5-Air conversion is `third-party-derived`, not Z.ai source weights. Both are `portable-gguf`, inference-oriented. GLM records its conversion source commit; Qwen's original repository revision at review is only a documentation snapshot, not a claimed conversion source commit. See [artifact evidence](REASONING_GGUF_V1046.md). Existing provenance values are unchanged.

# v1.0.4.7 provenance

The Huihui repositories are the community modifier's sources, not official Z.ai/Qwen checkpoints. Selected mradermacher/RoadToNowhere GGUFs are both `third-party-derived`. Exact GGUF commits are pinned; source/base revisions at review are explicitly documentation snapshots because exact conversion-source commits are not supplied. [Details and access limitations](HUIHUI_MODELS_V1047.md).

