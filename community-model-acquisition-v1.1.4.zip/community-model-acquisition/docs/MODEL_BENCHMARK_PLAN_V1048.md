# Comparative benchmark plan — v1.0.4.8

Documentation only: no model execution, benchmark installation or HP changes have occurred.

## Design and controls

Compare each new modified model with its own unmodified parent, not just the highest-scoring unrelated model. Keep Thinking and Instruct pairs separate. Treat the GRPO/SFT model as a separate training intervention from abliteration. Keep the existing Qwen3-Coder-Next Q6 acquisition intact: comparison against its Q4_K_M derivative is quantization-confounded unless an independently authorized matching original Q4_K_M is available. Do not acquire additional models automatically.

Pre-register task sets and scoring before examining results. Use disjoint tuning and held-out evaluation sets. Freeze repository revisions, model hashes, runtime commit, embedded template, context length, prompt text, sampling parameters, seed, reasoning budget and maximum output tokens. Document unavoidable differences, especially GPT-OSS original MXFP4 versus this mixed Q4_K_M conversion. Run matched quantization where practical; never attribute a precision/template change solely to refusal reduction.

Start at 4096 context tokens. Use an explicit common prompt set and supported mode per model. Keep tool availability identical; a tool call request is not evidence the model actually executed a tool. Separate raw-model output from external retrieval/tool augmentation. Avoid uncontrolled network or shell actions. Use disposable sandboxes for any later coding evaluation; manual review precedes execution.

## Evaluation matrix

| Dimension | Tasks and measurement |
|---|---|
| General reasoning/factual accuracy | Held-out problems with traceable answer keys; score final correctness separately from explanation plausibility. |
| Scientific reasoning | Study-design critique, causal inference, interpretation of uncertainty, contradictory evidence; blinded expert rubric. |
| Mathematics | Verifiable solutions and numerical checks, not eloquence alone. |
| Python coding | Unit-tested tasks with fixed dependencies; correctness, edge cases, unnecessary dependencies. |
| Multi-file development | Small frozen repositories; patch applicability, regression tests, maintainability and instruction adherence. |
| Instruction following | Explicit constraint checklists and competing-priority cases. |
| Refusal frequency | Separate full refusal, partial refusal, useful bounded answer, and compliant answer; use a fixed human-reviewed rubric. |
| Unnecessary benign refusals | Benign but sensitive tasks, with expected permissible scope independently annotated. |
| Hallucinations | Unsupported claims, invented citations/API names, unjustified certainty; verify against fixed references. |
| Context retention | Facts introduced at controlled positions and lengths; distractors and contradicted facts. |
| Formatting | JSON/schema validity, requested sections, citation format and token-budget compliance. |
| Performance | Time to first token, prompt processing tokens/s, generation tokens/s, wall time and peak system RAM/VRAM. |

## Measurements and analysis

Record CPU/GPU models, driver/runtime versions, GPU placement, thread counts, NUMA policy, power/thermal settings and concurrent workload. Do not alter existing protection services for the benchmark. Distinguish cold model load from warm inference, prompt evaluation from token generation, and load time from time to first generated token. Report actual prompt/output token counts and whether reasoning tokens are counted. Use repeated trials and more than one seed where stochastic sampling is used; summarize medians/ranges or uncertainty intervals, not only the best run.

For dual-socket HP experiments, separately record placement/locality and test a small predeclared thread-count grid while keeping everything else fixed. Treat 48/96 GB VRAM configurations as different hardware experiments. Record GPU/system memory with timestamps and watch for swapping; record failures/OOMs rather than silently dropping them. CPU offload can fit a model without making it fast.

Blind model labels for human scoring where feasible. Use paired per-task differences, confidence intervals and correction for multiple exploratory comparisons. Preserve prompts, raw outputs, evaluator version and scores. Assess willingness separately from correctness: fewer refusals can coexist with more incorrect, fabricated or unsafe answers. No improvement claim is justified by willingness alone or by converter benchmark claims.

## Acceptance boundaries

Acquisition acceptance means complete required files and validated hashes. Runtime acceptance means a particular installed build loads and responds correctly. Research-performance qualification means reproducible evaluated outputs. These are separate gates. This release completes software/catalog work only; full payload acquisition and all runtime/behavior benchmarks remain future operator activities.
