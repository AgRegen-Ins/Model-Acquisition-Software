# Accountability inventory and exports — v1.0.4.3

```bash
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format json > model-accountability.json
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format csv > model-accountability.csv
```

This read-only view is computed on request. It exposes model/family/instance identity, total and active parameters, architecture and architecture type, purpose, precision, format, variant role, preservation policy, training classification/details, inference runtime constraints, acquisition origin, status, actual-or-estimated size basis, paths, repository/pin, verification evidence/time, associated projects, host/observation, dependency status and quarantine bytes. Null parameter counts mean unknown/not applicable; absent legacy metadata is not fabricated. A projector is a component of one vision system, not an extra family.

| Status | Meaning |
|---|---|
| cataloged-not-downloaded | Catalog entry with no observed managed/external instance |
| downloaded-verified | Managed files have recorded upstream hash verification and current metadata checks pass |
| downloaded-unverified | Managed record lacks upstream evidence, or external file metadata changed since its recorded audit |
| external-registered | Custody recorded; local SHA identity or remote report alone does not establish upstream match |
| external-verified | Explicit local digest comparison matched pinned repository evidence; cached checks still pass |
| incomplete | Missing component/file or required local dependency; artifact_status separately reports parent checkpoint state |
| missing | Registered path is inaccessible or absent, possibly an unmounted drive |
| verification-failed | Explicit local/upstream integrity mismatch or managed failed audit |
| quarantined | Separate subset row for retained managed quarantine data |

`managed_storage_summary` is the existing allocated-byte accounting verbatim. Catalog estimates, last-hashed external logical bytes and remote reports are separate; they are never summed into managed storage. Quarantine rows overlap their managed revision totals. Multiple rows for one model are intentional distinct installations/revisions, not duplicate model catalog entries. Earlier managed revisions are discovered from their manifests regardless of toolkit version/catalog pin; removed catalog entries remain reported.

Legacy interfaces remain available unchanged:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format json
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format csv
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --sort size
```

Legacy inventory current files continue to refresh after managed acquisitions/verification/repair and successful import. The expanded accountability export is intentionally on demand so external availability and policy changes are current without background scanning. External mutations do not rewrite ordinary acquisition manifests.
