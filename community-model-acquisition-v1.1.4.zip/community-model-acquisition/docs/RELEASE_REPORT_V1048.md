# Release report — Community Model Acquisition Toolkit v1.0.4.8

Exclusive baseline: verified v1.0.4.7 ZIP SHA-256 `3afd40c93c5ed18938ad2ef1b17facdf1474bac9b50fce8723f171cc685758ce`. Baseline: 55 entries, 596 ZIP members, 595 packaged hashes, CRC passed; 270 tests passed on Python 3.12.14.

Added exactly five GGUF Q4_K_M variants; final catalog 60 entries. Existing entries and historical profile memberships are unchanged; only `all` grows naturally. Acquisition production code, dependencies/settings and archive behavior are unchanged; application version metadata becomes 1.0.4.8. Historical tests retain their test methods; only catalog-growth expectations changed. New tests cover these additions using metadata and tiny inert fixtures.

GPT-OSS source substitution is explicitly authorized: mradermacher's conversion replaces the inaccessible proposed Huihui download source for this new ID only. It is two raw concatenation parts totaling 87,850,987,840 bytes, not llama.cpp native split GGUF shards. The other four previously resolved manifests and revisions were preserved.

Selected weight total: 281,647,031,584 bytes. Including five README files: 281,647,056,142 bytes. Fresh combined free-space requirement: 310,885,503,580 bytes. Q4_K_M is a mixed tensor preset, not uniform four-bit precision; this GPT-OSS representation is not native MXFP4.

See `LARGE_REFUSAL_REDUCED_MODELS_V1048.md` for all exact IDs, repositories, immutable revisions, filenames, published hashes, licensing and runtime notes; `UBUNTU_ACCEPTANCE_V1048.md` for actual CLI commands; `MODEL_BENCHMARK_PLAN_V1048.md` for future controlled comparisons.

## Validation scope

The source-tree and final extracted-package test logs are released separately with the final validation report. Live pinned metadata and six CLI dry-runs are recorded under `evidence/v1.0.4.8/`. Source-only runtime inspection and bounded header reads are not full model hash verification or HP inference qualification. No model was acquired on the Dell or executed on the HP.

## Limitations and deviations

Inaccessible modification-source repositories remain documented, not bypassed. Converter lineage is declared, not cryptographically proven; exact conversion input commits are unknown. MIT conversion labels do not override Apache-2.0 base obligations. GRPO noncommercial/share-alike requirements are explicit. No unrestricted redistribution/legal clearance is asserted. This release preserves available evidence and supports operator-controlled acquisition; it does not certify those models' behavioral quality.

The toolkit retains revision directories, per-file reuse and established Hugging Face resume behavior. It does not acquire a new shared content-addressed store, cumulative HTTP-byte ceiling, inference runtime, automatic merge, conversion, execution or pruning mechanism. Existing archives are untouched.

The external final report adds final ZIP checksum, exact changed paths and cross-Python clean-extraction results after packaging, avoiding a circular self-hash inside the ZIP.
