# Huihui-derived inference models — v1.0.4.7

Reviewed 2026-10-16 UTC (2026-10-15 America/New_York). Exactly two Q4_K_M GGUF variants are added. These are existing community-modified weights acquired as inert files; the toolkit does not perform abliteration, conversion or inference. “Refusal-reduced” describes the modifier's claim, not a measured result, improved accuracy or guaranteed behavior.

## Exact artifacts

| Model ID | GGUF repository | Immutable revision | Selected bytes including README |
|---|---|---|---:|
| `huihui-glm-4-7-flash-abliterated-gguf-q4-k-m` | `mradermacher/Huihui-GLM-4.7-Flash-abliterated-GGUF` | `2d925ab0fdaa279a87485f4786ca22661bf030b2` | 18,132,725,887 |
| `huihui-qwen3-32b-abliterated-gguf-q4-k-m` | `RoadToNowhere/Qwen3-32B-abliterated-Q4_K_M-GGUF` | `36a6a1be225e6728acaec150ae944cf24491f684` | 19,762,152,900 |

| Exact GGUF filename | Bytes | Published SHA-256 |
|---|---:|---|
| `Huihui-GLM-4.7-Flash-abliterated.Q4_K_M.gguf` | 18,132,722,048 | `ca247d439725435ad5addc43926d311d0b0cd97cb65a32eb7d5b3ac479bf434d` |
| `qwen3-32b-abliterated-q4_k_m.gguf` | 19,762,149,504 | `a27a92cf139a68efcbb267c6af6d20bb8f3feddc700f3b03cd8d41f4dc443348` |

Each selection also requires its repository's `README.md` (3,839 / 3,396 bytes respectively), verified against its pinned Git blob identity and locally SHA-256 hashed by normal acquisition. `evidence/v1.0.4.7/selected-files.json` records exact file manifests. Both weights are **single files**, with tokenizer/chat template embedded; no shards, mmproj or companion model is required. Other quantizations and all original Safetensors weights are excluded.

## Provenance and licensing

Both entries use `source_kind=third-party-derived`, `variant_role=portable-gguf`, `preservation_policy=inference-only` and inference-oriented training suitability. Huihui is the community modifier; the GGUF publishers are separate converters. No existing source checkpoint or policy is replaced.

GLM lineage: `zai-org/GLM-4.7-Flash` → `huihui-ai/Huihui-GLM-4.7-Flash-abliterated` → mradermacher GGUF. The converter card and GGUF `general.source.url` identify the Huihui source. Public source snapshot: `335122816389785f5f3b57d469d43d620e6469bf`; base documentation snapshot: `7dd20894a642a0aa287e9827cb1a1f7f91386b67`. MIT is declared by the source/base/converter, with base license text retained in evidence.

Qwen lineage: `Qwen/Qwen3-32B` → `huihui-ai/Qwen3-32B-abliterated` → RoadToNowhere GGUF. The converter explicitly names Huihui and llama.cpp/GGUF-my-repo conversion. Huihui public-metadata snapshot: `7a754614e9172cd416b4652342084bea8b5c98b0`; base documentation snapshot: `9216db5781bf21249d130ec9da846c4624c16137`. Apache-2.0 is declared throughout, with the base license preserved. Retain applicable licenses/notices when redistributing.

**Neither converter records an exact immutable Huihui conversion-source commit.** The source snapshots above are not a claim of byte-for-byte reconstruction provenance. GGUF identity itself is pinned and hash-specified. Huihui Qwen source access is gated (`auto`); a source configuration request returned HTTP 401. Only its public card/API metadata were inspected; the gate was not bypassed. The selected public GGUF is independently accessible. No access to gated source files is needed by its acquisition entry.

Rejected alternative: `mradermacher/Qwen3-32B-abliterated-GGUF` declares **roslein/Qwen3-32B-abliterated**, not Huihui. Its similarly named Q4_K_M is not substituted. mradermacher's GLM **57B/depth-expanded** variants are also outside this request. Candidate labels alone were not treated as proof of lineage.

## Architecture and runtime evidence

| Property | Huihui GLM | Huihui Qwen |
|---|---|---|
| Model architecture | GLM4-MoE-Lite, MLA, MoE | Qwen3 dense |
| GGUF architecture key | `deepseek2` | `qwen3` |
| Stored parameters counted from tensor directory | 29,943,393,920 | 32,762,123,264 |
| Active parameters | Approximately 3B per base model; not remeasured | Not applicable to dense model |
| Layers | 47 | 64 |
| Expert counts | 64 routed, 4 selected plus shared | Not MoE |
| Artifact context field | 202,752 | 40,960 |
| Tensor directory | 844 tensors | 707 tensors |
| Quantized/mixed tensor types | Q4_K, Q6_K, Q5_0, FP32 | Q4_K, Q6_K, FP32 |
| GGUF disk size | 16.887 GiB | 18.405 GiB |

Context values are the GGUF configuration, not validated maximums on a particular build or workstation. Begin later evaluation at 4096 tokens. RAM/VRAM must additionally cover context cache, compute buffers and OS overhead. Exact memory minima and speed are unmeasured. Current GPU capacity was not inspected; CPU/partial CUDA offload and larger-VRAM deployment can be evaluated separately using existing installations.

GLM's `deepseek2` key is expected for this conversion, not a mistaken DeepSeek model selection. Current llama.cpp source handles GLM 4.7 Lite's 47-layer/154,880-vocabulary case and its gating behavior. A sufficiently current build with that support is required. The embedded GLM template matches the inspected Huihui template exactly.

Qwen requires dense Qwen3 and embedded-template handling. Its embedded template includes thinking/non-thinking controls, expects string message content, and predates the currently published base-model template's structured-content handling. Do not assume arbitrary structured-content messages will work. Its tokenizer type/pre-tokenizer labels are `gpt2`/`qwen2`, normal GGUF tokenizer implementation names for this family, not a model-identity substitution. Huihui's gated tokenizer/config could not be directly compared.

Runtime source inspected at llama.cpp `2851b3bcbf8d993a2243ae751c0a7dfa8e944a40`: `src/models/deepseek2.cpp`, `src/models/qwen3.cpp`, model/architecture/vocabulary code and GGML types. This is source-level compatibility evidence; no minimum release tag, installed HP compatibility or successful inference is claimed.

## Scope of verification

Live immutable-revision metadata and required-file enumeration passed. Bounded 12 MiB header prefixes were parsed from each GGUF, checking GGUF v3, quantization file type 15, architecture, tensor directory and template/tokenizer presence. These prefix hashes are **not** full-file verification. No complete weight download, model loading, repository-code execution, HP benchmark or refusal-rate test occurred. Synthetic tests qualify acquisition behavior; real payload/inference acceptance remains operator work.

## Sources

- [Huihui GLM source](https://huggingface.co/huihui-ai/Huihui-GLM-4.7-Flash-abliterated/tree/335122816389785f5f3b57d469d43d620e6469bf)
- [Selected GLM conversion](https://huggingface.co/mradermacher/Huihui-GLM-4.7-Flash-abliterated-GGUF/tree/2d925ab0fdaa279a87485f4786ca22661bf030b2)
- [Huihui Qwen source card](https://huggingface.co/huihui-ai/Qwen3-32B-abliterated/blob/7a754614e9172cd416b4652342084bea8b5c98b0/README.md)
- [Selected Qwen conversion](https://huggingface.co/RoadToNowhere/Qwen3-32B-abliterated-Q4_K_M-GGUF/tree/36a6a1be225e6728acaec150ae944cf24491f684)
- [Inspected llama.cpp revision](https://github.com/ggml-org/llama.cpp/tree/2851b3bcbf8d993a2243ae751c0a7dfa8e944a40)

Copies of reviewed cards, configurations, license files, APIs and header summaries are bundled under `evidence/v1.0.4.7/`.
