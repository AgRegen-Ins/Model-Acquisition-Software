# Ubuntu acceptance — v1.0.4.3

Run acquisition commands only on the computer with the intended model storage mounted. Run external vision registration/verification on the computer actually holding its files. Nothing below assumes those files are on the Dell server. Keep earlier application versions and their model root intact.

## 1. Verify and install alongside the existing application

Put the ZIP and its matching `.sha256` sidecar together in Downloads:

```bash
cd ~/Downloads
sha256sum -c community-model-acquisition-v1.0.4.3.zip.sha256
mkdir -p ~/community-toolkits/model-acquisition-v1.0.4.3
unzip community-model-acquisition-v1.0.4.3.zip -d ~/community-toolkits/model-acquisition-v1.0.4.3
cd ~/community-toolkits/model-acquisition-v1.0.4.3/community-model-acquisition
python3 - <<'PY'
import hashlib,json,pathlib
root=pathlib.Path('.')
checks=json.loads((root/'PACKAGE-CHECKSUMS.json').read_text())
for name,expected in checks.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
assert actual==set(checks)|{'PACKAGE-CHECKSUMS.json'},'Unexpected/missing package files'
assert (root/'modelkit/__init__.py').read_text().strip()=='__version__ = "1.0.4.3"'
print('All package hashes, membership and version verified')
PY
sudo apt install python3-venv
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -v
```

Verify exact package membership before creating `.venv`/Python caches, as shown. This installs only acquisition dependencies, not model inference frameworks, GPU runtimes or phonemizers.

## 2. Confirm existing storage and inventory

```bash
findmnt --mountpoint /srv/community-library
.venv/bin/python model_acquire.py --root /srv/community-library/models --status
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --sort size
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format csv > ~/model-accountability.csv
```

`--status` writes ordinary toolkit reports; `--inventory` is read-only. Existing v1.0.3/v1.0.4/v1.0.4.2 manifests are discovered in place, including older revisions. No upgrade download or migration is required. A missing mount must be corrected before any write/acquisition, not bypassed by creating `/srv/community-library` on the internal filesystem. On a machine with a different real archive path, use its correct `--root` and explicit `--expected-mount /actual/mount` when appropriate.

## 3. Locate the existing vision files on their actual host

```bash
ls -lh "$HOME/vision-models/qwen2.5-vl-3b/"
```

If that directory does not exist, stop this registration step and locate the files on the correct computer. Do not invent filenames or copy personal voice recordings. The following creates only a registration specification. Set the two environment variables to the actual full paths found above; the paths may have different basenames from the repository artifacts.

```bash
export VISION_GGUF="$HOME/vision-models/qwen2.5-vl-3b/Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf"
export VISION_PROJECTOR="$HOME/vision-models/qwen2.5-vl-3b/mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf"
.venv/bin/python - <<'PY'
import json,os,pathlib
paths={
 'Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf':pathlib.Path(os.environ['VISION_GGUF']).expanduser(),
 'mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf':pathlib.Path(os.environ['VISION_PROJECTOR']).expanduser(),
}
for p in paths.values():
    assert p.is_absolute() and p.is_file() and not p.is_symlink(),str(p)
spec={'instance_id':'sanitizer-qwen-vision','model_id':'qwen2-5-vl-3b-instruct-gguf-q4-k-m',
      'artifact_kind':'model-artifacts','location_kind':'external-installation',
      'files':{k:str(v) for k,v in paths.items()},
      'associated_projects':['Community Document Sanitizer','Untrusted Acquisition Toolkit'],
      'custody_notes':'Existing external installation; retain original files and references.'}
pathlib.Path('vision-registration.json').write_text(json.dumps(spec,indent=2)+'\n')
PY
```

Use a distinct instance ID for another computer/installation. Registry writes can target the central archive via its properly mounted share; otherwise register to a separately chosen model root on the source host and keep that registry's custody evidence. To describe an installation remotely at the central registry, use a remote-reported specification (see CROSS_PROJECT_REGISTRY.md); it must not be presented as locally verified. This release does not automate inter-host attestation or synchronization.

## 4. Register and compare actual hashes

With the actual central/host registry root mounted and supplied explicitly:

```bash
.venv/bin/python model_registry.py --root /srv/community-library/models --register vision-registration.json
.venv/bin/python model_registry.py --root /srv/community-library/models --verify-instance sanitizer-qwen-vision --upstream
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format json > ~/model-accountability.json
```

Registration hashes files but starts `external-registered`. The explicit upstream operation resolves `ggml-org/Qwen2.5-VL-3B-Instruct-GGUF` at `5037fcf163dd95d1e41d1974465f0898ed108ca2` and compares both file digests, not approximate sizes. If either differs, retain the originals and investigate the actual source; do not rename files to claim a match. If the files belong to another immutable revision, a separate reviewed catalog variant may be appropriate. No filename-only approval is supported.

Optional adoption, only after complete upstream verification and reviewing available space:

```bash
.venv/bin/python model_registry.py --root /srv/community-library/models --import-instance sanitizer-qwen-vision --yes
```

This makes a verified managed copy; it does not move/delete originals or change sanitizer paths. Existing managed targets cause refusal. Failed copies remain in private staging for inspection and are not counted as complete. A later large import additionally requires `--allow-large`. Ordinary model acquisition does not require this adoption step.

## 5. Dry-run every new profile

```bash
for profile in document-vision audio-transcription audiobook-narration voice-customization multimodal-core multimodal-preservation; do
  .venv/bin/python model_acquire.py --root /srv/community-library/models --profile "$profile" --dry-run
 done
```

All new profiles are opt-in. The complete multimodal set is 12,538,672,324 selected bytes before reserve. `multimodal-core` selects only the vision pair, Whisper turbo and Kokoro English voices (4,725,922,149 bytes). Source file metadata and exact revisions appear in `docs/MULTIMODAL_ADDITIONS.md` and `evidence/v1.0.4.3/selected-files.json`. F5 selection automatically adds only its required Vocos component, never an unrelated alternative model.

## 6. Explicit acquisition and verification

After reviewing mount, free space, model/runtime notes and license restrictions, choose a model or profile. Interactive confirmation remains available:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile multimodal-core
# Or an explicit individual choice:
.venv/bin/python model_acquire.py --root /srv/community-library/models --model f5-tts-v1-base-inference
.venv/bin/python model_acquire.py --root /srv/community-library/models --verify
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory
```

`--verify` hashes the managed collection and may take time for existing large archives. It does not hash external registered installations; use `--verify-instance` for those. Existing resumable download/retry behavior is unchanged. Network acquisition never installs inference software or executes downloaded Python/checkpoint objects. Runtimes, model quality, GPU behavior and voice conditioning must be tested separately with deliberate local inputs. Whisper selected artifacts run through Transformers; they are not directly whisper.cpp GGML or CTranslate2 files.

Keep public model voice packs separate from personal reference audio. Chatterbox/F5 references stay in explicitly controlled local directories and are passed directly to their runtimes, never to automatic archive ingestion.
