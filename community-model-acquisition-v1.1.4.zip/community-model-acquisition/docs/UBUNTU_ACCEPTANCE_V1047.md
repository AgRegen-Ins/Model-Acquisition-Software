# Ubuntu acceptance — v1.0.4.7

Acquire on the Dell's existing writable authoritative model archive. Do not direct acquisition to an HP read-only share. No mount/permission changes or inference setup are required by this release.

## Validate and install alongside the existing toolkit

Run from the directory containing the downloaded ZIP and sidecar:

```bash
sha256sum -c community-model-acquisition-v1.0.4.7.zip.sha256
mkdir toolkit-v1.0.4.7
unzip community-model-acquisition-v1.0.4.7.zip -d toolkit-v1.0.4.7
cd toolkit-v1.0.4.7/community-model-acquisition
python3 - <<'PY'
import hashlib,json
from pathlib import Path
for name,expected in json.loads(Path('PACKAGE-CHECKSUMS.json').read_text()).items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==expected,name
print('All package checksums passed')
PY
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -c 'from modelkit import __version__; print(__version__)'
```

Use Python 3.10–3.14. Expected results: 270 tests passing, version `1.0.4.7`. Dependency installation is explicit and uses unchanged requirements. Place application code in your established applications location (for example an operator-managed `/opt` installation), separate from model storage; no application belongs in the model payload directories. Keep the old release intact.

## Dry-runs

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-glm-4-7-flash-abliterated-gguf-q4-k-m --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-qwen3-32b-abliterated-gguf-q4-k-m --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-glm-4-7-flash-abliterated-gguf-q4-k-m \
  --model huihui-qwen3-32b-abliterated-gguf-q4-k-m --dry-run
```

| Selection | Download bytes, including README | Required free bytes, initially |
|---|---:|---:|
| GLM | 18,132,725,887 | 21,019,740,299 |
| Qwen | 19,762,152,900 | 22,812,110,014 |
| Both | 37,894,878,787 | 42,758,108,489 |

The reserve remains `int(estimated_new_bytes * 1.10) + 1 GiB`. Recognized completed files reduce the estimate; partial chunks are conservatively not deducted. Dry-run resolves live metadata without writing payloads/root. Exit 0 means metadata success, not sufficient space or completed acquisition. Check any printed insufficient-space warning.

## Explicit acquisition and resumption

```bash
mountpoint /srv/community-library
df -h /srv/community-library/models
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-glm-4-7-flash-abliterated-gguf-q4-k-m --yes
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-qwen3-32b-abliterated-gguf-q4-k-m --yes
```

If mount validation fails, stop and resolve it through the established storage process; do not bypass the guard. Both individual selections and the combined pair are below the unchanged 50 GB large-download threshold, so `--allow-large` is not required for them alone. Larger aggregate selections still need the existing confirmation interlock. No automatic acquisition occurs.

After interruption, rerun the same acquisition command. There is no separate resume flag. Completed files are checked/reused; existing Hugging Face partial recovery remains active. Do not use `--latest` for these pinned acceptance tests. Use `--repair` only deliberately when replacing damaged files with preservation in quarantine; it is not needed for ordinary resumption.

## Status, audit and exports

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --status
.venv/bin/python model_acquire.py --root /srv/community-library/models --verify
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --sort size
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format json
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format csv
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format json
```

Existing `--verify` audits the **whole managed collection**, updates audit/report metadata, and does not alter weights; `--model` does not restrict it. Ensure the existing writable storage mount is present. A failure may concern an unrelated existing revision—inspect the per-model report. `--status` is a recorded status/size/mtime check, not full hashing. Storage inventory reports on-disk revisions; registry accountability also distinguishes cataloged-not-downloaded entries.

Completion means acquisition exit 0, every selected file recorded with verified hash, revision `manifest.json` status `verified`, and no problems for that model on the subsequent full hash audit. Neither a new catalog entry nor a successful dry-run means downloaded. Normal operations maintain inventory files under `_toolkit/inventory/`.

## Expected payloads

```text
/srv/community-library/models/reasoning/huihui-glm-4-7-flash-abliterated-gguf-q4-k-m/2d925ab0fdaa279a87485f4786ca22661bf030b2/payload/Huihui-GLM-4.7-Flash-abliterated.Q4_K_M.gguf
/srv/community-library/models/reasoning/huihui-qwen3-32b-abliterated-gguf-q4-k-m/36a6a1be225e6728acaec150ae944cf24491f684/payload/qwen3-32b-abliterated-q4_k_m.gguf
```

Each payload folder also holds `README.md`; its revision directory contains `manifest.json` and `repository.json`. Preserve original filenames/case. Both GGUFs are single files—no “first shard” is needed. Later HP deployment copies must be independently hash-checked against the archive manifest. This release performs no deployment, conversion, benchmark changes or model execution.

See [model notes](HUIHUI_MODELS_V1047.md) for source gating, conversion lineage, licenses, template constraints and untested-runtime boundaries.
