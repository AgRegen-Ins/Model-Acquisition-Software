# Architecture and extension contract

The application is independent of the Community Library source-acquisition code. Python 3.10+ core and the JSON catalog are portable. Bash and PowerShell isolate setup differences.

- `model_acquire.py`: CLI/menu, root selection, previews, confirmations, free-space checks, collection lock, report dispatch.
- `modelkit/core.py`: configuration validation, safe paths, file selection, commit paths, integrity, atomic state, quarantine/repair, inventories/reports.
- `modelkit/huggingface.py`: Hugging Face metadata/download adapter using `HfApi.model_info(files_metadata=True)` and `hf_hub_download(local_dir=..., revision=<commit>)`.
- `modelkit/mounts.py`: configurable expected-mount selection and pre-write validation.
- `modelkit/storage.py`: non-mutating filesystem inventory, revision classification, allocated/logical accounting, text/CSV/JSON output and explicit atomic report writeback.
- `settings.json`: platform-scoped model-root to expected-mount rules; CLI override supported.
- `catalog.json`: independently editable variants, selection patterns, categories, profiles, estimates, roles, runtime/hardware hints, source provenance, pinned commits.

The adapter's `resolve(entry)` returns full revision, repository metadata, gating status, and file records (`path`, `size`, optional upstream `sha256`, optional `git_blob_sha1`). `download(entry, revision, filename, target, force=False)` downloads one file using established upstream mechanisms. A future adapter can implement this contract; it also needs a registration/factory change and revised revision validation for providers without Git-style identifiers. Provider registration is deliberately simple in v1, not a full plugin framework.

## State and durability

One manifest per variant/commit records the **exact selected set**, the catalog entry as acquired, timestamps, expected upstream hashes, and the results of local verification. JSON state is written to a same-directory temporary file, flushed/fsynced, then atomically replaced. Parent-directory fsync and sudden-power-loss guarantees depend on the platform/filesystem. Upstream handles partial transfer/cache state; temporary model chunks are not deleted by the toolkit.

A process lock prevents two cooperating downloads/verifiers sharing one root. Atomic replacement avoids half-written JSON. Planning/dry runs are read-only and do not require a lock; acquisition checks existing provenance again under the lock. Catalog edits that change a selection at an existing variant/commit are refused; create a new variant ID. Existing provenance is never silently repurposed for another repository.

Files that pass full hash checks are reused. Existing mismatches require `--repair`; their bytes are moved to a unique quarantine location. Invalid final files from the current transfer are likewise preserved before another attempt. Old commit directories and unrelated files remain. Raw exception strings from network libraries are not logged. No repository Python file is imported or executed.

## Add a model

Copy an entry in `catalog.json`, or use `sample-catalog.json` as a schema example. Assign a unique stable `id`, category, actual repository/publisher, source kind, base model relationship, profiles, and selection patterns. Set `revision` to a full reviewed commit, or `main` if you deliberately want it resolved afresh on every run. Actual acquisition still pins the resolved commit.

`include` / `exclude` use case-sensitive Python `fnmatch` patterns on the complete repository-relative POSIX path; `*` can match a slash. `required` lists patterns that must have a match after filtering. Prefer exact GGUF names to avoid selecting several quantizations, both split and unsplit copies, or stale variants. Include all pieces of a split GGUF; v1 does not parse GGUF internals to infer missing shards. Safetensors indexes are parsed after acquisition and every referenced shard must be part of the preserved file set.

An original model can use `include: ["*"]` and exclude redundant alternate exports. Include tokenizers/configs, model card and license files, and any auxiliary retrieval heads. Categories and metadata can be extended without changing the acquisition core. Optional metadata may be `null` where no reliable upstream value exists. Parameter totals from API tensor metadata can be misleading for quantized/MoE models; treat them as metadata, not a memory-capacity calculation.

Run an offline plan, then a live dry run, review the source/license/files, and acquire only after inspecting the summary. Estimated bytes in the catalog are a snapshot; live plans query exact selected sizes. There is no general-purpose credential field in catalog entries.

## Source verification

`evidence/` contains API responses captured during the build for the original 19 repositories plus available small configs; `evidence/v1.0.2/` adds four new source inventories and pinned cards/configs. `docs/CATALOG.md` links source repositories with provenance distinctions and lists reviewed commit hashes/licenses/selected sizes. At acquisition, `repository.json` captures fresh metadata at the exact requested revision; upstream cards/license files are downloaded as payload. Included evidence is a build snapshot, not a claim that upstream will remain unchanged.

References:

- https://huggingface.co/docs/huggingface_hub/guides/download
- https://huggingface.co/docs/huggingface_hub/package_reference/hf_api
- https://huggingface.co/docs/huggingface_hub/guides/cli
- https://huggingface.co/docs/hub/models-gated

Future work: non-Hub providers/mirrors, local imports, air-gapped dependency/runtime bundles, export/backup workflows, GGUF metadata parsing, richer runtime compatibility tests, and deployment tooling. None are prerequisites for this acquisition layer.

## v1.0.1 scope

The existing acquisition engine and adapter remain unchanged. CLI checks mount safety before setup, before live acquisition planning, before creating the collection lock, and before each variant. It refreshes storage snapshots after completed acquisitions (including repairs), after verification/status, and at handled interruption/end-of-run. Inventory has no network dependency and does not take a write lock or mutate model state. See `STORAGE.md` for field semantics and limitations.

## v1.0.2 scope

Catalog/profile expansion only: four entries for two coding families, optional metadata fields in the existing schema, documentation, updated expected test counts, and new catalog regression tests. CLI, acquisition, mount guard, storage inventory, checksum verification, setup scripts and retention behavior remain byte-identical to v1.0.1.

## v1.0.3 scope

Two additional GGUF variants and one profile. Runtime application files remain byte-identical to v1.0.2. `evidence/v1.0.3/` records source inventories, cards/configs/licenses where present, baseline catalog/checksums, and tests/dry runs. No schema changes; optional metadata continues to use existing extensible fields.

## v1.0.4 catalog extension

See [PRESERVATION_ADDITIONS.md](PRESERVATION_ADDITIONS.md), [PROFILES.md](PROFILES.md), and [PROVENANCE.md](PROVENANCE.md). Optional schema-1 metadata is retained in manifests. The only behavior extension is explicit `profile_members` resolution/validation in `load_catalog` and `select`; no acquisition, mount, hashing, inventory, resume, quarantine or retention functions change. Historical model entries are unchanged.
