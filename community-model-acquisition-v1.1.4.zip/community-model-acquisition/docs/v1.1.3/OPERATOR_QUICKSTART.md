# Ubuntu installation and educational acquisition — v1.1.3

Preserve the installed v1.1.2 application and its virtual environment. Extract v1.1.3 into a new version-specific directory, not over the old installation. The dedicated archive remains `/srv/ai-models`; its UUID and all storage settings are unchanged. No archive migration, full 2.62 TB comparison or manifest rewrite is required. Existing production inventory/migration/HP-replica qualification remains accepted. Write-enabled production activation has not been authorized.

## Install and read-only qualification

From the release download directory:

```bash
sha256sum -c community-model-acquisition-v1.1.3.zip.sha256
unzip -t community-model-acquisition-v1.1.3.zip
mkdir community-model-acquisition-v1.1.3
unzip community-model-acquisition-v1.1.3.zip -d community-model-acquisition-v1.1.3
cd community-model-acquisition-v1.1.3/community-model-acquisition
python3 verify_package.py
bash setup-linux.sh
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python model_storage.py --read-only
```

`setup-linux.sh` creates only the application virtual environment and installs the existing requirements. It does not configure or write the archive. Six optional real root-owned permission tests skip on an ordinary account; their simulated counterparts must pass. Do not run the application with sudo to hide missing privileges.

List entries and profiles without accessing an archive or network:

```bash
.venv/bin/python model_acquire.py --profile educational-assessment --list-catalog
.venv/bin/python model_acquire.py --profile educational-assessment --list-catalog --format json
.venv/bin/python model_acquire.py --root /srv/ai-models --profile educational-assessment --offline-plan
.venv/bin/python model_acquire.py --root /srv/ai-models --model autoscore-research-software --dry-run
```

Use `--model ID --dry-run` for any ID in COMPONENT_CATALOG.md or replace selection with a new profile. Dry-runs resolve live pinned metadata, exact byte totals, already-present files, free space and reserve; they do not download payloads. Offline plans use bundled estimates. The new profile membership is explicit and opt-in:

| Profile | Acquired components |
|---|---|
| educational-assessment | All eight additions |
| aiawe-preservation | 120-essay adapter, 480-essay adapter, AiAWE software |
| autoscore-preservation | AutoSCORE software only |
| argulens-preservation | Source/support files, LightGBM scorer, classifier LoRA |
| essay-evaluator-preservation | Fine-tuned Phi checkpoint only |

Existing profiles are unchanged; `all` naturally includes the additions. Listing a profile does not acquire it. Generic Gemma/Qwen/Phi base weights are not implicit dependencies. ArguLens classifier/scorer select only their shared source-support dependency, deduplicated once.

## Acquisition after separate operator authorization

Review licensing/access limitations and the dry-run first. These commands are instructions for later approved operation, not a request to activate production now:

```bash
.venv/bin/python model_acquire.py --root /srv/ai-models --expected-mount /srv/ai-models --model autoscore-research-software --yes
```

Repeat **the identical command** after interruption to resume. No separate resume flag is needed. Completed verified files are reused. GitHub partial bytes remain in the selected payload’s `.github-cache`; Range resumes are checked against exact size and final digest. If the server ignores Range, that incomplete file restarts safely. Existing HF resume behavior is unchanged. Do not remove partial files or alter historical manifests manually.

Use any other individual new ID in the same command. `--yes` never bypasses the existing 50 GB `--allow-large` interlock. The eight selections total about 11.73 GB before reserve; exact reviewed bytes and selected-file manifests are bundled. For an empty destination the existing formula requires approximately 13.98 GB (`int(new_bytes * 1.10) + 1 GiB`), with the filesystem session’s independent safety requirements still active. Live free space is authoritative.

## Verify only the selected acquisition

```bash
.venv/bin/python model_acquire.py --root /srv/ai-models --model autoscore-research-software --verify-selected
```

This action requires the same UUID-approved writable filesystem because it records audit results. It hashes only the specified pinned acquisition and its declared dependencies, validates manifest identity and reviewed file membership, and updates its audit record plus a selected report. It does not scan unrelated revisions or regenerate collection-wide inventories. Exit 0 means every selected record verified; missing/failed acquisitions return nonzero. The existing `--verify` remains a whole-collection action and is unnecessary for this acceptance.

Payload location is unchanged:

```text
/srv/ai-models/<category>/<id>/<immutable-revision>/payload/<exact-upstream-path>
/srv/ai-models/<category>/<id>/<immutable-revision>/manifest.json
```

For AutoSCORE: category `research-software`, ID `autoscore-research-software`, revision `c4a65eb714a26ce086fe00fc0d532cf3c5df4495`. A directory alone is not completion evidence. Require a verified manifest, all expected records and successful selected audit. No source file is installed or executed by acquisition.

## Explicit inventory exports

```bash
.venv/bin/python model_acquire.py --root /srv/ai-models --inventory --format json > "$HOME/model-inventory-v113.json"
.venv/bin/python model_report.py --root /srv/ai-models > "$HOME/model-accountability-v113.json"
.venv/bin/python model_report.py --root /srv/ai-models --output "$HOME/model-accountability-v113.xlsx"
```

Choose a new output filename if it exists. `model_report.py` includes catalog-only entries, actual acquisition state and capacity; `--inventory` describes revisions found on disk. Neither assumes catalog membership means acquisition. Export files must stay outside guarded archive mounts. These explicit reports scan archive metadata; they do not perform a fresh full-model hash audit. Ordinary acquisition retains the baseline automatic metadata inventory updates—no new implicit collection scan or historical payload rehash is introduced.

## Rollback

Stop any selected acquisition cleanly, preserve its partial/manifest records, and return to the untouched v1.1.2 application for old catalog entries. Do not use v1.1.2 to acquire new GitHub entries; use the preserved v1.1.3 package to resume those if needed. No manifest conversion or archive rollback is required. Do not delete either archive, change mounts or modify the HP replica/installation.
