# v1.1.3 change report

Derived exclusively from supplied v1.1.2 ZIP SHA-256 `6683a84189f3600810bdd7a1d8381cd295295b7f675703993fe086f8922d97b6`. Baseline: 741 ZIP members, 740 checked files, valid CRC, internal version 1.1.2; 415/415 tests pass on each Python 3.10–3.14.

The catalog grows from 60 to 68 typed artifacts across the four requested educational projects. Every existing model JSON value, existing profile definition/membership (except normal `all` growth) and preservation-policy entry remains identical. No generic substitute or duplicate GPT-OSS/DeepSeek/Qwen checkpoint is added. Exact files and source revisions are in COMPONENT_CATALOG.md and selected-manifests.json.

## Changes and rationale

- `modelkit/github.py`: narrowly scoped public GitHub transport, implementing the existing resolver/downloader protocol. Pins commit/tree regular blobs or release ID plus SHA-256. Fetches individual inert files rather than extracting remote archives or performing git checkout. Restricts HTTPS redirect destinations, refuses unsafe paths/symlinks, bounds metadata/payload size, checks Range resumes and cryptographic identities, and invokes existing storage checkpoints. Core acquisition still owns manifest, retry, quarantine and completion semantics.
- `modelkit/huggingface.py`: dispatches GitHub entries through that transport; for new HF artifacts, compares live metadata to reviewed exact pinned file manifests. Legacy HF entries take their previous path unchanged.
- `modelkit/core.py`: catalog loader permits and validates the additional GitHub adapter. Acquisition, hashing, retries, reserve, quarantine, retention and index-verification functions are unchanged.
- `model_acquire.py`: read-only `--list-catalog` and explicit `--verify-selected` routing. Both use existing selection/dependency semantics. Selected audits enter the unchanged StorageSession and collection lock; no new whole-archive scan is performed.
- `modelkit/selected_audit.py`: verifies only named pinned variants and their dependencies against manifests and hashes, writing selected audit results through existing guarded atomic writes.
- `catalog.json` and `preservation-policy.json`: append eight reviewed artifacts and five opt-in profiles, with explicit base dependencies, licensing uncertainty, roles and selected manifests.
- Version, documentation, evidence, tests and package hashes updated. Tests authenticate exact approved source deltas while retaining prior baseline comparisons; historical byte checks are not simply disabled. Fixed old catalog-count assertions now protect the original subset, with new tests protecting the full expanded set.

## Preserved boundaries

Storage UUID/mount/disconnection code, settings, directory structure, installers, requirements, inventory/XLSX implementation, external registry, custody semantics, archive comparison, recovery-directory policy and legacy manifests are byte-identical to v1.1.2. No new runtime dependencies were added. Selected Python, bytecode, training arguments and model files remain inert. No execution, model loading, conversion, training, API inference, automatic software installation or production writes occur during acquisition.

The old collection-wide acquisition metadata reports remain unchanged; no extra implicit scan or historical payload rehash was introduced. The new selected audit avoids a full verification pass. Production activation remains unauthorized. Prior migration and HP-replica checksum qualification does not need repetition.

## Limitations

AiAWE adapter licensing is unspecified; its base revision and verified merged checkpoint are unresolved. Three old AiAWE source documentation names are excluded under existing path rules. AutoSCORE dataset TSVs are withheld pending rights confirmation. ArguLens generic runtime bases are absent/unpinned and not silently acquired. Phi custom-code references need separate runtime review. No complete real model payloads, HP inference or grading accuracy were tested. GitHub anonymous API limits and network outages can interrupt metadata resolution; rerun later, without weakening pins. Runtime source dependencies are documented but not installed. These are preservation artifacts, not a ready-to-use grading service.

See VALIDATION_REPORT.md for exact qualification and remaining hardware acceptance. FILE_CHANGES.json and the external source diff identify every changed/added file.
