# Educational assessment components — v1.1.3

Publisher metadata reviewed 2026-10-26/27. Sizes are selected artifact bytes, not entire upstream repositories. Public metadata resolution is not full payload verification or runtime qualification. All new entries are cataloged; production acquisition status was not inspected.

| ID | Type | Files | Selected bytes | Repository | Immutable revision |
|---|---|---:|---:|---|---|
| `aiawe-gemma-3-27b-lora-120` | adapter | 21 | 1,856,474,721 | [jgayed/gemmalora120](https://huggingface.co/jgayed/gemmalora120) | `e496670beda8eb873e066d0f7bda9ced545c7943` |
| `aiawe-gemma-3-27b-lora-480` | adapter | 21 | 1,856,524,977 | [jgayed/gemmalorafull](https://huggingface.co/jgayed/gemmalorafull) | `5c53087e9c6720e34af060e9693f1160d77c9047` |
| `phi-3-5-essay-evaluator-original` | model | 13 | 7,644,554,881 | [DanielHafezi/essayevaluator](https://huggingface.co/DanielHafezi/essayevaluator) | `28d1b4536edd72a075e0609f6dc9c55a05b1410c` |
| `aiawe-research-software` | research-software | 410 | 3,934,568 | [waseda-awade/aiawe](https://github.com/waseda-awade/aiawe) | `cdead8080d1638b426c36898d2ca776c89816260` |
| `autoscore-research-software` | research-software | 32 | 899,935 | [AI4STEM-Education-Center/AutoSCORE](https://github.com/AI4STEM-Education-Center/AutoSCORE) | `c4a65eb714a26ce086fe00fc0d532cf3c5df4495` |
| `argulens-research-software` | research-software | 79 | 6,340,367 | [wwrwbs/AI_AWE](https://github.com/wwrwbs/AI_AWE) | `41ae3bd4dd9e891bf46dd4834644ca143dbd36df` |
| `argulens-lightgbm-scorer` | trained-scorer | 2 | 41,677,966 | [wwrwbs/AI_AWE](https://github.com/wwrwbs/AI_AWE) | `41ae3bd4dd9e891bf46dd4834644ca143dbd36df` |
| `argulens-qwen2-5-7b-classifier-lora` | adapter | 1 | 323,014,168 | [wwrwbs/AI_AWE](https://github.com/wwrwbs/AI_AWE) | `41ae3bd4dd9e891bf46dd4834644ca143dbd36df` |

Unique selected total: **11,733,421,583 bytes**. Dependencies are deduplicated by the existing selector. The ArguLens scorer/classifier each also select the 6,340,367-byte software component when requested alone.

Exact filenames, bytes and publisher digests are in `evidence/v1.1.3/selected-manifests.json` and each catalog entry’s `pinned_files`. Git-source identity uses the commit/tree and Git blob SHA-1. Acquisitions additionally compute and record local SHA-256; no uncomputed local checksums are asserted. Release asset identity is fixed by numeric ID and SHA-256, not its mutable tag.

## AiAWE Gemma-3-27B LoRA — 120 essays

Provenance: `third-party-derived`. Publisher: `jgayed`. Role: `specialized-adapter`. Format: Safetensors LoRA. Precision: not independently established; no tensor deserialization performed.

License: other (publisher unspecified); Gemma base terms apply separately. Adapter card declares other without license text. Do not infer MIT from application code or unrestricted redistribution. Proprietary ETS dataset not acquired.

Top-level final adapter, tokenizer/processor, chat template, training configuration, logs and inert training_args.bin. Intermediate checkpoint directories and optimizer states excluded. No merged weights or ETS corpus.

Capabilities: educational-assessment, automated-essay-scoring, educational-research, rubric-aligned-evaluation.

Acquired inert. No installation, inference, training, merging or remote code execution.

Runtime dependencies (recorded separately from acquired artifacts):
```json
[
  {
    "repository": "google/gemma-3-27b-it",
    "revision": null,
    "reason": "Adapter config specifies base name but not training revision; gated Gemma terms apply; not automatically acquired",
    "catalog_id": null
  }
]
```

## AiAWE Gemma-3-27B LoRA — 480 essays

Provenance: `third-party-derived`. Publisher: `jgayed`. Role: `specialized-adapter`. Format: Safetensors LoRA. Precision: not independently established; no tensor deserialization performed.

License: other (publisher unspecified); Gemma base terms apply separately. Adapter card declares other without license text. Do not infer MIT from application code or unrestricted redistribution. Proprietary ETS dataset not acquired.

Top-level final adapter, tokenizer/processor, chat template, training configuration, logs and inert training_args.bin. Intermediate checkpoint directories and optimizer states excluded. No merged weights or ETS corpus.

Capabilities: educational-assessment, automated-essay-scoring, educational-research, rubric-aligned-evaluation.

Acquired inert. No installation, inference, training, merging or remote code execution.

Runtime dependencies (recorded separately from acquired artifacts):
```json
[
  {
    "repository": "google/gemma-3-27b-it",
    "revision": null,
    "reason": "Adapter config specifies base name but not training revision; gated Gemma terms apply; not automatically acquired",
    "catalog_id": null
  }
]
```

## Phi-3.5 Essay Evaluator — DanielHafezi

Provenance: `third-party-derived`. Publisher: `DanielHafezi`. Role: `specialized-source-checkpoint`. Format: Safetensors. Precision: BF16.

License: mit (publisher model-card declaration). Model card MIT; no standalone LICENSE in this fine-tune repository. Base publisher also declares MIT. Private training dataset not distributed.

Complete repository: two weight shards, index, config, tokenizer, card, deploy descriptor. No Python source present. deploy.json is inert; external API references do not cause calls.

Capabilities: educational-assessment, automated-essay-scoring, educational-research, rubric-aligned-evaluation.

Config records Transformers 4.43.0 and Phi3ForCausalLM; auto_map references base-repository custom code. Prefer a reviewed runtime with native Phi3 support; no trust_remote_code execution by acquisition.

Runtime dependencies (recorded separately from acquired artifacts):
```json
[
  {
    "repository": "microsoft/Phi-3.5-mini-instruct",
    "revision": null,
    "reason": "Base relationship and auto_map custom-code references only; full fine-tuned weights included; no base weight download"
  }
]
```

## AiAWE application source snapshot

Provenance: `official-upstream`. Publisher: `waseda-awade`. Role: `research-framework`. Format: Source files. Precision: not applicable to source files.

License: mit. Application MIT license does not establish adapter, Gemma, ETS corpus or third-party service licensing.

All path-compatible regular files in pinned Git tree except three obsolete NOT-IN-USE documentation paths rejected by existing filename safety rules; includes bundled bare-repository files, hooks and environment examples, stored inert and never executed. No git clone/checkout or package installation.

Capabilities: educational-assessment, automated-essay-scoring, educational-research.

Acquired inert. No installation, inference, training, merging or remote code execution.

Runtime dependencies (recorded separately from acquired artifacts):
```json
[
  {
    "component": "Gemma LoRA + gated base + application services",
    "automatic_acquisition": false
  }
]
```

## AutoSCORE rubric evidence extraction and scoring framework

Provenance: `official-upstream`. Publisher: `AI4STEM-Education-Center`. Role: `research-framework`. Format: Source files. Precision: not applicable to source files.

License: mit (source); benchmark rights separate. Read the retained upstream license and third-party notices before redistribution or runtime use.

All non-dataset regular source-tree files, including prompts, rubrics, evaluation metrics and inert pyc files. Two ASAP dataset TSVs withheld pending separate redistribution-terms confirmation.

Capabilities: educational-assessment, automated-essay-scoring, educational-research, structured-evidence-extraction, rubric-aligned-evaluation.

Acquired inert. No installation, inference, training, merging or remote code execution.

Runtime dependencies (recorded separately from acquired artifacts):
```json
[
  {
    "component": "User-selected LLM runtime/API",
    "automatic_acquisition": false,
    "note": "No referenced GPT/Llama weights or paid API calls are acquired/invoked."
  }
]
```

## ArguLens source, features, prompts and adapter support files

Provenance: `official-upstream`. Publisher: `wwrwbs`. Role: `research-framework`. Format: Source files. Precision: not applicable to source files.

License: apache-2.0; vendored MIT notices retained. Read the retained upstream license and third-party notices before redistribution or runtime use.

All Git-tree files except two trained scorer files separately cataloged; includes adapter config/tokenizer, training YAML and evaluation code. Union with scorer entry reproduces complete Git tree.

Capabilities: educational-assessment, automated-essay-scoring, educational-research, writing-feedback, argument-analysis.

Acquired inert. No installation, inference, training, merging or remote code execution.

Runtime dependencies (recorded separately from acquired artifacts):
```json
[
  {
    "repository": "Qwen/Qwen2.5-7B-Instruct",
    "revision": null,
    "role": "Classifier base; not Coder; absent from baseline catalog; not auto-acquired"
  },
  {
    "repository": "Qwen/Qwen2.5-14B-Instruct",
    "revision": null,
    "role": "Unmodified feedback backbone; no specialized feedback checkpoint found; not auto-acquired"
  }
]
```

## ArguLens trained LightGBM scorer and scaler

Provenance: `official-upstream`. Publisher: `wwrwbs`. Role: `specialized-scorer`. Format: LightGBM text + JSON. Precision: text serialization; numeric precision not independently assessed.

License: apache-2.0 (explicit publisher LICENSE coverage). Read the retained upstream license and third-party notices before redistribution or runtime use.



Capabilities: educational-assessment, automated-essay-scoring, educational-research.

Acquired inert. No installation, inference, training, merging or remote code execution.

Runtime dependencies (recorded separately from acquired artifacts):
```json
[]
```

## ArguLens Qwen2.5-7B discourse-move classifier LoRA

Provenance: `third-party-derived`. Publisher: `wwrwbs`. Role: `specialized-adapter`. Format: Safetensors LoRA. Precision: not independently established; no tensor deserialization.

License: apache-2.0 (explicit publisher LICENSE coverage). Read the retained upstream license and third-party notices before redistribution or runtime use.

Release asset ID and SHA-256 pin identity independently of mutable release tag; digest agrees with committed model_checksums.sha256. Config/tokenizer come from source dependency. No merging or assembling runtime paths.

Capabilities: educational-assessment, automated-essay-scoring, educational-research, argument-analysis.

Acquired inert. No installation, inference, training, merging or remote code execution.

Runtime dependencies (recorded separately from acquired artifacts):
```json
[
  {
    "repository": "Qwen/Qwen2.5-7B-Instruct",
    "revision": null,
    "automatic_acquisition": false,
    "reason": "Training base revision unspecified; absent from catalog; Coder variants are not substitutes."
  }
]
```

## Findings and unresolved components

- AiAWE publication: https://arxiv.org/abs/2606.12801 links `jgayed/gemmalora120` (120 training essays / 360 held-out evaluation) and `jgayed/gemmalorafull` (480-essay deployment adapter). Both final adapters are PEFT LoRA rank 64 / alpha 128. They include training YAML, logs, tokenizer/processor/chat-template files and an inert `training_args.bin`. No `.bin` deserialization is performed. Intermediate checkpoints/optimizer states are excluded. The base is `google/gemma-3-27b-it`; training revision is unspecified. It is absent from the baseline and separately gated under Gemma terms. Adapter cards say `license: other` with no substantive license text; application MIT does not settle adapter redistribution rights. The ETS corpus is proprietary and not acquired.
- The investigated `jgayed/gemmalorafull32gguf` repository has only a 1,816,324,608-byte GGUF and attributes at `6753b6da85db24ca3585f6fccf6637ff0ab33c4c`. No verified standalone merged 27B checkpoint or validated runtime was established. It is not added. This is an unresolved candidate, not a substitution for the actual adapters.
- AiAWE source selection omits three obsolete `[NOT-IN-USE]` Markdown paths rejected by the toolkit’s existing filename policy. All other 410 regular files, including the bundled inert bare-Git objects, remain selected. This is an explicit partial source snapshot, not a claim that those three files were acquired. `withheld_files` records exact omissions. No path-policy weakening or executable checkout was introduced.
- AutoSCORE publication: https://arxiv.org/abs/2509.21910. All 32 non-dataset files are selected, including prompts/rubrics, metrics and configuration. Two ASAP example TSVs are withheld pending independent dataset redistribution-term confirmation; the repository MIT software license alone does not settle external benchmark rights. No pretrained model is implied, no paid API is invoked, and no referenced GPT/Llama weights are downloaded.
- ArguLens publication: https://arxiv.org/abs/2608.17356. Its LICENSE explicitly covers source, trained LoRA and LightGBM weights under Apache 2.0. Vendored MIT/permissive notices remain intact; raw PERSUADE 2.0 training data are not redistributed. Software (79 files) plus scorer (2 files) covers every regular Git-tree file. The release adds `adapter_model.safetensors`, asset ID `493658128`, 323,014,168 bytes, SHA-256 `7ab62b983fdc66085280b6418ee662a5f833831208a0cde79d1c959adb9660c0`, matching the committed checksum list. Adapter config/tokenizers live in the software dependency; no automatic runtime directory assembly occurs.
- ArguLens needs **Qwen2.5-7B-Instruct**, not a Qwen Coder variant. Feedback uses unmodified **Qwen2.5-14B-Instruct**. Neither exact general base is in the baseline; no pinned training base revision is supplied. These remain explicit unresolved runtime dependencies rather than duplicate or generic-model acquisitions. No specialized feedback checkpoint was found.
- Phi publishes 13 files including two BF16 Safetensors shards and their index. The metadata describes 3,821,079,552 parameters, dense Phi3ForCausalLM, Transformers 4.43.0, and configured 131,072-token context (original 4,096). This is configuration, not tested context quality. MIT is declared in the model card; no separate LICENSE file is present. Base-model MIT and the fine-tuned card are distinct evidence. The private training corpus is not included. `auto_map` references Microsoft base-repository code, but no Python model code is hosted in this checkpoint. A separately reviewed native-Phi3 runtime is preferable; acquisition never uses `trust_remote_code` and does not download unspecified remote code. No publisher-provided, validated GGUF was established.

## Preservation and deployment boundary

All 60 baseline entries and old profile memberships are preserved. Existing Qwen2.5 Coder/VL variants are not the required general Instruct bases. No Gemma/Phi/AiAWE/AutoSCORE/ArguLens duplicate was present. Existing GPT-OSS-120B and DeepSeek-V4-Flash are unchanged and are not selected by the new profiles.

Software preservation does not install dependencies or establish an operational scoring system. Adapters require separately reviewed compatible bases, tokenizers and runtimes. Training suitability is explicitly unknown where not established, despite preserving source/configuration for future research. No grading accuracy, fairness, reliability, inference speed, HP compatibility or classroom deployment claim is made. No adapters were loaded, merged, trained or executed.
