# Ubuntu acceptance — v1.0.4.4

Install alongside previous versions. Use the Dell's writable canonical archive for acquisition; the HP's existing Community Library mount is read-only and must not be made writable by these instructions. No models, runtime software, benchmark scripts, previous acquisitions or external project files are upgraded automatically.

## 1. Verify and install alongside the existing application

Put the ZIP and its matching `.sha256` sidecar together in Downloads:

```bash
cd ~/Downloads
sha256sum -c community-model-acquisition-v1.0.4.4.zip.sha256
mkdir -p ~/community-toolkits/model-acquisition-v1.0.4.4
unzip community-model-acquisition-v1.0.4.4.zip -d ~/community-toolkits/model-acquisition-v1.0.4.4
cd ~/community-toolkits/model-acquisition-v1.0.4.4/community-model-acquisition
python3 - <<'PY'
import hashlib,json,pathlib
root=pathlib.Path('.')
checks=json.loads((root/'PACKAGE-CHECKSUMS.json').read_text())
for name,expected in checks.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
assert actual==set(checks)|{'PACKAGE-CHECKSUMS.json'},'Unexpected/missing package files'
assert (root/'modelkit/__init__.py').read_text().strip()=='__version__ = "1.0.4.4"'
print('All package hashes, membership and version verified')
PY
sudo apt install python3-venv
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -v
```

Verify exact package membership before creating `.venv`/Python caches, as shown. This installs only acquisition dependencies, not model inference frameworks, GPU runtimes or phonemizers.


## 2. Inspect the mounted existing archive

On the computer that owns the writable canonical drive:

```bash
findmnt --mountpoint /srv/community-library
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --sort size
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format json > ~/model-accountability-v1044.json
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format csv > ~/model-accountability-v1044.csv
```

These inventory commands are read-only. Existing revisions and registry records are discovered in place; the four new entries should be `cataloged-not-downloaded` until actually acquired or registered. Policy tags do not prove an installation. If the mount is absent, correct it before any acquisition or report-writing status/verification operation. Never bypass the guard by creating an ordinary directory on the internal disk.

For another storage location, pass its actual `--root` and appropriate `--expected-mount /actual/mount`. Do not guess paths on the HP. Legacy `--status` and `--verify` write reports, so run them on the writable archive host rather than its read-only deployment mount.

## 3. Dry-run every new variant and profile

```bash
for model in \
  openscholar-8b-original \
  openscholar-8b-gguf-q4-k-m \
  ether0-24b-original \
  ether0-24b-gguf-q4-k-m
do
  .venv/bin/python model_acquire.py --root /srv/community-library/models --model "$model" --dry-run
done

for profile in \
  scientific-research-local \
  chemistry-research-local \
  scientific-research-preservation \
  scientific-research-inference
do
  .venv/bin/python model_acquire.py --root /srv/community-library/models --profile "$profile" --dry-run
done
```

Dry-run resolves metadata and writes no model payloads. Check exact pins, selected sizes, estimated new files, free space and required reserve. A successful dry-run exit means the plan resolved, not that disk space is sufficient: heed `INSUFFICIENT SPACE`. Existing verified files may reduce estimated new bytes. Full new preservation selection: 129,634,502,906 bytes; required free-space threshold on an empty selection: 143,671,695,020 bytes. Do not confuse this threshold with additional reserve alone.

## 4. Explicit acquisition after reviewing the plan

Choose one command or a profile; do not run every example automatically.

```bash
# Interactive confirmation, one compact research model:
.venv/bin/python model_acquire.py --root /srv/community-library/models --model openscholar-8b-gguf-q4-k-m

# Interactive confirmation, chemistry GGUF:
.venv/bin/python model_acquire.py --root /srv/community-library/models --model ether0-24b-gguf-q4-k-m

# Both inference copies only:
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile scientific-research-inference
```

To deliberately authorize all four after reviewing licenses and storage:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile scientific-research-preservation --yes --allow-large
```

`--yes` alone refuses the >50 GB source/preservation downloads. Interactive mode retains its explicit LARGE confirmation. Interrupted catalog downloads resume using the same command and pinned revision. Do not add `--latest` if you intend the verified release pins. No source checkpoint is deserialized; `.bin` remains inert data. Existing originals and verified revisions are retained.

## 5. Verify and inspect

On the writable canonical host:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --verify
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --sort size
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format csv > ~/model-accountability-v1044.csv
```

`--verify` audits all existing managed models, so it may take significant time and may report unrelated older acquisition problems; it does not execute weights. Do not automatically repair, replace or delete anything merely because an audit reports a failure. Review the report and decide on any separate repair action.

## 6. HP runtime acceptance is a later operator step

See `docs/HP_SCIENTIFIC_DEPLOYMENT.md` for paths, 4096-token starting context, CPU baseline and cautious partial GPU offload using existing llama.cpp. No real HP inference was performed for this release. The toolkit does not provision PaperQA2, an OpenScholar RAG system, or any GPU/Transformers environment. Read `SCIENTIFIC_MODELS.md` for licensing conflict, converter provenance and chemistry limitations.

Existing external model registration remains unchanged; `docs/CROSS_PROJECT_REGISTRY.md` and the historical `docs/UBUNTU_ACCEPTANCE.md` retain that workflow. Registration of new copies is optional, separate from ordinary catalog acquisition, and never inferred from filenames alone.
