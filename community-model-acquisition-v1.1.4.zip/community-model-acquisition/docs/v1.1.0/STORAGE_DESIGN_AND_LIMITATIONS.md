# Storage design, compatibility and limits

## Protected baseline

The release derives exclusively from the authenticated v1.0.4.8.1 ZIP:
`187223f766b9faf78ac8ec07b82fb6ac196feb29d8b10494396b8773d50c6b97`.
All 60 catalog entries, profile memberships, pinned revisions, selected
artifacts, preservation-policy bytes and dependency relationships are retained.
No previously acquired model, manifest or registry has been changed by development.

## Write boundary

Supported operator write entrypoints (`model_acquire.py` and
`model_registry.py`) open a `StorageSession`. The configuration selects the
longest matching approved rule, checks an actual Linux mount record against
`/dev/disk/by-uuid`, confirms block-device identity, filesystem type where
configured, writable mount options, access, reserve, and non-symlink paths.
Missing/inaccessible identity fails closed. A same-UUID remount with a different
mount ID aborts the existing session. Bind/subdirectory and nested archive
mounts are deliberately refused. Neither a profile, resume, repair, queue-like
repeated CLI invocation, registry import, nor `--expected-mount` bypasses this.
The toolkit has no separate queue daemon or recovery service.

The root directory is held by an open directory descriptor. Writes use
`/proc/self/fd/<fd>/...`, so later path resolution does not fall through to an
unmounted underlying SSD directory. Rechecks occur at file-mutation boundaries,
per download, after download, during metadata writes and before completion.
A process-local audit hook checks Python mutation paths while the session is
active and rejects unpinned archive writes and symlink descendants. It is a
storage guard, not a sandbox for arbitrary hostile Python code. Low-level
library functions are not a standalone operator interface: callers embedding
them must enter StorageSession; use the guarded CLIs for supported operation.
No environment variable or CLI option disables identity protection.

Already-open files may finish writes on the held filesystem during a detach;
they cannot become files on the underlying mount directory. Loss of identity
prevents subsequent completion commits. An outage may leave a previously
written manifest as `downloading` or a temporary report; metadata inventory
shows incomplete state. The application does not write failure records onto
unavailable/replaced storage. Restoring the volume permits ordinary resume.
This is not a guarantee against controller faults, power-loss corruption,
malicious concurrent directory replacement, or kernel/filesystem failures.
Exclusive operator control of writable archive directories remains required.

The public Hub API in pinned `huggingface_hub==1.33.0` resolves local directory
paths, which would undo descriptor pinning. The guarded adapter therefore
calls that exact dependency's internal local-dir engine directly, preserving
its auth, retry/cache/transfer behavior and returning to the unchanged core
hash verification. An unreviewed Hub version is rejected. The integration
is tested using actual local engine code with synthetic metadata/transport.
This private interface is a maintenance coupling; review it before changing
the dependency pin. Hub local cache paths and Xet cache configuration point
inside `_toolkit` on the held archive. Native transfer groups are aborted/
released before closing the handle. Native Xet behavior under actual hardware
loss still needs operator qualification; no real network/model transfer was
performed in this release's tests.

The inherited dependency can restart interrupted individual transfers; this
release preserves its behavior, not an invented byte-level resume guarantee.
Completed files/shards are reused after hashes. There is no new transport,
quantizer, model execution, pruning or replication service.

## Manifests and reports

Managed payload filenames and expected-file records are relative to the
revision's payload directory. Discovery uses the selected root. Moving the
whole category hierarchy therefore needs no conversion. Historical reports
and registry `managed_copy` paths remain historical. External-instance `paths`
remain explicit custody locations: silently retargeting them would misstate
which copy was hashed. Spreadsheet path-review notes expose them for operator
review. No global string replacement or live migration procedure is applied.
New report paths are rendered using the public archive root, never descriptor
aliases. Existing storage totals, quarantine semantics and current/superseded
classification remain unchanged. `_toolkit` caches are excluded from model
storage subtotals as before but included in whole-filesystem capacity usage.

XLSX is produced with the standard library, no new runtime dependency. Cells
are explicit text/numbers, never formulas from model metadata; no macros or
external links. Catalog estimates and actual stored bytes are separate. The
example workbook is synthetic and says so. A metadata scan is not a new hash
audit, and a hash audit is not proof of physical backup durability.

## Outstanding limits

- UUID-guarded writes are Linux-only in v1.1.0. Other platforms retain read-only
  planning/reporting; writable Windows support under the new mandatory identity
  contract is not qualified and fails closed. No claim of Windows physical
  volume validation is made.
- Physical ext4, real UUID links, DAS disconnect/reconnect, actual read-only
  mounts, block-device removal and privileged normal/lazy-unmount tests could
  not run here. The fixture tests are not hardware validation.
- Full archive migration verification, a new full-payload audit, real Hub
  downloads and real inference were not performed. These remain operator tasks.
- Filesystem UUIDs distinguish the configured volume, not cryptographic
  hardware identity; cloned UUIDs must not be mounted as substitutes. The serial
  number is an additional operator check, not a hardcoded application binding.
- Read-only inventory can inspect an absent/unmounted directory where sensible.
  Use model_storage.py before trusting a production view. Spreadsheet capacity
  does not report underlying SSD figures as the model volume.
- Capacity snapshots can change due to other processes. Reserve checks cannot
  reserve disk space against unrelated writers; no background monitor is added.
- The SHA-256 comparison checks content and membership only. Keep writers stopped;
  it is not a filesystem snapshot, ACL/xattr check or backup service.
- Malformed legacy manifests may require operator diagnosis. Reports never
  silently repair or rewrite them; errors must be investigated.
