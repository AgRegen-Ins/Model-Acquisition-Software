# Edmund-Library: migration, activation, rollback

The reported initial rsync copied 2,622,801,229,755 bytes, 2,230 regular files,
344 directories and 2,574 entries with zero deletions. These are operator
reported copy statistics, not independent verification. This release has not
accessed either production archive. Migration remains **unconfirmed** until
the operator's checksum comparison and acceptance checks pass.

## 1. Quiesce and confirm identities

Stop scheduling new acquisitions. Inspect running processes and wait for active
acquisition, repair, verification, registry-import and reporting jobs to finish.
Do not kill a writer in the middle of a manifest commit. Stop other tools that
write either archive for the entire comparison and cutover window.

```bash
pgrep -af 'model_acquire|model_registry|compare_archives|rsync'
findmnt --mountpoint /srv/community-library --output TARGET,SOURCE,FSTYPE,UUID,OPTIONS
findmnt --mountpoint /srv/ai-models --output TARGET,SOURCE,FSTYPE,UUID,OPTIONS
```

Confirm source UUID `1484dd7e-2c4a-4713-8ea2-de682f7d53ec`, destination UUID
`5c40f571-fb9c-4d75-a5fd-17df7d89af00`, ext4, and the exact mountpoints. Check
the drive serial `Y9Q0A3R7FFHG` using the installed OS's disk inspection tools
as an additional operator check. Do not rely on `/dev/sdc1` staying constant.
A blank or mismatched identity is a stop condition.

From the new application directory after installation:

```bash
.venv/bin/python model_storage.py --root /srv/community-library/models --read-only
.venv/bin/python model_storage.py --root /srv/ai-models --read-only
.venv/bin/python compare_archives.py \
  --source /srv/community-library/models \
  --destination /srv/ai-models > "$HOME/model-migration-sha256-comparison.json"
comparison_exit=$?
printf 'Comparison exit: %s\n' "$comparison_exit"
cat "$HOME/model-migration-sha256-comparison.json"
```

Proceed only with exit 0, `match: true`, no changed/missing/extra entries, and
plausible file/byte counts checked against the actual final source. This reads
both complete trees (roughly 5.25 TB of payload reads for the reported copy),
including `_toolkit`. It writes no archive files, does not deserialize weights,
and does not copy, synchronize, or delete anything. Run it with no concurrent
writers. It checks content and directory membership, not ACLs/xattrs/ownership.
Permission errors, symlinks, unsupported file types, root replacement, or mount
loss abort the comparison. Review any discrepancy; this release supplies no
automatic recopy or deletion command. Empty archives cannot pass.

Keep the comparison output outside both archives. If writes occurred after
comparison, quiesce and repeat it before treating the copy as validated.

## 2. Read-only application acceptance

```bash
.venv/bin/python model_acquire.py --root /srv/ai-models --inventory --format json > "$HOME/models-new-root.json"
.venv/bin/python model_report.py --root /srv/ai-models --output "$HOME/models-new-root.xlsx"
.venv/bin/python model_registry.py --root /srv/ai-models --inventory --format csv > "$HOME/model-accountability-new-root.csv"
```

Review all categories, model IDs, revisions, recorded verification evidence,
file counts, incomplete/failed states and representations. The expected root
contains `_toolkit`, `chat`, `coding`, `reasoning`, `reranking`, `retrieval`,
`research-data`, `research-software`, and `scientific-research` as applicable.
No new hierarchy is required. `verified` plus a metadata check is not a new
SHA-256 audit. Copied manifests are not rewritten by inventory/export.

Registry `paths` referencing old external installations remain historical and
operational for those external instances. The spreadsheet flags them for
review. They are not automatically redirected to a different physical copy.
Imported `managed_copy` strings and old reports are historical. Managed
acquisition/resume discovers manifests under the selected root and uses their
relative expected payload names; no manifest migration is needed.

## 3. Activate only after independent migration approval

Confirm no previous-version process is still targeting the old directory.
Use the new `/opt` application, existing credentials and existing permissions.
Start with the guarded local status operation, which writes reports only:

```bash
.venv/bin/python model_storage.py --root /srv/ai-models
.venv/bin/python model_acquire.py --root /srv/ai-models --status
```

Inspect `_toolkit/reports` and `_toolkit/inventory` at the new root. Check the
old root has no new writes. A collection-wide SHA-256 audit is optional but
recommended as a separate acceptance step; it reads all weights and updates
audit metadata only on the new archive:

```bash
.venv/bin/python model_acquire.py --root /srv/ai-models --verify
```

For a limited acquisition/reuse test, select a single model you already know
is completed. Copy its exact ID from the catalog, then review a dry-run first:

```bash
model_id='REPLACE_WITH_ONE_EXISTING_VERIFIED_MODEL_ID'
.venv/bin/python model_acquire.py --root /srv/ai-models --model "$model_id" --dry-run
.venv/bin/python model_acquire.py --root /srv/ai-models --model "$model_id" --yes --allow-large
```

The placeholder must be replaced, not run literally. The dry-run should show
zero estimated new payload bytes for unchanged completed files. A rerun still
hashes/rechecks them; unchanged payloads are reused. `--allow-large` is required
for large selections even when files already exist. If unexpectedly large new
bytes are shown, stop and diagnose instead of approving. Do not use `--repair`
merely to suppress a discrepancy. This is an operator-run test, not performed
by the developer. An explicitly selected small new acquisition can be approved
later. Compare its manifests, reports and storage location after completion.

## 4. Disconnect/recovery qualification

Never unplug the production archive to test this release. Use an expendable
filesystem on suitable hardware, explicit disposable settings, and fixtures.
Qualify missing UUID, wrong volume, read-only volume, absent mount, normal and
lazy unmount, actual USB I/O errors, reconnect and resume. These physical tests
are outstanding. On a real accidental failure: stop the command, restore the
same UUID at the same mountpoint, run `model_storage.py`, inspect inventory,
and rerun the identical acquisition command. Do not remove lock/partial files
or edit manifests to make an error disappear. The existing lock implementation
releases process locks when the process exits. Inspect any persistent failures.

## 5. Rollback

Stop all new-version writers. Keep both archives and all records intact. The
prior working application remains in its previous installation directory.
The safest rollback is an operational pause using read-only inventory while
the issue is investigated. Do not resume old-root writes automatically.

If reverting the software is necessary, v1.0.4.8.1 can read the unchanged
manifest format at `/srv/ai-models` with explicit `--root` and `--expected-mount`.
Its older guard does **not** provide UUID/pinned-handle protection. Treat
write-enabled rollback as a separate operator-authorized risk decision after
identity/capacity checks. Do not operate old and new writers concurrently.
Do not copy new manifests back over the original archive or reverse-sync
new-root state. New acquisitions since cutover remain on the dedicated disk.
If an old-root rollback is eventually authorized, reconcile those additions
separately before any further acquisitions to avoid duplicate custody records.

## 6. Original archive retirement and replication

No deletion is provided or performed. Keep `/srv/community-library/models`
unmodified until explicit retirement authorization after checksum validation,
application acceptance and suitable backup/replication. HP replication is a
separate one-way system; this application does not download to or manage the
HP disk. Remote registry records remain observations, not second acquisitions.
