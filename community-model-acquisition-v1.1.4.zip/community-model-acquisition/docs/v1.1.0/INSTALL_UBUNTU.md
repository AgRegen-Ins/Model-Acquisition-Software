# Ubuntu installation — v1.1.0

Baseline: Community Model Acquisition Toolkit v1.0.4.8.1. Target: v1.1.0.
Install side by side. Do not overwrite the previous working application or
change archive permissions, mounts, fstab, partitions, drivers, or replication.
The default root in the supplied settings is `/srv/ai-models` itself: do not
append `/models`. The copied category/revision hierarchy stays unchanged.

From the directory containing the downloaded ZIP and matching sidecar:

```bash
sha256sum -c community-model-acquisition-v1.1.0.zip.sha256
unzip -t community-model-acquisition-v1.1.0.zip
sudo mkdir /opt/community-model-acquisition-v1.1.0
sudo chown "$USER:$(id -gn)" /opt/community-model-acquisition-v1.1.0
unzip community-model-acquisition-v1.1.0.zip -d /opt/community-model-acquisition-v1.1.0
cd /opt/community-model-acquisition-v1.1.0/community-model-acquisition
python3 verify_package.py
bash setup-linux.sh
.venv/bin/python -m unittest discover -s tests -v
```

`mkdir` must fail if that installation path already exists; stop and inspect
rather than reusing it. `setup-linux.sh` creates only the application's venv,
installs the unchanged requirements, and prints CLI help. It does not configure
or access archive storage. Dependency installation requires network access or
an operator-prepared wheelhouse. Python 3.10–3.14 is qualified on Linux.

Read `settings.json`. Its longest matching `mount_guards` rule selects an
approved filesystem. No matching rule or missing UUID means no writes.

| Root/prefix | Expected mount | UUID | Write policy |
|---|---|---|---|
| `/srv/ai-models` | `/srv/ai-models` | `5c40f571-fb9c-4d75-a5fd-17df7d89af00` | Primary archive |
| `/srv/community-library/models` | `/srv/community-library` | `1484dd7e-2c4a-4713-8ea2-de682f7d53ec` | Read-only migration source |
| `/srv/system-backups/development` | `/srv/system-backups` | `ddee4515-4a57-4b2f-a074-89b49b87b7fd` | Explicit development roots only |

These are installation-specific settings, not hardcoded module constants.
An alternate reviewed settings file is selected with `--settings FILE`.
`--root` overrides the default directory, but cannot bypass its matched UUID
rule. `--expected-mount` must agree with that rule. Device names such as
`/dev/sdc1` and disk serial numbers are descriptive only: validation uses the
filesystem UUID, Linux mount ID, block-device identity, and pinned directory.

Before activation, follow CUTOVER_EDMUND_LIBRARY.md. Read-only checks:

```bash
.venv/bin/python model_storage.py --root /srv/ai-models --read-only
.venv/bin/python model_acquire.py --root /srv/ai-models --inventory --format json > "$HOME/models-before-cutover.json"
.venv/bin/python model_report.py --root /srv/ai-models --output "$HOME/models-before-cutover.xlsx"
```

Choose a fresh output filename: spreadsheet export refuses overwrite.
`--inventory` does not hash weights or certify migration. `--status` writes
reports and `--verify` writes audit metadata; defer both until activation.
Do not run the acquisition application with sudo. Use existing archive access.
