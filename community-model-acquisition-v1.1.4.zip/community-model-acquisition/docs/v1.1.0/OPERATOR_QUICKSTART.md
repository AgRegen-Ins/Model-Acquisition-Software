# v1.1.0 operator quickstart

Run from `/opt/community-model-acquisition-v1.1.0/community-model-acquisition`.
The reviewed default is `/srv/ai-models`; explicit `--root` remains supported.
Do not activate until the cutover guide's checksum and readiness gates pass.

```bash
# Read-only storage identity and capacity check
.venv/bin/python model_storage.py --root /srv/ai-models

# No network or archive writes; selects an existing profile
.venv/bin/python model_acquire.py --root /srv/ai-models --profile small-cpu --offline-plan

# Live metadata plan, without payload acquisition or archive writes
.venv/bin/python model_acquire.py --root /srv/ai-models --profile small-cpu --dry-run

# Only after reviewing the plan and explicitly approving this selection
.venv/bin/python model_acquire.py --root /srv/ai-models --profile small-cpu --yes
```

Profiles retain their prior meanings. For a single model use `--model EXACT_ID`;
repeat `--model` for a bulk selection. For ≥50 GB selected bytes use
`--yes --allow-large`; `--yes` alone never bypasses the interlock. Review the
actual plan rather than assuming a profile's size. Free capacity must satisfy
`int(remaining_new_bytes * 1.10) + 1,073,741,824`, with existing repair reserve
behavior retained. Every write session also requires at least 1 GiB available.

After an interruption, restore the correct mount, pass `model_storage.py`,
and rerun the same command. Completed files are revalidated and reused.
Byte/chunk-level partial reuse remains dependent on the pinned Hub/Xet engine;
there is no promise that every interrupted shard resumes at its last byte.
Never rename upstream files or delete originals to force progress.

```bash
# Read-only local disk inventory; CSV imports into LibreOffice/Excel
.venv/bin/python model_acquire.py --inventory --sort size
.venv/bin/python model_acquire.py --inventory --format csv > "$HOME/model-storage.csv"
.venv/bin/python model_registry.py --inventory --format json > "$HOME/model-accountability.json"

# Reproducible catalog + acquired + incomplete + not-acquired spreadsheet
.venv/bin/python model_report.py --output "$HOME/model-inventory-NEW-DATE.xlsx"
# Same data as JSON, including capacity and migration/path-review notes
.venv/bin/python model_report.py > "$HOME/model-report.json"

# Writes current reports on the guarded new archive
.venv/bin/python model_acquire.py --status
# Collection-wide full-payload hash audit; writes audit records
.venv/bin/python model_acquire.py --verify
```

Spreadsheet output must be a new path outside configured archive mounts. This
keeps reporting read-only against storage. It includes catalog-only entries
with zero actual local bytes and a separate estimated-byte field. Managed,
external, and remote custody states are distinct. It never declares migration
validated. Capacity numbers are withheld when filesystem identity cannot be
confirmed, rather than showing the internal disk's free space.

Model layout remains:
`/srv/ai-models/<category>/<model-id>/<immutable-revision>/payload/<upstream-filename>`
with sibling `manifest.json` and `repository.json`. Current reports remain in
`/srv/ai-models/_toolkit/inventory/`. Source code and metadata are inert data.
There are no automatic downloads, inference runs, conversions or deletions.
