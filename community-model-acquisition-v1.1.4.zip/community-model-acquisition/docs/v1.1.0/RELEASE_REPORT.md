# Community Model Acquisition Toolkit v1.1.0

Complete dedicated-storage release based exclusively on verified v1.0.4.8.1.
The supplied configuration defaults to `/srv/ai-models` and its UUID
`5c40f571-fb9c-4d75-a5fd-17df7d89af00`. All 60 catalog entries, profile memberships
and preservation-policy content remain unchanged.

The release adds UUID validation, descriptor-pinned writes and repeated storage
checks across acquisition, status/audit reporting and registry operations.
It retains existing model layout, relative manifests, hashing, file reuse,
quarantine and retention. It adds an inert XLSX inventory export, read-only
storage preflight and read-only SHA-256 migration comparison.

**Qualification:** 372 tests per interpreter, all passed on Python 3.10.22, 3.11.17, 3.12.14, 3.13.16, 3.14.8.
Source and fresh final-package extraction both pass: 3,720 executions, 0 failures,
0 errors, 0 skipped. Ubuntu setup/startup, ZIP CRC, exact membership, packaged
file hashes and external checksum are verified. The ZIP checksum is in its
matching `.zip.sha256` file and package-validation JSON.

**Not claimed:** physical USB/DAS validation, completed production migration,
real-model downloads, Dell full-payload verification or HP benchmarks.
The new mandatory writable-volume mode is Linux-only. The unprivileged
mount-test environment is unavailable; simulated tests are identified as such.
The pinned Hugging Face internal interface requires review before dependency
updates. These are explicit limitations, not hidden acceptance claims.

Start with INSTALL_UBUNTU.md and CUTOVER_EDMUND_LIBRARY.md. Retain the original
archive and old software. Activate only after independent migration checks pass.
No retirement/deletion, production migration or HP replication was performed.

## Deliverables

- `community-model-acquisition-v1.1.0.zip`: full runnable application.
- Matching `.zip.sha256`: package checksum.
- `source-diff-v1.0.4.8.1-to-v1.1.0.patch`: exact source/config/test/doc differences.
- `CHANGE_REPORT_v1.1.0.md`: changes and compatibility boundaries.
- `QUALIFICATION_REPORT_v1.1.0.md`: exact qualification and outstanding checks.
- `INSTALL_UBUNTU_v1.1.0.md`: side-by-side installation.
- `CUTOVER_EDMUND_LIBRARY_v1.1.0.md`: verification, activation, rollback, retirement gate.
- `OPERATOR_QUICKSTART_v1.1.0.md`: ordinary acquisition and reporting.
- `STORAGE_DESIGN_AND_LIMITATIONS_v1.1.0.md`: design and remaining risks.
- `inventory-example-v1.1.0.xlsx`: clearly labeled synthetic example.
- `validation-results-v1.1.0.zip`: executable-test logs and integrity evidence.
