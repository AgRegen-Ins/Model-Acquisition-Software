# v1.1.0 change report

## Starting point and preservation

Authoritative baseline: Community Model Acquisition Toolkit v1.0.4.8.1.
ZIP SHA-256: `187223f766b9faf78ac8ec07b82fb6ac196feb29d8b10494396b8773d50c6b97`.
The baseline contains 60 model entries and 322 passing tests. All catalog values,
IDs, repositories, revisions, profiles, dependencies and preservation-policy
content remain byte-identical. Existing acquisition manifests require no
conversion. Production archives were not accessed or modified.

## Production changes and rationale

| File | Change |
|---|---|
| `settings.json` | New default root and explicit UUID rules; original archive read-only; approved backup-development prefix |
| `modelkit/volume.py` (new) | Identity, writable/reserve checks, pinned directory session, mutation guard, narrow pinned Hub engine integration |
| `model_acquire.py` | Guard all writable CLI operations, including status/verify; config default root; public report paths; reject contradictory configure/planning flags |
| `model_registry.py` | Guard register/verify/import commands and support configured default root |
| `modelkit/core.py` | Pre/post-transfer and commit checkpoints; narrow trusted descriptor ancestor handling; public serialized paths; no change to payload hashing/selection semantics |
| `modelkit/mounts.py` | Preserve legacy presence guard and defer to active stronger session |
| `modelkit/huggingface.py` | Route guarded transfers through the exact pinned local engine without resolving away the handle |
| `modelkit/storage.py` | Permit only active trusted root handle; render public paths; accounting and status algorithms unchanged |
| `modelkit/archive_report.py`, `modelkit/workbook.py` (new) | Existing accountability data to inert XLSX; relative locations, file counts, successful-acquisition time and capacity |
| `model_report.py` (new) | Read-only archive export to a new external output file |
| `model_storage.py` (new) | Read-only identity/capacity preflight; no migration approval flag is persisted |
| `compare_archives.py` (new) | Independent read-only SHA-256 comparison with directory handles and identity rechecks |
| `verify_package.py` (new) | Operator check of packaged-file SHA-256 values |
| `setup-linux.sh` | Install software without touching archives; archive activation stays separate |
| `modelkit/__init__.py` | Version 1.1.0 |

`requirements.txt`, the catalog, policy, dependency resolver and registry
implementation are unchanged. No source converter, competing registry, queue
daemon, model executor or replication service has been introduced.

## Test/documentation changes

50 new safety/reporting/migration cases supplement all 322 inherited cases.
`tests/storage_test_support.py` isolates the new storage boundary in inherited
CLI tests; new safety tests exercise that boundary directly. Historical source
checks authenticate `tests/fixtures/storage-maintenance-delta.json` and reject
unapproved changes before comparing to older protected definitions. Exact file
membership and changes are in `FILE_CHANGES.json`. The unified source diff is
provided separately; all pre-existing release evidence is retained unchanged.

README and CHANGELOG lead with v1.1.0 and preserve history. Current installation,
cutover, rollback and ordinary commands live under `docs/v1.1.0/`. The synthetic
spreadsheet has its generator and JSON snapshot in `examples/`. No new runtime
spreadsheet dependency is needed.

## Deliberate compatibility boundaries

- Existing manifest/schema, model selection, source metadata, hashes, retries,
  quarantine, revisions, retention, dependencies and storage arithmetic remain.
- New mandatory write protection refuses roots without a reviewed UUID rule.
  Old `--expected-mount` cannot silently weaken identity checks.
- The supplied old-root rule is read-only. Software rollback does not authorize
  reopening the old archive for writes.
- Writable strict-identity operation is Linux-only; Windows read-only use is
  retained, and unsupported writes fail closed rather than bypass validation.
- The pinned Hub private interface is necessary because its public wrapper
  resolves descriptor paths. Its exact version and file-writing engine are
  tested. See limitations before any dependency upgrade.
- No migration string-replacement was performed. External custody paths must
  be reviewed as distinct physical instances.

## Result

372 tests pass on each of five supported Python versions in source and clean
extraction (3,720 passing executions). Full results and outstanding physical
qualification are in QUALIFICATION_REPORT.md. Production archive checks and
activation remain operator-controlled and have not been claimed complete.
