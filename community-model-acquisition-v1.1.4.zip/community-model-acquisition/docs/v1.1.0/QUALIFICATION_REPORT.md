# v1.1.0 test and qualification report

Qualification date: October 21, 2026. This is software qualification in a Linux
development environment, not production storage or hardware qualification.

## Exact automated results

Baseline v1.0.4.8.1: **322 tests passed**, 0 failed, 0 errors, 0 skipped
on Python 3.12.14. Baseline ZIP SHA-256, CRC and all 706 packaged-file hashes
were verified before development.

v1.1.0: **372 tests per run = 322 inherited + 50 new**.

| Python | Source passed | Fresh extraction passed | Failed | Errors | Skipped |
|---|---:|---:|---:|---:|---:|
| 3.10.22 | 372 | 372 | 0 | 0 | 0 |
| 3.11.17 | 372 | 372 | 0 | 0 | 0 |
| 3.12.14 | 372 | 372 | 0 | 0 | 0 |
| 3.13.16 | 372 | 372 | 0 | 0 | 0 |
| 3.14.8 | 372 | 372 | 0 | 0 | 0 |

The qualification matrix totals **3,720 passing test executions** across the
source and extracted package. Diagnostic development reruns are not added to
that total. No test uses multi-GB weights. All model acquisitions use inert
fixtures, mocks or the real pinned Hub local-dir engine with fake network
metadata and a tiny synthetic transport. No live Hugging Face model repository
was queried for this storage-only release; unchanged catalog evidence is retained.

## Required case mapping

| Requirement | Executed qualification | Result |
|---|---|---|
| Correct filesystem | Mock UUID/block-device identity; real pinned directory, writes and hashes | Pass; simulated identity |
| Missing mount | Existing directory with absent mount record, no writes | Pass |
| Incorrect filesystem | Wrong UUID device, wrong/replaced mount ID, bind/nested restrictions | Pass |
| Interrupted download | Loss after fixture payload write; no verified manifest commit | Pass |
| Resume | Reconnect, rehash/reuse completed file; inherited interruption/resume coverage | Pass |
| Existing completed model | Guarded CLI rerun with adapter redownload forbidden | Pass |
| Migrated archive | Copy fixture with preserved metadata to new root, discover/reuse and compare hashes | Pass |
| Manifest integrity | Bytes unchanged on copy/read-only report; payload SHA-256 and provenance preserved | Pass |
| Capacity | Plan reserve rejection, per-write minimum reserve, large confirmation remains mandatory | Pass |
| Inventory spreadsheet | Catalog-only, complete and incomplete rows; inert typed XLSX, capacity identity handling | Pass |
| Installation/startup | Fresh extracted setup-linux.sh creates venv, installs unchanged requirements and starts CLI | Pass |
| Regression | All 322 inherited method cases retained, including registry, quarantine and path safety | Pass |

Additional cases cover read-only status versus writing audit operations, registry
write guarding, non-Linux fail-closed behavior, traversal/symlink boundaries,
namespace replacement with no underlying-directory writes, pinned HF engine
arguments/actual local-file engine reuse, SHA-256 comparison differences and
empty-source refusal, spreadsheet overwrite rejection, and configure/planning
flag combinations. Original catalog and preservation-policy bytes are identical.

Historical immutable-source guards now authenticate exact approved v1.1.0
source deltas before applying their original checks. They do not exclude whole
functions without validation. The inherited CLI tests replace only the newly
introduced StorageSession boundary, continuing to test the former command
behavior and legacy mount-presence cases; the new tests call the real session
with controlled identity probes. No inherited case was deleted or skipped.

## Spreadsheet and package validation

The generated synthetic XLSX opens through openpyxl and Artifact Tool, exposes
all three intended sheets, contains the expected statuses and numeric sizes,
and has no formula-error matches. Rendered Models, Capacity and Read me ranges
were inspected for legibility. The workbook does not require either library
at runtime: the application exporter uses standard-library OpenXML/ZIP only.
Native Microsoft Excel/LibreOffice execution was not performed.

The final ZIP is checked for CRC, exact intended member list, internal version,
all packaged SHA-256 values and equality to its external SHA-256 sidecar.
The final extraction is tested again with the same interpreter matrix. Detailed
logs, per-run JSON summaries, baseline verification, installation output and
package validation are in the separately downloadable validation bundle.

## Not executed / environment unavailable

There are **zero automated skips**. The following are separate operational
qualification items, not passing tests or silently skipped hardware cases:

- Real ext4 device UUID discovery on Edmund-Library and its physical DAS.
- Actual normal/lazy unmount, USB cable loss, controller timeout and reconnect.
- Real alternate/wrong/read-only physical mounts and system-user permissions.
- Production source/destination checksum comparison and actual 2.62 TB migration.
- Real model payload download, production full-payload audit and HP inference.
- Windows writable-volume qualification under the new mandatory identity policy.

A disposable mount namespace probe (`unshare -Urnm true`) was rejected with
`Operation not permitted` when writing `/proc/self/uid_map`. No attempt was made
to obtain elevated privileges, mount or reformat production devices. The
namespace-replacement test uses ordinary temporary directories and a held file
descriptor; it is not presented as a physical unmount test.

## Acceptance decision

The executable software and packaging checks pass. The release is ready for
**controlled Ubuntu deployment**, contingent on the operator's independent
migration verification and the cutover guide. No production migration approval
is implied. Physical storage qualification and a real limited acceptance run
remain outstanding.
