# Release report — Community Model Acquisition Toolkit v1.0.4.8.1

Exclusive baseline: v1.0.4.8 ZIP SHA-256 `3328fa8f812d7fc71ed147794221c6c21981f8688089d767c4911eaa4ff40d14`. Baseline CRC, exact 684-member membership and all 683 packaged-file hashes verified. All 293 baseline tests passed on Python 3.12.14.

This maintenance release corrects rejection of legitimate repository names beginning with underscores. It adds a payload-component validator, preserves the strict internal identifier validator, rejects raw normalization aliases and retains symlink/root containment checks. Final post-acquisition reporting failures now explicitly distinguish reporting failure from the per-model acquisition results, remain nonzero failures and can be retried with `--status` after the cause is resolved.

The precise failure was reproduced using a legacy-format OpenScholar-style fixture plus two synthetic model acquisitions. Both new acquisitions and the legacy manifest remained verified; final `main -> inventory -> safe_path -> safe_name` raised on `__init__.py`. Storage inventory separately marked the source fixture partial without changing the verified manifest. Traceback/failure-state evidence is packaged.

All 60 catalog entries, all profile definitions/memberships and preservation-policy metadata are byte-identical to v1.0.4.8. No new models, artifact selection, dependency or archive layout changes. Production edits are confined to `modelkit/core.py`, the final reporting diagnostic in `model_acquire.py`, and version metadata. All other production modules/settings/dependencies remain unchanged. No migration, redownload, archive edit or model execution was performed.

Historical exact-source regression checks are retained through a hash-pinned literal patch reversal, not by excluding whole functions/files. All 293 inherited test methods remain; 29 new tests cover path security and end-to-end workflows. Final cross-Python and fresh-extraction outcomes are in the external validation report.

See `PATH_VALIDATION_FIX_V10481.md` for root cause, exact old/new rules, compatibility exceptions and security boundaries. See `UBUNTU_ACCEPTANCE_V10481.md` for a read-only preinstallation assessment, side-by-side installation, no-rehash metadata check, reporting retry and later optional full audit.

No actual Dell manifest or model payload was accessed in development. The real operator's recorded verification output is distinct from a new full hash audit. Synthetic reproduction establishes the failure mechanism but does not independently identify the exact first offending file in the Dell archive. Canonical historical filenames remain supported; noncanonical aliases such as `a//b` and `a/./b` are intentionally rejected. Case-sensitive versus case-insensitive storage and hostile concurrent symlink-race hardening are not redesigned by this fix.
