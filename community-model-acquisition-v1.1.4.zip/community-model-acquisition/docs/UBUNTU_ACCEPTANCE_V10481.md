# Ubuntu acceptance — v1.0.4.8.1

This is an application-only maintenance update. Preserve the existing v1.0.4.8 installation and all model data. Do not rerun the seven-model acquisition merely to repair its final report. All commands below are operator-invoked; development did not access the Dell.

## 1. Read-only preinstallation assessment on the Dell

From any terminal:

```bash
hostname
mountpoint /srv/community-library
df -h /srv/community-library
python3 - <<'PYASSESS'
import json
from pathlib import Path
root=Path('/srv/community-library/models')
for p in sorted(root.glob('*/*/*/manifest.json')):
    if p.is_symlink():
        print('SKIP symlink manifest:',p)
        continue
    try:
        s=json.loads(p.read_text())
        names=[f['path'] for f in s.get('expected',[]) if any(part.startswith('_') for part in f['path'].split('/'))]
        if names or 'abliterated' in s['entry']['id'] or 'grpo-uncensored' in s['entry']['id']:
            print(s['entry']['id'],s.get('status'),len(s.get('files',{})), '/',len(s.get('expected',[])))
            for n in names[:5]:print('  underscore path:',n)
            if len(names)>5:print('  additional underscore paths:',len(names)-5)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        print('UNREADABLE/MALFORMED manifest:',p,type(exc).__name__)
PYASSESS
```

This reads JSON only, does not execute repository code, does not alter metadata and does not hash payloads. Recorded `verified` status is historical evidence, not a new cryptographic audit. Keep the output for comparison. Do not edit manifests or rename `__init__.py` files.

## 2. Validate and install alongside the old application

Download the new ZIP and its matching sidecar to `~/Downloads`, preserving the filenames below. If your browser appended `(1)`, use the actual names consistently. Run:

```bash
cd "$HOME/Downloads"
sha256sum -c community-model-acquisition-v1.0.4.8.1.zip.sha256
```

Continue only after `OK`. Install in a new application directory; do not overwrite an existing installation:

```bash
if [ -e /opt/community-model-acquisition-v1.0.4.8.1 ]; then
  echo 'Destination already exists; stop and inspect it before continuing.'
else
  sudo install -d -m 0755 -o "$USER" -g "$(id -gn)" /opt/community-model-acquisition-v1.0.4.8.1 &&
  unzip "$HOME/Downloads/community-model-acquisition-v1.0.4.8.1.zip"     -d /opt/community-model-acquisition-v1.0.4.8.1
fi
```

If that reports an existing destination or an extraction error, stop. Otherwise:

```bash
cd /opt/community-model-acquisition-v1.0.4.8.1/community-model-acquisition
python3 - <<'PYCHECK'
import hashlib,json
from pathlib import Path
for name,expected in json.loads(Path('PACKAGE-CHECKSUMS.json').read_text()).items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==expected,name
print('All packaged-file checksums passed')
PYCHECK
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -c 'from modelkit import __version__; print(__version__)'
```

Expected: 322 passing tests, version `1.0.4.8.1`. Use Python 3.10–3.14. Requirements are unchanged; dependency installation is explicit. Keep application code separate from model data. Do not run acquisition as root and do not change archive mounts/permissions.

## 3. Focused read-only postinstallation check — no weight hashing

From the new application directory:

```bash
.venv/bin/python - <<'PYASSESS'
from pathlib import Path
from modelkit.core import load_catalog,inventory,safe_path
root=Path('/srv/community-library/models')
c=load_catalog(Path('catalog.json'))
for name in ['__init__.py','_private.py','__main__.py','_config.json','training/torchtune/__init__.py']:
    safe_path(root/'validation-only-unused-root',name)
print('Python repository path examples accepted; no files created.')
data=inventory(root,c,verify=False)
ids=set()
import json
for version in ('v1.0.4.7','v1.0.4.8'):
    ids.update(json.loads(Path(f'evidence/{version}/new-ids.json').read_text()))
for row in data['models']:
    if row['id'] in ids or 'openscholar' in row['id'].lower():
        print(row['id'],row['status'],row.get('problems',[]))
problems=[r for r in data['models'] if r['status'] in ('partial','failed')]
print('Collection metadata scan completed. Partial/failed revisions:',len(problems))
for row in problems:print(row['id'],row['status'],row.get('problems',[]))
PYASSESS
```

This checks existing manifests plus file existence/size/mtime across the collection. It writes neither manifests nor reports and does not rehash payloads. It also demonstrates final collection inventory no longer fails on `__init__.py`. Expect the seven acquired revisions to remain verified if unchanged. Investigate any real missing/changed file; this fix does not conceal it. Superseded/partial historical revisions may legitimately produce other statuses.

Read-only storage inventory is also available:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format json
```

## 4. Retry final reporting without downloading

After the read-only check succeeds:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --status
```

This is the deliberate reporting retry. It creates current reports under `_toolkit/reports` and `_toolkit/inventory`; it uses recorded hashes plus size/mtime checks, not a full weight rehash. It does not download files, rename payloads, replace originals or rewrite acquisition manifests. An unsafe/unreadable unrelated record can still produce an error; do not suppress it. Share that output rather than editing records to force success.

## 5. Later full audit, if desired

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --verify
```

This is collection-wide, reads full payloads and writes audit metadata. It can take a long time on the HDD. It is not required for the focused reporting acceptance check and does not download replacement weights. Acquisition-time verification records remain useful, but only a new full audit can establish current byte-for-byte integrity after possible later disk changes. Do not combine `--verify` with model selectors expecting a targeted audit.

No manifest/schema migration occurs. The old installation remains available for comparison, but retains the reporting bug. The seven model acquisitions should not be restarted unless a separate real acquisition problem is established.
