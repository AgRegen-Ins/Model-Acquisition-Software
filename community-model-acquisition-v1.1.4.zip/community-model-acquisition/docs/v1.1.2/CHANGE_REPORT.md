# v1.1.2 — test-fixture portability maintenance

## Root cause and evidence

The v1.1.1 simulated permission fixture replaced mount/inode metadata but copied `st_uid` and `st_gid` from the temporary directory created by the test runner. Under the development container's UID/GID 0 this accidentally represented the intended root-owned ext4 recovery directory. Under an ordinary account it represented a non-root-owned directory. The production detector correctly refused the exclusion, and the fixture's simulated EACCES then produced the reported failures.

The unchanged v1.1.1 fixture reproduced both reported results when given UID/GID 1000 metadata: inventory `scan_complete: false` with `Cannot fully scan: lost+found`, and comparison `{"permission_error": "lost+found"}`. The comparison assertion accessed a missing `match` key, explaining the test error as well as the inventory assertion failure. These are invalid positive-case fixtures under an ordinary account, not grounds to weaken production owner checks. The original all-root qualification missed this portability defect.

The six skips on an ordinary account are expected: those optional tests require a root-owned mode-000 fixture and a child process with capabilities dropped. The simulated counterparts must pass without root privileges. Do not run the application or test suite with sudo to hide the defect.

## Correction and preservation

Only the **simulated** recovery entry now explicitly receives UID/GID 0, alongside its existing synthetic inode 11 and ext4 mount identity. The real-permission fixture continues to use actual ownership. No chown, chmod of production files, or permission-policy exception was added.

New tests exercise simulated metadata for 0:0, 1000:1000, 1000:0, 0:1000 and 65534:65534, retain error reporting for unrelated and nested directories, and hash-check 25 unchanged application/configuration files. All 412 inherited test methods remain present; three new methods bring the suite to 415. Existing tests still reject non-root ownership in the actual detector.

All production Python source except `modelkit/__init__.py` version metadata is byte-identical to v1.1.1. Catalog, profiles, settings, installers, dependencies, mount/UUID checks, inventory/comparison behavior, manifests, resume, acquisition, verification, quarantine and retention are unchanged. The existing exact-source guards remain unchanged. Only tests/fixture data, version metadata, release documentation and package checksums change.

Authoritative baseline ZIP SHA-256:
`d39bc47dac4ed3147375ed5e77980df7250560dd85526ba8c9bc2a63f719fd01`

## Production status and boundaries

The operator has confirmed that v1.1.1 production inventory reports `scan_complete: true`, no warnings, 35 revisions, and the expected ext4 recovery exclusion. That successful acceptance remains valid. The migration and HP replica were independently checksum-verified previously. No repeat migration or full 2.62 TB comparison is required for this test correction.

Write-enabled production activation remains **unauthorized**. No archive/model files, storage permissions or production configuration were accessed or modified during this release. No models were downloaded or executed.

## Read-only acceptance

Preserve v1.1.1 and install v1.1.2 alongside it, using the existing installation workflow and a fresh application virtual environment. In the download directory:

```bash
sha256sum -c community-model-acquisition-v1.1.2.zip.sha256
unzip -t community-model-acquisition-v1.1.2.zip
```

Extract into a new version-specific application directory. From its `community-model-acquisition` directory:

```bash
python3 verify_package.py
bash setup-linux.sh
.venv/bin/python -m unittest discover -s tests -v
```

On an ordinary Linux account, expect **415 tests: 409 passed, 6 documented skips, zero failures/errors**. The six skips are the optional real root-owned fixture tests. On the qualified development environment all 415 run and pass. Do not treat documented skips as failures or bypass them with privileged application execution.

An optional read-only inventory check can use:

```bash
.venv/bin/python model_acquire.py --root /srv/ai-models --inventory --format json > /tmp/model-inventory-v112.json
```

No acquisition, status/verification writeback, comparison of all model bytes, or archive activation is required. Return to the preserved v1.1.1 application if acceptance fails; there is no archive migration or manifest rollback to perform.

## Qualification limitations

The environment cannot switch to an actual non-root UID/GID (the user namespace does not map those IDs). Ordinary-account behavior is exercised by injecting non-root fixture ownership and the non-root test eligibility result; it is explicitly **simulated**, not a claim of a real ordinary-user session. Separate real-permission tests use disposable root-owned mode-000 directories and capability-dropped child processes. No new physical ext4 or USB-DAS qualification was performed. Exact source/extraction results and package verification are in the accompanying release report and evidence bundle.
