# Ubuntu acceptance — v1.0.4.8

Acquire on the Dell's existing writable authoritative model archive. Do not direct acquisition to an HP read-only share. No mount/permission changes or inference setup are required by this release.

## Validate and install alongside the existing toolkit

Run from the directory containing the downloaded ZIP and sidecar:

```bash
sha256sum -c community-model-acquisition-v1.0.4.8.zip.sha256
mkdir toolkit-v1.0.4.8
unzip community-model-acquisition-v1.0.4.8.zip -d toolkit-v1.0.4.8
cd toolkit-v1.0.4.8/community-model-acquisition
python3 - <<'PY'
import hashlib,json
from pathlib import Path
for name,expected in json.loads(Path('PACKAGE-CHECKSUMS.json').read_text()).items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==expected,name
print('All package checksums passed')
PY
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -c 'from modelkit import __version__; print(__version__)'
```

Use Python 3.10–3.14. Expected results: 293 tests passing, version `1.0.4.8`. Dependency installation is explicit and uses unchanged requirements. Place application code in your established applications location (for example an operator-managed `/opt` installation), separate from model storage; no application belongs in the model payload directories. Keep the old release intact.


## Operator-controlled acquisition

Run on the Dell writable archive, using the existing mount and permissions. Do not acquire into the HP read-only Samba share. Each command below selects exactly one new variant.

### Huihui GPT-OSS-120B Abliterated — Q4_K_M GGUF

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-gpt-oss-120b-abliterated-gguf-q4-k-m --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-gpt-oss-120b-abliterated-gguf-q4-k-m --yes --allow-large
```

To resume an interruption, repeat the same acquisition command. Keep the pinned catalog and target root unchanged; completed verified files are reused.

### Huihui Qwen3-Next-80B-A3B Thinking Abliterated — Q4_K_M GGUF

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m --yes
```

To resume an interruption, repeat the same acquisition command. Keep the pinned catalog and target root unchanged; completed verified files are reused.

### Huihui Qwen3-Coder-Next Abliterated — Q4_K_M GGUF

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-qwen3-coder-next-abliterated-gguf-q4-k-m --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-qwen3-coder-next-abliterated-gguf-q4-k-m --yes
```

To resume an interruption, repeat the same acquisition command. Keep the pinned catalog and target root unchanged; completed verified files are reused.

### Huihui Qwen3-Next-80B-A3B Instruct Abliterated — Q4_K_M GGUF

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m --yes
```

To resume an interruption, repeat the same acquisition command. Keep the pinned catalog and target root unchanged; completed verified files are reused.

### Qwen3-Next-80B-A3B Thinking GRPO-Uncensored — Q4_K_M GGUF

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m --yes
```

To resume an interruption, repeat the same acquisition command. Keep the pinned catalog and target root unchanged; completed verified files are reused.

## Combined dry-run and acquisition

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model huihui-gpt-oss-120b-abliterated-gguf-q4-k-m \
  --model huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m \
  --model huihui-qwen3-coder-next-abliterated-gguf-q4-k-m \
  --model huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m \
  --model qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m \
  --dry-run
```

Fresh selected total: 281,647,056,142 bytes; minimum free space including current reserve: 310,885,503,580 bytes. The development host cannot hold this set and the live dry-run should report insufficient space; dry-run exit 0 means successful planning, not acquisition readiness. The actual acquisition refuses insufficient capacity. Already-present verified files reduce new bytes.

For an explicitly authorized combined acquisition, repeat that exact selection with `--yes --allow-large` instead of `--dry-run`. The 50,000,000,000-byte interlock applies to GPT-OSS and the combined selection. Each Qwen alone is below the threshold; `--yes` never bypasses the large interlock. Do not use `--latest` for reproducible acquisition.

## Completion, verification and inventory

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --status
.venv/bin/python model_acquire.py --root /srv/community-library/models --verify
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --sort size
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format json
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format csv
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format json
```

`--verify` audits the entire collection and writes audit metadata; it is not model-filtered. Storage inventory reports what is actually on disk; the accountability registry can show cataloged-not-downloaded entries. Catalog registration is not completion. A complete acquisition has manifest status `verified`, all required payload files present, and successful hashes; partial/failed status is not accepted. Reports refresh under `_toolkit/inventory/`.

Expected new directories and runnable inputs:

- `/srv/community-library/models/reasoning/huihui-gpt-oss-120b-abliterated-gguf-q4-k-m/1c169e33a4f278f10aca60a683a198e997ceb4d6/manifest.json`; weights under sibling `payload/`. Both raw parts are required before separate concatenation.
- `/srv/community-library/models/reasoning/huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m/c2e26d259894d06f56b1b40cef9b89648ff76e70/manifest.json`; weights under sibling `payload/`. Single runnable filename: `Huihui-Qwen3-Next-80B-A3B-Thinking-abliterated.Q4_K_M.gguf`.
- `/srv/community-library/models/coding/huihui-qwen3-coder-next-abliterated-gguf-q4-k-m/1f6b22858800db92ac4b75d8396d44d6869031fa/manifest.json`; weights under sibling `payload/`. Single runnable filename: `Huihui-Qwen3-Coder-Next-abliterated.Q4_K_M.gguf`.
- `/srv/community-library/models/chat/huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m/21d45bfb1a0db79ff0328890b20a37782340c395/manifest.json`; weights under sibling `payload/`. Single runnable filename: `Huihui-Qwen3-Next-80B-A3B-Instruct-abliterated.Q4_K_M.gguf`.
- `/srv/community-library/models/reasoning/qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m/25a85ef6a9e95f8b0ee6778b4b96a54a4a0575b0/manifest.json`; weights under sibling `payload/`. Single runnable filename: `Qwen3-Next-80B-A3B-Thinking-GRPO-Uncensored.Q4_K_M.gguf`.

## GPT-OSS deployment preparation — separate manual operation

After full archive verification, copy both exact raw parts and their manifest to an HP deployment directory; verify the copied files against the published SHA-256 values in the model report. Do not modify the Dell archive. From that separate deployment directory, concatenate in this exact order into a new file (the command refuses to overwrite an existing output):

```bash
(
  set -o noclobber
  cat -- Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf.part1of2 \
         Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf.part2of2 \
    > Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf
)
stat -c %s Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf
sha256sum Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf
```

Expected joined size: 87,850,987,840 bytes. Record the locally computed joined SHA-256 separately; upstream part hashes do not specify a joined-file hash. A size match alone is not sufficient: both parts must have passed their own published hashes first. An interrupted join leaves an incomplete deployment output; do not execute it or treat it as verified. This join was not performed during development. Use the completed `.gguf` for inference; the other four models are already single GGUF files.

No HP model execution, copying, joining, server setup, runtime installation or benchmark changes were performed by this release. See the benchmark plan for later operator-controlled testing.
