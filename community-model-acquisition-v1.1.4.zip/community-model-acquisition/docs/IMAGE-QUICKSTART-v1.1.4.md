# Ubuntu v1.1.4 image acquisition quickstart

Keep v1.1.3 installed separately. Verify the release checksum from the download directory:

```bash
sha256sum -c community-model-acquisition-v1.1.4.zip.sha256
unzip community-model-acquisition-v1.1.4.zip -d community-model-acquisition-v1.1.4
cd community-model-acquisition-v1.1.4/community-model-acquisition
python3 verify_package.py
bash setup-linux.sh
.venv/bin/python -c 'import modelkit; print(modelkit.__version__)'
.venv/bin/python -m unittest discover -s tests -v
```

Review settings.json before any write; this release retains /srv/ai-models and its approved UUID. It does not alter mounts or permissions. Reuse your separately reviewed installation settings if customized. Do not run acquisition on the HP replica.

```bash
.venv/bin/python model_storage.py --read-only
.venv/bin/python model_acquire.py --profile image-generation-local-inference --list-catalog --format json
.venv/bin/python model_acquire.py --root /srv/ai-models --model sd15-fp16 --offline-plan
.venv/bin/python model_acquire.py --root /srv/ai-models --model sd15-fp16 --dry-run
```

Offline plan uses bundled sizes, not disk verification. Live dry-run resolves selected exact files and shows dependency objects, estimated new bytes, free bytes and reserve. Metadata access does not prove permission to download gated weights. For gated repositories accept the publisher terms and use the installed Hugging Face CLI's `hf auth login` through `.venv/bin/hf auth login`; do not paste tokens into shared logs.

After reviewing the plan, an explicit operator acquisition:

```bash
.venv/bin/python model_acquire.py --root /srv/ai-models --model sd15-fp16 --yes
.venv/bin/python model_acquire.py --root /srv/ai-models --profile image-generation-local-inference --dry-run
.venv/bin/python model_acquire.py --root /srv/ai-models --profile image-generation-local-inference --yes --allow-large
```

Use --allow-large only after review when the selection is >=50GB; the flag never bypasses UUID, capacity or reserve checks. The local-inference profile is intentionally limited; high-end/source-preservation/all can be hundreds of GB or multiple TB. Dependencies are included automatically and deduplicated by ID. To acquire just one listed component, pass its exact ID with --model. No implicit install or inference occurs.

Resume by rerunning the same acquisition command. Do not delete partials or rename revision directories. Already verified files are rechecked and reused. For explicit selected hashing (includes required dependencies):

```bash
.venv/bin/python model_acquire.py --root /srv/ai-models --model sd15-fp16 --verify-selected
.venv/bin/python model_acquire.py --root /srv/ai-models --inventory --format json
.venv/bin/python model_report.py --root /srv/ai-models
.venv/bin/python model_report.py --root /srv/ai-models --output "$HOME/model-inventory-v1.1.4.xlsx"
```

Export must be outside guarded archive mounts and must name a new file. XLSX is manual only. model_report JSON/XLSX includes required dependencies and recorded status; legacy inventory retains its existing storage-oriented format. A report does not perform fresh full-payload hashing. Avoid whole-archive --verify just to verify one image model.

Expected managed layout: `/srv/ai-models/<category>/<model-id>/<immutable-revision>/manifest.json`, `repository.json`, `payload/<exact-upstream-path>`. Completion requires a verified manifest and its complete expected file set, plus verified required component records for pipeline completeness. The `docs/IMAGE-COMPONENTS.json` component_layout gives deployment mapping. Do not rewrite historical manifests to assemble a runtime. Use independently copied/verified deployment files and separately qualified Diffusers/ComfyUI; this toolkit does not create a runnable environment.

If acceptance fails, stop new acquisition and retain both installations and all archive records. Return to the preserved v1.1.3 executable for its existing entries; do not remove image files or edit manifests. No migration or repeat2.62TB checksum comparison is required by this catalog/report extension.
