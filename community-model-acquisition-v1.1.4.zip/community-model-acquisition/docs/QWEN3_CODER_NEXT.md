# Qwen3-Coder-Next — v1.0.4.2

Reviewed 2026-10-04 UTC. This release extends the verified v1.0.4.1 package, SHA-256 `271e0ff01cf0d477be1085331a9e58d94062f253addf0e7c4e8218f87ea39035`. No acquisition or storage code changed.

## Canonical and inference artifacts

| ID | Repository | Immutable revision | Role / provenance | Precision | Selected bytes |
|---|---|---|---|---|---:|
| `qwen3-coder-next-original` | `Qwen/Qwen3-Coder-Next` | `a7fbcb5c0e12d62a448eaa0e260346bf5dcc0feb` | source-weights / official-upstream | BF16 Safetensors | 159,376,351,965 |
| `qwen3-coder-next-gguf-q6-k` | `unsloth/Qwen3-Coder-Next-GGUF` | `ce09c67b53bc8739eef83fe67b2f5d293c270632` | portable-gguf / third-party-derived | Q6_K GGUF recipe | 65,614,001,999 |

Both are Apache-2.0 according to their pinned cards and API metadata. The official card's LICENSE link has no corresponding LICENSE file in this snapshot; no nonexistent file is required. The GGUF metadata also declares Apache-2.0. Unsloth is the converter. Its card and GGUF identify the Qwen base family but do not establish a conversion input commit; `conversion_base_revision` remains null. The canonical pin is a preservation reference, not an assertion about that input commit.

The source repository total equals the source selected bytes. The whole Unsloth multi-quant repository is **1,802,394,170,046 bytes**; only the selected Q6_K set below is acquired. Decimal GB are bytes / 1e9; the Q6_K set is about 61.11 GiB.

## Exact selected files

Source: all **52 files**, including `model-00001-of-00040.safetensors` through `model-00040-of-00040.safetensors` inclusive, plus:

```
.gitattributes
README.md
chat_template.jinja
config.json
generation_config.json
merges.txt
model.safetensors.index.json
qwen3_coder_detector_sgl.py
qwen3coder_tool_parser_vllm.py
tokenizer.json
tokenizer_config.json
vocab.json
```

| Q6_K file | Bytes |
|---|---:|
| `Q6_K/Qwen3-Coder-Next-Q6_K-00001-of-00003.gguf` | 5,936,320 |
| `Q6_K/Qwen3-Coder-Next-Q6_K-00002-of-00003.gguf` | 49,795,838,592 |
| `Q6_K/Qwen3-Coder-Next-Q6_K-00003-of-00003.gguf` | 15,812,217,376 |
| `README.md` | 9,711 |
| **Total** | **65,614,001,999** |

The first shard is metadata-only (zero tensors) and is nevertheless required: it holds tokenizer and chat-template metadata and declares three shards / 843 tensors across the set. The GGUF weights-and-header set totals 65,613,992,288 bytes. The remaining two shards contain weights. No projector is needed: this is a text-only architecture. No other quantizations or calibration imatrix files are selected. The exact 56 selected paths, sizes and upstream hashes are in `evidence/v1.0.4.2/selected-files.json`; catalog `required` makes omission of any selected file an error.

## Architecture and supported capabilities

Publisher family designation: approximately **80B total / 3B active per token**. Hub BF16 tensor count: **79,674,391,296** parameters. `Qwen3NextForCausalLM` uses 48 hybrid layers: three Gated DeltaNet/MoE layers per gated-attention/MoE layer, with 512 routed experts, 10 selected and one shared expert. Native context is **262,144** tokens. Text only.

Shared tags: `agentic-coding`, `software-engineering`, `repository-scale-coding`, `long-horizon-agent`, `tool-use`, `function-calling`, `long-context`, `code-generation`, `reasoning`. The source adds `fine-tuning-source` and `re-quantization-source`; GGUF adds `inference-optimized`. Both have `preservation_priority: core`. No standalone code-review or multimodal capability is asserted.

**Non-thinking mode only.** The reasoning tag describes documented long-horizon problem solving, not a switchable thinking mode. The model does not emit thinking blocks, and `enable_thinking=False` is not required.

## Runtime and training

- **Source Safetensors:** current Transformers; publisher documents vLLM >=0.15.0 and SGLang >=0.5.8. vLLM tool use requires `--enable-auto-tool-choice --tool-call-parser qwen3_coder`; SGLang uses `--tool-call-parser qwen3_coder`. Keep the supplied chat template and tokenizer. Model/parser files are preserved, never executed by this toolkit.
- **Q6_K GGUF:** llama.cpp architecture support is present in released **v0.5.0**, immutable commit `7fe450e19305b828c199d602c23a8337aaa1f03b`. Current source checked at `46847e61582097979f539595d893d83d8e1d1af1`. Load shard `00001-of-00003` with the other two alongside it. Embedded template support and Qwen3-Coder tool parsing are present; use `llama-server --jinja`. vLLM/SGLang support for the source does not establish support for this split GGUF, so they are not recommended for this artifact.
- **GPU distribution:** llama.cpp supports GPU layer offload and `--tensor-split` proportions. Start with layer splitting; the current separate `--split-mode tensor` mode is explicitly experimental. File sharding and GPU allocation are different mechanisms. Backend/kernel support and per-device allocation still matter.
- **Context:** start at 32,768 tokens or lower. Qwen recommends reducing context if memory is insufficient. Hybrid attention reduces some costs but does not eliminate full-attention KV cache, recurrent state, batching or runtime buffers. A native maximum is not a guarantee that the target hardware can serve it.
- **Customization:** canonical BF16 avoids starting from a lossy inference quantization. Transformers' Qwen3Next causal LM implementation exposes training loss and MoE router loss. Unsloth's model guide documents BF16 LoRA on a B200. This supports preserving the source for architecture-aware adapters/fine-tuning, conversion and re-quantization; it does not guarantee arbitrary QLoRA recipes or full training on two 48 GB cards. Validate hybrid/MoE kernels, trainable modules, activation/optimizer memory and tooling first. GGUF remains inference-oriented.

## Hardware target and hierarchy

The Q6_K target is an HP Z8 G4-class workstation with **2 x 48 GB GPUs**, **96 GB aggregate VRAM**, and **256–512+ GB system RAM**. CPU inference is possible only as a limited high-RAM experiment, with no speed claim. The 32 GB Dell is not a practical target.

Q6_K leaves more nominal weight headroom than this repository's Q8_0 set (84,812,255,584 weight/header bytes). That is the deliberate selection rationale, not a benchmark ranking or measured fit guarantee. Selected-file bytes are not runtime VRAM requirements. Dual-card VRAM is not a seamless single memory pool; runtime splitting, each GPU's limits, driver/backend support and interconnect determine feasibility. Full/near-full GPU residency must be measured on the target. BF16 source weights alone exceed 96 GB; source serving/training needs additional capacity or offload.

Intended roles: Qwen3-Coder-30B-A3B Q4_K_M = everyday coder; Next Q6_K = primary workstation coding/agent candidate; 480B-A35B = archival/future hardware. This is an operator deployment hierarchy, not a claim of comparative benchmark performance.

## Profile changes

`coding-workstation` contains exactly, in catalog order:

1. `qwen3-coder-30b-a3b-instruct-gguf-q4-k-m`
2. `qwen3-coder-next-gguf-q6-k`

The existing 30B entry is referenced through the already-supported top-level `profile_members`, leaving its JSON unchanged. No 480B is included. Source Next joins `preservation-source-weights`, `coding`, `coding-archive` and `future`. Q6_K joins `coding` and `coding-workstation`. `all` grows by two. All legacy members retain their order; Dell/local/agentic-core profiles are unchanged. Source preservation remains explicitly opt-in.

## Commands

From the extracted package on Ubuntu:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python model_acquire.py --root /srv/community-library/models --model qwen3-coder-next-original --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models --model qwen3-coder-next-gguf-q6-k --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile coding-workstation --dry-run
# After inspecting the plan and confirming the configured volume is mounted:
.venv/bin/python model_acquire.py --root /srv/community-library/models --model qwen3-coder-next-original --yes --allow-large
.venv/bin/python model_acquire.py --root /srv/community-library/models --model qwen3-coder-next-gguf-q6-k --yes --allow-large
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile coding-workstation --yes --allow-large
```

`--allow-large` does not bypass mount or reserve checks. `--yes` alone still refuses large real acquisitions. Dry runs remain read-only and can report insufficient space without failing the metadata-resolution check. Completed verified files are reused on reruns; no deletion/pruning was added.

## Evidence and limits

Research used pinned cards, configs, Hub file metadata and the GGUF first-shard header. Only the 5.94 MB zero-tensor metadata shard was read for format/template evidence; no weight-bearing shard was downloaded. API manifests capture sizes and LFS/git hashes, not a local full-weight integrity check. Runtime execution, GPU residency, throughput and actual training were not tested.

Authoritative references (snapshots/metadata in `evidence/v1.0.4.2`):

- [Official model card](https://huggingface.co/Qwen/Qwen3-Coder-Next/blob/a7fbcb5c0e12d62a448eaa0e260346bf5dcc0feb/README.md), [config](https://huggingface.co/Qwen/Qwen3-Coder-Next/blob/a7fbcb5c0e12d62a448eaa0e260346bf5dcc0feb/config.json), [source file tree](https://huggingface.co/Qwen/Qwen3-Coder-Next/tree/a7fbcb5c0e12d62a448eaa0e260346bf5dcc0feb).
- [Converter card](https://huggingface.co/unsloth/Qwen3-Coder-Next-GGUF/blob/ce09c67b53bc8739eef83fe67b2f5d293c270632/README.md), [Q6_K files](https://huggingface.co/unsloth/Qwen3-Coder-Next-GGUF/tree/ce09c67b53bc8739eef83fe67b2f5d293c270632/Q6_K).
- [Released llama.cpp architecture](https://github.com/ggml-org/llama.cpp/blob/7fe450e19305b828c199d602c23a8337aaa1f03b/src/models/qwen3next.cpp).
- [Pinned split loader](https://github.com/ggml-org/llama.cpp/blob/46847e61582097979f539595d893d83d8e1d1af1/src/llama-model-loader.cpp), [GPU/split/Jinja flags](https://github.com/ggml-org/llama.cpp/blob/46847e61582097979f539595d893d83d8e1d1af1/common/arg.cpp), [Qwen tool parsing selection](https://github.com/ggml-org/llama.cpp/blob/46847e61582097979f539595d893d83d8e1d1af1/common/chat.cpp), [function calling](https://github.com/ggml-org/llama.cpp/blob/46847e61582097979f539595d893d83d8e1d1af1/docs/function-calling.md).
- [Pinned Transformers training implementation](https://github.com/huggingface/transformers/blob/469230357aab0f2b303b0d638c1f8d06edb14184/src/transformers/models/qwen3_next/modeling_qwen3_next.py).
- [Unsloth deployment/training guide](https://unsloth.ai/docs/models/qwen3-coder-next), reviewed 2026-10-04 (mutable documentation; BF16 LoRA/B200 statement, not a hardware guarantee).
