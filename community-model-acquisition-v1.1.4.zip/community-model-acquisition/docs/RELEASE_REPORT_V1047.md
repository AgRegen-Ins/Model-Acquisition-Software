# Community Model Acquisition Toolkit v1.0.4.7

Review date: 2026-10-16 UTC / 2026-10-15 America/New_York.

## Baseline and scope

Started exclusively from completed **two-model v1.0.4.6**, `community-model-acquisition-v1.0.4.6.zip`, SHA-256:

`f8cbd1246f2a5e82a62b5ab5f5ce87136fd84f2825346c37fc051b16d02fe386`

Confirmed version 1.0.4.6, 53 catalog entries, ZIP CRC, exactly 538 members and all 537 packaged-file hashes. Untouched baseline passed all **242 tests** on Python 3.12.14 before modification. No earlier or separately named OpenScholar release substituted.

Added exactly:

- `huihui-glm-4-7-flash-abliterated-gguf-q4-k-m` — mradermacher conversion, `2d925ab0fdaa279a87485f4786ca22661bf030b2`, single GGUF plus README, 18,132,725,887 bytes selected.
- `huihui-qwen3-32b-abliterated-gguf-q4-k-m` — RoadToNowhere conversion, `36a6a1be225e6728acaec150ae944cf24491f684`, single GGUF plus README, 19,762,152,900 bytes selected.

[Technical manifest and provenance](HUIHUI_MODELS_V1047.md) includes repositories, hashes, licenses, source snapshots, runtime requirements and known limitations. Both are third-party-derived, inference-only portable GGUF variants; no Safetensors sources or unrelated models were added.

## Preservation and compatibility

All **53 existing catalog entry values remain exactly identical**, including IDs, repositories, pins, artifact patterns, provenance, capabilities and runtime metadata. Historical profiles and explicit memberships remain identical; only `all` naturally grows to 55. No new profile introduced. Existing policy records unchanged; two inference-only records added.

All existing production Python files are byte-identical except `modelkit/__init__.py` version. Requirements, setup scripts, settings, mount validation, reserve calculations, large-download rules, hashing, retries/resume, quarantine, retention, inventory, dependency and registry behavior are unchanged. No local archive or installed model file was accessed or modified. No schema migration required.

Historical tests remain; only catalog cardinality and additive `all`/policy-set expectations were updated. The protected-source portability fixture and comparisons are unchanged. No raw `ast.dump()` hash introduced.

Modified baseline files (plus regenerated `PACKAGE-CHECKSUMS.json`):

- `catalog.json`, `preservation-policy.json`, `modelkit/__init__.py`
- `README.md`, `CHANGELOG.md`
- `docs/CATALOG.md`, `docs/PROFILES.md`, `docs/PROVENANCE.md`, `docs/VALIDATION.md`
- `tests/test_toolkit.py`, `tests/test_v103.py`, `tests/test_v104.py`, `tests/test_v1042.py`, `tests/test_v1043.py`, `tests/test_v1044.py`, `tests/test_v1045.py`, `tests/test_v1046.py`

New principal files: `tests/test_v1047.py`, `docs/HUIHUI_MODELS_V1047.md`, `docs/UBUNTU_ACCEPTANCE_V1047.md`, this report and `evidence/v1.0.4.7/`. Exact added/modified path enumeration is in the packaged change manifest; no prior file removed.

## Qualification

**270 tests**: all 242 inherited plus 28 new. Source runs pass on Python **3.10.22, 3.11.17, 3.12.14, 3.13.16 and 3.14.8**. Each run: **270 passed, 0 skipped, 0 failures, 0 errors**.

Focused coverage includes exact entries, immutable pin forwarding, manifest bytes/reserves, quantization/missing-file rejection, correct Huihui versus roslein lineage, source-snapshot uncertainty, gated-source/public-GGUF distinction, roles/provenance, MoE/dense fields, header/templates, dependency/deduplication, protected existing entries/profiles/policies/code, read-only dry-runs, mount/storage checks, large-limit retention, inert synthetic acquisition, hash verification, interruption/reuse, quarantine, missing payload and inventory exports. Existing cross-platform, resume and security tests are retained. No full model payload is downloaded by tests.

Live pinned metadata matched exact selected files and totals. Individual GLM, individual Qwen and combined dry-runs exited 0. Initial free space on the development host was approximately 28.67 GB, enough for each individual reserve but insufficient for combined **42,758,108,489 bytes**; the combined dry-run correctly warned. Individual reserves: 21,019,740,299 and 22,812,110,014 bytes. Both variants and their pair are below the unchanged 50 GB large-download threshold. Synthetic threshold testing confirms larger plans still require `--allow-large` with `--yes`.

Temporary development environments used unchanged requirements plus `socksio` only for this host's SOCKS proxy. This is not a toolkit dependency change. No installation occurred on the user's machines.

## Research boundaries

- Both public GGUF pins, cards, file sizes and published LFS SHA-256 identities resolve. Metadata/header checks passed; full weight hashes were **not** locally verified.
- Two 12 MiB GGUF header prefixes were inspected as inert binary data. No model loading, source-code execution, inference, abliteration or re-quantization occurred.
- GLM's current Huihui template/config could be inspected. Qwen's Huihui source is gated; a configuration request returned HTTP 401. Only public metadata/card were used, with no bypass. The selected GGUF is public and explicitly declares Huihui lineage.
- Neither converter records an exact source commit used for conversion; source commits at review are documentation snapshots. No cryptographic proof of the conversion's source-weight identity is claimed.
- Current llama.cpp source supports the inspected architecture paths, including GLM's `deepseek2` GLM4-MoE-Lite representation. Installed HP compatibility, memory use, speed, refusal reduction and scientific quality are **untested**.
- Qwen's embedded template predates current base-template changes and expects string content. Full runtime testing is a separate acceptance step.

The toolkit adds no automatic downloads, background execution, destructive cleanup, source transformations or runtime deployment. “Abliterated/refusal-reduced” is source classification, not a promise about model behavior.

## Final package validation

The accompanying external `VALIDATION_REPORT_v1.0.4.7.md` records final ZIP CRC, membership, file hashes, SHA-256 sidecar and fresh-extraction test results. It is generated after packaging to avoid a self-referential ZIP checksum. Full source and extraction logs are downloadable in the validation-results ZIP.

[Ubuntu acceptance](UBUNTU_ACCEPTANCE_V1047.md) provides exact dry-run/acquisition/resume/audit/inventory commands. Cataloged, downloaded, fully hash-verified and successfully inferred remain distinct states.
