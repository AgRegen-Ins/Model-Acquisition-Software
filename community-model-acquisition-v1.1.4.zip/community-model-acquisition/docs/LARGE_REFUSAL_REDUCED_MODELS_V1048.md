# Large refusal-reduced models — v1.0.4.8

This release adds five independently selectable inference variants. The original 55 entries and historical profile memberships remain unchanged. No new named profile; `all` naturally contains 60 entries. No source checkpoints are replaced.

## Acquisition and resource totals

| Model | Weight files | Weight bytes | Selected bytes including README | Required free bytes with toolkit reserve |
|---|---:|---:|---:|---:|
| Huihui GPT-OSS-120B Abliterated — Q4_K_M GGUF | 2 | 87,850,987,840 | 87,850,995,429 | 97,709,836,795 |
| Huihui Qwen3-Next-80B-A3B Thinking Abliterated — Q4_K_M GGUF | 1 | 48,410,990,624 | 48,410,995,059 | 54,325,836,388 |
| Huihui Qwen3-Coder-Next Abliterated — Q4_K_M GGUF | 1 | 48,487,032,960 | 48,487,036,956 | 54,409,482,475 |
| Huihui Qwen3-Next-80B-A3B Instruct Abliterated — Q4_K_M GGUF | 1 | 48,410,989,216 | 48,410,993,426 | 54,325,834,592 |
| Qwen3-Next-80B-A3B Thinking GRPO-Uncensored — Q4_K_M GGUF | 1 | 48,487,030,944 | 48,487,035,272 | 54,409,480,623 |

Weights total **281,647,031,584 bytes**. Complete selected files total **281,647,056,142 bytes** (281.647056 GB; 262.304 GiB). A fresh combined plan requires **310,885,503,580 free bytes** under the unchanged `int(new_bytes * 1.10) + 1 GiB` reserve formula.

Permanent archive planning: selected bytes above plus manifests, audit records, filesystem allocation and any retained partial/quarantined data. Fresh files become the payload in the revision directory through the existing Hugging Face local-directory workflow; no additional whole-repository staging copy is introduced. Reserve is a safety allowance, not a measured peak or a guarantee against all cache/quarantine growth. Resume accounts for reusable completed files; current disk free space is checked live. Keep additional headroom for interrupted files and repairs.

Deployment storage is separate: copying all five models to HP needs another weight-sized allocation. GPT-OSS raw-part concatenation additionally needs 87,850,987,840 bytes for a joined file if its parts are retained on the same deployment disk. No merging or conversion runs during acquisition.

## Memory and runtime planning

These are MoE models: approximately 117B total/5.1B active for GPT-OSS and 80B total/3B active for the Qwen family. Active parameters describe computation, not total resident storage. Artifact tensor-directory counts are recorded separately below. These are text models; no multimodal projector or separate runtime tokenizer is required by the inspected GGUF artifacts.

The four Qwen GGUFs each occupy approximately 45.1–45.2 GiB, and GPT-OSS approximately 81.8 GiB. These are weight footprints, not measured total inference RAM. Add KV/recurrent state, compute buffers, allocator overhead and OS memory. For conservative planning only, budget roughly 60–70 GiB system RAM per Qwen and 100–120 GiB for GPT-OSS at an initially constrained context; these ranges are unmeasured allowances, not upstream minimum requirements. Actual memory depends on build, context, batching and offload.

At 48 GB VRAM, GPT-OSS requires substantial system-RAM offload; a Qwen full-offload configuration is tight or insufficient after overhead. At 96 GB VRAM, all weight sets fit the nominal byte budget individually, but runtime overhead/context and per-device placement can still require offload. Two 48 GB devices are not automatically a single transparent 96 GB pool. CPU-resident experts/selective CUDA offload may help fit models, subject to installed build support; PCIe transfers, NUMA locality and CPU compute can limit speed. No performance is claimed.

Start separate inference acceptance at 4096 context tokens and increase only after measuring memory and stability. GPT-OSS uses Harmony-oriented embedded formatting and gpt-oss support; Qwen requires qwen3next hybrid attention/recurrent MoE support, not merely generic Qwen3 support. Use each embedded template and keep Thinking, Instruct and Coder modes distinct. Do not transplant sampling/tool/reasoning assumptions between variants. The current runtime source was reviewed at `e707790c73590c2ff5303045b714afb0c5e22035`; this does not establish compatibility of the HP installed binary. No runtime installation or benchmark was performed.

## Model manifests and provenance

### Huihui GPT-OSS-120B Abliterated — Q4_K_M GGUF

- ID: `huihui-gpt-oss-120b-abliterated-gguf-q4-k-m`
- Repository: https://huggingface.co/mradermacher/Huihui-gpt-oss-120b-BF16-abliterated-GGUF
- Immutable revision: `1c169e33a4f278f10aca60a683a198e997ceb4d6`
- Developer/base: `openai/gpt-oss-120b`
- Converter-declared modification source: `huihui-ai/Huihui-gpt-oss-120b-BF16-abliterated`
- Modification: `abliterated`; converter `mradermacher`; provenance `third-party-derived`.
- Role `portable-gguf`; policy `inference-only`; priority `experimental`; capabilities: inference-optimized, refusal-reduced, general-chat, reasoning.
- Architecture: gpt-oss MoE; 116829156672 stored tensor parameters; approximately 5100000000 active parameters from upstream architecture. 128 experts, 4 selected per token (shared-expert handling remains architecture-specific).
- Artifact context metadata: 131072 tokens; not a tested workstation context.
- Q4_K_M preset; actual tensor types/counts: Q8_0=37, F32=433, Q5_0=181, Q4_K=36.
- License: `apache-2.0`. Apache-2.0 declared by converter and official base. Preserve attribution and notices. Huihui source inaccessible (HTTP 401); its full current license record and conversion-source commit were not independently verified.
- No commercial clearance asserted; retain all applicable upstream and conversion terms.
- Public converter inspected. Source metadata unavailable (401); no bypass.
- Converter-declared lineage, not cryptographic proof of source weights. Source/base snapshots are not asserted conversion input commits; exact source commit unknown.
- Join raw part1of2 then part2of2 into a separate deployment copy; do not use llama-gguf-split --merge for these byte parts. Use embedded Harmony template and a current gpt-oss-capable runtime. Not original MXFP4.

| Selected file | Bytes | Published identity |
|---|---:|---|
| `Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf.part1of2` | 44023414784 | LFS SHA-256 `b91f86b7d03082a406ae553633af23c932617cc60226f80a259a84c6fc496728` |
| `Huihui-gpt-oss-120b-BF16-abliterated.Q4_K_M.gguf.part2of2` | 43827573056 | LFS SHA-256 `bb07eddc3ab302c49ae329c2e4a972da2a44764117a5569b3e0d67f1a3f8daed` |
| `README.md` | 7589 | Git blob SHA-1 `1339f26bea5024d23cf8a266178c900915e1e76f` |

### Huihui Qwen3-Next-80B-A3B Thinking Abliterated — Q4_K_M GGUF

- ID: `huihui-qwen3-next-80b-a3b-thinking-abliterated-gguf-q4-k-m`
- Repository: https://huggingface.co/mradermacher/Huihui-Qwen3-Next-80B-A3B-Thinking-abliterated-GGUF
- Immutable revision: `c2e26d259894d06f56b1b40cef9b89648ff76e70`
- Developer/base: `Qwen/Qwen3-Next-80B-A3B-Thinking`
- Converter-declared modification source: `huihui-ai/Huihui-Qwen3-Next-80B-A3B-Thinking-abliterated`
- Modification: `abliterated`; converter `mradermacher`; provenance `third-party-derived`.
- Role `portable-gguf`; policy `inference-only`; priority `experimental`; capabilities: inference-optimized, refusal-reduced, general-chat, reasoning.
- Architecture: qwen3next MoE; 79674391296 stored tensor parameters; approximately 3000000000 active parameters from upstream architecture. 512 experts, 10 selected per token (shared-expert handling remains architecture-specific).
- Artifact context metadata: 262144 tokens; not a tested workstation context.
- Q4_K_M preset; actual tensor types/counts: Q6_K=55, F32=313, Q4_K=391, BF16=48.
- License: `mit`. Converter declares MIT; official Qwen base declares Apache-2.0. Preserve both statements and inherited Apache notices; converter MIT does not supersede base obligations. Huihui source inaccessible (HTTP 401), so derivative license chain is incomplete.
- No commercial clearance asserted; retain all applicable upstream and conversion terms.
- Public converter inspected. Source metadata unavailable (401); no bypass.
- Converter-declared lineage, not cryptographic proof of source weights. Source/base snapshots are not asserted conversion input commits; exact source commit unknown.
- Requires qwen3next hybrid attention/recurrent MoE support; use embedded chat template and preserve Thinking/Instruct/Coder distinction. No separate projector required.

| Selected file | Bytes | Published identity |
|---|---:|---|
| `Huihui-Qwen3-Next-80B-A3B-Thinking-abliterated.Q4_K_M.gguf` | 48410990624 | LFS SHA-256 `f75963a2aa6f6df28ad0d88a68bf84ba3157f4bc0f6db07bf27c3e2030e06ee4` |
| `README.md` | 4435 | Git blob SHA-1 `3a5e83b3d8ed6175d200bac2581cc81efdb7a375` |

### Huihui Qwen3-Coder-Next Abliterated — Q4_K_M GGUF

- ID: `huihui-qwen3-coder-next-abliterated-gguf-q4-k-m`
- Repository: https://huggingface.co/mradermacher/Huihui-Qwen3-Coder-Next-abliterated-GGUF
- Immutable revision: `1f6b22858800db92ac4b75d8396d44d6869031fa`
- Developer/base: `Qwen/Qwen3-Coder-Next`
- Converter-declared modification source: `huihui-ai/Huihui-Qwen3-Coder-Next-abliterated`
- Modification: `abliterated`; converter `mradermacher`; provenance `third-party-derived`.
- Role `portable-gguf`; policy `inference-only`; priority `experimental`; capabilities: inference-optimized, refusal-reduced, code-generation, reasoning.
- Architecture: qwen3next MoE; 79674391296 stored tensor parameters; approximately 3000000000 active parameters from upstream architecture. 512 experts, 10 selected per token (shared-expert handling remains architecture-specific).
- Artifact context metadata: 262144 tokens; not a tested workstation context.
- Q4_K_M preset; actual tensor types/counts: Q6_K=57, F32=313, Q4_K=389, Q5_K=36, BF16=48.
- License: `apache-2.0`. Apache-2.0 declared by converter and official base. Preserve attribution and notices. Huihui modification source also declares Apache-2.0.
- No commercial clearance asserted; retain all applicable upstream and conversion terms.
- Public converter inspected. Source metadata snapshot preserved; does not prove conversion input identity.
- Converter-declared lineage, not cryptographic proof of source weights. Source/base snapshots are not asserted conversion input commits; exact source commit unknown.
- Requires qwen3next hybrid attention/recurrent MoE support; use embedded chat template and preserve Thinking/Instruct/Coder distinction. No separate projector required.

| Selected file | Bytes | Published identity |
|---|---:|---|
| `Huihui-Qwen3-Coder-Next-abliterated.Q4_K_M.gguf` | 48487032960 | LFS SHA-256 `14607f1f49aa0e259e929e9f95a000f2d7bbcfb223d1e407c38d1af847f94a17` |
| `README.md` | 3996 | Git blob SHA-1 `5e2e904c23ee19f8054d14d70fbd9b98bb2fd945` |

### Huihui Qwen3-Next-80B-A3B Instruct Abliterated — Q4_K_M GGUF

- ID: `huihui-qwen3-next-80b-a3b-instruct-abliterated-gguf-q4-k-m`
- Repository: https://huggingface.co/mradermacher/Huihui-Qwen3-Next-80B-A3B-Instruct-abliterated-GGUF
- Immutable revision: `21d45bfb1a0db79ff0328890b20a37782340c395`
- Developer/base: `Qwen/Qwen3-Next-80B-A3B-Instruct`
- Converter-declared modification source: `huihui-ai/Huihui-Qwen3-Next-80B-A3B-Instruct-abliterated`
- Modification: `abliterated`; converter `mradermacher`; provenance `third-party-derived`.
- Role `portable-gguf`; policy `inference-only`; priority `experimental`; capabilities: inference-optimized, refusal-reduced, general-chat, instruction.
- Architecture: qwen3next MoE; 79674391296 stored tensor parameters; approximately 3000000000 active parameters from upstream architecture. 512 experts, 10 selected per token (shared-expert handling remains architecture-specific).
- Artifact context metadata: 262144 tokens; not a tested workstation context.
- Q4_K_M preset; actual tensor types/counts: Q6_K=55, F32=313, Q4_K=391, BF16=48.
- License: `mit`. Converter declares MIT; official Qwen base declares Apache-2.0. Preserve both statements and inherited Apache notices; converter MIT does not supersede base obligations. Huihui source inaccessible (HTTP 401), so derivative license chain is incomplete.
- No commercial clearance asserted; retain all applicable upstream and conversion terms.
- Public converter inspected. Source metadata unavailable (401); no bypass.
- Converter-declared lineage, not cryptographic proof of source weights. Source/base snapshots are not asserted conversion input commits; exact source commit unknown.
- Requires qwen3next hybrid attention/recurrent MoE support; use embedded chat template and preserve Thinking/Instruct/Coder distinction. No separate projector required.

| Selected file | Bytes | Published identity |
|---|---:|---|
| `Huihui-Qwen3-Next-80B-A3B-Instruct-abliterated.Q4_K_M.gguf` | 48410989216 | LFS SHA-256 `fc21ad98215cafb548d0386439cbc6dfeadc540f3fec9333f70b596c2504cd5e` |
| `README.md` | 4210 | Git blob SHA-1 `5e26333b8ebdb4b2b1c567c861ba050de9991da1` |

### Qwen3-Next-80B-A3B Thinking GRPO-Uncensored — Q4_K_M GGUF

- ID: `qwen3-next-80b-a3b-thinking-grpo-uncensored-gguf-q4-k-m`
- Repository: https://huggingface.co/mradermacher/Qwen3-Next-80B-A3B-Thinking-GRPO-Uncensored-GGUF
- Immutable revision: `25a85ef6a9e95f8b0ee6778b4b96a54a4a0575b0`
- Developer/base: `Qwen/Qwen3-Next-80B-A3B-Thinking`
- Converter-declared modification source: `puwaer/Qwen3-Next-80B-A3B-Thinking-GRPO-Uncensored`
- Modification: `supervised-fine-tuning-and-GRPO-with-LoRA`; converter `mradermacher`; provenance `third-party-derived`.
- Role `portable-gguf`; policy `inference-only`; priority `experimental`; capabilities: inference-optimized, refusal-reduced, general-chat, reasoning.
- Architecture: qwen3next MoE; 79674391296 stored tensor parameters; approximately 3000000000 active parameters from upstream architecture. 512 experts, 10 selected per token (shared-expert handling remains architecture-specific).
- Artifact context metadata: 262144 tokens; not a tested workstation context.
- Q4_K_M preset; actual tensor types/counts: Q6_K=57, F32=313, Q4_K=389, Q5_K=36, BF16=48.
- License: `cc-by-nc-sa-4.0`. CC-BY-NC-SA-4.0 declared by fine-tune and converter: noncommercial and share-alike restrictions apply; underlying Qwen base declares Apache-2.0. Preserve attribution and base notices.
- Noncommercial; share-alike and attribution required.
- Public converter inspected. Source metadata snapshot preserved; does not prove conversion input identity.
- Converter-declared lineage, not cryptographic proof of source weights. Source/base snapshots are not asserted conversion input commits; exact source commit unknown.
- Requires qwen3next hybrid attention/recurrent MoE support; use embedded chat template and preserve Thinking/Instruct/Coder distinction. No separate projector required.

| Selected file | Bytes | Published identity |
|---|---:|---|
| `Qwen3-Next-80B-A3B-Thinking-GRPO-Uncensored.Q4_K_M.gguf` | 48487030944 | LFS SHA-256 `a4f285f8ad70a8ff996117d66429a015066be1fc859d5cfd5239a36b4913ec3a` |
| `README.md` | 4328 | Git blob SHA-1 `fdf2d79c7e93c43d3d9e2002ab667b67b4167726` |

## GPT-OSS alternative-source decision

The original mixed-format Huihui repository returned HTTP 401. The continuation prompt explicitly authorized the mradermacher conversion. Its live metadata is public/ungated; its card declares the intended Huihui source. The inspected GGUF names that model and the BF16 GPT-OSS lineage. The known declared chain is OpenAI GPT-OSS → Unsloth BF16 representation → Huihui modification → mradermacher GGUF. The exact modification input/conversion commits are not established; this is declared provenance, not cryptographic proof of source tensors. The original Huihui repository remains documented as inaccessible.

The selected GPT-OSS files are two **raw byte parts**. Part 1 starts with a GGUF v3 header; part 2 does not start with GGUF magic. The converter documents concatenation. Both exact parts are required and independently size/hash-verified by the unchanged acquisition workflow. Do not use `llama-gguf-split --merge` or try to load part 1 as a complete model. Preserve the original parts and prepare a separately joined deployment copy only after acquisition verification.

## Licensing and research limitations

The Thinking/Instruct conversion cards declare MIT, while official Qwen bases declare Apache-2.0. Both statements are preserved, with explicit inherited-obligation cautions; the inaccessible Huihui source documents remain unresolved. No legal clearance or unrestricted redistribution/commercial-use assurance is made. For the GRPO model, preserve CC-BY-NC-SA-4.0 noncommercial/share-alike terms alongside base notices. Source cards, available license files and pinned API snapshots are bundled as evidence; review those before redistribution.

All five artifact sets were identified through live immutable repository metadata, bounded GGUF header inspection and public documentation. Header reads were 12 MiB per Qwen artifact and 32 MiB for GPT-OSS part 1 after a 12 MiB read proved too short; part 2 received a 64-byte availability probe. These reads are not complete payload verification. LFS SHA-256 identifies whole-file content; Git blob SHA-1 uses Git object framing; Xet identifiers, if present in API data, are not relabeled as ordinary SHA-256. No model deserialization or repository code execution occurred.

Reduced refusal is publisher-described behavior. Neither willingness nor accuracy, retained reasoning, safety behavior, language quality or runtime performance was measured. GGUFs are inference artifacts, not canonical training-friendly checkpoints.

## Preserved software boundary

Application code is byte-identical to v1.0.4.7 except version metadata. This toolkit uses revision directories and manifests, not a shared content-addressed object store or a cumulative HTTP-traffic ceiling. Existing per-file reuse/resume and accounting behavior is preserved; this release does not add such unrelated mechanisms. Historical original models, registries, dependency handling, mount rules, reserve rules, quarantine and retention are unchanged.
