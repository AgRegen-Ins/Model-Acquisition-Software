# Ubuntu acceptance — v1.0.4.5

Install alongside earlier toolkit releases. Acquire on the Dell's writable canonical archive. The HP's `/mnt/community-library` share remains read-only; do not alter it or the existing OpenAI original.

## 1. Verify and install alongside the existing application

Put the ZIP and its matching `.sha256` sidecar together in Downloads:

```bash
cd ~/Downloads
sha256sum -c community-model-acquisition-v1.0.4.5.zip.sha256
mkdir -p ~/community-toolkits/model-acquisition-v1.0.4.5
unzip community-model-acquisition-v1.0.4.5.zip -d ~/community-toolkits/model-acquisition-v1.0.4.5
cd ~/community-toolkits/model-acquisition-v1.0.4.5/community-model-acquisition
python3 - <<'PY'
import hashlib,json,pathlib
root=pathlib.Path('.')
checks=json.loads((root/'PACKAGE-CHECKSUMS.json').read_text())
for name,expected in checks.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
assert actual==set(checks)|{'PACKAGE-CHECKSUMS.json'},'Unexpected/missing package files'
assert (root/'modelkit/__init__.py').read_text().strip()=='__version__ = "1.0.4.5"'
print('All package hashes, membership and version verified')
PY
sudo apt install python3-venv
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -v
```

Verify exact package membership before creating `.venv`/Python caches, as shown. This installs only acquisition dependencies, not model inference frameworks, GPU runtimes or phonemizers.



## 2. Inspect existing storage without changing acquisitions

```bash
findmnt --mountpoint /srv/community-library
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --sort size
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format json > ~/model-accountability-v1045.json
```

Inventory is read-only. Your original checkpoint's prior records remain in place. The new GGUF should remain cataloged-not-downloaded until independently acquired or registered; a verified original does not verify its GGUF alternative. Stop before writes if the expected drive is not mounted. Do not create a substitute directory on the root filesystem to bypass mount safety.

## 3. Live metadata-only plans

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --model gpt-oss-120b-gguf-mxfp4 --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile gpt-oss-120b-local-inference --dry-run
```

Both select exactly one variant, one 63,387,346,208-byte GGUF and three provenance text files; total 63,387,561,321 bytes. Without existing reusable files, 70,800,059,277 bytes free are required including reserve. Confirm the revision `238abdd290bb874b90a5da1b4549881b7d05c091`. Dry-run exit 0 means successful planning, not sufficient disk space; heed any INSUFFICIENT SPACE warning. No model download occurs in these commands.

## 4. Explicit large acquisition after plan review

Interactive confirmation:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile gpt-oss-120b-local-inference
```

Or explicit noninteractive authorization after reviewing the plan:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile gpt-oss-120b-local-inference --yes --allow-large
```

`--yes` alone is insufficient; interactive mode retains its extra LARGE confirmation. The original checkpoint is not a member of this profile or a dependency. The toolkit does not convert it. Rerun the same pinned command to resume an interruption. Do not use `--latest` if you intend the release's verified pin. Existing completed files/revisions are preserved.

## 5. Audit and inventory

On the writable canonical archive host:

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --verify
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --sort size
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format csv > ~/model-accountability-v1045.csv
```

The legacy --verify command audits all managed revisions and writes reports; it can take substantial time and reveal unrelated earlier failures. It does not deserialize or execute weights. Do not automatically repair or delete old files because another entry fails. Review before any separate repair operation.

## 6. Prepare HP benchmarking separately

Read `docs/HP_GPT_OSS_120B.md`. It provides an optional non-overwriting NVMe copy verified against the exact GGUF SHA-256, the existing executable path, Harmony/Jinja settings, 4096-token initial context and thread/NUMA/offload experiments. No inference test or performance claim is included in this release. Keep the read-only share, original source checkpoint and existing HP installation unchanged.
