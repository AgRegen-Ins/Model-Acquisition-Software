# Higher-tier coding additions — v1.0.2

Reviewed 2026-09-28 UTC (September 27 evening in Connecticut). Both families are Apache-2.0. Existing schema version remains 1; optional metadata fields are preserved by the existing core. Parameter counts below are publisher-rounded counts, not exact tensor-element counts.

| Family | Architecture | Total / active parameters | Context |
|---|---|---|---|
| Qwen2.5-Coder-14B-Instruct | Qwen2ForCausalLM, dense | 14.7B / not MoE | Pinned config and GGUF card: 32,768; original card describes up to 131,072 with appropriate YaRN configuration |
| Qwen3-Coder-30B-A3B-Instruct | Qwen3MoeForCausalLM, MoE | 30.5B / 3.3B | 262,144 native; publisher describes extension to 1M with YaRN, not a 32 GB recommendation |

## Implemented variants

| Exact ID | Repository | Provenance | Selected GB | Full pinned revision |
|---|---|---|---:|---|
| `qwen2-5-coder-14b-instruct-original` | [Qwen/Qwen2.5-Coder-14B-Instruct](https://huggingface.co/Qwen/Qwen2.5-Coder-14B-Instruct) | official-upstream | 29.551689 | `aedcc2d42b622764e023cf882b6652e646b95671` |
| `qwen2-5-coder-14b-instruct-gguf-q4-k-m` | [Qwen/Qwen2.5-Coder-14B-Instruct-GGUF](https://huggingface.co/Qwen/Qwen2.5-Coder-14B-Instruct-GGUF) | official-derived | 8.988127 | `d0a692ef765eefbf2fabb130b3cb2e8917e3d225` |
| `qwen3-coder-30b-a3b-instruct-original` | [Qwen/Qwen3-Coder-30B-A3B-Instruct](https://huggingface.co/Qwen/Qwen3-Coder-30B-A3B-Instruct) | official-upstream | 61.079827 | `b2cff646eb4bb1d68355c01b18ae02e7cf42d120` |
| `qwen3-coder-30b-a3b-instruct-gguf-q4-k-m` | [unsloth/Qwen3-Coder-30B-A3B-Instruct-GGUF](https://huggingface.co/unsloth/Qwen3-Coder-30B-A3B-Instruct-GGUF) | third-party-derived | 18.556698 | `b17cb02dd882d5b6ab62fc777ad2995f19668350` |

Original weights are BF16 Safetensors. The official Qwen repository search returned the 30B-A3B original and FP8 repositories, but no public official GGUF repository; querying the anticipated official GGUF URL returned HTTP 401 (which alone cannot distinguish private from nonexistent). We therefore make no claim that an official public GGUF is available. The selected Unsloth repository is a converter-maintained source, with the official Qwen base identified in its card. Its conversion base commit is not asserted to equal the separately pinned original revision.

The official 14B GGUF repository provides FP16 plus Q2_K, Q3_K_M, Q4_0, Q4_K_M, Q5_0, Q5_K_M, Q6_K and Q8_0. It contains both split and unsplit Q4_K_M files; selection uses only `qwen2.5-coder-14b-instruct-q4_k_m.gguf`. The Unsloth 30B repository provides BF16, IQ, Q2/Q3/Q4/Q5/Q6/Q8 and UD variants, including standard Q4_K_M. Only `Qwen3-Coder-30B-A3B-Instruct-Q4_K_M.gguf` is selected. Full inventories are preserved in `evidence/v1.0.2/`; small model cards/license files and metadata accompany each selected weight representation.

## Why both GGUFs belong to coding-local

This is a conservative feasibility estimate, not a benchmark. With one CPU session and FP16 K/V cache, the approximate cache size is `2 × layers × KV heads × head dimension × context tokens × 2 bytes`. The two factors of 2 represent K plus V and the bytes per FP16 value. Pinned configs specify 48 layers and head dimension 128 (directly, or hidden size / attention heads).

| Model | GGUF weights | FP16 KV at 4,096 tokens | At 8,192 tokens |
|---|---:|---:|---:|
| 14B dense | 8.37 GiB | 0.75 GiB | 1.50 GiB |
| 30B-A3B MoE | 17.28 GiB | 0.375 GiB | 0.75 GiB |

Runtime compute buffers, prompt batching, allocator overhead, other applications and Ubuntu add memory beyond these figures. All expert weights remain resident/mapped; active parameter count mainly reduces per-token computation, not weight storage. Use a compatible llama.cpp build, begin at 4096 tokens with one session and a modest batch, and inspect its reported memory allocation before increasing context. Do not let the runtime automatically allocate the native maximum context.

Weight plus KV for the larger model is about 17.66 GiB. A nominal 32 GiB installation leaves about 14.34 GiB before OS/buffers; even treating 32 GB as decimal (~29.80 GiB) leaves about 12.14 GiB. This supports a short-context experiment, not a guaranteed throughput or maximum-context claim. Large concurrent programs can eliminate that headroom.

At 262,144 tokens the larger model's FP16 KV cache alone is about 24 GiB, exceeding the available budget once weights are included. Original BF16 downloads (~29.55 and ~61.08 GB) remain archival profile entries. The separate existing `dell` profile is unchanged to avoid unexpectedly expanding prior selections.

## Verification evidence

Official cards/configs, license files, API file inventories, public Qwen search results, live pinned dry-run output and regression results are included under `evidence/v1.0.2/`. No full weights were downloaded or run during this update.

## v1.0.4.2 addition

v1.0.4.2 adds the [Qwen3-Coder-Next workstation tier](QWEN3_CODER_NEXT.md), alongside the unchanged earlier Qwen coding entries. `coding-workstation` contains only 30B Q4_K_M and Next Q6_K.
