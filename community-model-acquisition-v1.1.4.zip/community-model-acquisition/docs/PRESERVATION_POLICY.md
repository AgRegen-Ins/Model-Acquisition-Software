# Tiered preservation policy — v1.0.4.3

`preservation-policy.json` is human-editable archival intent, separate from immutable artifact identities. The accountability report joins it by model ID; it never influences `select`, dependencies, downloads, deletion, verification or runtime installation. Legacy catalog entries remain exact JSON matches with v1.0.4.2. New entries also carry their initial `preservation_policy` and `associated_projects` fields. The external policy file is the reporting override; missing legacy values use selective/unknown.

| Policy | Intent |
|---|---|
| inference-only | Complete usable inference artifacts and documented dependencies; no automatic source duplicate |
| source-and-inference | Preserve both source/customization and practical deployment capability, through separate explicit operator selections |
| source-priority | Source checkpoint first; deployment variant may be added later |
| selective | Operator judges whether a second source/deployment representation is worthwhile |

Coding, agentic, reasoning and research entries use source-and-inference. Retrieval/reranking and all new vision/audio systems use inference-only. General chat entries are selective. This does not promise that both variants currently exist, are unquantized, fit current hardware, or have verified training tooling. All old source variants remain available and preserved.

`training_suitability_class` supports conventional-fine-tuning, adapter-based, specialized-quantization-aware, inference-oriented, and unknown as descriptive values. This release records unknown for legacy formats without researched training evidence, preserves their existing detailed training notes, and uses adapter-based for Qwen3-Coder-Next source based on prior evidence. GGUF/new inference systems are inference-oriented; no higher-precision recovery is implied. Official provenance, tensor precision, container format, role, capabilities, training tooling and verification state are independent. Official gpt-oss MXFP4 is not treated as generic BF16, nor is reduced precision alone used to conclude that customization is impossible.

`associated_projects` is a list of intended consumers. It neither selects additional downloads nor claims installations on their hosts. Instance-specific associations are recorded in the registry. Policy changes never launch acquisition. Keep the JSON file beside the application, or pass a different `--policy` file to `model_registry.py`.


## v1.0.4.4

Both OpenScholar and ether0 families use `source-and-inference` for each separate variant. All 46 legacy policy records are unchanged. Source training suitability is architecture-level, not tested training success; source roles and preservation policy do not cause downloads.


## v1.0.4.5

The new GGUF uses source-and-inference metadata, with inference-oriented training suitability. Original policy records are unchanged; no policy triggers a second download.
