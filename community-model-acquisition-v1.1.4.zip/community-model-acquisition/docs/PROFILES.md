# Acquisition profiles

## v1.0.4.7

No new profiles. All historical named selections remain identical. Use `--model huihui-glm-4-7-flash-abliterated-gguf-q4-k-m` and/or `--model huihui-qwen3-32b-abliterated-gguf-q4-k-m`. Neither is added to coding, research, Dell or source-preservation profiles. `all` naturally grows from 53 to 55. See [acceptance commands](UBUNTU_ACCEPTANCE_V1047.md).

## v1.0.4.6

No new named profiles and no changes to existing profile membership. Two exact variants are selected individually with `--model qwen3-next-80b-a3b-thinking-gguf-q6-k` and `--model glm-4-5-air-gguf-q4-k-m`; repeat `--model` to select both. `all` naturally includes all 53 entries and remains an enormous explicitly selected acquisition. Neither new entry is silently added to Dell, coding, research or source-preservation profiles.

## Historical v1.0.4.2 profile table

All new profiles are explicit opt-in archives. They are not Dell/local selections. v1.0.4 archive profiles remain intact. v1.0.4.2 adds only the new Next IDs to coding/source/future selections and adds `coding-workstation`; all prior model memberships remain unchanged. `preservation-source-weights` is never nested inside another profile.

| Profile | Count | GB before reserve | GB with 10% + 1 GiB reserve |
|---|---:|---:|---:|
| `agentic-core-originals` | 5 | 3,840.664 | 4,225.805 |
| `agentic-core-runnable` | 5 | 1,767.446 | 1,945.265 |
| `research-agent` | 4 | 1,182.783 | 1,302.135 |
| `coding-agent` | 3 | 856.381 | 943.093 |
| `preservation-source-weights` | 21 | 5,494.646 | 6,045.184 |
| `coding-workstation` | 2 | 84.171 | 93.662 |

## agentic-core-originals

ARCHIVE: five canonical source checkpoints; explicit opt-in; multi-terabyte; --yes requires --allow-large.

- `glm-5-3-flash-original`
- `mistral-small-4-119b-original`
- `minimax-m3-original`
- `kimi-k2-7-code-original`
- `glm-5-3-original`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile agentic-core-originals --dry-run
```

## agentic-core-runnable

ARCHIVE: five compressed primary inference variants; includes experimental GLM-5.3-Flash GGUF; --yes requires --allow-large.

- `glm-5-3-flash-gguf-ud-q4-k-xl`
- `mistral-small-4-119b-nvfp4`
- `minimax-m3-mxfp8`
- `kimi-k2-7-code-gguf-ud-q4-k-xl`
- `glm-5-3-gguf-ud-q4-k-xl`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile agentic-core-runnable --dry-run
```

## research-agent

ARCHIVE: GLM-5.3-Flash GGUF, Mistral Small 4 NVFP4, MiniMax-M3 MXFP8, GLM-5.3 GGUF; future hardware; --yes requires --allow-large.

- `glm-5-3-flash-gguf-ud-q4-k-xl`
- `mistral-small-4-119b-nvfp4`
- `minimax-m3-mxfp8`
- `glm-5-3-gguf-ud-q4-k-xl`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile research-agent --dry-run
```

## coding-agent

ARCHIVE: Kimi-K2.7-Code GGUF, GLM-5.3-Flash GGUF, Mistral Small 4 NVFP4; --yes requires --allow-large.

- `glm-5-3-flash-gguf-ud-q4-k-xl`
- `mistral-small-4-119b-nvfp4`
- `kimi-k2-7-code-gguf-ud-q4-k-xl`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile coding-agent --dry-run
```

## preservation-source-weights

Explicit opt-in canonical archive: all existing official-upstream entries plus five new canonical entries. Upstream does not imply unquantized or universally trainable; --yes requires --allow-large.

- `bge-m3-original`
- `bge-reranker-v2-m3-original`
- `qwen2-5-coder-1-5b-instruct-original`
- `qwen2-5-coder-7b-instruct-original`
- `qwen3-14b-original`
- `qwen3-32b-original`
- `qwen3-4b-original`
- `qwen3-8b-original`
- `qwen3-coder-480b-a35b-instruct-original`
- `deepseek-v4-flash-original`
- `gpt-oss-120b-original`
- `gpt-oss-20b-original`
- `glm-4-7-flash-original`
- `qwen2-5-coder-14b-instruct-original`
- `qwen3-coder-30b-a3b-instruct-original`
- `glm-5-3-flash-original`
- `mistral-small-4-119b-original`
- `minimax-m3-original`
- `kimi-k2-7-code-original`
- `glm-5-3-original`
- `qwen3-coder-next-original`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile preservation-source-weights --dry-run
```

Mistral NVFP4 is the official compressed default in the new agent profiles. Its GGUF alternative is individually selectable and included in `all`. MiniMax uses official MXFP8; no incomplete GGUF is included. The GLM Flash GGUF in runnable/research/coding profiles requires an experimental compatible runtime. See [runtime details](PRESERVATION_ADDITIONS.md).

The source profile includes 15 existing `official-upstream` entries plus the five v1.0.4 canonical entries and Qwen3-Coder-Next source (21 total). This classifies provenance, not generic training suitability: legacy MXFP4/FP8/native quantizations may require specialized customization tools. Their existing entry metadata is retained byte-for-byte at the JSON value level.

## Backward-compatible explicit membership

`profile_members` is an optional top-level object mapping a profile name to model IDs. Selection takes the union of this list and each entry’s existing `profiles`, in catalog order without duplicate downloads. Missing IDs/unknown profiles are rejected on load. `all` remains the complete catalog. Old schema-1 catalogs without this object work unchanged. The extension references existing source entries and the existing 30B coder in `coding-workstation` without editing their entries.

Every new variant and profile exceeds 50 GB. Interactive acquisition retains the existing extra LARGE confirmation. Noninteractive `--yes` requires `--allow-large`; insufficient-space and mount checks remain in force. Planning counts all selected files and subtracts only recognized completed files; partial chunks are conservatively not deducted.

## coding-workstation — v1.0.4.2

Exactly `qwen3-coder-30b-a3b-instruct-gguf-q4-k-m` then `qwen3-coder-next-gguf-q6-k`. Intended for a future 96 GB aggregate VRAM workstation; no 480B. Next source is added to `coding`, `coding-archive`, `future`, and `preservation-source-weights`; Next Q6_K is added to `coding` and this new profile. `coding-local`, Dell profiles and all existing entries are unchanged. See [hardware rationale and commands](QWEN3_CODER_NEXT.md).

## v1.0.4.3 multimodal profiles (explicit opt-in)

### document-vision

2,774,658,784 selected bytes; 4,125,866,486 bytes including reserve.

- `qwen2-5-vl-3b-instruct-gguf-q4-k-m`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile document-vision --dry-run
```

### audio-transcription

4,714,006,128 selected bytes; 6,259,148,564 bytes including reserve.

- `whisper-large-v3-inference`
- `whisper-large-v3-turbo-inference`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile audio-transcription --dry-run
```

### audiobook-narration

455,211,866 selected bytes; 1,574,474,876 bytes including reserve.

- `kokoro-82m-inference`
- `piper-english-voices-inference`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile audiobook-narration --dry-run
```

### voice-customization

4,594,795,546 selected bytes; 6,128,016,924 bytes including reserve.

- `chatterbox-tts-english-inference`
- `f5-tts-vocos-mel-24khz`
- `f5-tts-v1-base-inference`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile voice-customization --dry-run
```

### multimodal-core

4,725,922,149 selected bytes; 6,272,256,187 bytes including reserve.

- `qwen2-5-vl-3b-instruct-gguf-q4-k-m`
- `whisper-large-v3-turbo-inference`
- `kokoro-82m-inference`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile multimodal-core --dry-run
```

### multimodal-preservation

12,538,672,324 selected bytes; 14,866,281,380 bytes including reserve.

- `qwen2-5-vl-3b-instruct-gguf-q4-k-m`
- `whisper-large-v3-inference`
- `whisper-large-v3-turbo-inference`
- `kokoro-82m-inference`
- `chatterbox-tts-english-inference`
- `f5-tts-vocos-mel-24khz`
- `f5-tts-v1-base-inference`
- `piper-english-voices-inference`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile multimodal-preservation --dry-run
```

F5 selection expands its explicit Vocos dependency once. Policies never expand selection. All earlier profile descriptions/members remain unchanged; only `all` naturally includes eight additions.


## v1.0.4.4 scientific profiles

See [scientific profile membership and sizes](SCIENTIFIC_PROFILES.md). Four opt-in profiles added; no historical memberships changed except normal `all` expansion.


## v1.0.4.5

`gpt-oss-120b-local-inference` selects only `gpt-oss-120b-gguf-mxfp4`, 63,387,561,321 bytes before reserve. All historical memberships unchanged except normal `all` growth. This is an opt-in large acquisition.
