# Image catalog and dependency inventory v1.1.4

86 added records: 27 primary variants and 59 components. Selecting every new record once requires 618,892,028,719 bytes (618.89 GB), before reserve/caches. Existing all-profile acquisitions are much larger.

## Primary selections

| Model ID | Selected artifact bytes | Complete dependency closure bytes | Role | Gate |
|---|---:|---:|---|---|
| `sd15-original` | 3,438,182,001 | 5,482,682,995 | canonical-source | False |
| `sd15-fp16` | 1,719,139,765 | 2,742,248,425 | inference-optimized | False |
| `sdxl-base-1-0-original` | 10,270,100,513 | 13,878,910,096 | canonical-source | False |
| `sdxl-base-1-0-fp16` | 5,135,172,537 | 6,941,233,090 | inference-optimized | False |
| `sdxl-refiner-1-0-original` | 9,038,284,043 | 12,153,239,009 | canonical-source | False |
| `pony-diffusion-v6-xl-original` | 6,938,041,089 | 6,941,239,972 | canonical-source | False |
| `illustrious-xl-v1-0-original` | 6,938,044,633 | 6,941,243,516 | canonical-source | False |
| `animagine-xl-4-0-original` | 5,135,165,254 | 6,941,219,039 | canonical-source | False |
| `noobai-xl-1-1-original` | 5,135,156,462 | 6,941,201,536 | canonical-source | False |
| `flux2-klein-4b-original` | 7,751,129,319 | 15,980,170,895 | canonical-source | False |
| `flux2-klein-base-4b-original` | 7,751,129,412 | 15,980,171,047 | canonical-source | False |
| `z-image-turbo-original` | 24,619,753,541 | 32,848,332,901 | canonical-source | False |
| `flux1-dev-original` | 23,803,098,317 | 33,746,429,582 | canonical-source | auto |
| `sd3-5-large-original` | 16,292,854,362 | 27,628,332,447 | canonical-source | auto |
| `qwen-image-2512-original` | 40,861,246,073 | 57,704,613,522 | canonical-source | False |
| `hidream-i1-full-original` | 34,211,860,372 | 63,254,972,272 | canonical-source | False |
| `flux2-dev-original` | 64,446,666,510 | 112,823,070,830 | canonical-source | auto |
| `flux1-kontext-dev-original` | 23,803,103,563 | 33,746,440,574 | canonical-source | auto |
| `qwen-image-edit-2511-original` | 40,861,234,354 | 57,720,469,052 | canonical-source | False |
| `flux2-klein-4b-fp8` | 4,070,641,882 | 12,467,741,073 | inference-optimized | False |
| `z-image-turbo-bf16-comfy` | 12,309,871,185 | 20,706,055,260 | inference-optimized | False |
| `flux1-dev-gguf-q4-k-s` | 6,806,006,434 | 12,549,655,204 | inference-optimized | False |
| `sd3-5-large-gguf-q4-0` | 4,772,067,376 | 11,739,046,168 | inference-optimized | False |
| `qwen-image-2512-gguf-q4-k-m` | 13,299,596,391 | 22,943,161,601 | inference-optimized | False |
| `hidream-i1-full-gguf-q4-k-m` | 11,481,431,446 | 27,699,095,652 | inference-optimized | False |
| `flux2-dev-gguf-q4-k-m` | 20,082,435,432 | 38,470,621,343 | inference-optimized | False |
| `flux2-dev-nvfp4-mixed` | 22,772,037,905 | 41,160,223,816 | inference-optimized | False |

Closure includes required components only, not optional refiner/base variants. A dependency can be gated even when the main artifact is public.

## Profiles

| Profile | Explicit primary IDs | Closure records | Bytes | Required reserve-inclusive bytes from empty selection |
|---|---|---:|---:|---:|
| `image-generation-lightweight` | sd15-fp16 | 5 | 2,742,248,425 | 4,090,215,091 |
| `image-generation-sdxl` | sdxl-base-1-0-fp16 | 5 | 6,941,233,090 | 8,709,098,223 |
| `image-generation-modern` | flux2-klein-4b-original, z-image-turbo-bf16-comfy | 8 | 36,686,226,155 | 41,428,590,594 |
| `image-generation-high-end` | flux1-dev-original, sd3-5-large-original, qwen-image-2512-original, hidream-i1-full-original, flux2-dev-original | 24 | 285,465,083,282 | 315,085,333,434 |
| `image-generation-high-willingness` | pony-diffusion-v6-xl-original, noobai-xl-1-1-original | 7 | 13,882,441,508 | 16,344,427,482 |
| `image-generation-anime` | animagine-xl-4-0-original, noobai-xl-1-1-original, illustrious-xl-v1-0-original | 12 | 20,823,664,091 | 23,979,772,324 |
| `image-generation-photorealism` | sdxl-base-1-0-fp16, z-image-turbo-bf16-comfy, flux1-dev-gguf-q4-k-s | 12 | 39,615,495,014 | 44,650,786,339 |
| `image-editing` | flux1-kontext-dev-original, qwen-image-edit-2511-original, flux2-klein-4b-original, flux2-dev-original | 17 | 220,270,151,351 | 243,370,908,310 |
| `image-generation-source-preservation` | sd15-original, sdxl-base-1-0-original, sdxl-refiner-1-0-original, pony-diffusion-v6-xl-original, illustrious-xl-v1-0-original, animagine-xl-4-0-original, noobai-xl-1-1-original, flux2-klein-4b-original, flux2-klein-base-4b-original, z-image-turbo-original, flux1-dev-original, sd3-5-large-original, qwen-image-2512-original, hidream-i1-full-original, flux2-dev-original, flux1-kontext-dev-original, qwen-image-edit-2511-original | 61 | 462,743,099,101 | 510,091,150,835 |
| `image-generation-local-inference` | sd15-fp16, sdxl-base-1-0-fp16, flux2-klein-4b-fp8 | 14 | 22,151,222,588 | 25,440,086,670 |

`all` intentionally grows by these 86 records and about618.89GB. It is not the recommended image quickstart. Read both plans and explicitly approve large acquisitions with existing --allow-large; --yes alone does not bypass it. No profile runs by merely listing it.

## Exact repositories/revisions

| ID | Repository | Immutable revision | Provenance |
|---|---|---|---|
| `sd15-pipeline-config` | stable-diffusion-v1-5/stable-diffusion-v1-5 | `451f4fe16113bff5a5d2269ed5ad43b0592e9a14` | third-party-derived |
| `sd15-original` | stable-diffusion-v1-5/stable-diffusion-v1-5 | `451f4fe16113bff5a5d2269ed5ad43b0592e9a14` | third-party-derived |
| `sd15-original-text-encoder` | stable-diffusion-v1-5/stable-diffusion-v1-5 | `451f4fe16113bff5a5d2269ed5ad43b0592e9a14` | third-party-derived |
| `sd15-original-vae` | stable-diffusion-v1-5/stable-diffusion-v1-5 | `451f4fe16113bff5a5d2269ed5ad43b0592e9a14` | third-party-derived |
| `sd15-original-safety-checker` | stable-diffusion-v1-5/stable-diffusion-v1-5 | `451f4fe16113bff5a5d2269ed5ad43b0592e9a14` | third-party-derived |
| `sd15-fp16` | stable-diffusion-v1-5/stable-diffusion-v1-5 | `451f4fe16113bff5a5d2269ed5ad43b0592e9a14` | third-party-derived |
| `sd15-fp16-text-encoder` | stable-diffusion-v1-5/stable-diffusion-v1-5 | `451f4fe16113bff5a5d2269ed5ad43b0592e9a14` | third-party-derived |
| `sd15-fp16-vae` | stable-diffusion-v1-5/stable-diffusion-v1-5 | `451f4fe16113bff5a5d2269ed5ad43b0592e9a14` | third-party-derived |
| `sd15-fp16-safety-checker` | stable-diffusion-v1-5/stable-diffusion-v1-5 | `451f4fe16113bff5a5d2269ed5ad43b0592e9a14` | third-party-derived |
| `sdxl-base-1-0-pipeline-config` | stabilityai/stable-diffusion-xl-base-1.0 | `462165984030d82259a11f4367a4eed129e94a7b` | official-upstream |
| `sdxl-base-1-0-original` | stabilityai/stable-diffusion-xl-base-1.0 | `462165984030d82259a11f4367a4eed129e94a7b` | official-upstream |
| `sdxl-base-1-0-original-text-encoder` | stabilityai/stable-diffusion-xl-base-1.0 | `462165984030d82259a11f4367a4eed129e94a7b` | official-upstream |
| `sdxl-base-1-0-original-text-encoder-2` | stabilityai/stable-diffusion-xl-base-1.0 | `462165984030d82259a11f4367a4eed129e94a7b` | official-upstream |
| `sdxl-base-1-0-original-vae` | stabilityai/stable-diffusion-xl-base-1.0 | `462165984030d82259a11f4367a4eed129e94a7b` | official-upstream |
| `sdxl-base-1-0-fp16` | stabilityai/stable-diffusion-xl-base-1.0 | `462165984030d82259a11f4367a4eed129e94a7b` | official-derived |
| `sdxl-base-1-0-fp16-text-encoder` | stabilityai/stable-diffusion-xl-base-1.0 | `462165984030d82259a11f4367a4eed129e94a7b` | official-derived |
| `sdxl-base-1-0-fp16-text-encoder-2` | stabilityai/stable-diffusion-xl-base-1.0 | `462165984030d82259a11f4367a4eed129e94a7b` | official-derived |
| `sdxl-base-1-0-fp16-vae` | stabilityai/stable-diffusion-xl-base-1.0 | `462165984030d82259a11f4367a4eed129e94a7b` | official-derived |
| `sdxl-refiner-1-0-pipeline-config` | stabilityai/stable-diffusion-xl-refiner-1.0 | `5d4cfe854c9a9a87939ff3653551c2b3c99a4356` | official-upstream |
| `sdxl-refiner-1-0-original` | stabilityai/stable-diffusion-xl-refiner-1.0 | `5d4cfe854c9a9a87939ff3653551c2b3c99a4356` | official-upstream |
| `pony-diffusion-v6-xl-original` | AstraliteHeart/pony-diffusion-v6 | `5ec9c05863255568f1b59753e3838107befaa712` | third-party-derived |
| `illustrious-xl-v1-0-original` | OnomaAIResearch/Illustrious-XL-v1.0 | `89d625482edf06d545b740265482f5c8fb2cadb0` | third-party-derived |
| `animagine-xl-4-0-pipeline-config` | cagliostrolab/animagine-xl-4.0 | `2b7c1b397761bf5bd3cc42e5b39ec99314a75a96` | third-party-derived |
| `animagine-xl-4-0-original` | cagliostrolab/animagine-xl-4.0 | `2b7c1b397761bf5bd3cc42e5b39ec99314a75a96` | third-party-derived |
| `animagine-xl-4-0-original-text-encoder` | cagliostrolab/animagine-xl-4.0 | `2b7c1b397761bf5bd3cc42e5b39ec99314a75a96` | third-party-derived |
| `animagine-xl-4-0-original-text-encoder-2` | cagliostrolab/animagine-xl-4.0 | `2b7c1b397761bf5bd3cc42e5b39ec99314a75a96` | third-party-derived |
| `animagine-xl-4-0-original-vae` | cagliostrolab/animagine-xl-4.0 | `2b7c1b397761bf5bd3cc42e5b39ec99314a75a96` | third-party-derived |
| `noobai-xl-1-1-pipeline-config` | Laxhar/noobai-XL-1.1 | `814a274af2b8097c0828819d561ec74c7d0c6cea` | third-party-derived |
| `noobai-xl-1-1-original` | Laxhar/noobai-XL-1.1 | `814a274af2b8097c0828819d561ec74c7d0c6cea` | third-party-derived |
| `noobai-xl-1-1-original-text-encoder` | Laxhar/noobai-XL-1.1 | `814a274af2b8097c0828819d561ec74c7d0c6cea` | third-party-derived |
| `noobai-xl-1-1-original-text-encoder-2` | Laxhar/noobai-XL-1.1 | `814a274af2b8097c0828819d561ec74c7d0c6cea` | third-party-derived |
| `noobai-xl-1-1-original-vae` | Laxhar/noobai-XL-1.1 | `814a274af2b8097c0828819d561ec74c7d0c6cea` | third-party-derived |
| `flux2-klein-4b-pipeline-config` | black-forest-labs/FLUX.2-klein-4B | `e7b7dc27f91deacad38e78976d1f2b499d76a294` | official-upstream |
| `flux2-klein-4b-original` | black-forest-labs/FLUX.2-klein-4B | `e7b7dc27f91deacad38e78976d1f2b499d76a294` | official-upstream |
| `flux2-klein-4b-original-text-encoder` | black-forest-labs/FLUX.2-klein-4B | `e7b7dc27f91deacad38e78976d1f2b499d76a294` | official-upstream |
| `flux2-klein-4b-original-vae` | black-forest-labs/FLUX.2-klein-4B | `e7b7dc27f91deacad38e78976d1f2b499d76a294` | official-upstream |
| `flux2-klein-base-4b-pipeline-config` | black-forest-labs/FLUX.2-klein-base-4B | `a3b4f4849157f664bdbc776fd7453c2783562f4d` | official-upstream |
| `flux2-klein-base-4b-original` | black-forest-labs/FLUX.2-klein-base-4B | `a3b4f4849157f664bdbc776fd7453c2783562f4d` | official-upstream |
| `z-image-turbo-pipeline-config` | Tongyi-MAI/Z-Image-Turbo | `f332072aa78be7aecdf3ee76d5c247082da564a6` | official-upstream |
| `z-image-turbo-original` | Tongyi-MAI/Z-Image-Turbo | `f332072aa78be7aecdf3ee76d5c247082da564a6` | official-upstream |
| `z-image-turbo-original-text-encoder` | Tongyi-MAI/Z-Image-Turbo | `f332072aa78be7aecdf3ee76d5c247082da564a6` | official-upstream |
| `z-image-turbo-original-vae` | Tongyi-MAI/Z-Image-Turbo | `f332072aa78be7aecdf3ee76d5c247082da564a6` | official-upstream |
| `flux1-dev-pipeline-config` | black-forest-labs/FLUX.1-dev | `3de623fc3c33e44ffbe2bad470d0f45bccf2eb21` | official-upstream |
| `flux1-dev-original` | black-forest-labs/FLUX.1-dev | `3de623fc3c33e44ffbe2bad470d0f45bccf2eb21` | official-upstream |
| `flux1-dev-original-text-encoder` | black-forest-labs/FLUX.1-dev | `3de623fc3c33e44ffbe2bad470d0f45bccf2eb21` | official-upstream |
| `flux1-dev-original-text-encoder-2` | black-forest-labs/FLUX.1-dev | `3de623fc3c33e44ffbe2bad470d0f45bccf2eb21` | official-upstream |
| `sd3-5-large-pipeline-config` | stabilityai/stable-diffusion-3.5-large | `ceddf0a7fdf2064ea28e2213e3b84e4afa170a0f` | official-upstream |
| `sd3-5-large-original` | stabilityai/stable-diffusion-3.5-large | `ceddf0a7fdf2064ea28e2213e3b84e4afa170a0f` | official-upstream |
| `sd3-5-large-original-text-encoder` | stabilityai/stable-diffusion-3.5-large | `ceddf0a7fdf2064ea28e2213e3b84e4afa170a0f` | official-upstream |
| `sd3-5-large-original-text-encoder-3` | stabilityai/stable-diffusion-3.5-large | `ceddf0a7fdf2064ea28e2213e3b84e4afa170a0f` | official-upstream |
| `sd3-5-large-original-vae` | stabilityai/stable-diffusion-3.5-large | `ceddf0a7fdf2064ea28e2213e3b84e4afa170a0f` | official-upstream |
| `qwen-image-2512-pipeline-config` | Qwen/Qwen-Image-2512 | `25468b98e3276ca6700de15c6628e51b7de54a26` | official-upstream |
| `qwen-image-2512-original` | Qwen/Qwen-Image-2512 | `25468b98e3276ca6700de15c6628e51b7de54a26` | official-upstream |
| `qwen-image-2512-original-text-encoder` | Qwen/Qwen-Image-2512 | `25468b98e3276ca6700de15c6628e51b7de54a26` | official-upstream |
| `qwen-image-2512-original-vae` | Qwen/Qwen-Image-2512 | `25468b98e3276ca6700de15c6628e51b7de54a26` | official-upstream |
| `hidream-i1-full-pipeline-config` | HiDream-ai/HiDream-I1-Full | `8ccbbfb270ccdae26d6bb0081df67dc81e4033bf` | official-upstream |
| `hidream-i1-full-original` | HiDream-ai/HiDream-I1-Full | `8ccbbfb270ccdae26d6bb0081df67dc81e4033bf` | official-upstream |
| `hidream-i1-full-original-text-encoder` | HiDream-ai/HiDream-I1-Full | `8ccbbfb270ccdae26d6bb0081df67dc81e4033bf` | official-upstream |
| `hidream-i1-full-original-text-encoder-2` | HiDream-ai/HiDream-I1-Full | `8ccbbfb270ccdae26d6bb0081df67dc81e4033bf` | official-upstream |
| `hidream-llama3-1-8b-instruct-component` | meta-llama/Llama-3.1-8B-Instruct | `0e9e39f249a16976918f6564b8830bc894c89659` | official-upstream |
| `flux2-dev-pipeline-config` | black-forest-labs/FLUX.2-dev | `26afe3a78bb242c0a8bb181dcc8937bb16e5c66c` | official-upstream |
| `flux2-dev-original` | black-forest-labs/FLUX.2-dev | `26afe3a78bb242c0a8bb181dcc8937bb16e5c66c` | official-upstream |
| `flux2-dev-original-text-encoder` | black-forest-labs/FLUX.2-dev | `26afe3a78bb242c0a8bb181dcc8937bb16e5c66c` | official-upstream |
| `flux2-dev-original-vae` | black-forest-labs/FLUX.2-dev | `26afe3a78bb242c0a8bb181dcc8937bb16e5c66c` | official-upstream |
| `flux1-kontext-dev-pipeline-config` | black-forest-labs/FLUX.1-Kontext-dev | `24e9dedc4ef646698dc8eb4e18ae2cec3c9fea0d` | official-upstream |
| `flux1-kontext-dev-original` | black-forest-labs/FLUX.1-Kontext-dev | `24e9dedc4ef646698dc8eb4e18ae2cec3c9fea0d` | official-upstream |
| `qwen-image-edit-2511-pipeline-config` | Qwen/Qwen-Image-Edit-2511 | `6f3ccc0b56e431dc6a0c2b2039706d7d26f22cb9` | official-upstream |
| `qwen-image-edit-2511-original` | Qwen/Qwen-Image-Edit-2511 | `6f3ccc0b56e431dc6a0c2b2039706d7d26f22cb9` | official-upstream |
| `image-t5xxl-fp8-scaled-comfy` | comfyanonymous/flux_text_encoders | `6af2a98e3f615bdfa612fbd85da93d1ed5f69ef5` | third-party-derived |
| `image-qwen3-4b-comfy` | Comfy-Org/Z-Image-Turbo | `6fc90a3b1b653e935a0d175e260736de25b84df5` | third-party-derived |
| `image-flux-ae-comfy` | Comfy-Org/HiDream | `942970a008493fc9bf05b4827374009e69f6a993` | third-party-derived |
| `image-flux2-vae-comfy` | Comfy-Org/Flux-2-Klein-4B | `5b3abca5c0dc1ecd4eaf3340868d09063fc1c965` | third-party-derived |
| `image-qwen2-5-vl-7b-fp8-comfy` | Comfy-Org/Qwen-Image | `1f12b17be14c89b026c51a91d67c32f84bb047bc` | third-party-derived |
| `image-qwen-vae-comfy` | Comfy-Org/Qwen-Image | `1f12b17be14c89b026c51a91d67c32f84bb047bc` | third-party-derived |
| `image-flux2-mistral-fp8-comfy` | Comfy-Org/Flux-2-Dev | `9630c1b4b6e690497ae0c19bb6b1b35d4ebedcb7` | third-party-derived |
| `hidream-clip-g-hidream-component` | Comfy-Org/HiDream | `942970a008493fc9bf05b4827374009e69f6a993` | third-party-derived |
| `hidream-clip-l-hidream-component` | Comfy-Org/HiDream | `942970a008493fc9bf05b4827374009e69f6a993` | third-party-derived |
| `hidream-llama-3-1-8b-instruct-fp8-scaled-component` | Comfy-Org/HiDream | `942970a008493fc9bf05b4827374009e69f6a993` | third-party-derived |
| `flux2-klein-4b-fp8` | black-forest-labs/FLUX.2-klein-4b-fp8 | `5b4408e59397a4a37ccb46afe426d8ed86379441` | official-derived |
| `z-image-turbo-bf16-comfy` | Comfy-Org/Z-Image-Turbo | `6fc90a3b1b653e935a0d175e260736de25b84df5` | third-party-derived |
| `flux1-dev-gguf-q4-k-s` | city96/FLUX.1-dev-gguf | `3c60ac659f4b1f2ab3ca8bd4488272069b36a148` | third-party-derived |
| `sd3-5-large-gguf-q4-0` | city96/stable-diffusion-3.5-large-gguf | `a2f64f3850d78119dbdae7fb81466fb1e2d8e8bd` | third-party-derived |
| `qwen-image-2512-gguf-q4-k-m` | unsloth/Qwen-Image-2512-GGUF | `899597deea5b6e8593a021684b4571e06b59ebea` | third-party-derived |
| `hidream-i1-full-gguf-q4-k-m` | city96/HiDream-I1-Full-gguf | `12e1d50fee542ede30c0b640bc1b0594231e8e15` | third-party-derived |
| `flux2-dev-gguf-q4-k-m` | city96/FLUX.2-dev-gguf | `ade5d688ddab0d9cf4a5b01bf4321e01c115020d` | third-party-derived |
| `flux2-dev-nvfp4-mixed` | black-forest-labs/FLUX.2-dev-NVFP4 | `142b87e70bc3006937b7093d89ff287b5f59f071` | official-derived |
