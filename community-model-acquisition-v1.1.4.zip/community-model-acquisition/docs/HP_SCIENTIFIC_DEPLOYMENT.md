# HP deployment notes — v1.0.4.4

Target hardware is user-reported: HP Z8 G4, Ubuntu 26.04.1 LTS, two Xeon Platinum 8260 CPUs (48 physical cores/96 threads), 352 GB ECC RAM, RTX 3050 6 GB VRAM, 2 TB Samsung NVMe and an existing CUDA-enabled llama.cpp. The toolkit did not inspect or change the HP, benchmark scripts, installed software or existing model files. No real inference test occurred.

| GGUF | Disk GB / GiB | Initial context | RAM planning estimate, not measurement | GPU constraint |
|---|---|---:|---|---|
| OpenScholar Q4_K_M | 4.921 / 4.583 | 4096 | Roughly 6–8 GiB plus OS/service headroom | 6 GB VRAM may be tight with KV/cache/buffers and display use; full offload not promised |
| ether0 Q4_K_M | 14.334 / 13.350 | 4096 | Roughly 16–20 GiB plus OS/service headroom | Weights alone exceed 6 GB; use CPU or partial offload |

These estimates start from GGUF disk size, FP16 KV cache and an allowance for runtime buffers; they are not exact minima. At 4096 tokens, two FP16 K/V arrays imply approximately 0.5 GiB KV for 32-layer OpenScholar and 0.625 GiB for 40-layer ether0, using 8 KV heads of dimension 128. Runtime batching, GPU splitting, mmap, context and cache precision change actual residency. Maximum configured context is 131072/32768 respectively, not a recommendation to start at that length. The HP's system RAM is ample for these weight sizes; speed remains unmeasured.

Acquire on the Dell's writable canonical archive, not through the HP's read-only mount. The HP may read verified GGUFs there, though network load latency can differ from local NVMe. A local deployment copy/registration is a separate explicit operation; nothing here modifies mounts or copies models automatically.

The following commands are optional manual runtime examples, **not toolkit installation steps**. Use the existing binaries and actual verified paths. First inspect that build's `--help` for `--jinja`; current llama-server can use the embedded template. Do not use `-hf`, which could fetch different artifacts automatically. The explicit `-m` path must refer to the pinned verified GGUF.

```bash
export LLAMA_SERVER=/absolute/path/to/existing/llama-server
export MODEL_GGUF=/actual/verified/path/to/model.gguf
"$LLAMA_SERVER" -m "$MODEL_GGUF" -c 4096 -ngl 0 --jinja --host 127.0.0.1 --port 8081
```

This is a CPU baseline bound to localhost; no benchmark is claimed. After measuring memory and results, the operator can repeat with a small positive `-ngl` and tune layer offload within available VRAM. Do not assume 96 threads improves performance: NUMA placement, physical cores and memory bandwidth matter. Leave existing benchmark scripts intact.

OpenScholar must receive actual retrieved/supplied passages to evaluate grounded synthesis; it has no installed literature index. For ether0 preserve the embedded scientific prompt and custom reasoning/answer tokens. Start with a benign formula-to-SMILES question and assess syntax and correctness independently. Q4 chemical output quality is unvalidated, and the converter favors higher precision for SMILES. Neither model should be benchmarked by assuming a generic chat template or unverified maximum context.

Source training is a separate project: 352 GB system RAM is not a promise that 6 GB GPU LoRA/full fine-tuning will be practical. Source checkpoint file size excludes optimizer state, activations, gradients and preprocessing resources.
