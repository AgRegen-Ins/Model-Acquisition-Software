# Repository-path validation correction — v1.0.4.8.1

## Root cause and evidence

The exclusively used baseline is v1.0.4.8, SHA-256 `3328fa8f812d7fc71ed147794221c6c21981f8688089d767c4911eaa4ff40d14`. Its 60 catalog records, profiles, selected artifacts and preservation policy are unchanged byte-for-byte.

A disposable fixture contains a legacy-format verified OpenScholar-style software revision and two ordinary synthetic model acquisitions. The baseline successfully commits both new manifests as verified, then reproduces exactly:

`model_acquire.main -> inventory -> safe_path -> safe_name -> ToolkitError: Unsafe directory identifier: __init__.py`

The final call is `report(root, inventory(root, catalog))`. Python evaluates `inventory(...)` before calling `report(...)`, so report publication has not begun when this exception occurs. `inventory` scans every recorded revision, including entries absent from the current catalog. It applies `safe_path` to `retriever/contriever/src/__init__.py`; the old validator strips leading periods and applies an identifier regex requiring an initial letter/digit. Leading underscores therefore fail. The same issue affects acquisition planning, actual file acquisition, core status/full-hash inventory and registry path validation wherever those functions call `safe_path`.

A separate storage-inventory path catches `ToolkitError` and records the source revision as `partial` with a missing/changed-files warning, even though its manifest remains `verified` and the file is valid. This explains how per-model inventory refresh can finish with misleading state while the later collection-wide core report raises an exception.

Captured traceback and failure-state evidence are in `evidence/v1.0.4.8.1/baseline-failure-traceback.txt` and `baseline-failure-state.json`. The legacy fixture manifest is byte-identical before/after failure; both new manifests remain verified. This establishes the mechanism with synthetic data. The actual Dell archive and its OpenScholar Software manifest were not accessed, so the exact real-world model ID and first offending payload cannot independently be established here. The operator output establishes recorded statuses/file counts for all seven acquisitions; it was not a fresh full cryptographic audit.

## Narrow code changes

`safe_name` is unchanged. Catalog/model/category/registry identifier rules and revision pin checks remain strict. A new `safe_payload_component` handles inert repository names separately, accepting leading underscores such as `__init__.py`, `_private.py`, `__main__.py`, `_config.json` and underscore-prefixed directory components. It retains the existing ASCII alphabet, trailing-dot rejection, leading-period treatment and reserved Windows device protections.

`safe_path` uses this component validator and checks the raw slash-separated spelling before filesystem normalization. Its existing symlink rejection and resolved-root containment checks remain unchanged. No repository file is executed or imported.

The final post-acquisition report/refresh block now wraps failures with an explicit `Post-acquisition reporting failed` message, states that results remain recorded in per-model manifests, and suggests `--status` after fixing the reporting issue. The original exception remains chained for traceback diagnosis. Failure is not suppressed and the CLI still exits nonzero. The message does not claim that every acquisition succeeded: individual manifest results remain authoritative.

No download/retry/hash/quarantine/reserve/mount/retention code, registry implementation, storage implementation or adapter is changed. `modelkit/__init__.py` changes only version metadata. No schema migration or model redownload is needed.

## Accepted and rejected spellings

| Class | Behavior |
|---|---|
| Python source names and nested packages | Accept leading underscores; archive as inert bytes. |
| Ordinary GGUF, Safetensors, README/config/tokenizer names | Preserve acceptance. |
| `.gitattributes`, `.git/config`, `.cache/data`, leading-period names | Preserve canonical filename support inside the designated payload root. No Git hooks, Python imports or cache scripts are executed. Repository `.cache` handling is not redesigned. |
| Managed identifiers beginning with `_` or `.` | Still rejected by unchanged `safe_name`. |
| Absolute paths, drive prefixes, UNC/backslashes, colon/ADS syntax | Rejected. |
| Parent traversal, null/control characters, invalid ASCII characters | Rejected. |
| Reserved device names (case-insensitive, with extensions), trailing dots/spaces | Rejected. |
| Symlink root, parent, destination or dangling destination | Rejected by unchanged containment checks. |
| Empty components, `a//b`, `./a`, `a/./b`, trailing slash | Now explicitly rejected before normalization. |

The last row is a deliberate security tightening for noncanonical path spellings that the former `PurePosixPath` parser could silently collapse. It is not a rename/migration; canonical paths and legitimate historical filenames remain accepted. If an old manifest contains such an alias, report it rather than silently rewriting it or weakening validation. Existing identifiers are not affected.

The validator does not case-fold, Unicode-normalize or rename repository paths. Unicode filename support is not broadened. Existing filesystem case-sensitivity semantics remain; this fix does not make repositories containing both `A` and `a` portable to case-insensitive storage. No native Windows run is claimed. Existing symlink/containment checks are retained, not upgraded into race-free hostile-concurrent-writer filesystem transactions.

## Regression protection

The 293 inherited test methods remain. Historical source/hash guards compare the original exact source after reversing only the two approved literal maintenance changes. The allowlisted diff fixture has a hard-coded SHA-256; altered/duplicated patch text fails. This is not a blanket exemption for `safe_path`, all of `core.py`, or the CLI. The portable source guard itself remains unchanged and does not hash `ast.dump`.

29 new tests cover valid Python names and deep packages; canonical ordinary/hidden paths; traversal/normalization aliases; Windows paths/ADS/devices; nulls/malformed types; symlink root/parents/leaves; unchanged identifier/revision rules; old failing validator; exact catalog/policy preservation; authenticated baseline traceback/state; exact approved source delta; inert source acquisition; upstream SHA-256 and Git blob checks; metadata/full-hash inventory; inventory exports; registry registration/verification; multi-model final reporting; baseline failure after verified commits; explicit report-failure semantics and retry; interruption/reuse; corruption/quarantine; missing/same-size corruption; safe rerun and read-only dry-run.

All payloads used for tests are tiny inert fixtures. Python fixture files contain a raising statement so accidental execution would fail; no downloaded source execution is required or performed. Synthetic legacy manifests are explicit historical-format fixtures with actual fixture hashes, sizes and timestamps; no production manifest is reconstructed or rewritten to pass tests.

## Recovery and limitations

Installing alongside the previous version leaves the original application and archive intact. A read-only metadata inventory can inspect existing records without hashing hundreds of GB. After that, `--status` regenerates collection reports/current inventory and writes toolkit report metadata; it does not re-download weights or perform a full hash audit. Successfully verified manifests are retained. A later `--verify` performs collection-wide hash reads and updates audit metadata; it is a separate operator operation and can take substantial time.

The development environment cannot certify the current bytes of the Dell archive or runtime behavior of the seven models. No Dell payload, mount, permission, manifest, audit record, HP runtime or deployment copy was modified during development. No full weights were downloaded. The earlier GPT-OSS raw-part joining requirement remains unchanged.
