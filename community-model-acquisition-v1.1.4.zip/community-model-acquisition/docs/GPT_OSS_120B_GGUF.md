# gpt-oss-120b GGUF MXFP4 — v1.0.4.5

This release adds one deployment variant and one opt-in profile. It was built exclusively from verified v1.0.4.4. All 50 existing catalog entries, original policy records and historical profile memberships remain unchanged. Only normal `all` selection grows. Production modules remain byte-identical except version metadata.

## Identity and selected artifacts

- Model ID: `gpt-oss-120b-gguf-mxfp4`
- Profile: `gpt-oss-120b-local-inference` (this variant only)
- Repository owner: **ggml-org**, the llama.cpp/ggml project organization; not OpenAI.
- Exact repository: `ggml-org/gpt-oss-120b-GGUF`
- Immutable revision: `238abdd290bb874b90a5da1b4549881b7d05c091`
- Provenance: `third-party-derived`, a project-maintained conversion of official OpenAI weights.
- Canonical source relationship: `gpt-oss-120b-original`, `openai/gpt-oss-120b`, revision `b5c939de8f754692c1647ca79fbf85e8c1e70f8a`.
- The conversion's `.src_sha` PRIMARY line explicitly matches that existing source pin. The user's previously verified local original was not inspected, modified or reconverted in this release.
- Family remains the historical `gpt` value to group with the unchanged original; the new `upstream_model_family` value identifies OpenAI gpt-oss-120b specifically.
- Role: `portable-gguf`; policy: `source-and-inference`. This is not a training-source replacement.

| Selected file | Bytes | Advertised upstream digest |
|---|---:|---|
| `gpt-oss-120b-MXFP4.gguf` | 63,387,346,208 | `SHA-256:582bd40f6886200101f4c4ed9f25f3fe80cc14c86e9e2b37746cd8904a0c622d` |
| `README.md` | 457 | `Git-blob-SHA1:7fe089b3503ceac9b64ffdf0c1d9dbcc9eee3b28` |
| `.src_sha` | 97 | `Git-blob-SHA1:09c86bd1eca9c69b9e97a637dbddd7a0229697d7` |
| `convert.log` | 214,559 | `Git-blob-SHA1:d6747e09c5e85ac4d41200b16cfb3eca1c7b9f14` |

The single GGUF is **unsharded**, 63,387,346,208 bytes (63.387 GB decimal, approximately 59.034 GiB). The selected archive with README, source-revision record and conversion log is **63,387,561,321 bytes**. Empty-selection free-space threshold including existing 10% overhead plus 1 GiB reserve: **70,800,059,277 bytes**. Already-completed recognized files may reduce estimated new bytes; real space/mount checks remain authoritative.

There is no required projector, separate tokenizer, config or companion weight file for ordinary GGUF inference: tokenizer and template are embedded. Repository Eagle3 BF16 and Q8_0 files are optional speculative-decoding draft models and are intentionally excluded. The four required selected files include archival provenance metadata; those text files are not runtime dependencies. `convert.log` is preserved as inert text, never executed.

## Architecture and tensor representation

MoE `GptOssForCausalLM`; GGUF architecture `gpt-oss`. Header-derived total: **116,829,156,672 parameters** (approximately 117B). Publisher active count: approximately **5.1B per token**. 36 blocks, 128 experts, 4 selected experts per token; 64 attention heads and 8 KV heads. The configured 131,072 context maximum is not an initial benchmark setting or a memory guarantee. Sliding and full attention alternate; the sliding window is 128.

GGUF v3 header has 687 tensors: **108 MXFP4, 146 Q8_0 and 433 FP32**. These are tensor counts, not parameter shares. llama.cpp file type 38 is `LLAMA_FTYPE_MOSTLY_MXFP4_MOE`; tensor type 39 is MXFP4. The conversion log records repacking native MXFP4 expert weights and `MXFP4_MOE` processing of the output. This is native-MXFP4-oriented mixed precision, not BF16 equivalence and not uniform 4-bit storage. Nonexpert tensors include Q8_0 quantization, so exact equivalence to the official checkpoint's output is not asserted.

A bounded 16 MiB prefix was read to parse metadata (12,980,359 bytes) and the tensor directory (ending at byte 13,022,233). No full tensor payload was downloaded or executed. The complete advertised file SHA-256 is from repository LFS metadata, not a local full-model hash.

## Tokenizer, Harmony and runtime compatibility

All 200,019 defined source token IDs match the GGUF; merges and chat template are identical. The GGUF has 201,088 vocabulary slots, including padding to the model vocabulary size. Its embedded template supports Harmony roles/channels, reasoning effort and tool schemas. Do not hand-replace it with ChatML, a generic chat template or plain unformatted completion prompts.

Current llama.cpp source inspected at `cbe28bb3cb0758f0c566a9a3561766821aeb0748` includes the OpenAI MoE implementation (`src/models/openai-moe.cpp`), MXFP4 types and gpt-oss chat parsing. This establishes implementation/metadata compatibility, **not** a real HP load test. The installed HP executable must have these capabilities; this release does not rebuild or upgrade it.

Use conversation mode and the embedded Jinja/Harmony template. `reasoning_effort` accepts low, medium or high; the embedded default is medium. Start with low and 4096 context to limit initial workload. Low is not equivalent to disabling reasoning. A short generation cap can truncate reasoning before a final answer, so record that as truncation rather than a quality failure.

For a reproducible initial sampling configuration, explicitly record temperature 1.0, top-p 1.0, top-k 0, min-p 0.0 and repeat penalty 1.0. The llama.cpp project guide notes that disabling top-k can add CPU sampling overhead and retain very low-probability tokens. Other sampler choices can be separate labeled experiments; do not present them as speed or quality improvements without measurement. Explicit tool schemas and a separate orchestration layer are required for tool use. Downloading this GGUF installs neither browsing nor Python execution and grants no tool permissions.

## License and provenance limits

The official OpenAI source LICENSE is Apache 2.0; ggml-org's card and GGUF metadata also declare Apache 2.0. Preserve applicable license/notice obligations on redistribution. The source license and card are retained as research evidence. ggml-org conversion remains `third-party-derived` under the existing catalog convention, even though it is maintained by the inference project. It is not original OpenAI upstream weights.

The recorded source revision is unusually explicit and matches the existing canonical entry. That conversion record is publisher-provided evidence, not an independently reproduced conversion or full tensor-equivalence audit. No signed provenance attestation, full real-model hash verification, inference-speed result or scientific-quality guarantee is claimed.

## Sources and evidence

- [Pinned ggml-org repository](https://huggingface.co/ggml-org/gpt-oss-120b-GGUF/tree/238abdd290bb874b90a5da1b4549881b7d05c091)
- [Pinned original model](https://huggingface.co/openai/gpt-oss-120b/tree/b5c939de8f754692c1647ca79fbf85e8c1e70f8a)
- [llama.cpp gpt-oss project guide](https://github.com/ggml-org/llama.cpp/discussions/15396)
- [OpenAI Harmony](https://github.com/openai/harmony)
- [Pinned llama.cpp source](https://github.com/ggml-org/llama.cpp/tree/cbe28bb3cb0758f0c566a9a3561766821aeb0748)

Pinned APIs/cards/configs, conversion log/source pin, compact GGUF header summary and tokenizer comparison are in `evidence/v1.0.4.5`. No model payload ships in this ZIP. See `HP_GPT_OSS_120B.md` for benchmark preparation and `UBUNTU_ACCEPTANCE_V1045.md` for safe operator acquisition.
