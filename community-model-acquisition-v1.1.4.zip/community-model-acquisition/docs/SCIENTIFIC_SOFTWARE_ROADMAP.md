# Scientific software integration roadmap — documentation only

Model acquisition and verification remain separate from software/dependency preservation, document acquisition/sanitization, and runtime research orchestration. No package below is a model checkpoint, dependency, profile member or installation action in this release.

| Project | Future role | Priority / boundary |
|---|---|---|
| [PaperQA2](https://github.com/Future-House/paper-qa) | Retrieval and citation-grounded document research | Highest-priority near-term software integration candidate |
| [Robin](https://github.com/Future-House/robin) | Multi-agent scientific workflows | Future research-agent capability |
| [Aviary](https://github.com/Future-House/aviary) | Agent environments, development and evaluation | Future research-agent capability |
| [LDP](https://github.com/Future-House/ldp) | Agent decision processes and training | Future research-agent capability |

A future software archive would pin each project's source, license and dependency lock separately, including packages/model dependencies needed for offline operation. Preserving the project does not establish that all features run without cloud APIs. Provider, network, credential and license audits precede deployment. The pinned README snapshots in evidence are research records, not complete software distributions.

The document acquisition and sanitizer systems would supply approved text plus stable document/page/citation identifiers. A separately deployed inference runtime would resolve a verified registered model path and expose an explicitly configured local endpoint. PaperQA2 could then be evaluated against the local scientific corpus using independently provisioned retrieval/embedding resources and citation checks. This is a proposed interface, not implemented plug-and-play compatibility.

OpenScholar is a candidate generator/synthesizer over supplied evidence; ether0 is a molecular reasoning specialist, not a replacement for the retrieval pipeline or general research agent. Robin/Aviary/LDP might later use registered endpoints under bounded agent permissions. Model custody, provenance and verification remain the toolkit's responsibility; tool execution and research validation remain the orchestrator's responsibility.

AgRegen's intended benefit is reproducible scientific synthesis and domain research. Each generated claim should remain traceable to evidence, while model revision, runtime revision and prompt/evaluation configuration are recorded separately. This release implements none of those future orchestration mechanisms.
