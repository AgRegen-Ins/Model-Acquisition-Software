# Community Model Acquisition Toolkit v1.1.1

Maintenance release from verified v1.1.0, addressing the two production acceptance failures involving `/srv/ai-models/lost+found`.

## Correction

Inventory and read-only archive comparison now share a conservative recovery-directory recognition function. It excludes `lost+found` before descending, only when all of the following hold:

- Linux mount information identifies the archive itself as a complete ext4 filesystem root, with a matching device number and root inode 2.
- The immediate `lost+found` entry is a directory, on the same device, with conventional inode 11, UID/GID 0 and private permissions (no group/other access or special mode bits).
- The archive path is not symlinked, the entry is not a symlink, there is no nested mount at/below that entry, and mount information remains stable during recognition.
- Descriptor-pinned operations still match the visible archive; an active write session retains its existing identity checks.

This intentionally supports the conventional mkfs-created directory. It does not assert that every valid ext4 recovery directory must have inode 11: recreated/nonstandard directories are not automatically excluded. Unknown metadata, alternate filesystems, unmounted directories, subdirectory/bind mounts, ordinary files, nested `lost+found` entries and unrelated permission errors retain normal scanning/error behavior. No arbitrary path exclusion flag was introduced.

JSON inventory and comparison include `excluded_filesystem_entries`; text inventory prints `EXCLUDED`. Recovery contents are outside the model archive report and comparison, and are not inspected, hashed or declared verified. This does not certify a recovery directory as empty. An administrator should assess filesystem recovery data separately if needed. Payload and manifest accounting is unchanged.

## Compatibility and scope

The baseline ZIP SHA-256 was independently checked against:
`7289002140f5066ec457d43ebde7ec52bb0504f2e90c8cda56dd5def038880e0`.
All 730 internal baseline hashes and ZIP CRC passed before development.

Only inventory scanning, comparison scanning, version metadata, regression guards/tests and release documentation/checksums change. All 60 catalog entries, profiles, settings, manifests, UUID checks, download/resume, verification, quarantine, retention and registry code remain unchanged. The source diff and exact file-change list accompany this release. Historical documents remain historical; this section supersedes their release-version and migration-status statements.

The operator reports that the original migration and HP replica have both passed independent checksum verification. This maintenance release does not invalidate those results or require another migration or a full 2.62 TB rehash. No production archive was accessed or modified, no model was downloaded or executed, and no storage permissions were changed.

## Acceptance on Edmund-Library

1. Keep v1.1.0 installed and preserve its settings. Verify the new ZIP sidecar using `sha256sum -c community-model-acquisition-v1.1.1.zip.sha256` in the download directory.
2. Extract v1.1.1 into a new version-specific directory alongside v1.1.0. From the extracted `community-model-acquisition` directory, run `python3 verify_package.py`, then `bash setup-linux.sh`. The unchanged installer creates a local virtual environment, installs `requirements.txt` and prints help; it does not access the archive. Use v1.1.1 filenames/directories for this maintenance installation; the v1.1.0 cutover is already complete. Run `python3 verify_package.py` before creating local output files in the package. Do not copy an old virtual environment over the new package.
3. Run read-only acceptance:

```bash
.venv/bin/python model_storage.py --read-only
.venv/bin/python model_acquire.py --root /srv/ai-models --inventory --format json > /tmp/ai-model-inventory-v1.1.1.json
.venv/bin/python - <<'PY'
import json
p = json.load(open('/tmp/ai-model-inventory-v1.1.1.json'))
print('scan_complete:', p['summary']['scan_complete'])
print('excluded:', p.get('excluded_filesystem_entries', []))
print('warnings:', p['warnings'])
PY
```

Expect the confirmed root `lost+found` exclusion and no warning about descending into it. `scan_complete` is true only if there are no other scan warnings. Investigate any remaining warnings; do not mask them, run acquisition as root, or change recovery-directory permissions to silence errors.

The existing comparison command is unchanged:

```bash
.venv/bin/python compare_archives.py --source /srv/community-library/models --destination /srv/ai-models
```

A full production comparison rehashes all regular archive files and is **optional**, not a prerequisite to this maintenance release. The fix is covered with small synthetic comparisons. If run, matching archive contents yield exit 0 with an explicit destination recovery-directory exclusion. Genuine differences or other access errors still fail.

Rollback: stop using v1.1.1 and return to the preserved v1.1.0 application/environment. No model or manifest rollback/conversion is needed; this fix performs no migration. Do not delete the original archive.

## Qualification boundaries

The automated tests use disposable trees and controlled ext4 mount/inode probes; EACCES injection exercises the actual inventory and descriptor-based comparison traversal. Optional Linux tests create root-owned private directories with mode 000 and drop all capabilities in a child process to test genuine permissions. They require Linux root for fixture ownership and permission to drop child capabilities and are explicitly skipped when unavailable. No test requires privileged execution of the application on production data.

A disposable unmounted 32 MiB ext4 image created with e2fsprogs was inspected read-only with debugfs: `/lost+found` had inode 11, directory mode 0700, UID/GID 0. This supports the conventional layout check, but is not a mounted-filesystem or USB-DAS hardware qualification. The container disallows mount namespaces and UID/GID switching; genuine EACCES tests use capability dropping in a child instead. Final read-only acceptance on Edmund-Library remains the physical confirmation.

Reference: Linux ext4 special inode documentation distinguishes filesystem root inode 2, traditional first nonreserved inode 11, and the lost+found superblock field: https://docs.kernel.org/filesystems/ext4/special_inodes.html . The conservative automatic exclusion does not read raw block devices or require new dependencies/privileges.

## Automated source qualification

All 372 inherited regression tests are retained. Forty focused maintenance tests bring the suite to 412. On Python 3.10.22, 3.11.17, 3.12.14, 3.13.16 and 3.14.8, each source-tree run passed 412 tests with zero failures, errors or skips. This includes six genuine EACCES child-process cases and six simulated EACCES cases. The new authenticated baseline fixture checks 724 unchanged v1.1.0 files, including catalog, profile/configuration and acquisition protection files. The existing exact-source guard remains enforced through a new narrowly approved inventory-source delta.

Final clean-extraction results, ZIP SHA-256, CRC, exact archive membership and internal packaged-file checks are recorded in the accompanying `RELEASE_REPORT-v1.1.1.md` and validation evidence. On ordinary non-root hosts, six optional root-owned permission fixtures may skip with explicit reasons; the equivalent simulated cases remain active.
