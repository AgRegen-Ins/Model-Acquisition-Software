# Mount protection and storage inventory — v1.0.1

## Configure the expected storage mount

`settings.json` is external and human-editable:

```json
{
  "mount_guards": [
    {
      "platform": "posix",
      "root": "/srv/community-library/models",
      "expected_mount": "/srv/community-library"
    }
  ]
}
```

The most specific matching root rule wins. A rule also matches descendants of its model root. Supported platform values are `posix`, `nt` (Windows), and `any`. Rules with another platform are ignored. Unmatched roots have no guard; add a rule for every external-storage destination you intend to protect. An empty rule list is appropriate only when you intentionally use ordinary internal storage. The model root still must be supplied or entered each run.

For a one-run override:

```bash
.venv/bin/python model_acquire.py --root /mnt/archive/models --expected-mount /mnt/archive --profile small-cpu
```

Both rule paths must be absolute. The resolved root must be beneath the expected mount. The check uses the platform's mount detection; Linux also checks `/proc/self/mountinfo` for same-filesystem bind mounts. Windows rules can use a drive root or UNC share, for example `"root": "E:\\models", "expected_mount": "E:\\", "platform": "nt"`. Windows does not read Linux mount tables.

A missing expected mount stops setup/acquisition before creating model data. The CLI checks again before creating acquisition metadata and before each model. Do not create the mount directory merely to satisfy the check: an ordinary directory is insufficient. Connect and mount the intended disk first. The guard checks **mount presence**, not the drive's serial number/UUID; the wrong disk mounted at the same path can pass. Storage disappearing between checks is still an operational hazard.

Dry runs, offline plans, status, and inventory can be used without satisfying the mount guard. `--inventory` is entirely read-only and can report an absent root without creating it. A missing mount may hide the actual collection; an empty report from an unmounted path does not mean the disk's contents were deleted. Status/verification retain their existing metadata/report-write behavior and require an existing root; they never download model weights.

## Revision classification

Rows are grouped by category, variant ID, and source repository. Fields include the manifest's display name, purpose/description, publisher, source provenance, format, quantization, exact directory revision, acquisition date, age in days, recorded/current quick-check status, catalog pin, and disk usage.

- **Current:** the successfully acquired (`verified`, still passing size/time checks) local revision with the newest recorded original acquisition date. This is local acquisition order, not inferred Git ancestry or upstream publication time. Rerunning verification does not reset that acquisition date.
- **Superseded:** another valid revision in that group acquired strictly before the current working revision. This can include older partial/failed attempts.
- **Pending:** an incomplete/failed revision that cannot conservatively be classified as superseded. A newer failed download does not supersede a working model.
- **Undetermined/unknown:** insufficient metadata, missing acquisition date, an ambiguous equal date, or missing/corrupt manifest. These are never counted as automatically recoverable superseded space. When verified dates tie, the catalog pin (then revision string) breaks the choice of current; other tied rows remain undetermined.

The catalog's pinned revision and `catalog_revision_match` are separate fields. Downloading with `--latest` does not rewrite the catalog pin. Variants removed from the catalog retain their recorded metadata and are marked `configured: false`; their local revision groups are still classified. A missing/invalid manifest leaves metadata unknown while directory/file usage is still included. An `.incomplete` file in such a directory is recognized as partial data.

Inventory is a quick metadata check. It neither reads all weight bytes nor refreshes their cryptographic verification. Use `--verify` for the existing full hash audit. An inventory scan may show a formerly verified revision as partial if file sizes or timestamps changed.

## Storage accounting

The scanner examines every category/variant/revision directory under the root, including payload caches, failed attempts, quarantine, manifests, and unknown files. It excludes `_toolkit` logs/reports so generating reports does not inflate model totals. Files outside the three-directory layout are counted as unclassified storage. Symlinks are not followed; permission errors and skipped links produce warnings.

`disk_bytes` is regular-file allocated blocks (`st_blocks * 512`) when supported, with file-length fallback on platforms without that information. `logical_bytes` separately reports file lengths. Empty directories and directory filesystem metadata are not included. The report is not a byte-for-byte reproduction of filesystem free-space accounting.

Hard links are deduplicated within each revision and across the overall total. Category/current/superseded subtotals may overlap if a file is linked across those boundaries. Quarantine and partial/failed totals also overlap the containing revision totals, so **do not add these summary categories together**.

Potential recoverable space counts allocated bytes in superseded revisions **excluding all hard-linked files**. This is a conservative candidate estimate. It does not account for filesystem snapshots, reflinks/shared extents, compression, open files, or block allocation overhead; it is not a promise of how much space a future manual cleanup would free. No deletion command exists in this release.

## Exports and automatic snapshots

`--inventory` prints a grouped human-readable report. `--format csv` prints one row per actual revision with a header; it quotes commas/newlines using the standard CSV module. The CSV contains per-revision fields; collection summaries are in text/JSON. `--format json` includes all rows, summaries, warnings, definitions and view settings. Root notices go to stderr so redirected CSV/JSON is clean. Include `--root` for unattended export; otherwise interactive root selection still applies.

`--sort size` sorts groups by aggregate revision disk usage, then revisions by size, largest first. `--superseded` filters displayed rows only: JSON/text summary totals still cover the entire collection. CSV has no summary row that could be mistaken for a model.

State-changing CLI operations regenerate:

```text
_toolkit/inventory/current-inventory.txt
_toolkit/inventory/current-inventory.csv
_toolkit/inventory/current-inventory.json
```

Each file is replaced atomically and shares a generated timestamp; the three-file set is not a transactional filesystem snapshot. Snapshot generation runs under the existing collection lock during acquisition/status/verification. Abrupt termination can leave old snapshot files; a fresh `--inventory` reads disk state directly. Read-only inventory does not acquire/write a lock, so concurrent changes can produce a transient/incomplete report; heed warnings or rerun after the download finishes.

## v1.0.4.3

The [accountability report](ACCOUNTABILITY_INVENTORY.md) joins external installations without changing this legacy inventory or adding external sizes to managed totals.
