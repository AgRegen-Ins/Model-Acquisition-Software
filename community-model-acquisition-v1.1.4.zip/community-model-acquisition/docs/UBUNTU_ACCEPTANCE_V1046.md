# Ubuntu acquisition and verification — v1.0.4.6

Run acquisition on the Dell's existing **writable authoritative archive**, not the HP's read-only `/mnt/community-library` mount. These instructions do not change mounts or permissions. Catalog registration does not mean downloaded or verified. No model payload is bundled.

## Validate and install side by side

Place ZIP and sidecar together. In that directory:

```bash
sha256sum -c community-model-acquisition-v1.0.4.6.zip.sha256
mkdir toolkit-1.0.4.6-reasoning
unzip community-model-acquisition-v1.0.4.6.zip -d toolkit-1.0.4.6-reasoning
cd toolkit-1.0.4.6-reasoning/community-model-acquisition
python3 - <<'PY'
import hashlib,json
from pathlib import Path
for name,expected in json.loads(Path('PACKAGE-CHECKSUMS.json').read_text()).items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==expected,name
print('All packaged-file checksums passed')
PY
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -c 'from modelkit import __version__; print(__version__)'
```

This explicit setup installs only existing toolkit dependencies; no runtime or model code is installed. Expected version `1.0.4.6`, expected tests 242 passing. Use Python 3.10–3.14. Keep the older toolkit folder intact.

## Dry-runs (metadata only)

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model qwen3-next-80b-a3b-thinking-gguf-q6-k --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model glm-4-5-air-gguf-q4-k-m --dry-run
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model qwen3-next-80b-a3b-thinking-gguf-q6-k \
  --model glm-4-5-air-gguf-q4-k-m --dry-run
```

Dry-run reports total bytes, estimated new files, free space, reserve and large-download warnings. It does not create the root or download weights. A successful metadata-only dry-run can still print **INSUFFICIENT SPACE**; that is not acquisition success.

| Selection | Selected bytes | Required free bytes for an empty acquisition |
|---|---:|---:|
| Qwen | 65,528,476,256 | 73,155,065,705 |
| GLM | 63,633,990,692 | 71,071,131,585 |
| Both | 129,162,466,948 | 143,152,455,466 |

Reserve remains `int(estimated_new_bytes * 1.10) + 1 GiB`. Files already recognized as completed reduce the estimate; incomplete chunks are conservatively not deducted. Metadata, cache, filesystem allocation and quarantine can affect actual storage. Review current free space, not only this table.

## Explicit acquisition and resume

The default configuration expects `/srv/community-library` to be mounted. Confirm it without changing it:

```bash
mountpoint /srv/community-library
df -h /srv/community-library/models
```

If mount validation fails, stop and resolve the storage problem through the established operator process. Do not bypass the guard.

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model qwen3-next-80b-a3b-thinking-gguf-q6-k --yes --allow-large
.venv/bin/python model_acquire.py --root /srv/community-library/models \
  --model glm-4-5-air-gguf-q4-k-m --yes --allow-large
```

Each exceeds 50 GB: `--yes` alone is insufficient. After interruption rerun the **same command**. Existing Hugging Face partial-download recovery is retained; completed files are checked and reused. No separate resume flag exists. Do not use `--latest` if accepting these exact pinned artifacts. Do not add `--repair` to ordinary reruns: repair is an explicit damaged-file replacement operation that preserves old bytes in quarantine.

## Verification and inventory

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --status
.venv/bin/python model_acquire.py --root /srv/community-library/models --verify
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --sort size
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format json
.venv/bin/python model_acquire.py --root /srv/community-library/models --inventory --format csv
.venv/bin/python model_registry.py --root /srv/community-library/models --inventory --format json
```

**Existing `--verify` is collection-wide**, not filtered by `--model`; it rehashes all managed revisions and writes audit/report metadata. It does not modify weight contents. Allow time for large existing archives and ensure the writable Dell mount is present. `--inventory` is read-only storage reporting for on-disk revisions. Registry inventory also shows cataloged/not-downloaded entries. `--status` is recorded status plus size/mtime, not a full hash audit.

Complete acquisition requires exit code 0, `manifest.json` status `verified`, records for every selected file, and no audit problems after `--verify`. Verify can return failure because of an unrelated existing revision; inspect the per-model report. Logs/reports and automatically maintained inventories live under `_toolkit/`.

## Expected paths and first files

Each revision directory has `manifest.json`, `repository.json`, and `payload/` containing exact upstream names; failed/repaired files may also leave preserved quarantine/cache data. Paths:

```text
/srv/community-library/models/reasoning/qwen3-next-80b-a3b-thinking-gguf-q6-k/de5795cd9a4f5538d1dd5c9823fdd73eacfae3fe/payload/Qwen3-Next-80B-A3B-Thinking-Q6_K.gguf
/srv/community-library/models/reasoning/glm-4-5-air-gguf-q4-k-m/23a7a815a57a697e59f36fd8a897c632730a1fe9/payload/GLM-4.5-Air-Q4_K_M-00001-of-00002.gguf
/srv/community-library/models/reasoning/glm-4-5-air-gguf-q4-k-m/23a7a815a57a697e59f36fd8a897c632730a1fe9/payload/GLM-4.5-Air-Q4_K_M-00002-of-00002.gguf
```

For later inference, Qwen uses its single GGUF. GLM starts from `00001`; **keep both GLM shards together**, including the small metadata shard. Independently copied HP deployment files must be hash-checked against the archive manifest. Do not point acquisition at the read-only Samba share or overwrite canonical files. This guide performs no copying, inference, benchmark changes or llama.cpp installation.
