# Community Model Acquisition Toolkit v1.0.4.6 — two-model reasoning release

Date: 2026-10-14. This is the requested v1.0.4.5 → v1.0.4.6 **Qwen/GLM inference acquisition** release. It is not the separate OpenScholar ecosystem package previously bearing v1.0.4.6. Releases were kept separate; no OpenScholar code/integrations were copied into this package. Historical OpenScholar model entries already in v1.0.4.5 remain unchanged.

## Confirmed baseline

Supplied `community-model-acquisition-v1.0.4.5.zip`, SHA-256:

`97b92bcd9832aad26e1df234db0efdf8eac6ba0cf2dbc211310b405412f49670`

Verified internal version 1.0.4.5, ZIP CRC, 488 exact members and all 487 packaged-file hashes before modification. The untouched extracted baseline passed **214 tests**, no failures/errors/skips, on Python 3.12.14. All implementation started from that extraction, not from an earlier release or the separate ecosystem package.

## Scope and compatibility

- Added `qwen3-next-80b-a3b-thinking-gguf-q6-k` and `glm-4-5-air-gguf-q4-k-m`; exact required artifacts, pins and hashes in [model details](REASONING_GGUF_V1046.md).
- All **51 existing model-entry JSON values** are identical. All prior named profile selections are identical; `all` grows to 53 through existing selection behavior. No new profiles or implicit downloads.
- Existing preservation-policy values unchanged; only two inference-only policy records added. Old checkpoints, IDs, dependencies, manifests and local acquisition history untouched.
- Every existing production Python file is byte-identical except the version string in `modelkit/__init__.py`. Requirements, platform setup scripts, settings, mounts, core acquisition, resume, retries, hashing, inventory, retention, quarantine, registry and filesystem restrictions are unchanged.
- Historical tests retained; only catalog-count/additive-`all`/policy-set expectations updated. Portable protected-source regression fixtures and comparisons remain unchanged; no raw-AST hash reintroduced.

Modified baseline files (excluding regenerated `PACKAGE-CHECKSUMS.json`): `CHANGELOG.md`, `README.md`, `catalog.json`, `preservation-policy.json`, `modelkit/__init__.py`, `docs/PROFILES.md`, `docs/CATALOG.md`, `docs/PROVENANCE.md`, `docs/VALIDATION.md`, `tests/test_toolkit.py`, `tests/test_v103.py`, `tests/test_v104.py`, `tests/test_v1042.py`, `tests/test_v1043.py`, `tests/test_v1044.py`, `tests/test_v1045.py`.

New functional/test/documentation files: `tests/test_v1046.py`, `docs/REASONING_GGUF_V1046.md`, `docs/UBUNTU_ACCEPTANCE_V1046.md`, this report, and evidence under `evidence/v1.0.4.6/`. The final change manifest enumerates every new/changed path; no baseline member is removed.

## Qualification

**242 automated tests**: all 214 prior tests plus 28 focused tests. Source-tree runs pass on Python **3.10.22, 3.11.17, 3.12.14, 3.13.16, 3.14.8**. Each run: **242 passed, 0 skipped, 0 failed, 0 errors**.

Coverage includes unchanged old entries/profiles/code; exact repository/pins and adapter calls; complete required selections/bytes; single Qwen/two GLM shards; quantization-substitution rejection; split-header/tensor consistency; embedded templates; provenance and policy; mounts, reserves and `--yes`/`--allow-large`; read-only dry-runs; interrupted synthetic acquisition and completed-shard reuse; missing/truncated/same-size-corrupt payload rejection; quarantine; rerun safety; inventory/export and cataloged-versus-downloaded status. Synthetic payloads are inert bytes, not valid inference weights; no model execution occurs in tests. Existing adapter-resume tests are retained.

Live pinned Hugging Face metadata resolution succeeded for both entries. Individual and combined CLI dry-runs each exited 0 and matched selected manifests. All three printed large-download warnings. Development free space was approximately 28.72 GB: all three correctly reported insufficient space while remaining usable metadata-only dry-runs. Required reserve totals are 73,155,065,705 / 71,071,131,585 / 143,152,455,466 bytes respectively. These are developer-host checks, not measurements of the Dell mount.

The development HTTP client needed `socksio` solely for this environment's SOCKS proxy; installed only in the temporary development environment. No toolkit requirement or installation script was changed. No HP environment or installed archive was accessed.

## Verification boundaries and limitations

- Repository metadata and immutable pins verified live; published full-file hashes recorded.
- Header/structure inspected via bounded HTTP ranges: 12 MiB from each large GGUF and GLM's complete small metadata shard. That small shard's SHA-256 matched; **neither complete model's tensor payload was downloaded or hashed**.
- Current llama.cpp model implementations inspected at the documented commit. Installed HP runtime, inference and performance remain **untested**. No claim of stable performance or exact RAM minimum.
- No required quantization/model substitution or unresolved selection blocker. Qwen's exact conversion-source commit is undocumented; this uncertainty is explicit.
- No automatic downloads, model execution, conversion, background jobs, runtime modification, deletion or archive migration added.
- Existing archive verification is collection-wide and updates audit metadata, as documented. Existing safeguards were not redesigned.

## Final packaging

The external `VALIDATION_REPORT_v1.0.4.6.md` accompanies the ZIP and records final fresh-extraction test results, exact ZIP membership/count, CRC, packaged hashes and final SHA-256. It is produced after packaging to avoid self-referential archive checksums. Internal tests and source results are preserved in evidence; full external validation logs are also supplied. Do not infer final packaging results from this pre-packaging report alone.

[Ubuntu acceptance instructions](UBUNTU_ACCEPTANCE_V1046.md) distinguish cataloging, acquisition, verification and later independent deployment.
