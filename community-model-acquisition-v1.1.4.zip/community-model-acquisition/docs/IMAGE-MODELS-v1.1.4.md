# Image models v1.1.4 — preservation and deployment boundaries

This release extends the verified supplied v1.1.3 package, not an earlier toolkit. All 68 existing catalog entries and historical profiles remain unchanged. 27 primary image variants and 59 component records are added. Components are selectable acquisition objects, not 59 extra independently runnable models. Existing adapters, UUID storage guards, reserve accounting, download/resume/verification, registry and targeted auditing code are unchanged.

## Selection and completeness

One native Safetensors/Diffusers representation is preserved per source entry. Duplicate root checkpoints, ONNX, Flax, PyTorch pickle files, unrelated precision variants, gallery media and training datasets are not silently added. SD1.5 uses the EMA inference-source representation; this is not a preserved training optimizer state or a non-EMA training snapshot. Required safety checker and feature extractor remain included. SDXL Refiner is independently selectable, never a required Base dependency. No converter or inference code is run.

Native pipelines are split into the main network, exact required encoder/VAE weights, and publisher pipeline configuration. The existing dependency resolver selects their complete closure once. Index files stay alongside all their shards. Identical complete components reuse an ID based on exact SHA-256 and byte size, not architecture names. Some partial-shard overlap with an older generic Qwen3-4B checkpoint remains: its complete weight set differs from Z-Image's encoder, so it is not silently substituted. Small publisher metadata/tokenizers may repeat to preserve each pipeline configuration.

`component_layout` is an informational deployment map from original pipeline paths to archived component IDs and source paths. Acquisition does not merge files, rewrite configs, create runtime symlinks or install software. Native Diffusers deployment needs a separately assembled deployment copy following this map. FP16 variants require the runtime's FP16 variant selection. ComfyUI uses individual checkpoint/encoder/VAE loader paths. The map prefixes companion deployment-copy names with component IDs so two shared upstream files named model.fp16.safetensors cannot collide. Archive filenames remain unchanged; select the copied names in the separate runtime loaders. The archive hierarchy remains category/model-ID/revision/payload. Choose the actual payload files from the map, not a whole model directory as though it were already a runtime installation.

Recorded artifact verification and pipeline completeness are separate. The existing accountability inventory reports an otherwise verified model as incomplete while required local dependency records are missing. This is recorded verification with file fingerprints, not fresh hashing. External runtime libraries, Python environments, custom nodes and hardware readiness are never represented as acquired model components. Use selected verification before deployment.

## Target-specific findings and licensing

- **SD1.5:** the deprecated Runway address redirects to `stable-diffusion-v1-5/stable-diffusion-v1-5`. Its card explicitly says it is an unaffiliated mirror. It is classified third-party-derived/mirror, never falsely original Runway publication. FP32 and FP16 Diffusers sets; CreativeML OpenRAIL-M obligations remain. Native support includes the safety checker.
- **SDXL Base/Refiner:** official Stability repositories, FP32 source and Base FP16 official-derived. OpenRAIL++ terms and use restrictions apply. Refiner is optional.
- **Pony V6:** AstraliteHeart publisher repository, exact `v6.safetensors`; sparse 39-byte card declares CreativeML OpenRAIL-M. Bounded JSON Safetensors header inspection confirms FP16 SDXL UNet, two conditioning encoders and VAE tensors. No pickle deserialization or tensor loading. Sparse publisher documentation limits behavioral/license interpretation; no universal unrestricted guarantee.
- **Illustrious v1.0:** exact OnomaAIResearch release, not v1.1 despite a later card introduction mentioning it. Its card links SDXL's license (OpenRAIL++), not the NoobAI license. Header confirms bundled FP16 components. 1536px publisher resolution increases memory demands.
- **Animagine 4.0:** exact native Diffusers release, not the separately published `opt` checkpoint. OpenRAIL++ and mature-rating/tag guidance retained.
- **NoobAI XL 1.1:** Laxhar publisher release based on NoobAI1.0/Illustrious. Fair AI Public License 1.0-SD plus explicit publisher noncommercial, derivative-sharing and content restrictions. Training distribution includes Danbooru/e621. High-willingness is descriptive coverage, not permission to ignore its restrictions. Preserve its scheduler rather than assuming an arbitrary SDXL sampler.
- **WAI:** unresolved. Civitai model 827184 could not be independently inspected (HTTP403). TheReprinter mirror lists versions9/12/14 but does not establish authentic publisher hash and applicable version-specific license sufficiently. No WAI entry, guessed pin or unrelated substitute is added.
- **FLUX.2 klein4B:** official distilled BF16 plus optional undistilled base4B, separately named; Apache2.0. Both generation and reference editing use the same selected checkpoint. Official FP8 is an inference variant with exact Qwen3-4B and Klein VAE companions. Base is not an automatic dependency of distilled. Native publisher memory guidance (~13GB) is not a guarantee for a6GB GPU.
- **Z-Image-Turbo:** official native transformer is F32 in this revision, not silently described as BF16. Comfy-Org BF16 is a separate third-party deployment conversion. Exact Qwen3 encoder and FLUX AE accompany it. Apache2.0.
- **FLUX.1 dev/Kontext/FLUX.2 dev:** gated official native repositories; FLUX dev noncommercial terms and acceptable-use policy apply independently of download accessibility. Outputs have their own license provisions; this report does not collapse outputs and weight redistribution into one permission. Accept terms using the operator's authorized HF account. Generation and editing share FLUX.2 dev weights; Kontext is distinct. Full native FLUX.2 includes its large Mistral encoder, tokenizer/processor and exact dev VAE.
- **SD3.5 Large:** official MMDiT, three encoders and VAE. Stability Community License permits specified uses below the publisher's $1M annual revenue threshold; above it requires enterprise terms. Review full current terms/AUP before redistribution or deployment. The GGUF Q4_0 is city96-derived; Q4_K_M is not invented where absent.
- **Qwen Image2512:** official BF16 transformer plus Qwen2.5-VL encoder, tokenizer and VAE; Apache2.0. Unsloth Q4_K_M is third-party-derived and uses ComfyUI-GGUF (also publisher documents stable-diffusion.cpp, not llama.cpp). Its selected Comfy encoder is FP8-scaled; this is not canonical BF16 preservation.
- **HiDream-I1 Full:** actual Full F16 diffusion transformer; CLIP encoders F32, T5 BF16, external Llama3.1-8B-Instruct required by the publisher. Main MIT terms do not relicense Meta's encoder. Official source dependency requires Meta gated approval and its Community License/AUP. GGUF uses explicitly published HiDream Comfy companions, including a separately attributed Meta-derived FP8 encoder; public conversion availability does not erase Meta obligations. No Fast/Dev substitution.
- **FLUX.2 NVFP4:** official mixed NVFP4/BF16 selected; not GGUF, not source weights. Future supported hardware/runtime target; native NVFP4 acceleration is not claimed on RTX3050/3060. The full BF16 canonical source remains separately selectable. The dev VAE is different from Klein's; no interchangeable substitution.
- **Qwen Image Edit:** original,2509,2511 are different releases. This release explicitly selects official **2511**, whose publisher describes improved consistency and multi-image editing over2509. All processor files, special tokens, tokenizer, encoder and VAE are preserved. Apache2.0. No generic unversioned ID conflates releases.

Licenses are component-specific. Converted CLIP/OpenCLIP (MIT), T5/Qwen/Mistral (Apache2.0), and Meta Llama components retain their original obligations. Public repository metadata and a conversion card are not a universal redistribution grant. Pinned card/license files are in the acquisition selections where provided and research evidence accompanies this release. No authentication bypass was attempted. Gated index contents unavailable without approval are explicitly recorded in index-checks.json; planned filenames/digests still resolve via public pinned metadata, and existing post-download index verification remains mandatory.

## Runtime/hardware qualification

Image GGUFs are diffusion-network GGUFs for **ComfyUI-GGUF**, not language models for llama.cpp. No runtime installation, GPU test or image inference occurred. ComfyUI core/custom-node support changes; pin and validate a runtime separately. Metadata compatibility is not measured performance.

| Planning tier | Assumptions/examples |
|---|---|
| 4–6GB | SD1.5 FP16, batch1,512px; attention/memory optimization may be required |
| 8–12GB | SDXL FP16 around1024px; KleinFP8/ZImageBF16 with separate CPU text encoders and offloading; not guaranteed on6GB |
| 16–24GB | Larger quantized diffusion networks with CPU/offloaded encoders; resolution/batch add memory |
| 32–48GB | Larger GGUF/BF16 networks with substantial encoder placement management |
| >48GB | Complete large native pipelines, especially FLUX2dev/Qwen/HiDream, or advanced CPU/multi-device offloading |

These are estimates, not minimums. Disk bytes are not peak VRAM. HP352GB system RAM can hold these artifact sets individually but does not imply acceptable latency. RTX3050 6GB cannot host complete large pipelines. RTX3060 12GB is not automatically sufficient either. No benchmark speed is claimed.

## High-willingness boundary

Community illustration profiles preserve diverse training distributions and published prompting styles. The selection is not an empirical refusal benchmark. Runtime/interface moderation is independent; nothing here disables it. Mature-capable does not mean universally accurate, universally unrestricted or exempt from publisher license restrictions. Safety-related source documentation is retained.

## Source references

All exact repository links, commits, filenames, digests and component mappings are in IMAGE-COMPONENTS.json/CSV and evidence/v1.1.4. Primary runtime references: https://github.com/city96/ComfyUI-GGUF ; https://github.com/Comfy-Org/workflow_templates ; https://github.com/Comfy-Org/comfy-quants/blob/main/docs/quantization/flux2.md ; https://huggingface.co/HiDream-ai/HiDream-I1-Full ; https://huggingface.co/Laxhar/noobai-XL-1.1 ; https://stability.ai/license . Exact model-card snapshots are bundled; mutable runtime links are references, not installed dependencies.
