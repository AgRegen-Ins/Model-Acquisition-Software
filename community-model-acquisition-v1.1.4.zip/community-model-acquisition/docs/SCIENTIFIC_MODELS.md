# Scientific research additions — v1.0.4.4

Reviewed 2026-10-13 UTC. This is a catalog/profile/policy/documentation expansion from verified v1.0.4.3. All 46 prior entries, policy records and historical profile memberships remain unchanged; `all` naturally grows to 50. No production Python module changes other than the version string. New policies never cause an implicit second download.

These are acquisition configurations with verified pinned metadata and bounded header inspection. No full model payload was downloaded, no checkpoint was deserialized, and no CPU/GPU inference or training was performed. Runtime support means architecture/tokenizer/template compatibility, not an end-to-end deployment benchmark.

| Model ID | Repository | Immutable revision | Selected bytes | Format / precision | Provenance / role |
|---|---|---|---:|---|---|
| `openscholar-8b-original` | `OpenSciLM/Llama-3.1_OpenScholar-8B` | `8f9c03066206880174d24f083dc46afa61a0c7a7` | 16,069,764,442 | PyTorch / BF16 | official-upstream / canonical-source |
| `openscholar-8b-gguf-q4-k-m` | `bartowski/Llama-3.1_OpenScholar-8B-GGUF` | `b2f6c23c36212144e5b045d1d1a8441f0703da3f` | 4,920,748,740 | GGUF / Q4_K_M | third-party-derived / portable-gguf |
| `ether0-24b-original` | `futurehouse/ether0` | `d2155a6a6c992d0da6f6c49234f0a7cb4d780e94` | 94,309,625,093 | Safetensors / FP32 | official-upstream / canonical-source |
| `ether0-24b-gguf-q4-k-m` | `redponike/ether0-GGUF` | `1cd2278fa01b3a24fb530fc84eb92737516f8795` | 14,334,364,631 | GGUF / Q4_K_M | third-party-derived / portable-gguf |

All four variants have `source-and-inference` preservation intent. Canonical weights and GGUF are separate selectable entries. Canonical does not mean that a training workflow was tested, nor does it imply that a GGUF can recover its original precision. Dense models have no distinct active-expert count (`null`, not an invented MoE value).

## OpenScholar findings

The official checkpoint is a dense Llama 3.1 derivative, 8,030,261,248 model parameters calculated from the standard architecture/config, with a 131,072-position configured maximum. The intended task is scientific synthesis from evidence supplied in the prompt. The supplied `.bin` is 16,060,624,390 bytes. Config declares BF16; static disassembly of its ZIP-contained pickle **opcodes only** finds `torch BFloat16Storage` references. No pickle interpreter, `torch.load`, tensor constructor or repository Python code was executed. A bounded 256 KiB prefix sufficed to inspect the 41,423-byte metadata stream; tensor data was not read.

A Safetensors conversion is technically plausible for a reviewed tensor state dictionary. It is deliberately not attempted or made a dependency: conversion requires a separately reviewed loading environment, handling shared tensors and verifying tensor equality, dtype, shape, tokenizer and configuration. A reproducible conversion recipe alone is not proof of deterministic identical output bytes. This release preserves the publisher's source bytes unchanged.

The standard dense Llama architecture and published OpenScholar training code support future customization planning. LoRA/PEFT is an architecture-level candidate, not an exact-checkpoint fine-tuning success claim. Config records Transformers 4.42.3; that historical metadata is not treated as a verified minimum for all Llama 3.1 RoPE behavior. Use a reviewed current runtime with Llama 3.1 support. Training dependencies remain outside this toolkit.

Bartowski Q4_K_M is selected over the inspected QuantFactory alternative because its card documents llama.cpp b4132 and imatrix calibration, with a compact 4,920,734,944-byte artifact. Header architecture `llama`, file type 15 (Q4_K_M), layer dimensions, RoPE settings and vocabulary agree with source. Its entire 128,256-token ID mapping, merge list and chat template match the pinned source. GGUF tensor element count includes an extra 64-value RoPE tensor, so it is not substituted for model parameter count. The converter's old `OpenScholar/...` link redirects to the exact current OpenSciLM repository and revision.

Neither converter publishes the exact immutable source tensor commit used for conversion. Upstream family, tokenizer, dimensions and prompt format are corroborated; bit-for-bit conversion equivalence to today's canonical pin is **not** claimed. GGUF SHA-256 is the repository's advertised LFS identity, not a locally computed hash of an unacquired full model.

The model is not the complete OpenScholar system. Search, corpus indexes, retrievers, rerankers, citation resolution, research datasets and the full RAG pipeline are not acquired or installed. Future Community Library integration may retrieve sanitized scientific passages with stable document/page identifiers, pass them as context, then independently validate generated citation references. No such integration is implemented here.

## ether0 findings

The official checkpoint is dense `MistralForCausalLM`, derived from Mistral-Small-24B-Instruct-2501. All 21 Safetensors shard headers were read using bounded byte ranges: **23,573,058,560 FP32 tensor elements**, agreeing with the Hub metadata and config. This is not a BF16 source archive. Selected source files total 94,309,625,093 bytes; all shards, their index, tokenizer files, generation/model config, custom chat template, README and LICENSE are required. Decorative repository images and Git attributes are not required for inference and are excluded.

The configured context is 32,768. Publisher runtime examples use Transformers; its tools specify Transformers >=4.49 and the checkpoint config records 4.49.0. The public reward/evaluation repository is not the original full training pipeline. The unquantized Safetensors and ordinary Mistral layers are appropriate canonical inputs for future conversion and adapter/full fine-tuning experiments, subject to separate runtime validation and sufficient training hardware.

**Candidate change:** TensorBlock's card lists Q4_K_M, but its pinned current tree contains only Q2_K and Q3_K_M weights. That unavailable Q4 artifact is not cataloged. The selected alternative is `redponike/ether0-GGUF`, `ether0-Q4_K_M.gguf` (14,334,363,872 bytes). Its author documents llama.cpp b5602, imatrix calibration and a BF16 intermediary. The authoritative source remains FP32: this intermediate conversion loses precision before 4-bit quantization. Exact source commit and full tensor-equivalence proof are unavailable.

Header architecture is `llama`, which is llama.cpp's compatible representation for this Mistral architecture, not a claim that its upstream family is Meta Llama. Dimensions, 40 layers, 128 head dimensions and 32,768 context agree. All 131,076 defined source token IDs, merges and custom scientific chat template match. The GGUF vocabulary is padded to 131,136 slots matching config; 60 extra unused slots are not new chemistry tokens. Special reasoning/answer tokens are retained. The embedded template supplies a scientific system message and supports user/system/assistant roles; do not substitute a generic Mistral template or claim tool-call support.

The converter recommends higher precision for SMILES-heavy work. Q4_K_M is preserved as the requested compact benchmark option, not claimed chemically accuracy-equivalent to source or higher quants. No additional quantization is automatically included. Validate SMILES, stereochemistry and task accuracy independently before relying on outputs.

ether0 is a molecular-output specialist: formula-to-structure, constrained property changes, molecule generation and some single-step reaction/retrosynthesis tasks. It is not a general chemistry knowledge assistant. The publisher reports weak textbook knowledge and common-name confusion, and no special practical laboratory skill for purification, processing or scale-up. Prefer structural SMILES inputs; valid syntax and model confidence do not establish experimental correctness.

## Licensing findings

OpenScholar source metadata declares Llama 3.1 while its card says Apache 2.0. Bartowski's card/header also says Apache. Those statements do not establish that Meta's derivative obligations have been waived. The catalog uses `llama3.1` and records the conflict. Preserve the Llama license and notice when redistributing; account for attribution, naming, acceptable-use and the license's additional commercial terms (including its 700-million-user condition). Seek clarification from the model authors before treating the archive as Apache-only. This report is not a legal clearance. The base license and use policy are retained as evidence, obtained from Meta's pinned official GitHub repository because the gated HF raw LICENSE request returned 401.

ether0's pinned LICENSE is Apache 2.0, and its official Mistral base card also declares Apache 2.0. Respect notice/license obligations for any redistribution. The GGUF header repeats Apache 2.0, but redponike is a separate converter; no FutureHouse certification is implied. No assertion is made that PaperQA2, Robin, Aviary, LDP or other surrounding software all share this license.

## Evidence and current runtime support

`evidence/v1.0.4.4/` contains pinned Hub inventories, cards/configs, exact selected-file digests, GGUF header summaries, tokenizer comparisons, source precision evidence, runtime source snapshots and live dry-run logs. The research process read source/tokenizer metadata and small bounded weight headers only. Snapshot hashes are packaged; these are not signatures or full-model local integrity attestations.

Current llama.cpp source inspected at commit `cbe28bb3cb0758f0c566a9a3561766821aeb0748` contains the Llama model implementation, Llama-BPE/Tekken tokenizers and Mistral template support. Both formats predate current releases; no experimental architecture is required. Actual installed HP build compatibility must still be checked on that host. Do not install or change that build as part of acquisition.

## openscholar-8b-original

[Repository at immutable revision](https://huggingface.co/OpenSciLM/Llama-3.1_OpenScholar-8B/tree/8f9c03066206880174d24f083dc46afa61a0c7a7).

Capabilities: `scientific-literature-synthesis`, `research`, `scientific-reasoning`, `evidence-grounded-question-answering`, `fine-tuning-source`, `re-quantization-source`.

Policy: `source-and-inference`. Training: Canonical non-quantized BF16 checkpoint; standard Llama/Mistral linear layers are candidates for PEFT/LoRA and source conversion. Architecture/tooling compatibility is established; this exact checkpoint has not been loaded or fine-tuned in this release. PyTorch .bin is inert archive data; any future loading/conversion requires a separately reviewed isolated workflow.

Selected files:

| File | Bytes | Upstream digest |
|---|---:|---|
| `README.md` | 2,246 | `Git-blob-SHA1:c9fe76a750897df3416262c033f3ea1c284eb6dd` |
| `config.json` | 855 | `Git-blob-SHA1:0bb6fd75b3ad2fe988565929f329945262c2814e` |
| `generation_config.json` | 184 | `Git-blob-SHA1:cc7276afd599de091142c6ed3005faf8a74aa257` |
| `pytorch_model.bin` | 16,060,624,390 | `SHA-256:b6a517c767242bf9babfe9d150fb0d42bcf4c1b8f1f9f6f244243a872953dd99` |
| `special_tokens_map.json` | 296 | `Git-blob-SHA1:02ee80b6196926a5ad790a004d9efd6ab1ba6542` |
| `tokenizer.json` | 9,085,657 | `Git-blob-SHA1:5cc5f00a5b203e90a27a3bd60d1ec393b07971e8` |
| `tokenizer_config.json` | 50,814 | `Git-blob-SHA1:a4a50a844728e9e2d317061b166fd67c550312b4` |
## openscholar-8b-gguf-q4-k-m

[Repository at immutable revision](https://huggingface.co/bartowski/Llama-3.1_OpenScholar-8B-GGUF/tree/b2f6c23c36212144e5b045d1d1a8441f0703da3f).

Capabilities: `scientific-literature-synthesis`, `research`, `scientific-reasoning`, `evidence-grounded-question-answering`, `inference-optimized`.

Policy: `source-and-inference`. Training: Inference-oriented GGUF; not the canonical fine-tuning or re-quantization source. Keep the separate official checkpoint for customization.

Selected files:

| File | Bytes | Upstream digest |
|---|---:|---|
| `Llama-3.1_OpenScholar-8B-Q4_K_M.gguf` | 4,920,734,944 | `SHA-256:54865fc86451959b495c494a51bb1806c8b62bf1415600f0da2966a8a1fe6c7d` |
| `README.md` | 13,796 | `Git-blob-SHA1:a61c933c4e0d09cbf2252392a6ac3a6541d49678` |
## ether0-24b-original

[Repository at immutable revision](https://huggingface.co/futurehouse/ether0/tree/d2155a6a6c992d0da6f6c49234f0a7cb4d780e94).

Capabilities: `chemistry-reasoning`, `molecular-reasoning`, `scientific-reasoning`, `smiles-generation`, `research-specialist`, `fine-tuning-source`, `re-quantization-source`.

Policy: `source-and-inference`. Training: Canonical non-quantized FP32 checkpoint; standard Llama/Mistral linear layers are candidates for PEFT/LoRA and source conversion. Architecture/tooling compatibility is established; this exact checkpoint has not been loaded or fine-tuned in this release. Publisher documents SFT/RL training but its public ether0 code repository is reward/evaluation utilities, not the full training pipeline.

Selected files:

| File | Bytes | Upstream digest |
|---|---:|---|
| `LICENSE` | 11,341 | `Git-blob-SHA1:8dbd92807c444f8f8a32cd6651c490fabe4366d9` |
| `README.md` | 5,754 | `Git-blob-SHA1:aef26619ce56a3c5c151501912ce6689a48a27d5` |
| `chat_template.jinja` | 903 | `Git-blob-SHA1:768a7cdb6fdd10b9a78b947dd569fdb4776b8664` |
| `config.json` | 642 | `Git-blob-SHA1:c003ab96027702f48d090ee603c7dd7fac2d12a3` |
| `generation_config.json` | 155 | `Git-blob-SHA1:48021ec789cd27e19ab61fcb4a2ad8cc8dbf4826` |
| `model-00001-of-00021.safetensors` | 4,992,574,728 | `SHA-256:0cb64bde7082b4e221268ae7eda5f810e6b559faab3dba039227b00d16eecce9` |
| `model-00002-of-00021.safetensors` | 4,571,875,720 | `SHA-256:c053c7c4f38f9df7c551f4093e11562ffa0bb8dfc9b3a2b3eae0723b905dcd5f` |
| `model-00003-of-00021.safetensors` | 4,446,046,248 | `SHA-256:0883613b40af4455e245cffafa6b8e7f0455e1b0c14faac84abc53f4f799fbe3` |
| `model-00004-of-00021.safetensors` | 4,446,046,248 | `SHA-256:836de9d506d80fbcbc6b9e83aef31653c3e07981ce2c940038a79db28f897558` |
| `model-00005-of-00021.safetensors` | 4,446,046,248 | `SHA-256:b54f174cc8cf869ee3b91c64139d22bff21448d0f481ce705b55baff14abbe20` |
| `model-00006-of-00021.safetensors` | 4,446,046,264 | `SHA-256:4864ef66b68960555e1ff21414e0fdd651527f1ab996301858a0f1d478e163c9` |
| `model-00007-of-00021.safetensors` | 4,446,046,264 | `SHA-256:6e5d82c280d103ec6dae66d9f7b8b5d8d0dd3a9c13e14a69a09b5879329a22ff` |
| `model-00008-of-00021.safetensors` | 4,446,046,264 | `SHA-256:f1b8872a7a472f95cdaa06427d39fdf4d8ef7bb9294f1fd57dbc385bee830b22` |
| `model-00009-of-00021.safetensors` | 4,446,046,264 | `SHA-256:fc064b9e62e0ab8b93838804fbf2928ecdc4872dee8070ff414275f162d569da` |
| `model-00010-of-00021.safetensors` | 4,446,046,264 | `SHA-256:faba359dbf04871e3be0168fab3e9a1c64e9b6520cbd789a07f34cf99e82f202` |
| `model-00011-of-00021.safetensors` | 4,446,046,264 | `SHA-256:0e1e7899320234808c18cee9739e677abf62084def0b7b40fc2b3166bbb0bd57` |
| `model-00012-of-00021.safetensors` | 4,446,046,264 | `SHA-256:09864179156aef136f11c753cb2fe9a3a67e279906d6183e0dac1cd9405a5380` |
| `model-00013-of-00021.safetensors` | 4,446,046,264 | `SHA-256:0b0c81e8db54b70605946a9ede46117983d740d6ea247e0f45c7a5bb3d0c0ab9` |
| `model-00014-of-00021.safetensors` | 4,446,046,264 | `SHA-256:f7ae623f4729b9d534ca53dcac2447bfa4f25345765306e3b306adb020a4fda8` |
| `model-00015-of-00021.safetensors` | 4,446,046,264 | `SHA-256:bd5f275d227f197e005207cddd391f9ca5dd9170c5fd3939e83e8ef62c133fd7` |
| `model-00016-of-00021.safetensors` | 4,446,046,264 | `SHA-256:0bda5a688b27cc0fd87a5baeeed5d6bf54c0cf62e7a559c2bff0e5d7b9234d73` |
| `model-00017-of-00021.safetensors` | 4,446,046,264 | `SHA-256:b07d2b13a357de1998fe902a8d562a0bb41ecaa5b8194771e31bb16ee8a27fbf` |
| `model-00018-of-00021.safetensors` | 4,446,046,264 | `SHA-256:da31fa0482d119090ed031dfa14f37061a9045b98713befa8fe6df18a05d9cca` |
| `model-00019-of-00021.safetensors` | 4,446,046,264 | `SHA-256:05ebfbaf5430997ae6c7ff365616999368347e882ac725e27c7bf87219e511f4` |
| `model-00020-of-00021.safetensors` | 4,446,046,264 | `SHA-256:40c3eb42991fcecd28101cda400a56c1fce1b6425fc2aa490db333e3b2c37470` |
| `model-00021-of-00021.safetensors` | 4,698,993,432 | `SHA-256:93e33305780e263458db746978bf00e892c12cb882520ea652af6709c5fa5dea` |
| `model.safetensors.index.json` | 29,894 | `Git-blob-SHA1:e7016a13b98d73a94527f398c4afe27db8f2431d` |
| `special_tokens_map.json` | 21,311 | `Git-blob-SHA1:642b1b50c2ed17cd03114ad8af688a4854da558a` |
| `tokenizer.json` | 17,078,803 | `SHA-256:6396233c0e3e593eb1c4b2dc2e4ec1a8bdb88bf7747c36175b14011b95125508` |
| `tokenizer_config.json` | 199,706 | `Git-blob-SHA1:56bfa0b71e51e9adb2ef03693d678176126a04e6` |
## ether0-24b-gguf-q4-k-m

[Repository at immutable revision](https://huggingface.co/redponike/ether0-GGUF/tree/1cd2278fa01b3a24fb530fc84eb92737516f8795).

Capabilities: `chemistry-reasoning`, `molecular-reasoning`, `scientific-reasoning`, `smiles-generation`, `research-specialist`, `inference-optimized`.

Policy: `source-and-inference`. Training: Inference-oriented GGUF; not the canonical fine-tuning or re-quantization source. Keep the separate official checkpoint for customization.

Selected files:

| File | Bytes | Upstream digest |
|---|---:|---|
| `README.md` | 759 | `Git-blob-SHA1:0f23aa28c80bf0b0af5da528cdd8340a0e6ae2b2` |
| `ether0-Q4_K_M.gguf` | 14,334,363,872 | `SHA-256:40d73317d666ff5ef80a4f4cdaa441197a4d3ecf7a4fb61ea070ab0057e454c0` |

## Research sources

- [OpenScholar official model](https://huggingface.co/OpenSciLM/Llama-3.1_OpenScholar-8B) and [official research code](https://github.com/AkariAsai/OpenScholar).
- [Bartowski conversion](https://huggingface.co/bartowski/Llama-3.1_OpenScholar-8B-GGUF); [QuantFactory candidate](https://huggingface.co/QuantFactory/Llama-3.1_OpenScholar-8B-GGUF).
- [ether0 official model](https://huggingface.co/futurehouse/ether0), [official reward/evaluation code](https://github.com/Future-House/ether0), [Mistral base](https://huggingface.co/mistralai/Mistral-Small-24B-Instruct-2501).
- [TensorBlock candidate](https://huggingface.co/tensorblock/futurehouse_ether0-GGUF), [selected redponike conversion](https://huggingface.co/redponike/ether0-GGUF).
- [Meta Llama 3.1 license](https://github.com/meta-llama/llama-models/blob/0e0b8c519242d5833d8c11bffc1232b77ad7f301/models/llama3_1/LICENSE), [use policy](https://github.com/meta-llama/llama-models/blob/0e0b8c519242d5833d8c11bffc1232b77ad7f301/models/llama3_1/USE_POLICY.md).
- [PEFT LoRA documentation](https://huggingface.co/docs/peft/v0.21.0/package_reference/lora); no fine-tuning was run.
