# Cross-project registry — v1.0.4.3

The authoritative accountability view joins the model catalog, existing managed manifests on disk, `preservation-policy.json`, and `_toolkit/registry/instances.json`. Separate projects keep their inference runtimes and paths. The legacy `model_acquire.py --inventory` text/CSV/JSON schema, accounting and automatically maintained reports are unchanged. Use the separate `model_registry.py --inventory` for the expanded cross-project view.

## Explicit operations

- `--register SPEC.json`: hash explicitly named local files and record custody without changing external files. A filename, matching size or locally computed hash does not establish upstream provenance. No wildcard/directory crawling occurs.
- `--verify-instance ID`: rehash local files against recorded local identity. Add `--upstream` to resolve the exact catalog pin through the existing Hub adapter and compare trustworthy LFS SHA-256 or Git blob SHA-1. A changed previously recorded identity is a verification failure, even if a later re-registration is attempted. Use a new, explicitly named custody instance for a deliberate replacement; retain the old record.
- `--import-instance ID --yes`: re-resolve and reverify the complete selected artifact set, then copy via the existing acquisition/hash/quarantine machinery into private staging. Verify destination bytes before atomic promotion to a new managed revision directory. The original paths, contents and permissions are untouched. Existing managed destinations are refused, never overwritten. Ordinary acquisition/reruns remain separate and require no adoption step.

All mutations hold the same collection lock as normal acquisition. The configured mount guard applies to registry metadata writes and imports. Imports require the existing 10% + 1 GiB space reserve and `--allow-large` when >=50 GB, in addition to `--yes`. Staging lives in `_toolkit/import-staging`; interrupted/failed copies remain there with manifests and any quarantine for operator inspection, excluded from legacy managed-model totals. Import restart currently re-copies into new staging; normal network acquisition resume is unchanged. No automatic cleanup exists.

## Registration specification

```json
{
  "instance_id": "sanitizer-qwen-vision",
  "model_id": "qwen2-5-vl-3b-instruct-gguf-q4-k-m",
  "artifact_kind": "model-artifacts",
  "location_kind": "external-installation",
  "files": {
    "Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf": "/absolute/path/to/actual-model.gguf",
    "mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf": "/absolute/path/to/actual-projector.gguf"
  },
  "associated_projects": ["Community Document Sanitizer", "Untrusted Acquisition Toolkit"],
  "custody_notes": "Existing installation; retain paths and originals"
}
```

Keys are expected repository artifact names; values identify the actual local files, whose basenames may differ. Never infer identity from that mapping: registration remains unverified until an explicit upstream comparison succeeds. Registry IDs, catalog IDs and local paths are distinct. Reusing the same instance ID/path set merges project associations; conflicting IDs or duplicate aliases are refused. Unknown model IDs can be locally registered, but cannot become upstream-verified or imported without a matching pinned catalog entry. Supplied arbitrary hashes are not accepted as trusted upstream evidence.

`location_kind` is canonical-archive, deployment or external-installation. For metadata about another computer add `remote_reported: true`, `host`, and optional `reported_file_metadata` (reported sizes/hashes). Those reports are never probed, locally hashed or promoted to verified by this computer. They remain explicitly remote-reported. Remote verification/import must run on the recorded host holding the files. Multiple installation IDs can describe different paths/hosts for one model. Unavailable local paths are reported missing, with a note that a drive may be unmounted; no empty replacement directory is created.

Personal voice recordings are not model assets. Audio/video suffixes, arbitrary directory scans, symlinks, and quarantine/staging adoption are rejected. Only explicitly mapped catalog artifacts are accepted for known IDs; unknown IDs allow inert model-container/config suffixes. This is not a content classifier: operators must not disguise private voice profiles as model checkpoints. The toolkit never discovers, ingests, copies or publishes personal references, and never executes repository code or deserializes model objects. Chatterbox's publisher-provided `conds.pt` and Kokoro's public voice packs are model distribution assets, not user recordings.

## Compatibility and trust limits

The ordinary acquisition CLI and download adapter are byte-identical. Only `load_catalog` and `select` gained an explicit dependency call in core.py, within the same two definitions permitted by the portable source guard. Dependencies are validated for missing IDs/cycles, expanded before parent models and deduplicated. Preservation policy does not create dependencies. F5-TTS requires the pinned Vocos component. A completed parent checkpoint is distinct from a complete runnable system; the accountability view marks it incomplete while its exact pinned dependency is not verified locally on the same host. Legacy per-revision reports keep their original meaning.

Ordinary inventory uses stored verification evidence plus size/mtime/inode availability checks, not fresh full hashes. It cannot detect every modification retaining metadata. Run explicit verification for assurance. Registry JSON is operator-controlled local state, not a signed attestation or a network discovery service. No model inference or malware scan is performed by registration. Upstream hash matching establishes artifact identity, not model safety or output accuracy. A catalog change can require a renewed comparison against its current pin.
