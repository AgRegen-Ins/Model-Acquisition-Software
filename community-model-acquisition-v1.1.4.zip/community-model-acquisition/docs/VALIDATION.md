# Validation — v1.0.4.5

Source suite: **214 tests passed, zero failures/errors/skips** on Python 3.10.22, 3.11.17, 3.12.14, 3.13.16 and 3.14.8. Includes all 193 previous cases and 21 focused additions. All production modules except version metadata remain byte-identical to verified v1.0.4.4; the portable source guard is preserved.

Both live metadata dry-runs resolved exact pins and file sets. LARGE ARCHIVE and INSUFFICIENT SPACE warnings appeared correctly on this validation host; no real download was attempted.

| Selection | Selected bytes | Required free including reserve | Observed free bytes |
|---|---:|---:|---:|
| `gpt-oss-120b-gguf-mxfp4` | 63,387,561,321 | 70,800,059,277 | 27,448,958,976 |
| `gpt-oss-120b-local-inference` | 63,387,561,321 | 70,800,059,277 | 27,448,958,976 |

Full logs and selected-file metadata are in evidence/v1.0.4.5. Bounded header inspection is not full payload hashing. No real CPU/GPU inference occurred. Final ZIP SHA-256, CRC, exact membership, packaged hashes and fresh-extraction test results are in the external release report supplied alongside the ZIP.

# Validation — v1.0.4.4

Source suite: **193 tests, zero failures/errors/skips** on Python 3.10.22, 3.11.17, 3.12.14, 3.13.16 and 3.14.8. This includes all 166 prior cases plus 27 focused additions. Historical assertions only changed to reflect the expanding catalog count and permitted new profile names. Production code and portable source guard remain protected.

All eight live metadata-only dry-runs resolved exact pins and selected-file counts/bytes; no full weight download or inference. The source ether0 and preservation selection correctly printed LARGE ARCHIVE and INSUFFICIENT SPACE on this validation host. Dry-run exit 0 does not assert capacity.

| Selection | Selected bytes | Required with reserve | Observed free bytes |
|---|---:|---:|---:|
| `openscholar-8b-original` | 16,069,764,442 | 18,750,482,710 | 27,716,366,336 |
| `openscholar-8b-gguf-q4-k-m` | 4,920,748,740 | 6,486,565,438 | 27,716,366,336 |
| `ether0-24b-original` | 94,309,625,093 | 104,814,329,426 | 27,716,366,336 |
| `ether0-24b-gguf-q4-k-m` | 14,334,364,631 | 16,841,542,918 | 27,716,366,336 |
| `scientific-research-local` | 4,920,748,740 | 6,486,565,438 | 27,716,194,304 |
| `chemistry-research-local` | 14,334,364,631 | 16,841,542,918 | 27,716,198,400 |
| `scientific-research-preservation` | 129,634,502,906 | 143,671,695,020 | 27,716,190,208 |
| `scientific-research-inference` | 19,255,113,371 | 22,254,366,532 | 27,716,194,304 |

Source logs and live outputs are under `evidence/v1.0.4.4`. Final ZIP CRC, all file checksums, exact membership, freshly extracted cross-Python test results and ZIP SHA-256 are documented in the external release report supplied alongside the ZIP, avoiding a self-referential archive hash.

# v1.0.4.3 validation — 2026-10-11

Base: completed v1.0.4.2 ZIP, SHA-256 `2545625e369fa5c4ffc8fb773f5f02939f0640e7b879cc6e37feda38072eeb39`. Its CRC and all 257 checksummed members were verified before editing. No older release reconstruction.

## Implemented and tested

The suite contains **166 tests** (115 prior cases retained, 51 new tests). Source tree and fresh final ZIP extraction are exercised across CPython 3.10.22, 3.11.17, 3.12.14, 3.13.16 and 3.14.8. The accompanying external release report records exact results on final packaged bytes. Source logs are in `evidence/v1.0.4.3/source-tests/`.

New coverage includes pinned artifact sets/sizes, grouped vision projector, voice/config completeness, F5/Vocos dependencies, missing companions/cycles, all new profiles, policy overlays, exact legacy catalog/profile preservation, protected production source, local/remote registration, unknown upstream, SHA-vs-provenance distinction, altered files, duplicate IDs/project merges, unavailable drives, private voice exclusion, symlink/quarantine restrictions, non-execution, explicit copy confirmation, mount/reserve/large interlocks, verified-copy import, corruption/interruption staging, source permissions, historical manifests, JSON/CSV/text exports without hashes, and legacy glob compatibility. Existing download resume/verification/quarantine/inventory tests still execute. Tiny fixtures are the only payloads acquired/imported in tests. Import safety unit tests mock storage availability so they are portable on small test filesystems; dedicated tests force reserve failure and the large interlock.

All 38 existing model JSON values and old profile selections (except `all` growing) are exact. `model_acquire.py`, `modelkit/huggingface.py`, `modelkit/mounts.py`, `modelkit/storage.py`, requirements, settings and setup scripts remain byte-identical. `core.py` changed only inside `load_catalog` and `select`, the same two definitions excluded by the authenticated source-based v1.0.4.1 guard. They call the new explicit dependency module; all other core source remains exact. The v1.0.4.2 whole-core hash assertion now authenticates its original source fixture and compares source with only those existing permitted exclusions. It does not weaken protection for download, retry, resume, verification, quarantine, retention or module-level code, and never returns to raw AST dump hashing.

## Metadata-only validation

Eight individual-entry dry runs and six profile dry runs (14 total) use the unchanged actual Hub adapter and CLI. Each resolves full immutable commits, exact file names/hashes/sizes, deduplicated dependencies, free space and reserve with no model-root writes. Full details: `live-dry-runs.json` and `dry-run-*.txt`. All new profiles are below 50 GB; the existing >=50 GB warning/interlock remains covered by prior tests and the import-large fixture. No giant historical profile was downloaded.

## Full payload verification

Only tiny generated fixtures received full local hash verification, including corrupt-destination rejection and retained quarantine. No real full model weights were downloaded or verified. Research inspected small safetensors headers (without executing/deserializing checkpoint code) for Chatterbox/F5 precision. PyTorch/ONNX precision without independent evidence remains unknown. Runtime source/cards are inert evidence, not runtime execution.

## Not tested / operator action remaining

No actual GPU/CPU inference, audio-quality evaluation, training, Windows-native execution or cross-computer file transfer was run. Historical Ubuntu vision files were not accessible; registration/upstream matching is explicitly awaiting the operator on the machine holding them. Runtime dependencies and phonemizer resources are documented but not installed/preserved as a complete software mirror. Piper voice licenses require per-voice review; Qwen's research license conflicts with the converter's Apache tag; F5 weights are noncommercial. The registry never converts these uncertainties into upstream verification or a compatibility guarantee.

## Packaging

Final validation checks CRC, every packaged-file SHA-256, exact membership with no duplicate/missing/extra files, the 1.0.4.3 version, unchanged legacy values, a fresh path containing spaces, and the ZIP checksum sidecar. The external report carries the final ZIP hash and extraction results. `PACKAGE-CHECKSUMS.json` covers all packaged files except itself. No virtual environment, cache or real model weight is included.

---

# Historical v1.0.4.2 validation — 2026-10-04

Base: the validated v1.0.4.1 ZIP, SHA-256 `271e0ff01cf0d477be1085331a9e58d94062f253addf0e7c4e8218f87ea39035`; CRC and all 216 manifest hashes verified before extraction/editing.

The complete suite has **115 tests**: all 95 previous tests plus 20 focused Next expansion regressions. Source runs pass on CPython 3.10.21, 3.11.16, 3.12.14, 3.13.15 and 3.14.7, with zero failures, errors or skips. Logs are in `evidence/v1.0.4.2/source-tests/`. The same suite is repeated on the final ZIP extracted into a fresh path containing spaces; exact final results and package hash are in the accompanying release report.

The 36 previous model JSON values and their relative order are exact. Old profile descriptions and memberships are unchanged except the documented additive Next IDs. Operational files, settings, dependencies, setup scripts and source guard fixture are byte-identical to v1.0.4.1. The only production-file edit is `modelkit/__init__.py` version metadata. `modelkit/core.py` is entirely byte-identical, including load/selection. No schema change.

The v1.0.4.1 source-based protection is preserved exactly. Additional checks compare its helper and all five associated tests as source segments against an authenticated v1.0.4.1 fixture. Raw `ast.dump()` remains unused as a regression baseline. Catalog-count/membership assertions and the captured-metadata adapter were updated only for the two additions.

Three live metadata-only CLI dry runs (both Next IDs and `coding-workstation`) exit 0, resolve exact immutable revisions, enumerate the selected files and show large warnings, free space and 10% + 1 GiB reserve. Captured free space was 29,740,830,720 bytes, insufficient for every plan; this is correctly reported without writing payloads. Exact totals/CLI output are in `evidence/v1.0.4.2/live-dry-runs.json` and `dry-run-*.txt`. Existing `--yes` / `--allow-large` enforcement is exercised with metadata fixtures and mocked abundant free space so the large interlock itself is reached. Tiny real local files exercise interruption, shard reuse, verification and same-size corruption.

No weight-bearing model shard was downloaded. Research read only the zero-tensor GGUF first shard (5.94 MB) for embedded architecture/template metadata. Inference, multi-GPU execution and training were not performed. No native Windows run; existing mocked Windows/mount tests pass. The validation host required the optional `socksio` package for its SOCKS proxy during live network checks; toolkit dependencies are unchanged.

Package verification checks ZIP CRC, every SHA-256, exact manifest membership, version 1.0.4.2, old entry identity and protected code identity. The external SHA-256 sidecar authenticates the ZIP; `PACKAGE-CHECKSUMS.json` covers every other packaged file (not itself). No Python caches or virtual environments are packaged.

---

# Historical v1.0.4.1 maintenance validation — 2026-10-03

This release fixes a test-portability defect only. Source base: verified v1.0.4 ZIP, SHA-256 `eedbf4c1a446126b1eedbb025c242576966fba10643c6fa0a46739e9ea9df21d`; all 204 original file hashes and ZIP CRC verified before editing.

## Interpreter matrix

| CPython | Original v1.0.4 protected-source test | v1.0.4.1 full suite |
|---|---|---|
| 3.10.21 | Fails on AST hash | 95 passed |
| 3.11.16 | Fails on AST hash | 95 passed |
| 3.12.14 | Passes | 95 passed |
| 3.13.15 | Fails on AST hash | 95 passed |
| 3.14.7 | Fails on AST hash | 95 passed |

Every full run has zero failures, errors or skips. All 91 previous tests remain; four new tests validate the guard itself. Each environment installs the unchanged requirements. Evidence/logs are in `evidence/v1.0.4.1/`. The complete matrix is repeated against a fresh extraction of the final ZIP into a directory containing spaces. Native Windows execution is not performed; existing mocked portability coverage remains.

## Portable invariant

`tests/fixtures/core-v1.0.3.py.txt` contains the exact protected v1.0.3 module, verified against the SHA-256 in the existing `evidence/v1.0.4/v1.0.3-package-checksums.json`. The test reads UTF-8 source bytes and uses AST only to locate the source spans for exactly one `load_catalog` and one `select`. It replaces those spans with named placeholders and compares every remaining character. No AST serialization is hashed or compared. Decorators of the two permitted definitions are included in their spans; missing or duplicate exceptions are rejected.

This retains all protected function/class source checks and adds protection for module imports, statements, order and additional definitions. The four new tests prohibit calling `ast.dump`, mutate every protected definition and module-level code, exercise the two allowed exceptions, and reject missing/duplicate exceptions. The original AST-hash JSON is retained only as historical evidence.

## Scope and package checks

No operational Python file changed. `modelkit/__init__.py` changes only the version to 1.0.4.1. `catalog.json` and all existing model/profile/provenance/runtime/capability metadata are byte-identical to v1.0.4. CLI, core, adapter, mount safety, verification, resume, quarantine, retention, storage, setup and requirements are byte-identical.

Modified existing files: `tests/test_v104.py`, `modelkit/__init__.py`, `README.md`, `CHANGELOG.md`, `docs/VALIDATION.md`, `PACKAGE-CHECKSUMS.json`. Added: the authenticated source fixture and maintenance validation logs. No files removed. ZIP CRC, exact manifest membership and every package SHA-256 are checked after extraction; a ZIP checksum sidecar is supplied. The extracted package is tested on all five interpreters. No model metadata is refreshed and no model weights are downloaded for this maintenance release.

Run locally:

```bash
.venv/bin/python -m unittest discover -s tests -v
```

## Historical v1.0.4 validation

The report below records the original development environment. Its 91-test pass was real on that interpreter, but its AST-hash guard was not portable across Python versions. The v1.0.4.1 method and matrix above supersede that guard and its portability claim. Historical model-resolution evidence remains unchanged.

# v1.0.4 validation — 2026-10-03 UTC

91 tests pass: 0 failures, 0 errors, 0 skips. All 71 prior tests remain, plus 20 new tests. Historical count assertions now expect 36 variants. The previous whole-core hash assertion is replaced by a focused AST regression: only `load_catalog` and `select` may differ for the backwards-compatible explicit profile-membership extension; every other core function/class is unchanged.

```bash
python -m unittest discover -s tests -v
```

Output: `evidence/v1.0.4/regression-tests.txt`. The same full suite is run from a fresh extraction of the final ZIP into a path containing spaces.

## Verified release base

The supplied v1.0.3 ZIP matches SHA-256 `dbc40bb2eb90677c942eccba4473438ea54dc6cdc891607bfe80bd12b3f80420`. ZIP CRC and all 103 hashed files passed before edits. All 25 existing model-entry JSON values remain exactly identical; every old profile membership is identical except that `all` naturally grows. No old pins, selections or estimates are refreshed.

Eight protected files remain byte-identical: CLI, Hugging Face adapter, mount module, storage module, settings, dependencies, and Linux/Windows setup scripts. All download, retry, resume, verification, index-checking, quarantine and retention functions remain identical. Only profile loading/selection and version metadata change in application code.

## Live metadata-only checks

All 11 newly added variants and all five new profiles passed live `--dry-run` through the unchanged Hugging Face adapter. Every selected immutable revision resolved. Each run printed selected bytes, estimated new files, free space, reserve and the large-archive warning. The approximately 30 GB test disk correctly triggered the insufficient-space message; dry-run remained usable. No model root or payload was created. These successful dry runs prove planning/resolution, not enough space on the test host to acquire the archive.

Detailed logs: `evidence/v1.0.4/dry-run-*.txt` and `live-dry-runs.json`.

| Profile | Models | Approximate selected storage | With reserve |
|---|---:|---:|---:|
| agentic-core-originals | 5 | 3.841 TB | 4.226 TB |
| agentic-core-runnable | 5 | 1.767 TB | 1.945 TB |
| research-agent | 4 | 1.183 TB | 1.302 TB |
| coding-agent | 3 | 856.381 GB | 943.093 GB |
| preservation-source-weights | 20 | 5.335 TB | 5.870 TB |

Exact byte values and memberships are documented in the catalog and profile report. Profile totals overlap and must not be added as independent storage purchases. Each selected GGUF set includes all numbered shards and any required projector. Source indexes were checked against complete selected shard lists and inspected for integrated vision tensors where applicable. All selected weight/projector files expose LFS SHA-256 metadata; the toolkit verifies actual payload hashes during acquisition, not during metadata-only research.

## New regression coverage

Parsing, exact repositories/revisions, selected and whole-repository byte totals, every source file, index/shard completeness, all GGUF shards, missing projector refusal, integrated vision components, provenance, precision/license distinctions, capabilities, roles, priorities, runtime metadata, exact profiles, unchanged legacy entries, profile validation/deduplication, all 16 dry-run selections, `--yes` refusal without `--allow-large` for all 16 selections, terabyte totals/reserve, protected-code comparison, interrupted sharded acquisition and completed-shard reuse, and verified tiny GGUF/projector acquisition. No large weights are used; acquisition tests use tiny fixture bytes.

## Package verification

The final ZIP is CRC-tested and extracted. `PACKAGE-CHECKSUMS.json` lists SHA-256 for every packaged regular file except itself. Exact file-set equality and every hash are verified; no cache, virtual environment or model weight payload is packaged. The extracted version, new entries, old-entry identity and profile membership are checked. A ZIP `.sha256` sidecar is emitted and rechecked.

## Limits

No inference, full-weight transfer or training benchmark. Runtime and model-card claims can change after review; immutable artifact pins prevent silent changes to acquired bytes. GLM-5.3-Flash GGUF requires an experimental converter-compatible runtime. MiniMax GGUF is deferred because a complete compatible vision artifact set was not verified, even though newer llama.cpp supports the architecture. Source weights can themselves be natively quantized; specialized fine-tuning/conversion tooling is required. Very large contexts need additional runtime/KV/vision memory. No current Dell suitability is claimed. Windows behavior is covered by existing mocks rather than a native Windows run. Mount-presence checks do not authenticate drive identity; existing inventory limitations are unchanged. New taxonomy fields are available in catalog/manifests, not new inventory columns.
# v1.0.4.6 validation

See [RELEASE_REPORT_V1046.md](RELEASE_REPORT_V1046.md) for this two-model release. Historical results below apply to their named versions. Metadata/header inspection and synthetic software tests do not establish full-model integrity or HP inference performance.

# v1.0.4.7 validation

270 tests pass on Python 3.10–3.14; all 242 prior cases retained. [Release report](RELEASE_REPORT_V1047.md). Live metadata/header validation is not full-model hash verification or inference testing. Earlier sections remain historical.

