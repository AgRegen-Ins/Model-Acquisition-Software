# Operator guide

## Terminology

**Hugging Face** hosts model repositories: versioned collections of weights and the supporting files required to interpret them. A repository is more than one large weight file. A model card (`README.md`) explains intended use, capabilities, limitations, and often license information.

**Weights** are the learned numerical parameters. **Safetensors** stores tensors in a format designed to avoid executable pickle loading. **GGUF** packages model data and metadata for runtimes such as llama.cpp. **Quantization** uses lower-precision weight representations to reduce storage/memory, sometimes at an accuracy cost. Q4_K_M is a common roughly four-bit mixed quantization; it does not imply that every model can be converted or run by every runtime version.

**Original/upstream** means supplied by the model publisher. It is not a claim that the weights are full precision. An **official derived** GGUF is produced by that same publisher; a **third-party derived** copy is maintained by another organization. Both should identify their base model. Most shipped GGUF variants use official Qwen repositories; the Qwen3-Coder-30B-A3B GGUF added in v1.0.2 uses Unsloth and is explicitly third-party-derived. v1.0.3 also adds ggml-org gpt-oss and Unsloth GLM conversions, both third-party-derived. Community variants must label `source_kind` as `third-party-derived`, set their actual publisher, and retain the base repository relationship.

A **revision/commit hash** identifies one specific repository state. Branch names such as `main` move; the toolkit resolves/pins the commit before downloading. Separate commit directories preserve earlier acquisitions. Default runs use the bundled reviewed commit, while `--latest` is an explicit update request.

A **checksum** is a fingerprint of file bytes. Upstream LFS SHA-256 is checked when supplied. Ordinary Git files can be verified by their Git blob SHA-1 (which includes the `blob <size>\0` prefix); this is not the same as a raw-file SHA-1. Every completed file also gets a local SHA-256 for future preservation audits. When upstream hash evidence is absent, the manifest explicitly says `local-sha256`; correct size plus successful download and a local digest is weaker evidence, not an upstream-authenticated hash. Hashes detect byte differences; they do not prove that a model is safe, useful, or legally usable.

**Licenses** set terms for use and redistribution. A **gated repository** additionally requires access approval or accepting terms online. Downloading a model does not grant unlimited redistribution rights. License labels are preserved from the API along with any license files that exist. Some repositories provide a label but no standalone LICENSE; the toolkit records what exists rather than fabricating license text. Recheck the pinned card and applicable terms before public service or redistribution.

## Commands explained

| Command/component | Meaning |
|---|---|
| `sudo` | Run the following OS administration command with elevated privileges |
| `apt update` | Refresh Ubuntu's package list; does not install the toolkit |
| `apt install python3-venv python3-pip unzip` | Install environment, package installation, and ZIP extraction tools |
| `cd ~/Downloads` | Change into Downloads; `~` means your home directory |
| `unzip ...zip` | Extract the application folder from its archive |
| `bash setup-linux.sh` | Run the Bash setup script from the extracted folder |
| `python3 -m venv .venv` | Setup creates a private Python environment named `.venv` |
| `.venv/bin/python` | Use that environment's interpreter without activating it |
| `-m pip install -r requirements.txt` | Run pip as a Python module and install dependencies listed in the file |
| `model_acquire.py` | Run this toolkit's command-line application |
| `--root PATH` | Explicit destination containing the model categories and toolkit records |
| `--profile small-cpu` | Select a group of variants from the JSON catalog |
| `--model ID` | Select one specific variant; repeat this option to select several |
| `--dry-run` | Query upstream metadata and sizes without downloading payloads |
| `--offline-plan` | Display bundled estimates without network use or root writes |
| `--expected-mount PATH` | Require this storage mount before setup/acquisition writes |
| `--settings FILE` | Read mount guard rules from another JSON file |
| `--inventory` | Scan all local revision directories without writing payloads or reports |
| `--format csv` / `--format json` | Export inventory on stdout, suitable for redirection |
| `--sort size` | Sort variant groups, then revisions, by descending disk usage |
| `--superseded` | Show only superseded revision rows; keep full-collection summary |
| `--status` | Quick local inventory and timestamped reports |
| `--verify` | Read and hash every recorded file, then report integrity |
| `--repair` | Permit preserving damaged files in quarantine and fetching replacements |
| `--latest` | Resolve current tracking revision and retain old revision directories |
| `--check-updates` | Add network revision comparison to status/verify |
| `--yes --allow-large` | Explicit unattended approval, including a large archive |
| Quotes around a path | Keep a path containing spaces together as one argument |

Do not run the toolkit itself with `sudo`. If the root is unwritable, correct ownership of the intended model directory rather than running all downloads as root. Confirm the mount before long runs. Keep the server awake while downloading. Ctrl+C is handled cleanly; power loss can leave `.incomplete` upstream cache data or temporary JSON files, and the next run resumes/rechecks. Never unplug a mounted drive during writes.

## Failures and recovery

A missing or inaccessible repository can mean a typo, private repository, removed commit, gating, or missing credentials. Follow the displayed authentication guidance and check the repository URL from the catalog. A transfer is tried up to three times, with short backoff, before that variant is marked failed; the run continues with other planned variants. Planning failure stops before payload acquisition so you can fix the selection.

An existing bad final file is not silently replaced. Rerun that variant with `--repair`; its previous bytes are moved to the revision's quarantine directory before download. Unknown files stay untouched. Repair may need substantial extra space because old damaged data is retained. If an unverified final file was left after a crash, it is adopted only after a matching upstream hash; absent such evidence, use explicit repair.

A hash mismatch is not automatically evidence of malware or disk failure: it can also reflect incomplete bytes, a bad transfer, or metadata disagreement. The toolkit refuses to declare a match. It does not relax expected hashes after repeated failure.

Reports are timestamped `.txt` and `.json` files below `_toolkit/reports`. Event logs record starts, retry attempts, file verification, and final status without raw network exceptions. `verified` means requested files exist with recorded integrity evidence, including index-referenced shards. `partial` means incomplete files or changed size/time, while `failed` signals a failed operation or hash audit. A process killed without Ctrl+C may leave `downloading`; treat it as interrupted and rerun. `not downloaded` is derived from configured variants without a local manifest. The implementation goes directly from downloading to verified after checks; it does not expose an unverified success state called downloaded.

To move the collection, copy the complete category and `_toolkit` directories, then run `--verify --root NEW_PATH`. Copy-time timestamp changes can cause quick status to report partial even when bytes are identical; full verification refreshes that evidence. Export bundles and backup automation are future features.

## Storage review

Use `--inventory --sort size` before deciding which old revisions to retain. `--inventory --superseded --format csv` exports possible review candidates. Nothing is deleted, and the reported recoverable space is an estimate. Current snapshots are refreshed under `_toolkit/inventory/` after normal state-changing commands. Read `STORAGE.md` before interpreting overlapping totals.

## v1.0.4 catalog extension

See [PRESERVATION_ADDITIONS.md](PRESERVATION_ADDITIONS.md), [PROFILES.md](PROFILES.md), and [PROVENANCE.md](PROVENANCE.md). Optional schema-1 metadata is retained in manifests. The only behavior extension is explicit `profile_members` resolution/validation in `load_catalog` and `select`; no acquisition, mount, hashing, inventory, resume, quarantine or retention functions change. Historical model entries are unchanged.
