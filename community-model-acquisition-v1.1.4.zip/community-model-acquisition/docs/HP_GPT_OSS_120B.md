# HP Z8 G4 benchmark preparation — gpt-oss-120b

No real inference test was performed. The following are optional operator steps, not actions executed by this release. Existing HP software, model files and benchmark scripts remain unchanged.

User-reported target: Ubuntu 26.04.1 LTS, dual Intel Xeon Platinum 8260 (48 physical cores/96 threads), 352 GB ECC DDR4, RTX 3050 6 GB, NVIDIA driver 595.99.02, CUDA Toolkit 12.4, CUDA-enabled llama.cpp at `~/ai/llama.cpp/build-cuda/bin/llama-cli`. These versions were not independently inspected.

## Storage, RAM and GPU expectations

GGUF size: 63.387 GB / 59.034 GiB. Planning estimate, not measured minimum: allow roughly 70–85 GiB system RAM at 4096 tokens for model residency, KV cache and runtime/working buffers, plus OS/service headroom. Mmap and page-cache accounting, context, batching and offload can change reported RAM. Five billion active parameters do not mean the model requires only five billion parameters' worth of memory: all expert weights remain part of the model.

352 GB system RAM can hold this weight size, but CPU latency may be substantial. No tokens/second estimate is given. The 6 GB GPU cannot hold the entire model. Begin CPU-only, then test small partial offload if useful; buffer allocation, driver/display usage and batch size consume additional VRAM. Do not copy full-offload or large-batch examples for an 80 GB GPU onto this 6 GB card.

Acquire into the Dell's writable archive. `/mnt/community-library` on the HP is read-only and stays that way. Reading directly over Samba can add network/page-fault latency; an independently copied and verified NVMe deployment is suitable for a separate benchmark. Copy only the GGUF, never move or overwrite the original archive. Ensure over 64 GB free on the chosen NVMe location plus your operating reserve.

## Optional non-overwriting NVMe copy and verification

After the Dell acquisition has completed and passed its full hash audit, set the actual source path. This example matches the pinned catalog layout:

```bash
export GPT_SOURCE="/mnt/community-library/models/reasoning/gpt-oss-120b-gguf-mxfp4/238abdd290bb874b90a5da1b4549881b7d05c091/payload/gpt-oss-120b-MXFP4.gguf"
export GPT_DEST="$HOME/ai/models/gpt-oss-120b-mxfp4/238abdd290bb874b90a5da1b4549881b7d05c091"
python3 - <<'PYCODE'
import os,pathlib,hashlib,shutil
src=pathlib.Path(os.environ['GPT_SOURCE']);dest=pathlib.Path(os.environ['GPT_DEST'])
assert src.is_file() and src.stat().st_size==63387346208,'Wrong/missing source; stop'
dest.mkdir(parents=True,exist_ok=True)
assert shutil.disk_usage(dest).free>=70800059277,'Insufficient free space including reserve'
final=dest/src.name;partial=dest/(src.name+'.partial')
assert not final.exists(),'Destination already exists; do not overwrite'
# Exclusive creation refuses even an existing partial copy.
with src.open('rb') as inp,partial.open('xb') as out:
    shutil.copyfileobj(inp,out,8*1024*1024);out.flush();os.fsync(out.fileno())
h=hashlib.sha256()
with partial.open('rb') as inp:
    for block in iter(lambda:inp.read(8*1024*1024),b''):h.update(block)
assert partial.stat().st_size==63387346208
assert h.hexdigest()=='582bd40f6886200101f4c4ed9f25f3fe80cc14c86e9e2b37746cd8904a0c622d','Hash mismatch; retain partial, do not run'
os.link(partial,final)  # Atomic no-overwrite publication on local NVMe filesystem.
partial.unlink()       # Removes only the extra verified-copy link, never the original.
print('Local deployment copy verified:',final)
PYCODE
```

This optional manual copy is separate from archive acquisition/registration. It refuses existing files, preserves interrupted/failed partials and changes no source permissions. If interrupted, inspect the partial before deciding what to do; this small documentation example is not a new resumable transfer subsystem. Existing registry registration remains optional and unchanged.

## Inspect the existing runtime without changing it

```bash
"$HOME/ai/llama.cpp/build-cuda/bin/llama-cli" --version
"$HOME/ai/llama.cpp/build-cuda/bin/llama-cli" --help
nvidia-smi
lscpu
```

Check support for gpt-oss/MXFP4, conversation mode, `--jinja`, `--chat-template-kwargs`, thread and NUMA options. CUDA-enabled alone does not establish support for this architecture. If the installed build lacks support, stop the runtime experiment and plan a separate reviewed software update; acquisition is still independent.

## CPU baseline, then controlled variations

Use only the verified local GGUF path. No `-hf` or auto-download model presets:

```bash
export GPT_MODEL="$GPT_DEST/gpt-oss-120b-MXFP4.gguf"
"$HOME/ai/llama.cpp/build-cuda/bin/llama-cli"   -m "$GPT_MODEL" -c 4096 -ngl 0 -t 24 -tb 24   -cnv --jinja --chat-template-kwargs '{"reasoning_effort":"low"}'   --temp 1.0 --top-p 1.0 --top-k 0 --min-p 0.0 --repeat-penalty 1.0   -n 512 -p "Explain why checksum verification matters for a long-term digital archive."
```

This uses the embedded Harmony template; leave it intact. Check the installed build's help because flags evolve. A 512-token cap bounds this first experiment and may truncate reasoning before a final answer. Do not judge completed-answer quality from such a truncation.

Repeat the same prompt/context/sampling with `-t`/`-tb` 12, 24, 36 and 48 physical-thread settings. Consider 96 as a separate SMT comparison, not an assumed optimum. Record load time, prompt tokens/sec, generation tokens/sec, resident RAM, VRAM, output length and whether a final answer completed. Separate cold-load and warmed-cache runs.

The dual socket has NUMA effects. Compare default placement with `--numa distribute` only if supported; a one-node experiment using existing `numactl`/binding tools is optional. Record CPU binding and memory placement. Do not drop system caches, alter kernel settings or install tools automatically. Prior page placement/cache warmth can confound comparisons; record it rather than attributing every difference to thread count.

Then test small `-ngl` values (for example 1, then 2) within available VRAM and record actual placement/VRAM, rather than assuming faster inference. Expert placement controls such as CPU-MoE options vary by build and are separate experiments. Keep context 4096 initially; increasing toward 131072 increases work/memory and is not required for acceptance.

Model tool-calling capability is not authorization or implementation of tool execution. No browser, shell, Python agent or background service is started. These notes do not modify the HP's existing benchmarking scripts or install any runtime.
