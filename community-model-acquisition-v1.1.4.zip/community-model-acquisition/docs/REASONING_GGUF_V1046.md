# Two reasoning GGUF additions — v1.0.4.6

Review date: 2026-10-14. These are inference copies, not canonical training weights. This release adds exactly two entries and no new profiles or runtime software. User-intended research/writing evaluation is not a claim of scientific reliability, validated citations or measured performance.

## Exact acquisition specification

| ID | Repository | Immutable revision | Provenance | License |
|---|---|---|---|---|
| `qwen3-next-80b-a3b-thinking-gguf-q6-k` | `Qwen/Qwen3-Next-80B-A3B-Thinking-GGUF` | `de5795cd9a4f5538d1dd5c9823fdd73eacfae3fe` | official-derived | Apache-2.0 |
| `glm-4-5-air-gguf-q4-k-m` | `ggml-org/GLM-4.5-Air-GGUF` | `23a7a815a57a697e59f36fd8a897c632730a1fe9` | third-party-derived | MIT |

Required files (exact case; no wildcard quantization selection):

| Variant | File | Bytes | Upstream SHA-256 for weights |
|---|---|---:|---|
| Qwen | `Qwen3-Next-80B-A3B-Thinking-Q6_K.gguf` | 65,528,462,592 | `c7e3f469746d7695b6464f1bbaaded9811a299954edfd6f3e3294af75a7f3f9f` |
| Qwen | `README.md` | 13,664 | Git blob hash in selected manifest |
| GLM | `GLM-4.5-Air-Q4_K_M-00001-of-00002.gguf` | 9,308,768 | `f1c043df1877b7364fd8df129d010164010ead36333438e649ef8b412e57fd51` |
| GLM | `GLM-4.5-Air-Q4_K_M-00002-of-00002.gguf` | 63,624,271,808 | `524c7dc97b8206bdbc584fde130c909a4e927f1c7b2f973255fc9af9b9fc3b4b` |
| GLM | `README.md` | 393 | Git blob hash in selected manifest |
| GLM | `.src_sha` | 49 | Git blob hash in selected manifest |
| GLM | `convert.log` | 409,674 | Git blob hash in selected manifest |

Totals including selected documentation: Qwen **65,528,476,256 bytes**; GLM **63,633,990,692 bytes**; combined **129,162,466,948 bytes**. The exact machine-readable path/size/hash manifests are `evidence/v1.0.4.6/selected-files.json`. Upstream hashes here are published identities, not a claim that full weights were downloaded locally. Normal acquisition computes SHA-256 and verifies each selected file before marking the revision verified.

## Qwen interpretation

Official Qwen-derived GGUF, specifically **Thinking**, not Instruct. Header: `qwen3next`, 807 tensors, 79,674,391,296 stored parameters; publisher approximation 80B total/3B active. Hybrid Gated DeltaNet/Gated Attention MoE, 512 routed experts/10 selected plus shared expert. Native context 262,144. Q6_K tensors coexist with FP16/FP32; not uniformly six-bit and not source precision. Apache license text is preserved in the source evidence.

Requires a llama.cpp build supporting **qwen3next**, not just qwen3. Use embedded tokenizer/chat template; Thinking template opens `<think>` itself. Header defaults: temperature 0.6, top-p 0.95, top-k 20. No external tokenizer, projector or other weight shard is required. Original source documentation was inspected at `e502dd4100cc68c0de57643fd4317ec93a128670`; the official GGUF does not supply an exact conversion-source commit, so this is a documentation snapshot, not asserted conversion lineage.

## GLM interpretation

Z.ai's GLM-4.5-Air converted by the separate ggml-org project; not original Z.ai weights. `.src_sha` explicitly records `zai-org/GLM-4.5-Air` at `a24ceef6ce4f3536971efe9b778bdaa1bab18daa`. MIT license text is retained in source evidence. Header: `glm4moe`, 780 tensors/106,852,251,264 stored parameters; publisher approximation 106B total/12B active. 128 routed experts/8 selected, shared expert, native context 131,072. Quantization label Q4_K_M includes Q4_K, Q6_K, Q8_0, Q4_0 and FP32 tensors.

**Do not discard the small first shard.** It holds metadata, tokenizer and chat template with zero tensors; the second holds all tensors. Split indices 0/1, split count 2 and combined tensor count 780 agree. Start inference from `00001-of-00002.gguf` with both files alongside one another. Embedded template supports thinking/non-thinking and tool messages. Requires glm4moe, split loading and template handling. Optional `mtp-*` draft files are intentionally excluded; no mmproj is required for ordinary text inference.

## HP deployment notes (not deployment performed)

Target supplied by operator: dual Xeon Platinum 8260, 48 physical cores/96 threads, 352 GB RAM, RTX 3050 6 GB, CUDA llama.cpp. Neither model fits entirely in 6 GB VRAM. Weight storage is about 61.03 GiB Qwen / 59.26 GiB GLM; RAM also needs KV or recurrent-state, compute buffers, mappings and OS headroom. Exact working memory is context/build/offload-dependent and **not measured**. Active parameters are compute information, not the amount of RAM needed to keep weights available.

Start later runtime acceptance at 4096 context and a controlled output budget. Long reasoning can exhaust that budget. CPU-resident experts/selective CUDA offload may be useful, not guaranteed faster. Independently test 12/24/48 threads before assuming 96 helps; compare NUMA placement and local versus remote socket memory. Current upstream exposes CPU-MoE and NUMA controls, but check the installed executable's help rather than assuming flag compatibility. No benchmark or tuning is performed by this toolkit.

llama.cpp source inspected at `a0e6dc7384edb8f5d927155e1d26c10b4a310e6d`: `src/models/qwen3next.cpp`, `src/models/glm4-moe.cpp`, GGML tensor enums and argument handling. This establishes current source support, **not a minimum release version or verification of the HP binary**. Use template-aware conversation/Jinja support available in that build; do not replace templates with generic chat formatting. Tool calls need separate orchestration. Installed software, CUDA, drivers, benchmarks and read-only network shares are unchanged.

## Evidence and limits

- [Official Qwen GGUF](https://huggingface.co/Qwen/Qwen3-Next-80B-A3B-Thinking-GGUF/tree/de5795cd9a4f5538d1dd5c9823fdd73eacfae3fe), [Qwen source card](https://huggingface.co/Qwen/Qwen3-Next-80B-A3B-Thinking/blob/e502dd4100cc68c0de57643fd4317ec93a128670/README.md).
- [ggml-org GLM GGUF](https://huggingface.co/ggml-org/GLM-4.5-Air-GGUF/tree/23a7a815a57a697e59f36fd8a897c632730a1fe9), [Z.ai source card](https://huggingface.co/zai-org/GLM-4.5-Air/blob/a24ceef6ce4f3536971efe9b778bdaa1bab18daa/README.md).
- [Inspected llama.cpp commit](https://github.com/ggml-org/llama.cpp/tree/a0e6dc7384edb8f5d927155e1d26c10b4a310e6d).

Repository metadata, cards/configs/licenses, recorded source commit, bounded GGUF headers and runtime source were inspected as inert data. Header inspection read 12 MiB from each large file plus GLM's complete 9,308,768-byte metadata shard (its SHA-256 matches). Header parsing checked magic/version, architecture, tensor directory, split counts and embedded template/tokenizer presence. It did not execute tokenization, inference or repository code. Full tensor payload hashes remain operator acceptance work. Acquisition needs no new dependencies or GGUF parser: exact pinned filenames and published hashes protect these known artifacts through existing verification.

No requested variant is blocked. Network/repository availability can change; exact pins prevent silent substitutions. Scientific accuracy, application quality and HP performance remain untested. GGUF is inference-oriented; canonical training weights and existing acquisitions are not altered. Preservation-policy additions are `inference-only`, reflecting this release's requested scope, not a deletion instruction.
