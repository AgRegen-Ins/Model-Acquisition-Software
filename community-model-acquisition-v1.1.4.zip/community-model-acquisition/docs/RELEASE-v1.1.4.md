# Community Model Acquisition Toolkit v1.1.4 — release report

## Result

Implemented from the supplied, checksum-verified v1.1.3 package. Baseline ZIP SHA-256: `15473ae44da0126c94083c0e6da75a63d89a31bc9b571232b4ea9efa8c220d9e`. Baseline CRC and 832 internal hashes passed; all 455 inherited tests passed before changes. No earlier release was substituted.

The catalog now has 154 records: 68 unchanged historical entries plus 27 image-model variants and 59 shared/support components. Fifteen of 16 named targets are represented. WAI remains explicitly blocked pending authentic publisher checkpoint/version/license verification. Ten new opt-in profiles; historical memberships unchanged except intentional all growth. New selections total 618,892,028,719 bytes (~618.89GB) if all 86 are selected once. This is not a recommended automatic download.

## Exact changes

Production Python changes are limited to the version string and appended metadata columns/enrichment in modelkit/archive_report.py. Download/adapters, core planning, resume, integrity, quarantine, UUID checks, mount disconnection handling, storage accounting, registry, dependencies and --verify-selected remain byte-identical to v1.1.3. No dependency package was added.

Catalog/profile/policy additions use the existing schema and required-dependency resolver. Optional metadata component_layout describes separate deployment assembly without changing archive paths. The existing accountability view already checks recorded dependency status. All new required components are flat selections so missing companions remain visible. XLSX is still manual, with the original three sheets and original column prefix preserved.

Historical test methods remain present. Narrow total-count/profile-policy assertions were updated for additive entries; exact approved-source guard fixtures preserve comparisons to earlier baselines. Tests do not hash interpreter-dependent AST dumps. New qualification covers 48 cases, including inert sharded transfers, missing shards, interrupted resumption, selected auditing, quarantine, shared dependency reuse, collision-free companion deployment maps, license/gating/provenance and no implicit payload hashing.

Modified pre-existing files:

- `CHANGELOG.md`
- `README.md`
- `catalog.json`
- `modelkit/__init__.py`
- `modelkit/archive_report.py`
- `preservation-policy.json`
- `tests/education_guard.py`
- `tests/test_education_v113.py`
- `tests/test_path_maintenance.py`
- `tests/test_toolkit.py`
- `tests/test_v103.py`
- `tests/test_v104.py`
- `tests/test_v1042.py`
- `tests/test_v1043.py`
- `tests/test_v1044.py`
- `tests/test_v1045.py`
- `tests/test_v1046.py`
- `tests/test_v1047.py`
- `tests/test_v1048.py`

New source: tests/image_guard.py and tests/test_images_v114.py; new exact-delta fixture, pinned metadata/manifests and documentation under evidence/v1.1.4 and docs. Complete membership and every file digest are in PACKAGE-CHECKSUMS.json. The diff covers source, tests, catalog/policy and documentation, excluding regenerated checksums, bulk research evidence, binary examples and the diff itself.

## Executed regression tests

| Environment | Executed | Passed | Failures | Errors | Skips |
|---|---:|---:|---:|---:|---:|
| Source Python 3.10.22 | 503 | 503 | 0 | 0 | 0 |
| Source Python 3.11.17 | 503 | 503 | 0 | 0 | 0 |
| Source Python 3.12.14 | 503 | 503 | 0 | 0 | 0 |
| Source Python 3.13.17 | 503 | 503 | 0 | 0 | 0 |
| Source Python 3.14.9 | 503 | 503 | 0 | 0 | 0 |
| Fresh ZIP Python 3.10.22 | 503 | 503 | 0 | 0 | 0 |
| Fresh ZIP Python 3.11.17 | 503 | 503 | 0 | 0 | 0 |
| Fresh ZIP Python 3.12.14 | 503 | 503 | 0 | 0 | 0 |
| Fresh ZIP Python 3.13.17 | 503 | 503 | 0 | 0 | 0 |
| Fresh ZIP Python 3.14.9 | 503 | 503 | 0 | 0 | 0 |

Full logs and machine-readable counts accompany the package. No tests are silently removed or represented as hardware qualification.

## Live and bounded qualification

- 96 actual unchanged-CLI live dry-runs: 86 added records individually and 10 profiles. All returned 0. No archive root was created. File selection and byte totals resolved from pinned Hub metadata. Free/reserve figures in logs describe the development host, not Dell. Large plans correctly reported insufficient development capacity without writes.
- 31 unique repository/revision identities independently re-resolved; exact selected filenames, sizes, LFS SHA-256/git blob digests matched. Selected manifests enumerate every file. Gates remain legitimate operator access requirements.
- 15 selected shard indexes investigated: 7 publicly readable indexes parsed and all referenced shards selected; 8 returned 401 because publisher access approval was not present. Those indexes and all their publicly enumerated shards are selected; existing acquisition index verification remains mandatory after authorized download. No gate bypass attempted.
- Bounded Pony and Illustrious Safetensors JSON headers confirmed FP16 bundled UNet/conditioning/VAE structures. No tensor deserialization. Selected diffusion GGUF header probe results, where available, are in gguf-header-checks.json; no full weight hashing claim.
- A real 308-byte scheduler JSON component was fetched into disposable storage and passed upstream Git blob verification, local SHA-256 recording, selected audit and a zero-new-bytes rerun. This used a test-only bounded transport; no production archive or hardware mount was accessed.
- Manual XLSX example was generated by the delivered model_report.py against an empty disposable archive: 154 catalog rows, three sheets, no formulas, valid XML/CRC. It is not Edmund-Library inventory.

## Qualification boundaries and known limitations

No complete image-model weights were downloaded, executed or benchmarked. No software/custom nodes were installed into the HP, no production archive was modified, and no physical USB-DAS removal/ext4 acceptance test was performed. Existing simulated storage-safety tests passed; physical host acceptance is separate. Installation qualification uses disposable Linux environments, not a claim of testing the actual Ubuntu GPU host.

WAI is unresolved. SD1.5 is an explicitly attributed unaffiliated mirror. Gated payload access requires publisher approval. Licenses are not uniform: FLUX dev noncommercial, NoobAI noncommercial plus sharing/content terms, SD3.5 Community revenue threshold, and Meta Llama obligations for HiDream. Public converters do not erase upstream restrictions. Native pipelines require separately assembled deployment copies; component mapping does not install a runtime. NVFP4 is a future supported-hardware/runtime target, not a promise of acceleration on RTX3050/3060.

Two Z-Image encoder shards overlap with older Qwen3-4B weights, but the complete pinned component differs. A generic base-model substitution would be incorrect; it is not performed. Small per-publisher metadata may repeat. Aggregate size excludes caches/runtime environments and uses existing 10% plus 1 GiB reserve.

## Operator acceptance

Follow docs/IMAGE-QUICKSTART-v1.1.4.md. Verify ZIP sidecar and internal hashes, install alongside v1.1.3, review unchanged approved storage settings, run read-only storage validation and offline/live plans, then choose one operator-authorized acquisition. Use --verify-selected with explicit IDs and manually regenerate XLSX. No migration or repeat of the historical2.62TB checksum comparison is required.

## Deliverables

Full runnable ZIP and SHA-256 sidecar; source diff; this report; exact component CSV/JSON and model/profile tables; license/runtime review; Ubuntu quickstart; sample XLSX; executable tests and validation logs. ZIP CRC, exact membership and packaged hashes are checked by the release builder; external package-validation.json records the final ZIP digest.
