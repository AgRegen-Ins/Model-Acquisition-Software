# Scientific research profiles — v1.0.4.4

These four profiles are opt-in. Existing profiles are unchanged; the generic `all` selector grows normally. Neither source policy nor catalog loading triggers downloads. Sizes below include selected model and metadata files, but no runtime installation.

| Profile | Variants | Selected GB (decimal) | Required free GB with reserve |
|---|---:|---:|---:|
| `scientific-research-local` | 1 | 4.920749 | 6.486565 |
| `chemistry-research-local` | 1 | 14.334365 | 16.841543 |
| `scientific-research-preservation` | 4 | 129.634503 | 143.671695 |
| `scientific-research-inference` | 2 | 19.255113 | 22.254367 |

## scientific-research-local

- `openscholar-8b-gguf-q4-k-m`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile scientific-research-local --dry-run
```

## chemistry-research-local

- `ether0-24b-gguf-q4-k-m`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile chemistry-research-local --dry-run
```

## scientific-research-preservation

- `openscholar-8b-original`
- `openscholar-8b-gguf-q4-k-m`
- `ether0-24b-original`
- `ether0-24b-gguf-q4-k-m`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile scientific-research-preservation --dry-run
```

## scientific-research-inference

- `openscholar-8b-gguf-q4-k-m`
- `ether0-24b-gguf-q4-k-m`

```bash
.venv/bin/python model_acquire.py --root /srv/community-library/models --profile scientific-research-inference --dry-run
```

The source ether0 entry and scientific preservation profile exceed the 50 GB threshold. Noninteractive acquisition requires both `--yes` and `--allow-large`; `--yes` alone cannot bypass it. Interactive mode retains the existing explicit LARGE confirmation. Reserve/free-space and mount checks remain authoritative.
